"""Reproduce the exploratory RQ1 Participant-LOO repeated-measures ANOVAs.

Run: python run_anova.py
Uses frozen report predictions; no training or primary-analysis changes.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import time

import numpy as np
import pandas as pd
import scipy
from scipy import stats

ROOT = Path(__file__).resolve().parent
METHODS = ['SIMPLE_RNN', 'NO_ER', 'ERROR_REGRESSION']
LABELS = {'SIMPLE_RNN': 'RNN', 'NO_ER': 'PV-RNN without ER',
          'ERROR_REGRESSION': 'PV-RNN'}
TARGETS = ['EngageScore', 'Arousal', 'Valence']
SEEDS = {11, 23, 37, 51, 71}
SESSION_KEYS = ['protocol', 'Pid', 'Class_id', 'EnvironmentDateKey', 'target', 'mode']


def holm(pvalues):
    """Holm step-down adjusted P values, returned in original order."""
    p = np.asarray(pvalues, dtype=float)
    if not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
        raise ValueError('Finite P values between zero and one required')
    order = np.argsort(p, kind='stable')
    adjusted = np.minimum(1., np.maximum.accumulate(p[order]*(len(p)-np.arange(len(p)))))
    result = np.empty_like(p); result[order] = adjusted
    return result

def rm_anova_gg(values):
    """Balanced one-factor repeated-measures ANOVA with GG correction.

    Rows are participants, columns are methods. GG adjusts degrees of freedom,
    leaving F unchanged. All three outcomes are corrected; no pretest selection.
    """
    a = np.asarray(values, dtype=float)
    if a.ndim != 2 or a.shape[0] < 3 or a.shape[1] < 3 or not np.isfinite(a).all():
        raise ValueError('Complete participant-by-method matrix required')
    n, k = a.shape; grand = a.mean()
    ss_method = float(n*np.square(a.mean(axis=0)-grand).sum())
    residual = a-a.mean(axis=1, keepdims=True)-a.mean(axis=0)+grand
    ss_error = float(np.square(residual).sum())
    ss_subject = float(k*np.square(a.mean(axis=1)-grand).sum())
    df1, df2 = k-1, (n-1)*(k-1)
    if ss_error <= 0:
        raise ValueError('Zero residual variance; ordinary F inference undefined')
    fvalue = (ss_method/df1)/(ss_error/df2)
    contrast = np.eye(k)-np.ones((k, k))/k
    projected = contrast@np.cov(a, rowvar=False, ddof=1)@contrast
    epsilon = float(np.trace(projected)**2/((k-1)*np.trace(projected@projected)))
    epsilon = float(np.clip(epsilon, 1./(k-1), 1.))
    return dict(n_participants=n, n_methods=k, F=fvalue, df1=df1, df2=df2,
                p_uncorrected=float(stats.f.sf(fvalue, df1, df2)), epsilon_GG=epsilon,
                df1_GG=df1*epsilon, df2_GG=df2*epsilon,
                p_GG=float(stats.f.sf(fvalue, df1*epsilon, df2*epsilon)),
                partial_eta_squared=ss_method/(ss_method+ss_error),
                ss_method=ss_method, ss_error=ss_error, ss_subject=ss_subject)


def read_predictions(path):
    """Validate the complete frozen Participant-LOO subset used in the paper."""
    data = pd.read_csv(path, dtype={'Pid': str, 'Class_id': str})
    required = set(SESSION_KEYS + ['seed', 'observed', 'prediction'])
    if not required.issubset(data.columns):
        raise ValueError('Missing columns: ' + str(sorted(required - set(data.columns))))
    if data[list(required)].isna().any().any():
        raise ValueError('Missing input values')
    if (len(data) != 720 or set(data.protocol) != {'PARTICIPANT_LOO'}
            or set(data['mode']) != set(METHODS)
            or set(data.target) != set(TARGETS) or set(data.seed) != SEEDS):
        raise ValueError('Expected the 720-row, three-model, five-seed Participant-LOO subset')
    if not np.isfinite(data[['observed', 'prediction']].to_numpy()).all():
        raise ValueError('Nonfinite observations or predictions')
    if data.duplicated(SESSION_KEYS + ['seed']).any():
        raise ValueError('Duplicate session/model/seed row')
    if not data.groupby(SESSION_KEYS).seed.nunique().eq(5).all():
        raise ValueError('Incomplete seed coverage')
    session_id = ['Pid', 'Class_id', 'EnvironmentDateKey']
    if len(data[session_id].drop_duplicates()) != 16:
        raise ValueError('Expected 16 sessions')
    if not data.groupby(session_id + ['target'])['observed'].nunique().eq(1).all():
        raise ValueError('Observed labels differ across models or seeds')
    for _, group in data.groupby(['seed', 'mode', 'target']):
        if len(group) != 16 or group.Pid.nunique() != 11:
            raise ValueError('Expected 16 sessions from 11 participants in each comparison')
    return data


def aggregate_predictions(data):
    """Median predictions first; square errors second; average within person last."""
    session = data.groupby(SESSION_KEYS, sort=False).agg(
        observed=('observed', 'first'), prediction=('prediction', 'median'),
        n_seeds=('seed', 'nunique')).reset_index()
    session['squared_error'] = np.square(session.prediction - session.observed)
    person = session.groupby(['protocol', 'Pid', 'target', 'mode'], as_index=False).agg(
        MSE=('squared_error', 'mean'), n_sessions=('Class_id', 'size'))
    for table in (session, person):
        table['method_label'] = table['mode'].map(LABELS)
    return session, person


def analyze(person):
    rows = []
    for target in TARGETS:
        wide = person[person.target.eq(target)].pivot(
            index='Pid', columns='mode', values='MSE')[METHODS]
        if wide.shape != (11, 3) or wide.isna().any().any():
            raise ValueError('Expected a complete 11-participant by 3-model MSE matrix')
        result = rm_anova_gg(wide.to_numpy())
        result.update(
            target=target, dependent_variable='participant_mean_squared_error',
            protocol='PARTICIPANT_LOO',
            weighting='equal participants; within-person sessions averaged',
            inference_scope='exploratory; shared training/date dependencies not eliminated')
        rows.append(result)
    omnibus = pd.DataFrame(rows)
    omnibus['p_GG_Holm_3_outcomes'] = holm(omnibus.p_GG)
    return omnibus


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--predictions', type=Path,
                        default=ROOT / 'data/participant_loo_predictions.csv')
    parser.add_argument('--output', type=Path, default=ROOT / 'results_rerun')
    args = parser.parse_args()
    start = time.perf_counter()
    data = read_predictions(args.predictions)
    session, person = aggregate_predictions(data)
    omnibus = analyze(person)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    for name, table in [
        ('session_seed_median_predictions', session),
        ('participant_error_table', person),
        ('rm_anova_GG', omnibus),
    ]:
        table.to_csv(output / (name + '.csv'), index=False)
    audit = {
        'scope': 'Exploratory supplementary RQ1 omnibus ANOVA only',
        'protocol': 'PARTICIPANT_LOO',
        'aggregation': 'session seed median, squared error, within-participant mean',
        'correction': 'GG for all tests; Holm across the three GG-corrected p values',
        'significance_threshold': 0.05,
        'n_input_rows': len(data), 'n_participants': int(data.Pid.nunique()),
        'n_sessions': 16, 'n_seeds': 5, 'n_methods': 3, 'n_outcomes': 3,
        'methods': LABELS,
        'model_refitting': False,
        'input_sha256': sha256(args.predictions),
        'source_sha256': sha256(Path(__file__)),
        'software': {'python': platform.python_version(), 'numpy': np.__version__,
                     'pandas': pd.__version__, 'scipy': scipy.__version__},
        'elapsed_seconds': time.perf_counter() - start,
        'limitations': ['Participant weighting differs from primary session-weighted RMSE',
                        'Overlapping CV training sets and shared contexts are not fully modeled',
                        'Small sample; GG does not address all distributional assumptions'],
    }
    (output / 'analysis_audit.json').write_text(
        json.dumps(audit, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(omnibus[['target', 'F', 'epsilon_GG', 'df1_GG', 'df2_GG',
                   'p_GG', 'p_GG_Holm_3_outcomes']].to_string(index=False))
    print('Saved:', output)


if __name__ == '__main__':
    main()
