# RQ1 补充 ANOVA

Participant-LOO 下的三模型重复测量比较。每个 session 先取五 seed 预测中位数，
再计算平方误差，并在同一参与者内平均。每个报告指标得到 11 人 × 3 模型 MSE 表。
三个检验分别使用 GG 校正，再对三个 p 值做 Holm 校正。

```bash
python -m pip install -r requirements.txt
python run_anova.py
```

根目录 `python reproduce.py anova` 调用相同脚本。`data/` 包含必要预测，
`results/` 为核验结果；独立运行默认写入 `results_rerun/`。

三个校正后 p 值为 0.383、0.776、0.354。该分析是主体 RMSE 的探索性补充，
参与者等权，不完整处理交叉验证训练集重叠或共享课堂导致的依赖。
