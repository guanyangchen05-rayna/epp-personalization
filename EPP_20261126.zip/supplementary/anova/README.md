# RQ1 supplementary ANOVA

One-way repeated-measures ANOVAs compare RNN, PV-RNN without ER, and PV-RNN under
Participant-LOO for engagement, arousal, and valence. Five-seed median predictions
are computed within each session before squared errors are averaged within each
participant. Participants are equally weighted. All tests use Greenhouse–Geisser
correction followed by Holm correction across the three outcomes.

```bash
python -m pip install -r requirements.txt
python run_anova.py
```

The root command `python reproduce.py anova` invokes the same script. The default
standalone output directory is `results_rerun/`; `--output` selects another path.

| Outcome | F | GG p | GG + Holm p |
| --- | ---: | ---: | ---: |
| Engagement | 1.929 | 0.191 | 0.383 |
| Arousal | 0.218 | 0.776 | 0.776 |
| Valence | 2.507 | 0.118 | 0.354 |

`data/participant_loo_predictions.csv` contains 720 frozen rows: 16 sessions ×
three outcomes × three models × five seeds. `results/` contains reference outputs;
`validation/` records numerical checks. Stored modes `SIMPLE_RNN`, `NO_ER`, and
`ERROR_REGRESSION` map to the model names above, respectively.

This exploratory analysis supplements session-weighted pooled RMSE. It does not
fully account for dependence arising from overlapping training sets or shared
classroom context. The numerical ANOVA and Holm functions are unchanged from the
previously validated implementation. No model is trained by this script.
