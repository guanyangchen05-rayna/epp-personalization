"""Question 1: matched common/personal-precision physiology and report tests.

Reports supervise the shared readout only on OTHER participants. Personal rho
is calibrated solely from physiology/environment. Scoring always uses the same
frozen network, test mask, ER budget and fresh A for both precision conditions.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from .data import TARGETS

REPORT_COLUMNS=['cohort','Pid','Class_id','seed','validation_scope','target',
                'observed','common_prediction','individual_prediction','unit_prediction',
                'training_mean_prediction','common_squared_error','individual_squared_error',
                'common_log_precision','individual_log_precision']


def align_reports(cohort,reports):
    """Use ONLY the canonical complete-report subset, never partial meta labels."""
    values=np.full((len(cohort.meta),3),np.nan,dtype=float)
    if reports is None:return values
    if reports.meta.duplicated(['Pid','Class_id']).any():raise ValueError('Duplicate report keys')
    lookup={tuple(k):i for i,k in enumerate(cohort.meta[['Pid','Class_id']].astype(str).to_numpy())}
    for j,row in enumerate(reports.meta.itertuples(index=False)):
        key=(str(row.Pid),str(row.Class_id))
        if key not in lookup:raise ValueError('A complete-report session is absent from the physiology cohort')
        i=lookup[key]
        if not np.array_equal(cohort.arrays[i],reports.arrays[j]) or not np.array_equal(cohort.times[i],reports.times[j]):
            raise ValueError('Complete-report and physiology sequences/timestamps differ')
        y=np.array([getattr(row,t) for t in TARGETS],dtype=float)
        if not np.isfinite(y).all() or not 1<=y[0]<=5 or not ((y[1:]>=1)&(y[1:]<=4)).all():
            raise ValueError('Complete report has invalid outcome values')
        values[i]=y
    return values


def training_reports(report_values,training_indices):
    """Fit outcome scaling on outer-training complete reports exclusively."""
    y=report_values[training_indices]
    selected=np.isfinite(y).all(axis=1)
    if selected.sum()<2:raise ValueError('Full-chain validation requires at least two OTHER training reports')
    scaler=StandardScaler().fit(y[selected])
    standardized=np.full(y.shape,np.nan,dtype=np.float32)
    standardized[selected]=scaler.transform(y[selected]).astype(np.float32)
    return scaler,standardized,selected


def report_record(ident,observed,common,individual,unit,scaler,common_rho,individual_rho):
    """Read report estimates from the SAME inference that scores hidden P."""
    predictions=[scaler.inverse_transform(np.asarray(r['prediction_standardized'],dtype=float)[None,:])[0]
                 for r in (common,individual,unit)]
    baseline=scaler.mean_
    rows=[]
    for j,target in enumerate(TARGETS):
        y=float(observed[j]);c,i,u=(float(v[j]) for v in predictions)
        if not np.isfinite([y,c,i,u]).all():raise FloatingPointError('Nonfinite full-chain report prediction')
        rows.append(dict(**{k:ident[k] for k in ['cohort','Pid','Class_id','seed','validation_scope']},
            target=target,observed=y,common_prediction=c,individual_prediction=i,unit_prediction=u,
            training_mean_prediction=float(baseline[j]),common_squared_error=(y-c)**2,
            individual_squared_error=(y-i)**2,common_log_precision=common_rho,
            individual_log_precision=individual_rho))
    return rows


def _summary(group,root,cfg,rng):
    """Median of seed-specific errors; paired participant bootstrap, no refit."""
    keys=['Pid','Class_id'];seeds=sorted(group.seed.unique())
    if group.duplicated(keys+['seed']).any():raise ValueError('Duplicate paired chain score')
    common=group.pivot(index=keys,columns='seed',values='common_loss').reindex(columns=seeds)
    personal=group.pivot(index=keys,columns='seed',values='individual_loss').reindex(index=common.index,columns=seeds)
    a,b=common.to_numpy(float),personal.to_numpy(float)
    if not np.isfinite(a).all() or not np.isfinite(b).all() or (a<0).any() or (b<0).any():
        raise ValueError('Paired chain losses must be complete, finite and nonnegative across seeds')
    pids=common.index.get_level_values('Pid').to_numpy();people=np.unique(pids)
    def errors(indices):
        ca=a[indices].mean(axis=0);ib=b[indices].mean(axis=0)
        return (np.sqrt(ca),np.sqrt(ib)) if root else (ca,ib)
    ca,ib=errors(np.arange(len(a)));c=float(np.median(ca));i=float(np.median(ib))
    gain=100*(c-i)/c if c>1e-12 else np.nan
    draws=[]
    # One person cannot identify between-person sampling uncertainty.
    if len(people)>=2:
        for _ in range(cfg.bootstrap_reps):
            chosen=rng.choice(people,size=len(people),replace=True)
            index=np.concatenate([np.flatnonzero(pids==p) for p in chosen])
            x,y=errors(index);x,y=float(np.median(x)),float(np.median(y))
            if x>1e-12:draws.append(100*(x-y)/x)
    low,high=np.quantile(draws,[.025,.975]) if draws else (np.nan,np.nan)
    rows=[]
    for pid in people:
        x,y=errors(np.flatnonzero(pids==pid));x,y=float(np.median(x)),float(np.median(y))
        rows.append(dict(Pid=pid,n_sessions=int((pids==pid).sum()),common_error=x,
                         individual_error=y,absolute_gain=x-y,gain_pct=100*(x-y)/x if x>1e-12 else np.nan))
    return dict(n_sessions=len(a),n_participants=len(people),n_seeds=len(seeds),
                common_error_median=c,individual_error_median=i,absolute_gain=c-i,gain_pct=gain,
                common_seed_q25=float(np.quantile(ca,.25)),common_seed_q75=float(np.quantile(ca,.75)),
                individual_seed_q25=float(np.quantile(ib,.25)),individual_seed_q75=float(np.quantile(ib,.75)),
                gain_positive_seed_fraction=float(np.mean(ib<ca)),
                gain_ci95_low=float(low),gain_ci95_high=float(high),
                bootstrap_reps=cfg.bootstrap_reps,bootstrap_unit='participant',model_refitting=False,
                aggregation='session_equal_error_within_seed_then_seed_median'),rows


def summarize_chain(physiology,reports,cfg,outdir):
    """Four direct endpoints, with cross-session/within-session scopes separate."""
    outdir=Path(outdir)
    p=physiology.loc[physiology.status.eq('completed')].copy()
    required=['cohort','Pid','Class_id','seed','validation_scope']
    losses=p[required].copy();losses['target']='Physiology';losses['metric']='MSE'
    losses['common_loss']=p.population_MSE;losses['individual_loss']=p.individual_MSE
    if not reports.empty:
        y=reports[required+['target']].copy();y['metric']='RMSE'
        y['common_loss']=reports.common_squared_error;y['individual_loss']=reports.individual_squared_error
        losses=pd.concat([losses,y],ignore_index=True)
    all_summary=[];persons=[];rng=np.random.default_rng(94021)
    for (cohort,scope,target,metric),g in losses.groupby(['cohort','validation_scope','target','metric'],sort=True):
        ident=dict(cohort=cohort,validation_scope=scope,target=target,metric=metric,
                   primary_cross_session=scope=='held_out_session_prefix_to_masked_suffix')
        summary,person=_summary(g,metric=='RMSE',cfg,rng)
        all_summary.append(dict(**ident,**summary))
        persons.extend(dict(**ident,**r) for r in person)
    # The joint endpoint table uses exactly the same report-linked sessions for
    # physiology and behavior, avoiding a 100-vs-15-session narrative mismatch.
    matched=[]
    if not reports.empty:
        linked=reports[required].drop_duplicates()
        j=p.merge(linked,on=required,how='inner',validate='one_to_one')
        expected=len(linked)
        if len(j)!=expected:raise ValueError('Report scores lack matching held-out physiology scores')
        for (cohort,scope),g in j.groupby(['cohort','validation_scope'],sort=True):
            x=g[required].copy();x['common_loss']=g.population_MSE;x['individual_loss']=g.individual_MSE
            s,_=_summary(x,False,cfg,rng)
            matched.append(dict(cohort=cohort,validation_scope=scope,target='Physiology',metric='MSE',
                 primary_cross_session=scope=='held_out_session_prefix_to_masked_suffix',**s))
        matched.extend(r for r in all_summary if r['target']!='Physiology')
    pd.DataFrame(all_summary).to_csv(outdir/'chain_validation_summary.csv',index=False)
    pd.DataFrame(matched,columns=pd.DataFrame(all_summary).columns).to_csv(outdir/'chain_joint_summary.csv',index=False)
    pd.DataFrame(persons).to_csv(outdir/'chain_participant_gains.csv',index=False)
    return pd.DataFrame(all_summary)
