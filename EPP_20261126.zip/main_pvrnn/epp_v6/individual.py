"""One explicitly defined observation-precision parameter, not personal networks.

rho_i = log physiological observation precision, relative to unit environment
variance after population scaling. It changes the reconstruction/KL balance in
inference and the normalized Gaussian residual model. It is not neural precision,
attention, personality, or a stable cognitive trait without independent evidence.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from .model import train,pad,infer,seed_all,window_ids_tensor
from .data import scaled_training,transform,sha256
from .chain import align_reports,training_reports,report_record,summarize_chain,REPORT_COLUMNS


def profile_parameter(model,arrays,cfg,times=None):
    """Grid-profile rho; all candidates get fresh A=0 and identical ER budget.

    The objective includes -log precision; no post-hoc outcome criterion enters.
    F is beta-weighted and profiled over variational A: these scores must NOT be
    turned into likelihood-ratio confidence intervals or model evidences.
    """
    x,l=pad(arrays); rows=[]
    ids=window_ids_tensor(times,l,x.shape[1])
    for rho in cfg.log_precision_grid:
        _,_,d=infer(model,x,l,cfg,log_precision=float(rho),window_ids=ids)
        rows.append(dict(log_precision=float(rho),precision_multiplier=float(np.exp(rho)),
                         physiological_residual_SD=float(np.exp(-rho/2)),**d))
    # Deterministic tie rule, decided without reports: closest to population rho=0.
    best=min(rows,key=lambda r:(r['objective'],abs(r['log_precision']),r['log_precision']))
    out=dict(best)
    out.update(boundary_selected=best['log_precision'] in (cfg.log_precision_grid[0],cfg.log_precision_grid[-1]),
               profile_objective_span=max(r['objective'] for r in rows)-min(r['objective'] for r in rows),
               near_tie_count=sum(abs(r['objective']-best['objective'])<=1e-4 for r in rows),
               confidence_interval_available=False)
    return out,rows


def _checkpoint(path,model,scaler,cfg,train_keys,history,times=None,report_scaler=None,report_keys=None):
    torch.save(dict(state_dict=model.state_dict(),scaler_mean=scaler.mean_.tolist(),scaler_scale=scaler.scale_.tolist(),
                    config=vars(cfg),training_keys=train_keys,
                    training_minute_ids=None if times is None else [t.tolist() for t in times],
                    report_training_keys=[] if report_keys is None else report_keys,
                    target_scaler_mean=None if report_scaler is None else report_scaler.mean_.tolist(),
                    target_scaler_scale=None if report_scaler is None else report_scaler.scale_.tolist(),
                    gap_policy='prior_transitions_without_observation_loss'),path)
    pd.DataFrame(history).to_csv(path.with_suffix('.history.csv'),index=False)


def describe(cohort,cfg,outdir,report_cohort=None):
    """User-requested full-cohort pretrain -> frozen-backbone personal fits.

    This is explicitly descriptive/in-sample for the backbone. Independently
    cross-fitted validation below is required before stronger interpretations.
    If complete reports are supplied, shared training matches the full-chain
    generative/readout objective; personal rho calibration still uses no reports.
    """
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    allrows=[]; profiles=[]
    indices=np.arange(len(cohort.meta)); scaler,arrays=scaled_training(cohort,indices)
    if report_cohort is not None:
        report_scaler,y,mask=training_reports(align_reports(cohort,report_cohort),indices)
        report_keys=cohort.meta.iloc[indices[mask]][['Pid','Class_id']].to_dict('records')
    else:report_scaler,y,mask,report_keys=None,None,None,[]
    for seed in cfg.seeds:
        print(f'[individual {cohort.name}] full shared model seed={seed}',flush=True)
        model,history=train(arrays,cfg,seed,y=y,times=cohort.times,label_mask=mask)
        _checkpoint(outdir/f'full_shared_seed_{seed}.pt',model,scaler,cfg,
                    cohort.meta[['Pid','Class_id']].to_dict('records'),history,cohort.times,report_scaler,report_keys)
        pooled,_=profile_parameter(model,arrays,cfg,times=cohort.times)
        for pid,g in cohort.meta.groupby('Pid',sort=True):
            idx=g.index.to_numpy(); a=[arrays[i] for i in idx]
            best,curve=profile_parameter(model,a,cfg,times=[cohort.times[i] for i in idx])
            print(f'  participant={pid}: rho={best["log_precision"]:.2f}, '
                  f'sessions={len(idx)}, boundary={best["boundary_selected"]}',flush=True)
            info=dict(cohort=cohort.name,Pid=pid,seed=seed,n_sessions=len(idx),
                      n_dates=g.EnvironmentDateKey.nunique(),n_bins=sum(map(len,a)),
                      interpretation='record_based_physiological_residual_precision',
                      backbone_scope='full_cohort_in_sample',behavior_labels_used=False,
                      backbone_uses_reports=report_cohort is not None,
                      stable_person_trait_established=False,
                      pooled_log_precision=pooled['log_precision'],
                      delta_log_precision_vs_pooled=best['log_precision']-pooled['log_precision'])
            allrows.append(dict(**info,**best))
            profiles.extend(dict(**info,**r) for r in curve)
        pd.DataFrame(allrows).to_csv(outdir/'participant_parameters.csv',index=False)
        pd.DataFrame(profiles).to_csv(outdir/'parameter_profiles.csv',index=False)
    d=pd.DataFrame(allrows)
    summary=d.groupby('Pid',sort=True).agg(n_sessions=('n_sessions','first'),n_dates=('n_dates','first'),
                  rho_median=('log_precision','median'),rho_q25=('log_precision',lambda s:s.quantile(.25)),
                  rho_q75=('log_precision',lambda s:s.quantile(.75)),
                  boundary_fraction=('boundary_selected','mean')).reset_index()
    summary['precision_multiplier_median']=np.exp(summary.rho_median)
    summary['range_type']='seed_IQR_not_sampling_CI'
    summary.to_csv(outdir/'participant_parameter_summary.csv',index=False)
    return d


def score_hidden_physiology(model,array,cfg,rho,calibration_prefix=None,times=None,return_prediction=False):
    """All E observed. P wholly hidden (new session) or prefix only observed.

    No held-out P value enters the inference loss. Report labels are absent.
    Scores are plug-in Gaussian residual NLL, not full posterior predictive NLL.
    Future E is available at retained minutes: this is offline masked-channel
    evaluation, not online forecasting. The calibration and score masks use
    retained-bin indices; original minute intervals govern all state transitions.
    """
    x,l=pad([array]); observed=torch.zeros_like(x,dtype=torch.bool); observed[:,:,:2]=True
    ids=window_ids_tensor(None if times is None else [times],l,x.shape[1])
    score=torch.zeros_like(x,dtype=torch.bool)
    if calibration_prefix is None:
        score[:,:,2:]=True
    else:
        cutoff=int(calibration_prefix)
        observed[:,:cutoff,2:]=True
        score[:,cutoff+cfg.temporal_gap_bins:,2:]=True
    if not score.any(): raise ValueError('No independently scored physiological values')
    out,_,d=infer(model,x,l,cfg,observed=observed,log_precision=rho,window_ids=ids)
    error=(out['reconstruction'][score]-x[score]).square().mean().item()
    nll=.5*(np.exp(rho)*error-rho+np.log(2*np.pi))
    result=dict(MSE_physiology=float(error),plug_in_Gaussian_NLL=float(nll),n_scored_values=int(score.sum()),
                inference_objective=d['objective'])
    if return_prediction:result['prediction_standardized']=out['prediction'][0].detach().numpy().tolist()
    return result


def validate(cohort,cfg,outdir,report_cohort=None):
    """Independent backbone: exclude ALL target-person sessions and fit scaler
    only on the remaining people. Repeated-session and single-session tests are
    exported separately by scope. No full-cohort descriptive checkpoint is reused.
    """
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    rows=[]; curves=[]; audits=[];report_rows=[];report_coverage=[]
    report_values=align_reports(cohort,report_cohort)
    chain_enabled=report_cohort is not None
    for pid,g in cohort.meta.groupby('Pid',sort=True):
        tests=g.index.to_numpy(); others=np.flatnonzero(~cohort.meta.Pid.eq(pid))
        if not len(others): raise ValueError('Cannot train cross-fitted backbone without other participants')
        scaler,train_arrays=scaled_training(cohort,others)
        participant_arrays=transform(scaler,cohort.subset(tests))
        train_times=[cohort.times[i] for i in others]
        if chain_enabled:
            report_scaler,ytrain,label_mask=training_reports(report_values,others)
            report_keys=cohort.meta.iloc[others[label_mask]][['Pid','Class_id']].to_dict('records')
        else:report_scaler,ytrain,label_mask,report_keys=None,None,None,[]
        for seed in cfg.seeds:
            print(f'[validation {cohort.name}] hold out participant={pid}, seed={seed}',flush=True)
            model,history=train(train_arrays,cfg,seed,y=ytrain,times=train_times,label_mask=label_mask)
            # A fitted common parameter is needed: unit variance alone is not
            # a convincing comparator for participant-specific parameterization.
            pooled,pooled_curve=profile_parameter(model,train_arrays,cfg,times=train_times)
            pd.DataFrame(pooled_curve).to_csv(outdir/f'pooled_profile_pid_{pid}_seed_{seed}.csv',index=False)
            ckpt=outdir/f'backbone_pid_{pid}_seed_{seed}.pt'
            _checkpoint(ckpt,model,scaler,cfg,cohort.meta.iloc[others][['Pid','Class_id']].to_dict('records'),
                        history,train_times,report_scaler,report_keys)
            for j,idx in enumerate(tests):
                row=cohort.meta.iloc[idx]
                has_report=bool(np.isfinite(report_values[idx]).all())
                prefix=int(np.floor(len(participant_arrays[j])*cfg.calibration_fraction))
                ntest=len(participant_arrays[j])-prefix-cfg.temporal_gap_bins
                if min(prefix,ntest)<cfg.min_segment_bins:
                    rows.append(dict(Pid=pid,Class_id=row.Class_id,seed=seed,cohort=cohort.name,
                                     status='skipped_short_session',validation_scope='unavailable'))
                    if chain_enabled:
                        report_coverage.append(dict(cohort=cohort.name,Pid=pid,Class_id=row.Class_id,seed=seed,
                            has_complete_report=has_report,status='skipped_short_session',validation_scope='unavailable'))
                    continue
                if len(tests)>=2:
                    cal=[a for k,a in enumerate(participant_arrays) if k!=j]
                    cal_times=[cohort.times[k] for k in tests if k!=idx]
                    cal_ids=[str(cohort.meta.iloc[k].Class_id) for k in tests if k!=idx]
                    scope='held_out_session_prefix_to_masked_suffix'
                else:
                    cal=[participant_arrays[j][:prefix]]; cal_ids=[str(row.Class_id)]
                    cal_times=[cohort.times[idx][:prefix]]
                    scope='within_session_prefix_to_masked_suffix_not_trait_reliability'
                best,curve=profile_parameter(model,cal,cfg,times=cal_times)
                ident=dict(cohort=cohort.name,Pid=pid,Class_id=row.Class_id,seed=seed,
                           validation_scope=scope,calibration_prefix_bins=prefix,
                           calibration_sessions=json.dumps(cal_ids),n_participant_sessions=len(tests))
                curves.extend(dict(**ident,**p) for p in curve)
                unit=score_hidden_physiology(model,participant_arrays[j],cfg,0.,prefix,
                    times=cohort.times[idx],return_prediction=chain_enabled and has_report)
                pop=score_hidden_physiology(model,participant_arrays[j],cfg,pooled['log_precision'],prefix,
                    times=cohort.times[idx],return_prediction=chain_enabled and has_report)
                personal=score_hidden_physiology(model,participant_arrays[j],cfg,best['log_precision'],prefix,
                    times=cohort.times[idx],return_prediction=chain_enabled and has_report)
                if chain_enabled:
                    report_coverage.append(dict(cohort=cohort.name,Pid=pid,Class_id=row.Class_id,seed=seed,
                        has_complete_report=has_report,status='scored' if has_report else 'no_complete_report',
                        validation_scope=scope))
                    if has_report:
                        report_rows.extend(report_record(ident,report_values[idx],pop,personal,unit,
                            report_scaler,pooled['log_precision'],best['log_precision']))
                rows.append(dict(**ident,status='completed',log_precision=best['log_precision'],
                           precision_multiplier=best['precision_multiplier'],boundary_selected=best['boundary_selected'],
                           pooled_log_precision=pooled['log_precision'],
                           population_MSE=pop['MSE_physiology'],individual_MSE=personal['MSE_physiology'],
                           MSE_gain=pop['MSE_physiology']-personal['MSE_physiology'],
                           population_NLL=pop['plug_in_Gaussian_NLL'],individual_NLL=personal['plug_in_Gaussian_NLL'],
                           NLL_gain=pop['plug_in_Gaussian_NLL']-personal['plug_in_Gaussian_NLL'],
                           unit_precision_MSE=unit['MSE_physiology'],unit_precision_NLL=unit['plug_in_Gaussian_NLL'],
                           n_scored_values=personal['n_scored_values'],behavior_labels_used=chain_enabled,
                           parameter_fit_uses_report_labels=False,
                           scored_physiology_used_for_A=False,
                           backbone_uses_other_participant_reports=chain_enabled,
                           n_training_reports=len(report_keys),
                           behavior_scored=chain_enabled and has_report))
                audits.append(dict(**ident,backbone_training_participants=sorted(cohort.meta.iloc[others].Pid.unique().tolist()),
                              backbone_excludes_target_person=pid not in set(cohort.meta.iloc[others].Pid),
                              scaler_training_session_count=len(others),checkpoint_sha256=sha256(ckpt),
                              test_physiology_mask='all' if prefix is None else f'bins >= {prefix}',
                              score_starts_at_bin_index=0 if prefix is None else prefix+cfg.temporal_gap_bins,
                              whole_test_environment_observed=True,
                              report_training_keys=report_keys,
                              report_training_excludes_target_person=all(str(k['Pid'])!=str(pid) for k in report_keys),
                              target_report_used_for_training=False,
                              target_report_used_for_rho_selection=False,
                              target_report_used_for_A=False,
                              report_and_physiology_share_inference=True,
                              report_scaler_fit='other_participants_complete_reports_only' if chain_enabled else 'not_used',
                              fixed_backbone_for_common_and_individual=True,
                              elapsed_gaps_explicitly_modeled=True,
                              gap_policy='prior_transitions_without_observation_loss',
                              test_minute_ids=cohort.times[idx].tolist(),
                              last_calibration_minute_id=int(cohort.times[idx][prefix-1]),
                              first_scored_minute_id=int(cohort.times[idx][prefix+cfg.temporal_gap_bins])))
            pd.DataFrame(rows).to_csv(outdir/'parameter_validation.csv',index=False)
            pd.DataFrame(curves).to_csv(outdir/'validation_parameter_profiles.csv',index=False)
            (outdir/'validation_audit.json').write_text(json.dumps(audits,indent=2)+'\n')
            if chain_enabled:
                pd.DataFrame(report_rows,columns=REPORT_COLUMNS).to_csv(outdir/'chain_predictions.csv',index=False)
                pd.DataFrame(report_coverage).to_csv(outdir/'chain_report_coverage.csv',index=False)
    if chain_enabled:
        reports=pd.DataFrame(report_rows,columns=REPORT_COLUMNS)
        expected=sum(r['status']=='scored' for r in report_coverage)*3
        if len(reports)!=expected or reports.duplicated(['Pid','Class_id','seed','target']).any():
            raise AssertionError('Missing/duplicate full-chain report scores')
        # The complete subset was validated independently, not manufactured
        # from partial labels or copied into the physiology-only sessions.
        if len(report_coverage)!=len(cohort.meta)*len(cfg.seeds):raise AssertionError('Missing chain coverage records')
        summarize_chain(pd.DataFrame(rows),reports,cfg,outdir)
    return pd.DataFrame(rows)


def recovery(cohort,cfg,outdir,report_cohort=None):
    """Model-conditional simulation with KNOWN residual noise precision.

    Generate prior trajectories and add Gaussian E/P observation noise. Then
    run the SAME profiled estimator. Recovery can fail; all estimates, boundary
    hits, true-vs-estimated results are exported. Passing this check alone does
    not establish validity for humans, devices or environmental confounds.
    """
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    _,arrays=scaled_training(cohort,np.arange(len(cohort.meta)))
    if report_cohort is not None:
        _,y,mask=training_reports(align_reports(cohort,report_cohort),np.arange(len(cohort.meta)))
    else:y,mask=None,None
    rows=[]
    for seed in cfg.seeds:
        model,_=train(arrays,cfg,seed,y=y,times=cohort.times,label_mask=mask); rng=np.random.default_rng(seed+101)
        grid=np.asarray(cfg.log_precision_grid,dtype=float)
        # Two off-grid truths nearest zero exercise discretization without
        # doubling the already expensive full recovery experiment.
        midpoints=(grid[:-1]+grid[1:])/2
        selected_midpoints=midpoints[np.argsort(np.abs(midpoints),kind='stable')[:2]]
        truths=np.unique(np.r_[grid,selected_midpoints]) if cfg.recovery_include_midpoints else grid
        for rho in truths:
            for rep in range(cfg.recovery_reps):
                length=len(arrays[rep%len(arrays)])
                times=cohort.times[rep%len(arrays)]
                l=torch.tensor([length]); A=torch.zeros(1,length,model.adaptive_width)
                ids=window_ids_tensor([times],l,length)
                with torch.no_grad(): mean=model(l,A,sample=True,prior_only=True,window_ids=ids)['reconstruction'][0].numpy()
                noise=rng.normal(size=mean.shape); noise[:,2:]*=np.exp(-rho/2)
                synthetic=(mean+noise).astype(np.float32)
                best,_=profile_parameter(model,[synthetic],cfg,times=[times])
                rows.append(dict(seed=seed,replicate=rep,true_log_precision=rho,
                                  estimated_log_precision=best['log_precision'],
                                  boundary_selected=best['boundary_selected'],length=length,
                                  true_at_grid_boundary=rho in (cfg.log_precision_grid[0],cfg.log_precision_grid[-1]),
                                  true_on_estimation_grid=bool(np.any(grid==rho)),
                                  nearest_grid_absolute_error=float(np.min(np.abs(grid-rho))),
                                  data_type='synthetic_model_conditional_not_human_result'))
        pd.DataFrame(rows).to_csv(outdir/'parameter_recovery.csv',index=False)
    d=pd.DataFrame(rows)
    error=d.estimated_log_precision-d.true_log_precision
    correlation=d[['true_log_precision','estimated_log_precision']].corr().iloc[0,1]
    info=dict(n_simulations=len(d),RMSE_log_precision=float(np.sqrt(np.mean(error**2))),
              bias=float(error.mean()),correlation=None if not np.isfinite(correlation) else float(correlation),
              boundary_fraction=float(d.boundary_selected.mean()),
              interior_truth_boundary_fraction=float(d.loc[~d.true_at_grid_boundary,'boundary_selected'].mean()),
              automatic_validity_claim=False,simulation_scope='assumed_model_and_Gaussian_residuals_only')
    info['shared_training_uses_available_reports']=report_cohort is not None
    info['includes_off_grid_truths']=cfg.recovery_include_midpoints
    for label,mask in [('on_grid',d.true_on_estimation_grid),('off_grid',~d.true_on_estimation_grid)]:
        e=error[mask]
        info[label+'_n_simulations']=int(mask.sum())
        info[label+'_RMSE_log_precision']=float(np.sqrt(np.mean(e**2))) if len(e) else None
    info['mean_absolute_error_exceeding_grid_resolution']=float(np.maximum(error.abs()-d.nearest_grid_absolute_error,0).mean())
    (outdir/'recovery_summary.json').write_text(json.dumps(info,indent=2,allow_nan=False)+'\n')
    return d
