"""EPP pilot v0.6: explicit observation-error routes and parameter exploration."""
__version__ = "0.6.2-chain"
