"""Stdlib-only startup: recover exported tables, then validate before full fitting."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from collections import deque

REQUIRED_TABLES = (
    'envphys_session_analysis.csv', 'envphys_temporal_1s.csv',
    'behavior_session_analysis.csv', 'behavior_temporal_1s.csv',
    'processing_summary.json',
)
POINTER = 'epp_active_tables.json'


def complete(path):
    path = Path(path)
    return path.is_dir() and all((path/name).is_file() for name in REQUIRED_TABLES)


def fingerprint(path):
    # Compare actual CSVs, allowing only export timestamps in provenance to differ.
    hashes = []
    for name in REQUIRED_TABLES[:4]:
        h = hashlib.sha256()
        with (path/name).open('rb') as f:
            for block in iter(lambda: f.read(1024*1024), b''):
                h.update(block)
        hashes.append(h.hexdigest())
    return tuple(hashes)


def choose_tables(project, explicit=None, hints=()):
    root = Path(project).resolve()
    if explicit is not None:
        path = Path(explicit).expanduser().resolve()
        missing = [n for n in REQUIRED_TABLES if not (path/n).is_file()]
        if missing:
            raise FileNotFoundError('Explicit --table-dir is incomplete: '+str(path)+
                                    '\nMissing: '+', '.join(missing))
        return path
    for hint in hints:
        path = Path(hint).expanduser().resolve()
        if complete(path):
            return path
    pointer = root/POINTER
    if pointer.is_file():
        try:
            path = Path(json.loads(pointer.read_text(encoding='utf-8'))['table_dir'])
            if path.is_absolute() and complete(path):
                return path.resolve()
        except (OSError, ValueError, KeyError, TypeError):
            pass
    # Deliberately bounded: project root + data root and its first two levels.
    # Never scan backup folders, external drives, home folders or model results.
    data = root/'data'
    bases = [root, data]
    if data.is_dir():
        first = sorted(p for p in data.iterdir() if p.is_dir() and not p.is_symlink())
        bases.extend(first)
        for parent in first:
            bases.extend(sorted(p for p in parent.iterdir()
                                if p.is_dir() and not p.is_symlink()))
    candidates = sorted({p.resolve() for p in bases if complete(p)})
    if not candidates:
        partial = []
        for path in bases:
            found = [n for n in REQUIRED_TABLES if (path/n).is_file()]
            if found:
                missing = [n for n in REQUIRED_TABLES if n not in found]
                partial.append(str(path)+'\n  Missing: '+', '.join(missing))
        raise FileNotFoundError(
            'No complete exported EPP table directory found under '+str(data)+
            '\nThis does not establish that export failed. If stored elsewhere, '
            'supply --table-dir with its actual path.\n'+ '\n'.join(partial))
    if len(candidates) > 1:
        first_hashes = fingerprint(candidates[0])
        if any(fingerprint(p) != first_hashes for p in candidates[1:]):
            raise RuntimeError('Several different exported datasets were found; no training started. '
                               'Choose one using --table-dir:\n' + '\n'.join(map(str, candidates)))
    # Identical CSV exports are interchangeable; most recent export is deterministic.
    return max(candidates, key=lambda p: ((p/'envphys_temporal_1s.csv').stat().st_mtime_ns, str(p)))


def remember_tables(project, tables):
    path = Path(project)/POINTER
    raw = (json.dumps({'table_dir': str(Path(tables).resolve()),
                       'validated_by': 'run_epp_v6.py --stage check'}, indent=2)+'\n').encode('utf-8')
    fd, temporary = tempfile.mkstemp(prefix=path.name+'.', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(raw)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def run_visible(command, project):
    print('\nRunning: '+subprocess.list2cmdline(list(map(str, command))), flush=True)
    tail = deque(maxlen=40)
    # Stream into the notebook, including stderr, so a child error is never hidden
    # behind CalledProcessError. UTF-8 is set only for the subprocess, not globally.
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    with subprocess.Popen(command, cwd=project, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                          errors='replace', env=env, bufsize=1) as process:
        for line in process.stdout:
            print(line, end='', flush=True)
            tail.append(line)
        code = process.wait()
    if code:
        raise RuntimeError(f'Command failed (exit {code}); training will not advance.\n'+''.join(tail))


def preflight_and_run(project, tables=None, hints=(), run_full=False):
    root = Path(project).resolve()
    run_visible([sys.executable, '-u', 'verify_release.py'], root)
    selected = choose_tables(root, explicit=tables, hints=hints)
    print('\nTABLES='+str(selected), flush=True)
    command = [sys.executable, '-u', 'run_epp_v6.py', '--table-dir', str(selected),
               '--config', 'config/epp_v6.json']
    # Full cohort/provenance/alignment and parent-source checks, with no fitting.
    run_visible(command+['--stage', 'check'], root)
    remember_tables(root, selected)
    print('PREFLIGHT PASSED: table path, provenance and both cohorts validated.', flush=True)
    if run_full:
        run_visible(command+['--stage', 'all'], root)
    return selected
