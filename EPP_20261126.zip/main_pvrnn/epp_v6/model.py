"""Five arrows: state->E, E-error->state, state->P, P-error->state, state->Y.

E/P are observation groups, not literal neural hierarchy levels. Forward state
generation deliberately has no observation-value argument. Only the masked
loss lets observations influence A. No participant ID/profile is accepted.
"""
from __future__ import annotations
from contextlib import contextmanager
from dataclasses import dataclass, asdict
import random
import numpy as np
import torch
from torch import nn


@dataclass
class Settings:
    fast_d: int = 8
    slow_d: int = 4
    fast_z: int = 3
    slow_z: int = 2
    tau_fast: float = 2.
    tau_slow: float = 5.
    dropout: float = .25
    epochs: int = 150
    lr: float = .001
    adaptive_lr: float = .005
    weight_decay: float = .01
    kl_fast: float = .001
    kl_slow: float = .001
    er_steps: int = 150
    er_lr: float = .05
    seeds: tuple = (11, 23, 37, 51, 71)
    bootstrap_reps: int = 2000
    log_precision_grid: tuple = (-2., -1.5, -1., -.5, 0., .5, 1., 1.5, 2.)
    calibration_fraction: float = .5
    temporal_gap_bins: int = 2
    min_segment_bins: int = 3
    recovery_reps: int = 5
    recovery_include_midpoints: bool = True
    run_simple_rnn: bool = True

    def validate(self):
        for name in ('fast_d','slow_d','fast_z','slow_z','epochs','er_steps',
                     'bootstrap_reps','min_segment_bins','recovery_reps'):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f'{name} must be a positive integer')
        for name in ('lr','adaptive_lr','er_lr','tau_fast','tau_slow'):
            if not np.isfinite(getattr(self,name)) or getattr(self,name) <= 0:
                raise ValueError(f'Invalid {name}')
        if min(self.tau_fast,self.tau_slow) < 1 or not 0 <= self.dropout < 1:
            raise ValueError('Time constants >=1 and dropout in [0,1) required')
        if not np.isfinite([self.kl_fast,self.kl_slow,self.weight_decay,self.dropout]).all() or self.kl_fast <= 0 or self.kl_slow <= 0 or self.weight_decay < 0:
            raise ValueError('Positive KL weights and nonnegative weight decay required')
        g = tuple(float(v) for v in self.log_precision_grid)
        if len(g)<3 or tuple(sorted(set(g))) != g or not np.isfinite(g).all() or 0. not in g:
            raise ValueError('Precision grid must be finite, increasing, unique, include 0, length>=3')
        if max(abs(v) for v in g)>5:
            raise ValueError('Use a bounded log-precision range within [-5,5]')
        if not 0 < self.calibration_fraction < 1 or type(self.temporal_gap_bins) is not int or self.temporal_gap_bins < 0:
            raise ValueError('Invalid calibration split')
        if not self.seeds or len(set(self.seeds)) != len(self.seeds):
            raise ValueError('At least one unique seed required')
        if any(type(v) is not int or v<0 or v>=2**32 for v in self.seeds):
            raise ValueError('Integer seeds in [0,2**32) required')
        if type(self.recovery_include_midpoints) is not bool:raise ValueError('recovery_include_midpoints must be boolean')
        return self


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)


def pad(arrays):
    if not arrays or any(a.ndim!=2 or a.shape[1]!=5 or len(a)==0 or
                         not np.isfinite(a).all() for a in arrays):
        raise ValueError('Expected nonempty finite [time,5] sequences')
    lengths=torch.tensor([len(a) for a in arrays],dtype=torch.long)
    x=torch.zeros(len(arrays),int(lengths.max()),5)
    for i,a in enumerate(arrays): x[i,:len(a)]=torch.as_tensor(a,dtype=torch.float32)
    return x,lengths


def valid_mask(lengths, time):
    return torch.arange(time,device=lengths.device)[None,:] < lengths[:,None]


def window_ids_tensor(times,lengths,time):
    """Original class-relative minute IDs; padding is never a time point.

    The first retained minute remains the origin of each observed sequence.
    Only intervals BETWEEN retained observations advance unobserved dynamics.
    """
    if times is None:return None
    if len(times)!=len(lengths):raise ValueError('One minute-ID array per sequence required')
    ids=torch.zeros(len(lengths),time,dtype=torch.long,device=lengths.device)
    for i,(values,n) in enumerate(zip(times,lengths.tolist())):
        v=np.asarray(values)
        if v.shape!=(n,) or not np.issubdtype(v.dtype,np.integer) or (v<0).any() or (np.diff(v)<=0).any():
            raise ValueError('Minute IDs must be nonnegative, strictly increasing integers matching sequence length')
        ids[i,:n]=torch.as_tensor(v.copy(),dtype=torch.long,device=lengths.device)
    return ids


def minute_gaps(window_ids,lengths,time):
    """Number of unobserved one-minute transitions before each observation."""
    gaps=torch.zeros(len(lengths),time,dtype=torch.long,device=lengths.device)
    if window_ids is None:return gaps
    if window_ids.shape!=gaps.shape or window_ids.dtype!=torch.long or window_ids.device!=lengths.device:
        raise ValueError('Minute-ID tensor must be int64 [batch,time] on the lengths device')
    mask=valid_mask(lengths,time)
    if (window_ids[mask]<0).any():raise ValueError('Negative minute ID')
    if time>1:
        delta=window_ids[:,1:]-window_ids[:,:-1]
        if (delta[mask[:,1:]]<=0).any():raise ValueError('Retained minute IDs must strictly increase')
        gaps[:,1:]=torch.where(mask[:,1:],delta-1,torch.zeros_like(delta))
    return gaps


def gaussian_kl(mq,lq,mp,lp):
    return .5*(lp-lq+(lq.exp()+(mq-mp).square())/(lp.exp()+1e-8)-1).mean(-1)


class FiveArrowPVRNN(nn.Module):
    """Profile-free v5 core, with per-channel reconstructions made explicit."""
    def __init__(self,cfg:Settings):
        super().__init__(); self.cfg=cfg
        f,s,z,q=cfg.fast_d,cfg.slow_d,cfg.fast_z,cfg.slow_z
        self.prior_fast=nn.Linear(f+s,2*z)
        self.prior_slow=nn.Linear(s,2*q)
        self.post_base_fast=nn.Linear(f+s,2*z)
        self.post_base_slow=nn.Linear(s,2*q)
        self.fast_dyn=nn.Linear(f+s+z,f)
        self.slow_dyn=nn.Linear(s+f+q,s)
        self.sensory_head=nn.Sequential(nn.Linear(f+s,f+s),nn.Tanh(),nn.Linear(f+s,5))
        self.behavior_head=nn.Sequential(nn.LayerNorm(f+s),nn.Dropout(cfg.dropout),nn.Linear(f+s,3))

    @property
    def adaptive_width(self): return 2*(self.cfg.fast_z+self.cfg.slow_z)

    @staticmethod
    def split(p):
        m,l=p.chunk(2,-1); return m,l.clamp(-7,3)

    def forward(self,lengths,A,sample=False,prior_only=False,window_ids=None):
        b,t,_=A.shape; c=self.cfg
        if lengths.shape!=(b,) or (lengths<=0).any() or (lengths>t).any():
            raise ValueError('Invalid lengths')
        if A.shape[-1]!=self.adaptive_width: raise ValueError('Invalid A width')
        hf=A.new_zeros(b,c.fast_d); hs=A.new_zeros(b,c.slow_d)
        df,ds=hf.tanh(),hs.tanh()
        recon=[]; kf=[]; ks=[]
        mask=valid_mask(lengths,t)
        gaps=minute_gaps(window_ids,lengths,t)
        for j in range(t):
            # No A, observation, reconstruction loss or posterior KL is created
            # for a missing minute: q=p and only the learned prior advances.
            for step in range(int(gaps[:,j].max())):
                mpf,lpf=self.split(self.prior_fast(torch.cat([df,ds],-1)))
                mps,lps=self.split(self.prior_slow(ds))
                zf=mpf+(lpf*.5).exp()*torch.randn_like(mpf) if sample else mpf
                zs=mps+(lps*.5).exp()*torch.randn_like(mps) if sample else mps
                nf=(1-1/c.tau_fast)*hf+self.fast_dyn(torch.cat([df,ds,zf],-1))/c.tau_fast
                ns=(1-1/c.tau_slow)*hs+self.slow_dyn(torch.cat([ds,df,zs],-1))/c.tau_slow
                advance=(mask[:,j] & (step<gaps[:,j]))[:,None]
                hf=torch.where(advance,nf,hf); hs=torch.where(advance,ns,hs)
                df=torch.where(advance,nf.tanh(),df); ds=torch.where(advance,ns.tanh(),ds)
            mpf,lpf=self.split(self.prior_fast(torch.cat([df,ds],-1)))
            mps,lps=self.split(self.prior_slow(ds))
            bmf,blf=self.split(self.post_base_fast(torch.cat([df,ds],-1)))
            bms,bls=self.split(self.post_base_slow(ds))
            amf,alf,ams,als=torch.split(A[:,j],(c.fast_z,c.fast_z,c.slow_z,c.slow_z),-1)
            mqf,lqf=bmf+amf,(blf+alf).clamp(-7,3)
            mqs,lqs=bms+ams,(bls+als).clamp(-7,3)
            if prior_only: mqf,lqf,mqs,lqs=mpf,lpf,mps,lps
            zf=mqf+(lqf*.5).exp()*torch.randn_like(mqf) if sample else mqf
            zs=mqs+(lqs*.5).exp()*torch.randn_like(mqs) if sample else mqs
            nf=(1-1/c.tau_fast)*hf+self.fast_dyn(torch.cat([df,ds,zf],-1))/c.tau_fast
            ns=(1-1/c.tau_slow)*hs+self.slow_dyn(torch.cat([ds,df,zs],-1))/c.tau_slow
            active=mask[:,j,None]
            hf=torch.where(active,nf,hf); hs=torch.where(active,ns,hs)
            df=torch.where(active,nf.tanh(),df); ds=torch.where(active,ns.tanh(),ds)
            recon.append(self.sensory_head(torch.cat([df,ds],-1)))
            kf.append(gaussian_kl(mqf,lqf,mpf,lpf))
            ks.append(gaussian_kl(mqs,lqs,mps,lps))
        rep=torch.cat([df,ds],-1)
        return dict(reconstruction=torch.stack(recon,1),prediction=self.behavior_head(rep),
                    kl_fast=torch.stack(kf,1),kl_slow=torch.stack(ks,1),representation=rep)


def objective(out,x,lengths,cfg,observed=None,log_precision=0.):
    """At rho=0 this equals v5 channel-mean MSE + weighted KL.

    rho controls PHYSIOLOGICAL RESIDUAL precision (not psychological precision).
    E residual variance=1, P residual variance=exp(-rho), standardized units.
    The -rho normalizer is indispensable: optimizing rho*MSE alone is invalid.
    This is twice a Gaussian NLL (constant omitted), plus beta-weighted KL;
    with beta=.001 it is a weighted variational criterion, NOT an exact ELBO.
    """
    vm=valid_mask(lengths,x.shape[1])
    mask=vm[:,:,None].expand_as(x)
    if observed is not None:
        if observed.shape!=x.shape or observed.dtype!=torch.bool:
            raise ValueError('observed must be boolean with the target shape')
        mask=mask & observed
    if not mask.any(): raise ValueError('No observed targets')
    if not torch.isfinite(x[mask]).all(): raise ValueError('Nonfinite observed targets')
    # Index FIRST: hidden NaN/extreme values cannot enter the arithmetic/gradient.
    e=out['reconstruction'][mask]-x[mask]
    channels=torch.arange(5,device=x.device).view(1,1,5).expand_as(x)[mask]
    rho=torch.as_tensor(log_precision,dtype=x.dtype,device=x.device)
    per_log_precision=torch.where(channels>=2,rho,torch.zeros_like(rho))
    rec=(e.square()*per_log_precision.exp()-per_log_precision).mean()
    kf=out['kl_fast'][vm].mean(); ks=out['kl_slow'][vm].mean()
    return rec+cfg.kl_fast*kf+cfg.kl_slow*ks


def diagnostics(out,x,lengths):
    vm=valid_mask(lengths,x.shape[1]); err=(out['reconstruction']-x).square()[vm]
    vals=err.mean(0).detach().cpu().numpy()
    names=('Temperature','CO2','EDA','HR','SkinTEMP')
    d={f'MSE_{n}':float(v) for n,v in zip(names,vals)}
    d.update(MSE_environment=float(vals[:2].mean()),MSE_physiology=float(vals[2:].mean()),
             MSE_all=float(vals.mean()),KL_fast=float(out['kl_fast'][vm].mean().detach()),
             KL_slow=float(out['kl_slow'][vm].mean().detach()))
    return d


@contextmanager
def frozen(model):
    flags=[p.requires_grad for p in model.parameters()]; was=model.training
    try:
        model.eval()
        for p in model.parameters(): p.requires_grad_(False)
        yield
    finally:
        for p,v in zip(model.parameters(),flags): p.requires_grad_(v)
        model.train(was)


def infer(model,x,lengths,cfg,observed=None,log_precision=0.,steps=None,window_ids=None):
    """No outcome argument exists. Best UNSUPERVISED iterate includes A=0.

    Compared with v5's final iterate, v6 retains the best objective iterate as
    an explicit numerical change. This does not guarantee lower outcome MSE.
    """
    n=cfg.er_steps if steps is None else steps
    A=nn.Parameter(x.new_zeros(x.shape[0],x.shape[1],model.adaptive_width))
    opt=torch.optim.Adam([A],lr=cfg.er_lr)
    time_kw={} if window_ids is None else dict(window_ids=window_ids)
    with frozen(model),torch.enable_grad():
        best=float('inf'); best_A=A.detach().clone(); best_step=0
        for j in range(n+1):
            out=model(lengths,A,sample=False,**time_kw)
            loss=objective(out,x,lengths,cfg,observed,log_precision)
            if not torch.isfinite(loss): raise FloatingPointError('Nonfinite ER objective')
            value=float(loss.detach())
            if value<best: best=value; best_A=A.detach().clone(); best_step=j
            if j==n: break
            opt.zero_grad(set_to_none=True); loss.backward()
            nn.utils.clip_grad_norm_([A],5.,error_if_nonfinite=True); opt.step()
        with torch.no_grad(): result=model(lengths,best_A,sample=False,**time_kw)
    return result,best_A,dict(objective=best,best_step=best_step)


def train(arrays,cfg,seed,y=None,times=None,label_mask=None):
    seed_all(seed); x,l=pad(arrays); model=FiveArrowPVRNN(cfg)
    ids=window_ids_tensor(times,l,x.shape[1])
    A=nn.Parameter(torch.zeros(len(arrays),x.shape[1],model.adaptive_width))
    opt=torch.optim.AdamW([dict(params=model.parameters(),lr=cfg.lr,weight_decay=cfg.weight_decay),
                           dict(params=[A],lr=cfg.adaptive_lr,weight_decay=0.)])
    target=None if y is None else torch.tensor(y,dtype=torch.float32)
    if target is None:
        if label_mask is not None:raise ValueError('Report mask requires report targets')
        selected=None
    else:
        if target.shape!=(len(arrays),3):raise ValueError('Expected one outcome row per training session')
        selected=torch.ones(len(arrays),dtype=torch.bool) if label_mask is None else torch.as_tensor(label_mask)
        if selected.dtype!=torch.bool or selected.shape!=(len(arrays),) or not selected.any():
            raise ValueError('Report mask must select at least one complete training-session report')
        if not torch.isfinite(target[selected]).all():raise ValueError('Selected reports must be complete and finite')
    history=[]; model.train()
    for epoch in range(cfg.epochs):
        opt.zero_grad(set_to_none=True)
        out=model(l,A,sample=True,window_ids=ids); gen=objective(out,x,l,cfg)
        loss=gen; sup=gen.new_zeros(())
        if target is not None:
            yp=model(l,A.detach(),sample=False,window_ids=ids)['prediction']
            # Index before subtraction: absent reports are not zero labels and
            # cannot contribute values or gradients. A remains detached.
            sup=(yp[selected]-target[selected]).square().mean(); loss=loss+sup
        if not torch.isfinite(loss): raise FloatingPointError('Nonfinite training loss')
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
        nn.utils.clip_grad_norm_([A],5.,error_if_nonfinite=True); opt.step()
        history.append(dict(epoch=epoch+1,free_energy=float(gen.detach()),
                            behavior_loss=float(sup.detach())))
    model.eval()
    return model,history


class SimpleRNN(nn.Module):
    """Conventional observation-fed sequence-to-report comparator; no ER."""
    def __init__(self,hidden=20,dropout=.25):
        super().__init__()
        self.rnn=nn.RNN(5,hidden,batch_first=True,nonlinearity='tanh')
        self.head=nn.Sequential(nn.LayerNorm(hidden),nn.Dropout(dropout),nn.Linear(hidden,3))

    def forward(self,x,lengths,window_ids=None):
        gaps=minute_gaps(window_ids,lengths,x.shape[1])
        if gaps.any():
            # State-only recurrence on missing minutes. No observed feature is
            # imputed, and missing minutes have no target or output loss.
            h=x.new_zeros(1,len(lengths),self.rnn.hidden_size)
            blank=x.new_zeros(len(lengths),1,x.shape[-1])
            mask=valid_mask(lengths,x.shape[1])
            for j in range(x.shape[1]):
                for step in range(int(gaps[:,j].max())):
                    _,next_h=self.rnn(blank,h)
                    h=torch.where((mask[:,j] & (step<gaps[:,j]))[None,:,None],next_h,h)
                _,next_h=self.rnn(x[:,j:j+1],h)
                h=torch.where(mask[:,j][None,:,None],next_h,h)
            return self.head(h[-1])
        packed=nn.utils.rnn.pack_padded_sequence(x,lengths.cpu(),batch_first=True,enforce_sorted=False)
        _,h=self.rnn(packed)
        return self.head(h[-1])


def train_simple(arrays,y,cfg,seed,times=None):
    seed_all(seed); x,l=pad(arrays); model=SimpleRNN(dropout=cfg.dropout)
    ids=window_ids_tensor(times,l,x.shape[1])
    opt=torch.optim.AdamW(model.parameters(),lr=cfg.lr,weight_decay=cfg.weight_decay)
    target=torch.tensor(y,dtype=torch.float32); model.train()
    for _ in range(cfg.epochs):
        opt.zero_grad(set_to_none=True); loss=(model(x,l,window_ids=ids)-target).square().mean()
        if not torch.isfinite(loss): raise FloatingPointError('Nonfinite RNN loss')
        loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True); opt.step()
    model.eval(); return model
