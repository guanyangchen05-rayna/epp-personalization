"""Participant/date held-out report estimation, separate from personal rho fits."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
from .data import TARGETS,CHANNELS,outer_folds,scaled_training,transform
from .model import train,train_simple,pad,infer,diagnostics,objective,window_ids_tensor


def metrics(predictions):
    rows=[]
    for (protocol,seed,mode,target),g in predictions.groupby(['protocol','seed','mode','target'],sort=False):
        y=g.observed.to_numpy(); p=g.prediction.to_numpy(); b=g.baseline.to_numpy()
        rmse=float(np.sqrt(np.mean((y-p)**2))); br=float(np.sqrt(np.mean((y-b)**2)))
        r2=float(r2_score(y,p)) if len(y)>1 and np.std(y)>1e-12 else np.nan
        rows.append(dict(protocol=protocol,seed=seed,mode=mode,target=target,N_sessions=len(g),
                         RMSE=rmse,MAE=float(np.abs(y-p).mean()),R2=r2,BaselineRMSE=br,
                         RelativeRMSE=rmse/br if br>1e-12 else np.nan))
    return pd.DataFrame(rows)


def bootstrap(predictions,cfg):
    """Fixed out-of-fold predictions; seed median FIRST, then cluster resample.
    Does not retrain models. Date intervals with four clusters are descriptive.
    """
    rows=[]; rng=np.random.default_rng(721)
    keys=['protocol','Pid','Class_id','EnvironmentDateKey','target','mode']
    pooled=predictions.groupby(keys,sort=False).agg(observed=('observed','first'),
                prediction=('prediction','median')).reset_index()
    for (protocol,target),g in pooled.groupby(['protocol','target'],sort=False):
        index=['Pid','Class_id','EnvironmentDateKey']
        wide=g.pivot(index=index,columns='mode',values='prediction')
        y=g.groupby(index)['observed'].first().reindex(wide.index).to_numpy()
        column='Pid' if protocol=='PARTICIPANT_LOO' else 'EnvironmentDateKey'
        cluster=wide.index.get_level_values(column).to_numpy(); groups=np.unique(cluster)
        for comparison in ('NO_ER','SIMPLE_RNN'):
            if comparison not in wide: continue
            a=wide[comparison].to_numpy(); b=wide['ERROR_REGRESSION'].to_numpy()
            def gain(idx):
                ra=np.sqrt(np.mean((y[idx]-a[idx])**2)); rb=np.sqrt(np.mean((y[idx]-b[idx])**2))
                return 100*(ra-rb)/ra if ra>1e-12 else np.nan
            samples=[]
            for _ in range(cfg.bootstrap_reps):
                draw=rng.choice(groups,size=len(groups),replace=True)
                idx=np.concatenate([np.flatnonzero(cluster==v) for v in draw])
                samples.append(gain(idx))
            samples=np.asarray(samples); samples=samples[np.isfinite(samples)]
            lo,hi=np.quantile(samples,[.025,.975]) if len(samples) else (np.nan,np.nan)
            rows.append(dict(protocol=protocol,target=target,comparison='ER_vs_'+comparison,
                        gain_pct=gain(np.arange(len(y))),ci95_low=lo,ci95_high=hi,
                        n_clusters=len(groups),bootstrap_reps=cfg.bootstrap_reps,
                        finite_repetitions=len(samples),model_refitting=False,
                        aggregation='session_seed_median_before_RMSE',
                        interval_caution='only_four_date_clusters' if len(groups)==4 and column!='Pid' else 'small_pilot_sample'))
    return pd.DataFrame(rows)


def run_behavior(cohort,cfg,outdir):
    if cohort.name!='11': raise ValueError('Behavior evaluation uses complete-report cohort only')
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    preds=[]; diags=[]; audit=[]
    for protocol,group in [('PARTICIPANT_LOO','Pid'),('DATE_LOO','EnvironmentDateKey')]:
        folds=outer_folds(cohort.meta,group)
        for seed in cfg.seeds:
            for fold,train_idx,test_idx in folds:
                print(f'[behavior] {protocol} {fold} seed={seed}',flush=True)
                scaler,train_arrays=scaled_training(cohort,train_idx)
                test_arrays=transform(scaler,cohort.subset(test_idx))
                yt=cohort.meta.iloc[train_idx][TARGETS].to_numpy(float)
                ys=StandardScaler().fit(yt); yz=ys.transform(yt).astype(np.float32)
                train_times=[cohort.times[i] for i in train_idx]
                model,history=train(train_arrays,cfg,seed,yz,times=train_times)
                safe_fold=''.join(c if c.isalnum() or c in '-_' else '_' for c in fold)
                prefix=f'{protocol}_{safe_fold}_seed_{seed}'
                torch.save(dict(state_dict=model.state_dict(),config=vars(cfg),
                           sequence_scaler_mean=scaler.mean_.tolist(),sequence_scaler_scale=scaler.scale_.tolist(),
                           target_scaler_mean=ys.mean_.tolist(),target_scaler_scale=ys.scale_.tolist(),
                           training_session_indices=train_idx.tolist(),
                           training_minute_ids=[t.tolist() for t in train_times],
                           gap_policy='prior_transitions_without_observation_loss'),outdir/(prefix+'.pt'))
                pd.DataFrame(history).to_csv(outdir/(prefix+'_training.csv'),index=False)
                simple=train_simple(train_arrays,yz,cfg,seed,times=train_times) if cfg.run_simple_rnn else None
                if simple is not None:
                    torch.save(dict(state_dict=simple.state_dict(),hidden_size=20,config=vars(cfg),
                               sequence_scaler_mean=scaler.mean_.tolist(),sequence_scaler_scale=scaler.scale_.tolist(),
                               target_scaler_mean=ys.mean_.tolist(),target_scaler_scale=ys.scale_.tolist()),
                               outdir/(prefix+'_simple.pt'))
                audit.append(dict(protocol=protocol,fold=fold,seed=seed,
                         train_keys=cohort.meta.iloc[train_idx][['Pid','Class_id']].to_dict('records'),
                         test_keys=cohort.meta.iloc[test_idx][['Pid','Class_id']].to_dict('records'),
                         sequence_scaler_fit='outer_training_retained_bins_only',
                         target_scaler_fit='outer_training_sessions_only',
                         PVRNN_parameters=sum(p.numel() for p in model.parameters()),
                         RNN_parameters=None if simple is None else sum(p.numel() for p in simple.parameters()),
                         test_outcomes_used_for_ER=False,test_ER_batch_unit='one_session',
                         elapsed_gaps_explicitly_modeled=True,
                         gap_policy='prior_transitions_without_observation_loss'))
                for idx,array in zip(test_idx,test_arrays):
                    row=cohort.meta.iloc[idx]; x,l=pad([array]); A=torch.zeros(1,len(array),model.adaptive_width)
                    ids=window_ids_tensor([cohort.times[idx]],l,x.shape[1])
                    model.eval()
                    with torch.no_grad(): no=model(l,A,sample=False,window_ids=ids)
                    er,Aer,erinfo=infer(model,x,l,cfg,window_ids=ids)
                    conditions={'NO_ER':no,'ERROR_REGRESSION':er}
                    outputs={k:v['prediction'].detach().numpy() for k,v in conditions.items()}
                    if simple is not None:
                        with torch.no_grad(): outputs['SIMPLE_RNN']=simple(x,l,window_ids=ids).numpy()
                    outputs['TRAINING_MEAN']=np.zeros((1,3))  # replaced by original-scale mean below
                    for mode,pz in outputs.items():
                        yp=yt.mean(0) if mode=='TRAINING_MEAN' else ys.inverse_transform(pz)[0]
                        for j,target in enumerate(TARGETS):
                            preds.append(dict(protocol=protocol,fold=fold,seed=seed,Pid=row.Pid,
                                 Class_id=row.Class_id,EnvironmentDateKey=row.EnvironmentDateKey,target=target,
                                 mode=mode,observed=float(getattr(row,target)),prediction=float(yp[j]),
                                 baseline=float(yt[:,j].mean())))
                    # Reconstruction diagnostics: each SESSION, not inflated time-point N.
                    for mode,out in conditions.items():
                        d=diagnostics(out,x,l)
                        d.update(protocol=protocol,fold=fold,seed=seed,Pid=row.Pid,Class_id=row.Class_id,
                                 mode=mode,EnvironmentDateKey=row.EnvironmentDateKey,n_bins=len(array),
                                 objective=float(objective(out,x,l,cfg).detach()))
                        if mode=='ERROR_REGRESSION':d['best_step']=erinfo['best_step']
                        diags.append(d)
                    # Real channel reconstructions are exported in original units.
                    record=pd.DataFrame({'window_id':cohort.times[idx]})
                    raw=cohort.arrays[idx]
                    for j,ch in enumerate(CHANNELS):
                        record['observed_'+ch]=raw[:,j]
                        for mode,out in conditions.items():
                            rec=scaler.inverse_transform(out['reconstruction'][0].detach().numpy())
                            record[mode+'_'+ch]=rec[:,j]
                    record.to_csv(outdir/(prefix+f'_session_{idx}_reconstruction.csv'),index=False)
                    torch.save(Aer,outdir/(prefix+f'_session_{idx}_A.pt'))
                pd.DataFrame(preds).to_csv(outdir/'out_of_fold_predictions.csv',index=False)
                pd.DataFrame(diags).to_csv(outdir/'reconstruction_diagnostics.csv',index=False)
                (outdir/'fold_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    p=pd.DataFrame(preds)
    expected_modes=4 if cfg.run_simple_rnn else 3
    if len(p)!=2*len(cfg.seeds)*len(cohort.meta)*3*expected_modes:
        raise AssertionError('Missing/duplicate out-of-fold predictions')
    if p.duplicated(['protocol','seed','Pid','Class_id','mode','target']).any():
        raise AssertionError('Duplicate out-of-fold prediction')
    m=metrics(p); m.to_csv(outdir/'seed_metrics.csv',index=False)
    summary=m.groupby(['protocol','mode','target']).agg(
        RMSE_median=('RMSE','median'),RMSE_q25=('RMSE',lambda s:s.quantile(.25)),
        RMSE_q75=('RMSE',lambda s:s.quantile(.75)),RelativeRMSE_median=('RelativeRMSE','median'),
        RelativeRMSE_q25=('RelativeRMSE',lambda s:s.quantile(.25)),
        RelativeRMSE_q75=('RelativeRMSE',lambda s:s.quantile(.75)),R2_median=('R2','median')).reset_index()
    summary.to_csv(outdir/'performance_summary.csv',index=False)
    bootstrap(p,cfg).to_csv(outdir/'cluster_bootstrap.csv',index=False)
    # Per-person gain: descriptive distribution, not a fitted cognitive parameter.
    med=p.groupby(['protocol','Pid','Class_id','target','mode']).agg(
                   prediction=('prediction','median'),observed=('observed','first')).reset_index()
    med['squared_error']=(med.prediction-med.observed)**2
    person=med.groupby(['protocol','Pid','target','mode']).squared_error.mean().unstack('mode')
    person['MSE_gain_ER_vs_NO_ER']=person.NO_ER-person.ERROR_REGRESSION
    if 'SIMPLE_RNN' in person:person['MSE_gain_ER_vs_SIMPLE_RNN']=person.SIMPLE_RNN-person.ERROR_REGRESSION
    person.reset_index().to_csv(outdir/'participant_prediction_gains.csv',index=False)
    return p
