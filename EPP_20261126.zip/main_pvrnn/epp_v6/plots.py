"""Scientific plots from actual outputs; no synthetic examples passed as study results."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch

COLORS={'NO_ER':'#8A99AA','ERROR_REGRESSION':'#2D8276','SIMPLE_RNN':'#AE792E','TRAINING_MEAN':'#555555'}
LABELS={'NO_ER':'PV-RNN No-ER','ERROR_REGRESSION':'PV-RNN ER','SIMPLE_RNN':'Simple RNN'}
TARGETS=['EngageScore','Arousal','Valence']


def save(fig,path):
    for ext in ('pdf','svg','png'):fig.savefig(path.with_suffix('.'+ext),dpi=200,bbox_inches='tight')
    plt.close(fig)


def architecture(folder):
    fig,ax=plt.subplots(figsize=(7.1,3.8));ax.set(xlim=(0,10),ylim=(0,6));ax.axis('off')
    def box(x,y,w,h,label,color):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.08,rounding_size=.06',
                     facecolor=color,edgecolor='#555555',linewidth=.7))
        ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=9)
    def arrow(a,b,label,offset=(0,0),color='#555555'):
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=10,linewidth=1,color=color))
        ax.text((a[0]+b[0])/2+offset[0],(a[1]+b[1])/2+offset[1],label,
                fontsize=8,ha='center',va='center',color=color)
    box(3.4,2.8,3.2,1.2,'Inferred session state\nPV-RNN · Adaptive variables','#F4F5F6')
    box(.2,.7,3.2,1.0,'Environment\nTemperature · CO₂','#DDEAF6')
    box(6.6,.7,3.2,1.0,'Physiology\nEDA · HR · SkinTEMP','#DDF0EB')
    box(3.4,4.9,3.2,.7,'Engagement\nArousal · Valence','#F6E6D2')
    arrow((3.6,2.8),(2.1,1.7),'Prediction',(-.6,0),'#2F6EA5')
    arrow((2.6,1.7),(4.3,2.8),'Error',(.1,-.2),'#2F6EA5')
    arrow((6.4,2.8),(7.9,1.7),'Prediction',(.6,0),'#2D8276')
    arrow((7.4,1.7),(5.7,2.8),'Error',(-.1,-.2),'#2D8276')
    arrow((5,4.0),(5,4.9),'Readout',(.7,0))
    ax.text(5,.15,'Test-time inference: network weights fixed; report labels not used',ha='center',fontsize=8)
    save(fig,folder/'five_arrow_computational_routes')


def make_figures(run):
    run=Path(run);folder=run/'figures';folder.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
                         'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
    architecture(folder)
    chain=run/'question1_joint_validation.csv'
    if chain.exists():
        d=pd.read_csv(chain);d=d[d.primary_analysis.eq(True)].copy()
        names=['Physiology','EngageScore','Arousal','Valence']
        d=d.set_index('target').reindex(names).reset_index()
        ratio=d.individual_error_median/d.common_error_median
        if np.isfinite(ratio).any():
            fig,ax=plt.subplots(figsize=(6.1,2.9))
            y=np.arange(4)
            for j,row in d.iterrows():
                if np.isfinite(row.gain_ci95_low) and np.isfinite(row.gain_ci95_high):
                    ax.hlines(j,1-row.gain_ci95_high/100,1-row.gain_ci95_low/100,color='#2D8276')
            ax.scatter(ratio,y,s=30,color='#2D8276')
            ax.axvline(1,color='#777777',linestyle='--',linewidth=.8)
            labels=[f'{name} ({metric}; n={int(n)})' if np.isfinite(n) else name for name,metric,n in
                    zip(['Physiology','Engagement','Arousal','Valence'],d.metric,d.n_sessions)]
            ax.set(yticks=y,yticklabels=labels,xlabel='Individual / common prediction error',
                   title='Different-session calibration; same held-out sessions')
            ax.invert_yaxis();fig.tight_layout();save(fig,folder/'question1_chain_transfer')
    perf=run/'behavior_11/performance_summary.csv'
    if perf.exists():
        d=pd.read_csv(perf);d=d[d.protocol=='PARTICIPANT_LOO']
        fig,ax=plt.subplots(figsize=(5.6,2.7))
        modes=[m for m in LABELS if m in set(d['mode'])]
        for k,mode in enumerate(modes):
            sub=d[d['mode']==mode].set_index('target').reindex(TARGETS)
            y=np.arange(3)+(k-(len(modes)-1)/2)*.18
            ax.hlines(y,sub.RelativeRMSE_q25,sub.RelativeRMSE_q75,color=COLORS[mode])
            ax.scatter(sub.RelativeRMSE_median,y,color=COLORS[mode],label=LABELS[mode],s=25)
        ax.axvline(1,color='#555555',linestyle='--',linewidth=.8)
        ax.set(yticks=np.arange(3),yticklabels=['Engagement','Arousal','Valence'],
               xlabel='Relative RMSE (median and seed IQR)');ax.invert_yaxis()
        ax.legend(fontsize=8,frameon=False);save(fig,folder/'participant_LOO_performance')
    for n in ('22','11'):
        validation=run/f'cohort_{n}/validation/parameter_validation.csv'
        if validation.exists():
            v=pd.read_csv(validation,dtype={'Pid':str})
            v=v[v.status.eq('completed')]
            if not v.empty:
                fig,axes=plt.subplots(1,2,figsize=(7,2.9))
                for ax,scope,title in zip(axes,
                    ['held_out_session_prefix_to_masked_suffix','within_session_prefix_to_masked_suffix_not_trait_reliability'],
                    ['Different-session calibration','Within-session calibration']):
                    g=v[v.validation_scope.eq(scope)].groupby(['Pid','Class_id']).MSE_gain.median()
                    ax.axvline(0,color='#777777',linestyle='--',linewidth=.8)
                    ax.scatter(g.to_numpy(),np.arange(len(g)),s=22,color='#2D8276')
                    ax.set(yticks=np.arange(len(g)),yticklabels=[f'{p}/{c}' for p,c in g.index],
                           xlabel='MSE reduction vs common precision',title=title)
                    ax.xaxis.set_major_locator(MaxNLocator(4))
                    ax.ticklabel_format(axis='x',style='sci',scilimits=(-2,2))
                    ax.invert_yaxis()
                fig.tight_layout();save(fig,folder/f'cohort_{n}_parameter_validation')
        p=run/f'cohort_{n}/parameters/participant_parameter_summary.csv'
        if not p.exists():continue
        d=pd.read_csv(p,dtype={'Pid':str});y=np.arange(len(d))
        fig,ax=plt.subplots(figsize=(5.4,max(2.7,len(d)*.2)))
        ax.hlines(y,d.rho_q25,d.rho_q75,color='#2D8276')
        ax.scatter(d.rho_median,y,color='#2D8276',s=22)
        boundary=d.boundary_fraction.gt(0)
        ax.scatter(d.loc[boundary,'rho_median'],y[boundary],facecolors='none',edgecolors='#AE792E',s=65,
                   label='At least one seed selected grid boundary')
        ax.axvline(0,color='#777777',linewidth=.8,linestyle='--')
        ax.set(yticks=y,yticklabels=[f'{r.Pid} (n={r.n_sessions})' for r in d.itertuples()],
               xlabel='Physiological residual log precision\nMedian and IQR across seeds; descriptive fit')
        ax.invert_yaxis()
        if boundary.any():ax.legend(fontsize=7,frameon=False,loc='best')
        save(fig,folder/f'cohort_{n}_individual_parameters')
    manifest=run/'run_manifest.json'
    if manifest.exists():
        import json
        info=json.loads(manifest.read_text())
        if info.get('quick') or info.get('nonpaper_count_override'):
            (folder/'SMOKE_ONLY_NOT_PAPER_RESULTS.txt').write_text('Quick or nonpaper-count run. '
                'Do not insert these figures in the manuscript.\n')
