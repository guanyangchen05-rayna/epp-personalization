"""Strict adapter to v5 final tables. No room mapping, imputation or relabeling."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

CHANNELS=['IndoorTemperature','IndoorCO2','EDA','HR','TEMP']
TARGETS=['EngageScore','Arousal','Valence']
KEYS=['Pid','Class_id']


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def read_csv(path):
    if not Path(path).is_file(): raise FileNotFoundError(f'Exact v5 file required: {path}')
    return pd.read_csv(path,dtype={'Pid':str,'Class_id':str})


def session_keys(frame): return list(map(tuple,frame[KEYS].astype(str).to_numpy()))


@dataclass
class Cohort:
    name: str
    meta: pd.DataFrame
    arrays: list
    times: list
    qc: pd.DataFrame
    input_hashes: dict

    def subset(self,indices): return [self.arrays[int(i)] for i in indices]


def load_cohort(table_dir,name,enforce_counts=True):
    """22 means full physiology cohort; 11 means complete-report subset.

    Neither cohort is selected by model performance. Names are historical labels;
    exact expected counts are checked unless an explicit nonpaper-data override.
    """
    if name not in ('22','11'): raise ValueError('cohort must be 22 or 11')
    root=Path(table_dir)
    provenance=root/'processing_summary.json'
    if enforce_counts:
        if not provenance.is_file():raise FileNotFoundError('Formal runs require the v5 processing_summary.json beside the tables')
        info=json.loads(provenance.read_text())
        if info.get('environment_scope')!='school_indoor_context' or info.get('room_mapping_used') is not False:
            raise ValueError('Provenance must declare shared indoor context and no room mapping')
        expected_panel={'28','29','31','43','KB2','KB3','KB4','KB5'}
        if set(map(str,info.get('fixed_sensor_panel',[])))!=expected_panel:
            raise ValueError('Formal paper cohort requires the frozen eight-sensor panel')
        if info.get('eda_qc',{}).get('max_zero_fraction')!=.95:
            raise ValueError('Expected frozen 95% EDA zero-value rule')
    stem='envphys' if name=='22' else 'behavior'
    paths=[root/f'{stem}_session_analysis.csv',root/f'{stem}_temporal_1s.csv']
    meta,temp=map(read_csv,paths)
    needed=set(KEYS+['ClassStart','ClassEnd','EnvironmentDateKey','EnvironmentScope','Room'])
    if not needed.issubset(meta): raise ValueError(f'Missing metadata: {sorted(needed-set(meta))}')
    if meta.empty or meta[KEYS].isna().any().any() or meta.duplicated(KEYS).any():
        raise ValueError('Missing/duplicate session keys')
    if not meta.EnvironmentScope.eq('school_indoor_context').all():
        raise ValueError('Expected v5 shared indoor context, not room-exposure tables')
    start=pd.to_datetime(meta.ClassStart,errors='raise')
    end=pd.to_datetime(meta.ClassEnd,errors='raise')
    if not (end>start).all() or not meta.EnvironmentDateKey.eq(start.dt.strftime('DATE__%Y-%m-%d')).all():
        raise ValueError('Invalid dates/durations')
    if not meta.Room.isin(['R1','R2','R3','R4','R5']).all(): raise ValueError('Unexpected room scope')
    if 'EDA_QC_pass' not in meta or not meta.EDA_QC_pass.astype(str).str.lower().isin(['true','1']).all():
        raise ValueError('Canonical v5 EDA_QC_pass required for every retained session')
    if 'n_complete_env_phys_seconds' not in meta or (meta.n_complete_env_phys_seconds<300).any():
        raise ValueError('Expected at least 300 jointly complete seconds per session')
    if name=='11':
        if not set(TARGETS).issubset(meta) or not np.isfinite(meta[TARGETS].to_numpy(float)).all():
            raise ValueError('Complete session-level reports required')
        if not meta.EngageScore.between(1,5).all() or not meta[['Arousal','Valence']].apply(lambda s:s.between(1,4)).all().all():
            raise ValueError('Unexpected report scales')
    if enforce_counts:
        expected=(102,22,7) if name=='22' else (16,11,4)
        actual=(len(meta),meta.Pid.nunique(),meta.EnvironmentDateKey.nunique())
        if actual!=expected: raise ValueError(f'Cohort {name}: got {actual}, expected {expected}; '
                                             'inspect v5 QC, or explicitly use --allow-other-counts for nonpaper data')
    if not set(KEYS+CHANNELS+['DateTime']).issubset(temp): raise ValueError('Incomplete temporal schema')
    if temp[KEYS].isna().any().any() or set(session_keys(meta))!=set(session_keys(temp)):
        raise ValueError('Session and temporal key sets differ; cannot silently change the cohort')
    temp['DateTime']=pd.to_datetime(temp.DateTime,errors='raise')
    if temp.duplicated(KEYS+['DateTime']).any(): raise ValueError('Duplicate one-second observations')
    if not temp.DateTime.eq(temp.DateTime.dt.floor('s')).all(): raise ValueError('Expected one-second averages')
    meta=meta.sort_values(['ClassStart','Pid','Class_id'],kind='stable').reset_index(drop=True)
    groups={k:g for k,g in temp.groupby(KEYS,sort=False)}
    arrays=[]; times=[]; qc=[]
    for row in meta.itertuples(index=False):
        key=(row.Pid,row.Class_id); g=groups[key].sort_values('DateTime').copy()
        s,e=pd.Timestamp(row.ClassStart),pd.Timestamp(row.ClassEnd)
        if (g.DateTime<s).any() or (g.DateTime>e).any(): raise ValueError(f'Out-of-class timestamps: {key}')
        vals=g[CHANNELS].to_numpy(float)
        complete=np.isfinite(vals).all(axis=1)
        g=g.loc[complete].copy()
        if len(g)<300: raise ValueError(f'Insufficient complete seconds for {key}')
        if len(g)!=int(row.n_complete_env_phys_seconds):
            raise ValueError(f'Complete-second count differs from v5 session table: {key}')
        if (g.EDA==0).mean()>=.95: raise ValueError(f'Failed frozen EDA zero screen: {key}')
        g['bin']=np.floor((g.DateTime-s).dt.total_seconds()/60).astype(int)
        values=[]; ids=[]
        for wid,w in g.groupby('bin',sort=True):
            if len(w)<30: continue
            values.append(w[CHANNELS].mean().to_numpy(dtype=np.float32)); ids.append(int(wid))
        if not values: raise ValueError(f'No retained minute bins: {key}')
        arrays.append(np.stack(values)); times.append(np.asarray(ids,dtype=int))
        qc.append(dict(Pid=row.Pid,Class_id=row.Class_id,n_complete_seconds=len(g),
                       n_bins=len(ids),omitted_bins=max(ids)-min(ids)+1-len(ids),
                       max_internal_gap_bins=int(np.max(np.diff(ids)-1)) if len(ids)>1 else 0,
                       elapsed_gaps_explicitly_modeled=True,
                       gap_policy='prior_transitions_without_observation_loss',
                       EDA_log_transformed=False))
    hashed=paths+([provenance] if provenance.is_file() else [])
    return Cohort(name,meta,arrays,times,pd.DataFrame(qc),{p.name:sha256(p) for p in hashed})


def scaled_training(cohort,indices):
    arrays=cohort.subset(indices)
    scaler=StandardScaler().fit(np.concatenate(arrays))
    return scaler,[scaler.transform(a).astype(np.float32) for a in arrays]


def transform(scaler,arrays): return [scaler.transform(a).astype(np.float32) for a in arrays]


def outer_folds(meta,group):
    if group not in ('Pid','EnvironmentDateKey'): raise ValueError(group)
    if meta[group].nunique()<2: raise ValueError('Need at least two groups')
    folds=[]; covered=[]
    for value in sorted(meta[group].unique()):
        test=np.flatnonzero(meta[group].eq(value)); train=np.flatnonzero(~meta[group].eq(value))
        if not len(train) or set(meta.iloc[test][group]) & set(meta.iloc[train][group]):
            raise ValueError('Invalid group separation')
        covered.extend(test.tolist()); folds.append((str(value),train,test))
    if sorted(covered)!=list(range(len(meta))): raise ValueError('Incomplete outer folds')
    return folds
