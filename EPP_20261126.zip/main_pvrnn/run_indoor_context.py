"""Run original-data preprocessing and models with shared INDOOR context."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import queue
import signal
import threading
import time
import shlex
import subprocess
import sys
from run_pipeline import ROOT, TABLES, DEPS, sha256, require_dependencies


def load_config(args):
    cfg = json.loads(args.config.read_text(encoding='utf-8'))
    if cfg.get('environment_mode') != 'school_indoor_context':
        raise ValueError('Use config/indoor_context.json; historical mapping config is not interchangeable.')
    for name in ('raw_dir', 'table_dir', 'output_dir'):
        path = Path(getattr(args, name) or cfg[name]).expanduser()
        cfg[name] = str(path.resolve() if path.is_absolute() else (ROOT/path).resolve())
    raw = Path(cfg['raw_dir'])
    if any(Path(cfg[k]) == raw or raw in Path(cfg[k]).parents for k in ('table_dir', 'output_dir')):
        raise ValueError('Keep generated tables/results outside the original dataset directory.')
    if cfg.get('class_table'):
        path = Path(cfg['class_table']).expanduser()
        cfg['class_table'] = str(path.resolve() if path.is_absolute() else (ROOT/path).resolve())
    if cfg.get('aggregation') not in ('median', 'mean'):
        raise ValueError('aggregation must be median or mean.')
    if type(cfg.get('minimum_sensors')) is not int or cfg['minimum_sensors'] < 2:
        raise ValueError('minimum_sensors must be an integer >= 2.')
    cfg.setdefault('eda_qc_max_zero_fraction', 0.95)
    threshold = cfg['eda_qc_max_zero_fraction']
    if threshold is not None and (isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0 < threshold <= 1):
        raise ValueError('eda_qc_max_zero_fraction must be in (0,1], or null for an explicit unfiltered comparator.')
    rooms = cfg.get('included_rooms')
    if not isinstance(rooms, list) or not rooms or any(not isinstance(r, str) or not r.strip() for r in rooms):
        raise ValueError('included_rooms must be an explicit list of room labels.')
    if any(r.strip().casefold() in ('out', 'outdoor', 'outside') for r in rooms):
        raise ValueError('Outdoor classes cannot enter the indoor classroom scope.')
    if not isinstance(cfg.get('seeds'), list) or not cfg['seeds'] or any(type(v) is not int for v in cfg['seeds']) or len(set(cfg['seeds']))!=len(cfg['seeds']):
        raise ValueError('seeds must be a nonempty list of unique integers.')
    for key in ('epochs', 'er_steps', 'bootstrap_reps'):
        if type(cfg.get(key)) is not int or cfg[key] < 1:
            raise ValueError(f'{key} must be a positive integer.')
    if type(cfg.get('cpu_only')) is not bool or not isinstance(cfg.get('er_lr'), (int, float)) or cfg['er_lr'] <= 0:
        raise ValueError('Check cpu_only and er_lr.')
    if args.smoke:
        cfg.update(seeds=[11], epochs=1, er_steps=1, bootstrap_reps=20)
        cfg['output_dir'] = str(Path(cfg['output_dir'])/'smoke')
    return cfg


def build_commands(cfg, stage):
    tables, output = Path(cfg['table_dir']), Path(cfg['output_dir'])
    prepared = tables/'00_input'
    prepare = [sys.executable, '-u', str(ROOT/'scripts/prepare_indoor_context.py'),
               '--base-dir', cfg['raw_dir'], '--output-dir', str(prepared),
               '--aggregation', cfg['aggregation'], '--minimum-sensors', str(cfg['minimum_sensors']),
               '--rooms', ','.join(cfg['included_rooms'])]
    if cfg.get('class_table'):
        prepare += ['--class-table', cfg['class_table']]
    commands = {
        'prepare': prepare,
        'preprocess': [sys.executable, '-u', str(ROOT/'scripts/preprocess_indoor_context.py'),
                       '--base-dir', cfg['raw_dir'], '--output-dir', str(tables), '--input-dir', str(prepared)],
        'mixedlm': [sys.executable, '-u', str(ROOT/'scripts/mixedlm_indoor_context.py'),
                    '--input', str(tables/TABLES[0]), '--output-dir', str(output/'mixedlm')],
        'pvrnn': [sys.executable, '-u', str(ROOT/'scripts/pvrnn_indoor_context.py'),
                  '--table-dir', str(tables), '--output-dir', str(output/'pvrnn'),
                  '--epochs', str(cfg['epochs']), '--seeds', ','.join(map(str, cfg['seeds'])),
                  '--er-steps', str(cfg['er_steps']), '--er-lr', str(cfg['er_lr']),
                  '--bootstrap-reps', str(cfg['bootstrap_reps']), '--skip-mixedlm']}
    if cfg.get('eda_qc_max_zero_fraction', 0.95) is None:
        commands['preprocess'] += ['--no-eda-qc']
    else:
        commands['preprocess'] += ['--eda-max-zero-fraction', str(cfg.get('eda_qc_max_zero_fraction', 0.95))]
    stages = ('prepare','preprocess','mixedlm','pvrnn') if stage=='all' else (('prepare','preprocess') if stage=='preprocess' else (stage,))
    return [(s, commands[s]) for s in stages]


def require_inputs(stage, cfg):
    raw, tables = Path(cfg['raw_dir']), Path(cfg['table_dir'])
    if stage == 'prepare':
        if not raw.is_dir():
            raise FileNotFoundError(f'Original dataset directory missing: {raw}')
        return
    if stage == 'preprocess':
        paths = [tables/'00_input/Classroom_Data.csv', tables/'00_input/POOLED_INDOOR.csv', tables/'00_input/indoor_context_summary.json']
        if not all(p.is_file() for p in paths):
            raise FileNotFoundError('Prepare indoor context first; do not use historical mapping files.')
    else:
        names = TABLES if stage=='pvrnn' else TABLES[:1]
        absent = [str(tables/n) for n in names if not (tables/n).is_file()]
        if absent:
            raise FileNotFoundError('Complete indoor-context preprocessing first: '+', '.join(absent))
        summary_path = tables/'processing_summary.json'
        if not summary_path.is_file():
            raise FileNotFoundError('Missing processing_summary.json: rebuild preprocessing with this release.')
        summary = json.loads(summary_path.read_text(encoding='utf-8'))
        qc = summary.get('eda_qc', {})
        if 'max_zero_fraction' not in qc or qc['max_zero_fraction'] != cfg.get('eda_qc_max_zero_fraction', 0.95):
            raise ValueError('The analysis tables were not built with the configured EDA QC rule. Run --stage preprocess in a new run directory first.')


def stop_owned_worker(process):
    """Stop only the worker started by this invocation, including its children."""
    if process.poll() is not None:
        return
    if os.name == 'nt':
        result = subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if result.returncode and process.poll() is None:
            process.kill()
    else:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        if os.name != 'nt':
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        else:
            process.kill()
        process.wait(timeout=5)


def run_logged_worker(command, log_path, cwd, env, stage, on_start=None, heartbeat_seconds=15):
    """Tee output live; emit elapsed-time heartbeats during quiet processing."""
    kwargs = {'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == 'nt' else {'start_new_session': True}
    process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                               errors='replace', bufsize=1, **kwargs)
    started = time.monotonic()
    messages = queue.Queue()
    def read_output():
        try:
            for line in process.stdout:
                messages.put(line)
        finally:
            messages.put(None)
    reader = threading.Thread(target=read_output, daemon=True)
    reader.start()
    try:
        if on_start:
            on_start(process.pid)
        with Path(log_path).open('w', encoding='utf-8') as log:
            while True:
                try:
                    line = messages.get(timeout=heartbeat_seconds)
                except queue.Empty:
                    line = f'[runner] {stage} still running; elapsed {time.monotonic()-started:.0f}s; worker PID {process.pid}\n'
                if line is None:
                    break
                log.write(line);log.flush()
                print(line, end='', flush=True)
            return process.wait()
    except BaseException:
        stop_owned_worker(process)
        reader.join(timeout=2)
        raise
    finally:
        if process.stdout is not None and not reader.is_alive():
            process.stdout.close()


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', type=Path, default=ROOT/'config/indoor_context.json')
    p.add_argument('--stage', choices=('prepare','preprocess','mixedlm','pvrnn','all'), default='preprocess')
    for key in ('raw-dir','table-dir','output-dir'):
        p.add_argument('--'+key)
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--dry-run', action='store_true')
    args = p.parse_args(argv)
    cfg = load_config(args)
    plan = build_commands(cfg, args.stage)
    for stage, command in plan:
        print(f'[{stage}] {shlex.join(command)}', flush=True)
    if args.dry_run:
        return 0
    require_dependencies([s for s, _ in plan])
    require_inputs(plan[0][0], cfg)
    tag = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    run_dir = Path(cfg['output_dir'])/'runs'/tag
    run_dir.mkdir(parents=True)
    record = {'created_utc': tag, 'config': cfg, 'smoke_only': args.smoke,
              'python': sys.version, 'platform': platform.platform(),
              'environment_scope': 'school_indoor_context', 'environment_type': 'INDOOR',
              'room_mapping_used': False, 'raw_tree_fully_hashed': False,
              'packages': {n:importlib.metadata.version(n) for n in sorted({d for s,_ in plan for d in DEPS[s]})},
              'source_hashes': {str(f.relative_to(ROOT)):sha256(f) for f in (ROOT/'scripts').glob('*.py')}, 'stages': []}
    manifest = run_dir/'run_manifest.json'
    def save():
        manifest.write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    env = os.environ.copy()
    env.setdefault('MPLBACKEND', 'Agg')
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTHONUNBUFFERED'] = '1'
    if cfg['cpu_only']:
        env['CUDA_VISIBLE_DEVICES'] = ''
    save()
    try:
        for stage, command in plan:
            require_inputs(stage, cfg)
            inputs = ([Path(cfg['table_dir'])/n for n in (TABLES if stage=='pvrnn' else TABLES[:1])]
                      if stage not in ('prepare','preprocess') else list((Path(cfg['table_dir'])/'00_input').glob('*.csv')) if stage=='preprocess' else [])
            if stage == 'preprocess':
                inputs += [Path(cfg['raw_dir'])/n for n in ('Survey/Student_survey.csv', 'Survey/Studentsurvey.csv', 'Student_survey.csv', 'Studentsurvey.csv') if (Path(cfg['raw_dir'])/n).is_file()]
            entry = {'stage':stage, 'command':command, 'status':'running', 'input_sha256':{str(f):sha256(f) for f in inputs}}
            record['stages'].append(entry);save()
            log = run_dir/(stage+'.log')
            print(f'Running {stage}; log: {log}', flush=True)
            def worker_started(pid):
                entry['worker_pid'] = pid
                save()
            returncode = run_logged_worker(command, log, ROOT, env, stage, on_start=worker_started)
            entry.update(returncode=returncode, status='passed' if returncode==0 else 'failed');save()
            if returncode:
                tail='\n'.join(log.read_text(encoding='utf-8', errors='replace').splitlines()[-20:])
                raise RuntimeError(f'{stage} failed. Log: {log}\n{tail}')
            if stage=='prepare':
                info_path=Path(cfg['table_dir'])/'00_input/indoor_context_summary.json'
                record['indoor_context_summary']=json.loads(info_path.read_text(encoding='utf-8'))
                record['indoor_context_summary_sha256']=sha256(info_path);save()
        record['status']='completed'
    except KeyboardInterrupt:
        if record['stages'] and record['stages'][-1]['status']=='running':
            record['stages'][-1]['status']='interrupted'
        record.update(status='interrupted', error='KeyboardInterrupt: owned worker stopped')
        save()
        print('Interrupted. The worker started by this invocation has been stopped.', flush=True)
        raise
    except Exception as exc:
        record.update(status='failed', error=str(exc));save();raise
    save()
    print('Completed. Run record:',manifest,flush=True)
    return 0

if __name__=='__main__':
    try:
        raise SystemExit(main())
    except (OSError,ValueError,RuntimeError,KeyError) as exc:
        print(f'Error: {exc}',file=sys.stderr)
        raise SystemExit(1)
