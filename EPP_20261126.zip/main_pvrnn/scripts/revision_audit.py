"""Run supplementary checks without editing preprocessing, main fits or PV-RNN."""
from __future__ import annotations
import argparse, hashlib, importlib.metadata, json, platform, sys
from pathlib import Path
import numpy as np
import pandas as pd
from revision_models import (read_sessions,prepare,fit,fixed_rows,adjust_families,slope_rows,boolean,OUTCOMES)

MODELS=['reference_date','context_window','context_window_time','date_fixed_window_time','within_between_window_time']
def save_json(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def model_pair(d,outcome,model,records=None,with_reml=False):
    pair=[]
    for slope in [False,True]:
        r,meta=fit(d,outcome,model,slope=slope,reml=False)
        if records is not None:records.append(meta)
        pair.append(meta)
    return dict(outcome=outcome,model=model,N_sessions=len(d),N_participants=d.Pid.nunique(),N_dates=d.EnvironmentDateKey.nunique(),
                AIC_intercepts=pair[0]['AIC'],AIC_slope=pair[1]['AIC'],delta_AIC=pair[1]['AIC']-pair[0]['AIC'],
                slope_variance_ML=pair[1]['variance_components'].get('PidTempSlope'),converged=True)

def core(raw,out):
    d=prepare(raw);records=[];fixed=[];vc=[];comparisons=[];slopes=[]
    for model in MODELS:
        for outcome in OUTCOMES:
            print(f'[core] {model} / {outcome}',flush=True)
            comparisons.append(model_pair(d,outcome,model,records))
            for slope in [False,True]:
                r,meta=fit(d,outcome,model,slope=slope,reml=True);records.append(meta)
                fixed.extend(fixed_rows(r,meta))
                if slope:slopes.extend(slope_rows(r,d,meta))
                values=meta['variance_components']|{'Residual':meta['residual_variance']}
                for name,value in values.items():
                    vc.append(dict(model=model,outcome=outcome,slope=slope,component=name,variance=value,
                                   intercept_model_variance_proportion=value/sum(values.values()) if not slope else np.nan))
            # Checkpoint after every outcome, so a failure retains prior diagnostics.
            save_json(out/'fit_diagnostics.json',records)
            adjust_families(pd.DataFrame(fixed)).to_csv(out/'audit_fixed_effects.csv',index=False)
    pd.DataFrame(vc).to_csv(out/'audit_variance_components.csv',index=False)
    pd.DataFrame(comparisons).to_csv(out/'audit_model_comparison.csv',index=False)
    pd.DataFrame(slopes).to_csv(out/'audit_participant_slopes.csv',index=False)
    windows=d[['ContextWindowKey','EnvironmentDateKey','ClassStart','ClassEnd','Temperature_mean','CO2_mean']].drop_duplicates('ContextWindowKey')
    counts=d.groupby('ContextWindowKey').size();windows['n_sessions']=windows.ContextWindowKey.map(counts)
    windows.to_csv(out/'context_window_inventory.csv',index=False)
    design=[]
    for name in ['Temperature_mean','CO2_mean']:
        tot=((d[name]-d[name].mean())**2).sum();within=((d[name]-d.groupby('EnvironmentDateKey')[name].transform('mean'))**2).sum()
        design.append(dict(variable=name,fraction_between_dates_session_weighted=1-within/tot,
                           definition='Descriptive variance decomposition; within-between model uses equal weight per distinct window for date means.'))
    pd.DataFrame(design).to_csv(out/'covariate_date_clustering.csv',index=False)
    d[['Pid','Class_id','ContextWindowKey','EnvironmentDateKey','Hour_c','Temperature_z','Temperature_between_z',
       'Temperature_within_z','CO2_z','CO2_between_z','CO2_within_z']].to_csv(out/'audit_design.csv',index=False)

def influence(raw,tables,out):
    rows=[]
    for field in ['Pid','EnvironmentDateKey']:
        for value in sorted(raw[field].unique()):
            sub=raw.loc[raw[field].ne(value)].copy()
            for outcome in ['HR','SkinTEMP']:
                print(f'[influence] remove {field}={value} / {outcome}',flush=True)
                try:
                    r=model_pair(prepare(sub),outcome,'context_window')
                    rows.append(dict(exclusion_type=field,excluded_group=value,status='passed',**r))
                except Exception as exc:
                    rows.append(dict(exclusion_type=field,excluded_group=value,outcome=outcome,status='failed',error=str(exc)))
                pd.DataFrame(rows).to_csv(out/'influence_checks.csv',index=False)
    quality=[]
    scenarios=[('main_eda95',raw),('coverage_ge_50pct',raw.loc[raw.complete_env_phys_fraction_of_class.ge(.5)])]
    master_path=tables/'session_master.csv'
    if master_path.exists():
        master=pd.read_csv(master_path,dtype={'Pid':str,'Class_id':str})
        needed={'EnvPhysReady_before_EDA_QC','EDA_zero_fraction'}
        if needed.issubset(master):
            before=master.loc[boolean(master.EnvPhysReady_before_EDA_QC)].copy()
            # These are explicit sensitivity cohorts, never written to main tables.
            scenarios+=[('before_eda_screen',before)]
            for threshold in [.90,.99]:
                scenarios.append((f'eda_zero_threshold_{threshold:.2f}',before.loc[before.EDA_zero_fraction.lt(threshold)].copy()))
            before[['Pid','Class_id','EDA_zero_fraction']].to_csv(out/'eda_zero_fraction_distribution.csv',index=False)
    for name,sub in scenarios:
        for outcome in OUTCOMES:
            print(f'[quality] {name} / {outcome}',flush=True)
            try:
                d=prepare(sub);r,meta=fit(d,outcome,'context_window',reml=True)
                for row in fixed_rows(r,meta):quality.append(dict(scenario=name,status='passed',**row))
            except Exception as exc:quality.append(dict(scenario=name,outcome=outcome,status='failed',error=str(exc)))
    pd.DataFrame(quality).to_csv(out/'quality_sensitivity_fixed_effects.csv',index=False)

def environment(raw,tables,base_dir,out):
    from prepare_classroom_mapping import load_environment,locate
    from prepare_indoor_context import parse_usability
    info_path=tables/'00_input/indoor_context_summary.json'
    info=json.loads(info_path.read_text(encoding='utf-8'))
    panel=info['fixed_panel']
    env,inventory,_=load_environment(locate(base_dir,('.',),('Longitudinal','longitudinal'),directory=True))
    lookup={str(k).removesuffix('.csv'):k for k in env}
    frames=[env[lookup[str(p)]] for p in panel]
    index=frames[0].index
    if not all(f.index.equals(index) for f in frames):raise ValueError('Fixed-panel native grids differ.')
    t=pd.DataFrame({p:pd.to_numeric(f.IndoorTemperature,errors='coerce') for p,f in zip(panel,frames)},index=index)
    c=pd.DataFrame({p:pd.to_numeric(f.IndoorCO2,errors='coerce') for p,f in zip(panel,frames)},index=index)
    valid=pd.DataFrame({p:parse_usability(f.UsabilityMask,p) for p,f in zip(panel,frames)},index=index)&np.isfinite(t)&np.isfinite(c)&c.gt(0)
    complete=valid.all(axis=1)
    windows=raw[['ContextWindowKey','ClassStart','ClassEnd','Temperature_mean','CO2_mean','EnvironmentDateKey']].drop_duplicates('ContextWindowKey')
    targeted=pd.Series(False,index=index);source_rows=[];fits=[]
    variants={'median_fixed_panel':panel,'mean_fixed_panel':panel}
    variants.update({'median_without_'+str(p):[x for x in panel if x!=p] for p in panel})
    no_kb=[p for p in panel if not str(p).upper().startswith('KB')]
    if len(no_kb)>=2:variants['median_without_KB']=no_kb
    for name,members in variants.items():
        agg='mean' if name.startswith('mean_') else 'median'
        tt=getattr(t[members],agg)(axis=1).where(complete);cc=getattr(c[members],agg)(axis=1).where(complete)
        pairs=[]
        for r in windows.itertuples(index=False):
            mask=(index>=pd.Timestamp(r.ClassStart))&(index<=pd.Timestamp(r.ClassEnd));targeted.loc[mask]=True
            if not mask.any() or tt.loc[mask].isna().any() or cc.loc[mask].isna().any():raise ValueError('Missing original native bins; sensitivity may not silently change cohort.')
            pairs.append(dict(ContextWindowKey=r.ContextWindowKey,Temperature_mean=float(tt.loc[mask].mean()),CO2_mean=float(cc.loc[mask].mean())))
        values=pd.DataFrame(pairs).set_index('ContextWindowKey')
        sub=raw.copy()
        for col in ['Temperature_mean','CO2_mean']:sub[col]=sub.ContextWindowKey.map(values[col])
        if name=='median_fixed_panel':
            for col in ['Temperature_mean','CO2_mean']:
                if not np.allclose(sub[col],raw[col],rtol=1e-9,atol=1e-7):raise ValueError('Raw fixed-panel reconstruction does not match the frozen main input.')
        for outcome in OUTCOMES:
            print(f'[environment] {name} / {outcome}',flush=True)
            try:
                rr,meta=fit(prepare(sub),outcome,'context_window',reml=True)
                fits.extend(dict(scenario=name,status='passed',**r) for r in fixed_rows(rr,meta))
            except Exception as exc:fits.append(dict(scenario=name,outcome=outcome,status='failed',error=str(exc)))
        source_rows.extend(dict(scenario=name,panel=','.join(members),**r) for r in pairs)
    pd.DataFrame(fits).to_csv(out/'sensor_sensitivity_fixed_effects.csv',index=False)
    pd.DataFrame(source_rows).to_csv(out/'sensor_sensitivity_window_values.csv',index=False)
    # Outdoor observations are diagnostic only: never substituted into a model.
    outdoor=[]
    for key,frame in env.items():
        if 'OutdoorTemperature' in frame:
            outdoor.append(pd.to_numeric(frame.OutdoorTemperature,errors='coerce').reindex(index))
    if not outdoor:raise ValueError('Original OutdoorTemperature column unavailable for diagnostic.')
    for a in outdoor[1:]:
        if not np.allclose(a,outdoor[0],equal_nan=True):raise ValueError('OutdoorTemperature differs across source files; inspect provenance before choosing one.')
    native=pd.DataFrame({'Timestamp':index,'IndoorTemperature':t.median(axis=1).where(complete),'OutdoorTemperature':outdoor[0]})
    native=native.loc[targeted.to_numpy()].dropna().copy()
    native['Date']=pd.to_datetime(native.Timestamp).dt.strftime('%Y-%m-%d')
    rows=[]
    for label,x in [('all_target_native_bins',native)]+[(date,x) for date,x in native.groupby('Date')]:
        rows.append(dict(scope=label,n_native_bins=len(x),pearson_r=x.IndoorTemperature.corr(x.OutdoorTemperature)))
    centered=native[['IndoorTemperature','OutdoorTemperature']]-native.groupby('Date')[['IndoorTemperature','OutdoorTemperature']].transform('mean')
    rows.append(dict(scope='date_demeaned_native_bins',n_native_bins=len(native),pearson_r=centered.IndoorTemperature.corr(centered.OutdoorTemperature)))
    pd.DataFrame(rows).to_csv(out/'indoor_outdoor_correlation.csv',index=False)
    native.to_csv(out/'indoor_outdoor_native_diagnostic.csv',index=False)
    save_json(out/'environment_sources.json',dict(environment_files=inventory,fixed_panel=panel,
              input_summary_sha256=digest(info_path),main_cohort_kept_fixed=True,
              sensitivity_complete_mask='All original fixed-panel members valid; unchanged across sensor variants.',
              correlation_inference='Descriptive correlation only; serial dependence means no iid correlation p-value is reported.'))

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',type=Path,required=True)
    p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--stage',choices=['core','influence','environment','all'],default='core')
    args=p.parse_args(argv);cfg=json.loads(args.config.read_text(encoding='utf-8'))
    if cfg.get('environment_mode')!='school_indoor_context':raise ValueError('Expected indoor-context run_config.json.')
    tables=Path(cfg['table_dir']).resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    if out==tables or tables in out.parents:raise ValueError('Keep audit outputs outside input tables.')
    source=tables/'envphys_session_analysis.csv';raw=read_sessions(source)
    summary=json.loads((tables/'processing_summary.json').read_text(encoding='utf-8'))
    if summary.get('eda_qc',{}).get('max_zero_fraction')!=cfg.get('eda_qc_max_zero_fraction',.95):raise ValueError('QC metadata and source config differ.')
    record=dict(stage=args.stage,status='running',config=cfg,input_sha256=digest(source),N_sessions=len(raw),
                python=sys.version,platform=platform.platform(),packages={n:importlib.metadata.version(n) for n in ['numpy','pandas','scipy','statsmodels','patsy']},
                source_hashes={n.name:digest(n) for n in Path(__file__).parent.glob('revision_*.py')})
    path=out/f'{args.stage}_manifest.json';save_json(path,record)
    try:
        if args.stage in ['core','all']:core(raw,out)
        if args.stage in ['influence','all']:influence(raw,tables,out)
        if args.stage in ['environment','all']:environment(raw,tables,Path(cfg['raw_dir']),out)
        record['status']='completed'
    except BaseException as exc:
        record.update(status='interrupted' if isinstance(exc,KeyboardInterrupt) else 'failed',error=str(exc));raise
    finally:save_json(path,record)
    print('Supplementary audit complete:',out,flush=True)
    return 0
if __name__=='__main__':main()
