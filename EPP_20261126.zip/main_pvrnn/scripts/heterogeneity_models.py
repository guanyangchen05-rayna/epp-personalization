"""Participant heterogeneity checks with explicit boundary-companion models.

Original estimates are retained. Removing a near-zero nuisance variance is a
numerical sensitivity check, never a significance-based model-selection rule.
"""
from __future__ import annotations
import warnings
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy.stats import norm
from revision_models import OUTCOMES, specification

BOUNDARY_RATIO = 1e-6
NUISANCE_COMPONENTS = {'Date', 'ContextWindow'}

def near_zero(values, residual):
    scale = max(float(residual), sum(map(float, values.values())), 1e-12)
    return sorted(k for k, v in values.items() if float(v) <= BOUNDARY_RATIO * scale)

def fit(d, outcome, model, *, slope=False, reml=True, drop=()):
    terms, vc, slope_col = specification(model, slope)
    for name in drop:
        vc.pop(name, None)
    formula = OUTCOMES[outcome] + ' ~ ' + ' + '.join(terms)
    if not vc:
        raise ValueError('At least one random component is required in this audit.')
    m = smf.mixedlm(formula, d, groups=np.ones(len(d)), re_formula='0', vc_formula=vc)
    if np.linalg.matrix_rank(m.exog) < m.exog.shape[1]:
        raise ValueError('Rank-deficient fixed effects: ' + formula)
    attempts = []; candidates = []
    for optimizer in ['lbfgs', 'powell']:
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                r = m.fit(reml=reml, method=optimizer, maxiter=1500, disp=False)
            item = dict(optimizer=optimizer, converged=bool(r.converged), llf=float(r.llf),
                        warnings=list(dict.fromkeys(str(w.message) for w in caught)))
            attempts.append(item)
            if r.converged and np.isfinite(r.llf): candidates.append((r, item))
        except Exception as exc:
            attempts.append(dict(optimizer=optimizer, converged=False, error=str(exc)))
    if not candidates: raise RuntimeError('No converged finite fit: ' + str(attempts))
    r, selected = max(candidates, key=lambda x: x[0].llf)
    values = dict(zip(r.model.exog_vc.names, map(float, r.vcomp)))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        errors = r.bse_fe.copy()
        covariance = r.cov_params().loc[r.fe_params.index, r.fe_params.index].to_numpy()
    eig = np.linalg.eigvalsh(covariance) if np.isfinite(covariance).all() else np.array([np.nan])
    zeros = near_zero(values, r.scale)
    hessian_bad = any('not positive definite' in w for w in selected['warnings'])
    cov_bad = not np.isfinite(eig).all() or float(eig.min()) <= 0
    flags = []
    if zeros: flags.append('variance_boundary')
    if hessian_bad: flags.append('hessian_not_positive_definite')
    if cov_bad: flags.append('fixed_covariance_not_positive_definite')
    if not np.isfinite(errors.to_numpy()).all(): flags.append('unavailable_standard_error')
    meta = dict(model=model, outcome=outcome, slope=bool(slope), reml=bool(reml),
                dropped_components=','.join(sorted(drop)), optimizer=selected['optimizer'],
                converged=True, llf=float(r.llf), AIC=None if reml else float(r.aic),
                N_sessions=len(d), N_participants=d.Pid.nunique(),
                N_dates=d.EnvironmentDateKey.nunique(), N_windows=d.ContextWindowKey.nunique(),
                temperature_slope_predictor=slope_col, variance_components=values,
                residual_variance=float(r.scale), near_zero_components=zeros,
                boundary_ratio=BOUNDARY_RATIO, selected_warnings=selected['warnings'],
                inference_warnings=list(dict.fromkeys(str(w.message) for w in caught)),
                fixed_covariance_min_eigenvalue=float(eig.min()),
                inference_flags=flags, attempts=attempts)
    return r, meta

def fixed_rows(r, meta, variant):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore'); errors = r.bse_fe
    rows = []
    for term, beta in r.fe_params.items():
        se = float(errors[term]); finite = bool(np.isfinite(se) and se > 0)
        p = float(2 * norm.sf(abs(beta / se))) if finite else np.nan
        status = 'unavailable' if not finite else ('diagnostic_flag' if meta['inference_flags'] else 'available_unflagged')
        rows.append(dict(model=meta['model'], outcome=meta['outcome'], slope=meta['slope'],
                         reml=True, variant=variant, predictor=term, beta=float(beta), SE=se,
                         p=p, ci95_low=float(beta-1.95996398454*se),
                         ci95_high=float(beta+1.95996398454*se),
                         numerical_interval_available=finite, wald_status=status,
                         inference_flags=';'.join(meta['inference_flags']),
                         dropped_components=meta['dropped_components']))
    return rows

def adjust_environment_families(df):
    """Planned 6/12-test families, including absent boundary companions."""
    df=df.copy();df['q_BH_FDR']=np.nan;df['FDR_family_size']=0
    for _,g in df.groupby(['model','slope','variant'],dropna=False):
        terms=['Temperature_z','CO2_z'] if g.model.iloc[0]!='within_between_window_time' else [
            'Temperature_between_z','Temperature_within_z','CO2_between_z','CO2_within_z']
        idx=g.index[g.predictor.isin(terms)];planned=3*len(terms)
        values=df.loc[idx,'p'].to_numpy();padded=np.ones(planned)
        padded[:len(values)]=np.where(np.isfinite(values),values,1.)
        order=np.argsort(padded)
        q=np.minimum.accumulate((padded[order]*planned/np.arange(1,planned+1))[::-1])[::-1]
        restored=np.empty(planned);restored[order]=np.minimum(q,1)
        df.loc[idx,'q_BH_FDR']=np.where(np.isfinite(values),restored[:len(values)],np.nan)
        df.loc[idx,'FDR_family_size']=planned
    return df

def variance_rows(meta, variant):
    values = meta['variance_components'] | {'Residual':meta['residual_variance']}
    return [dict(model=meta['model'], outcome=meta['outcome'], slope=meta['slope'],
                 variant=variant, component=k, variance=v,
                 intercept_model_variance_proportion=v/sum(values.values()) if not meta['slope'] else np.nan,
                 inference_flags=';'.join(meta['inference_flags'])) for k,v in values.items()]

def participant_rows(r, d, meta, variant, component='PidIntercept'):
    """Conditional empirical Bayes deviations; not participant-level tests."""
    if component not in meta['variance_components']: return []
    effect = next(iter(r.random_effects.values()))
    covariance = next(iter(r.random_effects_cov.values()))
    rows = []
    for number, pid in enumerate(sorted(d.Pid.unique(), key=lambda p:(len(str(p)),str(p))), 1):
        marker = f'C(Pid)[{pid}]'
        keys = [k for k in effect.index if k.startswith(component+'[') and marker in k]
        if len(keys) != 1: raise ValueError(f'Ambiguous {component} for {pid}: {keys}')
        k = keys[0]; diagonal = float(covariance.loc[k,k])
        se = float(np.sqrt(diagonal)) if diagonal >= 0 else np.nan
        sub = d.loc[d.Pid.eq(pid)]; col = meta['temperature_slope_predictor']
        informative = len(sub)>1 and sub[col].nunique()>1 if component=='PidTempSlope' else len(sub)>1
        rows.append(dict(model=meta['model'], outcome=meta['outcome'], variant=variant,
                         component=component, Pid=pid, display_id=f'P{number:02}',
                         deviation=float(effect[k]), conditional_random_effect_SE=se,
                         conditional_low=float(effect[k])-1.96*se, conditional_high=float(effect[k])+1.96*se,
                         n_sessions=len(sub), n_dates=sub.EnvironmentDateKey.nunique(),
                         informs_repeated_measure_difference=bool(informative)))
    return rows

def compare(d, outcome, model, contrast, *, drop=(), full=None):
    """ML comparisons keep rows, fixed effects and nuisance structure identical."""
    slope = contrast == 'temperature_slope'
    if contrast not in ['participant_intercept','temperature_slope']: raise ValueError(contrast)
    if full is None: full = fit(d,outcome,model,slope=slope,reml=False,drop=drop)
    if contrast=='participant_intercept':
        reduced = fit(d,outcome,model,reml=False,drop=tuple(drop)+('PidIntercept',))
    else:
        reduced = fit(d,outcome,model,reml=False,drop=drop)
    a, b = full[1], reduced[1]
    delta = a['AIC']-b['AIC']; lr = 2*(a['llf']-b['llf'])
    row = dict(model=model,outcome=outcome,contrast=contrast,N_sessions=len(d),
               N_participants=d.Pid.nunique(),N_dates=d.EnvironmentDateKey.nunique(),
               N_windows=d.ContextWindowKey.nunique(),dropped_nuisance_components=','.join(sorted(drop)),
               AIC_with_component=a['AIC'],AIC_without_component=b['AIC'],delta_AIC=delta,
               likelihood_ratio=lr, nested_likelihood_order_valid=bool(lr>=-1e-4),
               with_component_flags=';'.join(a['inference_flags']),
               without_component_flags=';'.join(b['inference_flags']),
               AIC_favors_component=bool(delta<0),AIC_improvement_at_least_2=bool(delta<=-2))
    return row, [a,b]
