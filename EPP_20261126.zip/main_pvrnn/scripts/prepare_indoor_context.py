"""Prepare shared INDOOR context from original dated dataset files.

No physical room-to-sensor assignment is inferred. A fixed sensor panel is
selected using original class times, source quality flags and numeric validity
only. No physiology, survey, outcome or model result enters panel selection.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from prepare_classroom_mapping import load_classes, load_environment, locate, digest

CONTEXT_ID = 'POOLED_INDOOR'
DEFAULT_ROOMS = ('R1', 'R2', 'R3', 'R4', 'R5')

def parse_usability(values, sensor):
    normalized = values.astype('string').str.strip().str.lower()
    bad = normalized.notna() & ~normalized.isin(['true', 'false', '1', '0'])
    if bad.any():
        raise ValueError(f'{sensor}: invalid UsabilityMask values; expected True/False or 1/0.')
    return normalized.isin(['true', '1']).fillna(False)

def pool_environment(environment, classes, rooms=DEFAULT_ROOMS, minimum_sensors=4, aggregation='median'):
    if aggregation not in ('median', 'mean') or type(minimum_sensors) is not int or minimum_sensors < 2:
        raise ValueError('Choose median/mean and minimum_sensors >= 2.')
    rooms = tuple(rooms)
    if not rooms or any(str(r).strip().lower() in ('out', 'outdoor', 'outside') for r in rooms):
        raise ValueError('included_rooms must be a nonempty explicit set of indoor room labels.')
    names = sorted(environment)
    index = pd.DatetimeIndex(sorted(set().union(*(set(d.index) for d in environment.values()))))
    if len(index) == 0:
        raise ValueError('No dated native environmental records.')
    # This adapter requires native five-minute timestamps; it never invents dates.
    if ((index.second != 0) | (index.microsecond != 0) | (index.minute % 5 != 0)).any():
        raise ValueError('Expected original five-minute environmental timestamps.')
    grid = pd.date_range(index.min(), index.max(), freq='5min')
    target = classes[classes.Room.astype(str).isin(rooms)]
    relevant = pd.Series(False, index=grid)
    covered_class_ids = []
    for r in target.itertuples(index=False):
        if r.start_dt < grid.min() or r.end_dt > grid.max():
            continue
        # Include class endpoints and the immediately preceding native interval,
        # matching the established preprocessing context and QC boundaries.
        lo = (r.start_dt - pd.Timedelta(minutes=5)).floor('5min')
        hi = r.end_dt.ceil('5min')
        relevant.loc[(grid >= lo) & (grid <= hi)] = True
        covered_class_ids.append(r.Class_id)
    if not relevant.any():
        raise ValueError('No selected classroom dates overlap the dated environmental records.')
    temperature = pd.DataFrame(index=grid)
    co2 = pd.DataFrame(index=grid)
    valid = pd.DataFrame(index=grid)
    inventory = []
    for name in names:
        d = environment[name]
        if 'UsabilityMask' not in d:
            raise ValueError(f'{name}: UsabilityMask is required; it is never assumed to be True.')
        t = pd.to_numeric(d.IndoorTemperature, errors='coerce').reindex(grid)
        c = pd.to_numeric(d.IndoorCO2, errors='coerce').reindex(grid)
        usable = parse_usability(d.UsabilityMask, name).reindex(grid, fill_value=False)
        ok = usable & np.isfinite(t) & np.isfinite(c) & c.gt(0)
        temperature[name] = t
        co2[name] = c
        valid[name] = ok
        n = int(ok.loc[relevant].sum())
        inventory.append({'SensorCSV': name, 'n_native_rows': len(d),
                          'n_quality_valid_native_rows': int(ok.sum()),
                          'n_target_context_bins': int(relevant.sum()),
                          'n_valid_target_context_bins': n,
                          'included_in_fixed_panel': bool(ok.loc[relevant].all())})
    panel = [name for name in names if valid.loc[relevant, name].all()]
    if len(panel) < minimum_sensors:
        raise ValueError(f'Only {len(panel)} sensors are valid throughout the selected class context; '
                         f'fixed panel requires at least {minimum_sensors}. Do not lower this using model outcomes.')
    t = temperature[panel].where(valid[panel])
    c = co2[panel].where(valid[panel])
    n_valid = valid[panel].sum(axis=1)
    # Fixed composition: all panel members must be available. A bad record is
    # retained as a missing pooled value, never filled from a previous timestamp.
    complete = n_valid.eq(len(panel))
    aggregate = lambda frame: getattr(frame, aggregation)(axis=1).where(complete)
    pooled = pd.DataFrame({'Timestamp': grid,
                           'IndoorTemperature': aggregate(t).to_numpy(),
                           'IndoorCO2': aggregate(c).to_numpy(),
                           'n_valid_panel_sensors': n_valid.to_numpy(),
                           'panel_size': len(panel),
                           'Temperature_IQR': (t.quantile(.75, axis=1)-t.quantile(.25, axis=1)).where(complete).to_numpy(),
                           'CO2_IQR': (c.quantile(.75, axis=1)-c.quantile(.25, axis=1)).where(complete).to_numpy(),
                           'ContextQualityValid': complete.to_numpy()})
    output = classes.copy()
    statuses = []
    for r in output.itertuples(index=False):
        if str(r.Room) not in rooms:
            statuses.append('EXCLUDED_ROOM_SCOPE')
        elif r.start_dt < grid.min() or r.end_dt > grid.max():
            statuses.append('NO_ENVIRONMENT_DATE_COVERAGE')
        else:
            statuses.append('SHARED_INDOOR_CONTEXT')
    output['Matched_CSV'] = [CONTEXT_ID if s == 'SHARED_INDOOR_CONTEXT' else None for s in statuses]
    output['Confidence'] = np.nan
    output['MappingStatus'] = statuses
    output['MappingSource'] = ['Fixed-panel shared indoor context; no physical classroom mapping' if s == 'SHARED_INDOOR_CONTEXT' else '' for s in statuses]
    output['EnvironmentScope'] = 'school_indoor_context'
    metadata = {'environment_mode': 'school_indoor_context', 'environment_type': 'INDOOR',
                'room_mapping_used': False, 'individual_room_exposure_measured': False,
                'aggregation': aggregation, 'panel_policy': 'fixed_quality_complete_panel',
                'minimum_sensors_required': minimum_sensors, 'fixed_panel': panel,
                'panel_size': len(panel), 'included_rooms': list(rooms),
                'panel_selection_uses_outcomes_or_physiology': False,
                'n_classes': len(output), 'n_context_eligible_classes': len(covered_class_ids),
                'n_target_context_bins': int(relevant.sum()),
                'class_status_counts': output.MappingStatus.value_counts().to_dict(),
                'note': 'Shared monitored-school indoor background, not individual classroom exposure. '
                        'Original data may already contain author interpolation within usable days; no additional interpolation is performed.'}
    return output, pooled, pd.DataFrame(inventory), metadata

def prepare(base_dir, output_dir, class_table=None, rooms=DEFAULT_ROOMS, minimum_sensors=4, aggregation='median'):
    base_dir, output_dir = Path(base_dir).resolve(), Path(output_dir).resolve()
    table = Path(class_table) if class_table else locate(base_dir, ('Participant_class_info', 'participant_class_info', '.'), ('Class_table.csv', 'class_table.csv'))
    if table.name.casefold() == 'classroom_data.csv':
        raise ValueError('Use the original dated Class_table.csv, not a derived mapping.')
    classes = load_classes(table)
    longitudinal = locate(base_dir, ('.',), ('Longitudinal', 'longitudinal'), directory=True)
    environment, records, ignored = load_environment(longitudinal)
    output, pooled, sensor_qc, summary = pool_environment(environment, classes, rooms, minimum_sensors, aggregation)
    output_dir.mkdir(parents=True, exist_ok=True)
    output.to_csv(output_dir / 'Classroom_Data.csv', index=False)
    pooled.to_csv(output_dir / f'{CONTEXT_ID}.csv', index=False)
    sensor_qc.to_csv(output_dir / 'indoor_sensor_qc.csv', index=False)
    pd.DataFrame(records).to_csv(output_dir / 'environment_inventory.csv', index=False)
    issues = []
    if {'Week','Weekday'}.issubset(classes):
        for (week, weekday), group in classes.groupby(['Week','Weekday']):
            if group.start_dt.dt.normalize().nunique() > 1:
                issues.append({'Week':str(week), 'Weekday':str(weekday), 'Class_ids':group.Class_id.tolist(), 'dates':sorted(group.start_dt.dt.strftime('%Y-%m-%d').unique())})
    summary['raw_week_date_inconsistencies'] = issues
    summary.update(class_table_source=str(table.resolve()), class_table_sha256=digest(table),
                   environment_files=records, ignored_non_environment_csvs=ignored)
    summary['pooled_series_sha256'] = digest(output_dir / f'{CONTEXT_ID}.csv')
    (output_dir / 'indoor_context_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: summary[k] for k in ('environment_type', 'aggregation', 'fixed_panel', 'panel_size', 'n_context_eligible_classes', 'class_status_counts')}, indent=2))
    print('Prepared shared indoor context:', output_dir)
    return output, summary

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base-dir', type=Path, required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--class-table', type=Path)
    p.add_argument('--rooms', default=','.join(DEFAULT_ROOMS))
    p.add_argument('--minimum-sensors', type=int, default=4)
    p.add_argument('--aggregation', choices=('median', 'mean'), default='median')
    a = p.parse_args()
    prepare(a.base_dir, a.output_dir, a.class_table, tuple(v.strip() for v in a.rooms.split(',') if v.strip()), a.minimum_sensors, a.aggregation)

if __name__ == '__main__':
    main()
