"""Small pandas-only checks shared by the indoor-context model entry points."""
import pandas as pd


def validate_context_table(frame):
    needed = {'EnvironmentScope', 'EnvironmentDateKey', 'ClassStart', 'Room'}
    if not needed.issubset(frame):
        raise ValueError(f'Not an indoor-context table; missing {sorted(needed-set(frame))}.')
    if frame.empty or not frame.EnvironmentScope.eq('school_indoor_context').all():
        raise ValueError('Expected nonempty shared indoor context tables.')
    date = pd.to_datetime(frame.ClassStart, errors='raise').dt.strftime('DATE__%Y-%m-%d')
    if not frame.EnvironmentDateKey.eq(date).all():
        raise ValueError('EnvironmentDateKey must agree with ClassStart calendar date.')


def validate_fold_coverage(folds, beh, protocol):
    if not folds:
        raise ValueError(f'{protocol}: no valid folds; too few sessions/groups for evaluation.')
    test_indices = []
    for fold in folds:
        train, test = fold['train_idx'], fold['test_idx']
        if set(train) & set(test):
            raise ValueError('Train/test session overlap.')
        column = 'Pid' if protocol == 'PARTICIPANT_LOO' else 'EnvironmentDateKey'
        if set(beh.loc[train, column]) & set(beh.loc[test, column]):
            raise ValueError(f'{protocol}: held-out group enters training.')
        test_indices.extend(test)
    if sorted(test_indices) != sorted(beh.index.tolist()):
        raise ValueError(f'{protocol}: folds do not predict each behavior session exactly once. '
                         'A held-out group may leave fewer than five training sessions.')
