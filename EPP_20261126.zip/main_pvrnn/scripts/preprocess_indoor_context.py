"""Apply established class-local physiology/survey preprocessing to indoor context."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import pandas as pd
import preprocess_sessions as core
from prepare_indoor_context import CONTEXT_ID
from eda_session_qc import apply_eda_session_qc, DEFAULT_MAX_ZERO_FRACTION


def preprocess(base_dir, output_dir, input_dir, eda_max_zero_fraction=DEFAULT_MAX_ZERO_FRACTION):
    base_dir, output_dir, input_dir = map(Path, (base_dir, output_dir, input_dir))
    info = json.loads((input_dir / 'indoor_context_summary.json').read_text(encoding='utf-8'))
    if info.get('environment_mode') != 'school_indoor_context' or info.get('room_mapping_used') is not False:
        raise ValueError('Expected newly prepared shared indoor context, not historical room mapping.')
    original_cache = core.EnvironmentCache
    original_builder = core.build_session_master
    class IndoorContextCache(original_cache):
        def __init__(self, longitudinal_dir):
            # Read generated context only; never write a fake source into raw data.
            super().__init__(input_dir)
        def load(self, sensor_name):
            if core.clean_id(sensor_name) not in (None, CONTEXT_ID):
                raise ValueError('Unexpected individual sensor in shared-context input.')
            return super().load(sensor_name)
    def build_quality_screened_master(merged_1s, class_env_summary, strict_labels):
        master = original_builder(merged_1s, class_env_summary, strict_labels)
        return apply_eda_session_qc(master, merged_1s, eda_max_zero_fraction)
    core.EnvironmentCache = IndoorContextCache
    core.build_session_master = build_quality_screened_master
    try:
        core.main(base_dir=base_dir, output_dir=output_dir,
                  classroom_table=input_dir / 'Classroom_Data.csv')
    finally:
        core.EnvironmentCache = original_cache
        core.build_session_master = original_builder
    classes = pd.read_csv(input_dir / 'Classroom_Data.csv', dtype={'Class_id': str})
    room_by_class = classes.set_index('Class_id').Room
    for name in ('session_master.csv', 'envphys_session_analysis.csv',
                 'behavior_session_analysis.csv', 'behavior_temporal_1s.csv'):
        path = output_dir / name
        try:
            d = pd.read_csv(path, dtype={'Pid': str, 'Class_id': str})
        except pd.errors.EmptyDataError:
            raise ValueError(f'{name} is empty: inspect 00_qc before fitting models.')
        if d.empty:
            raise ValueError(f'No rows in {name}: inspect 00_qc before fitting models.')
        d['Room'] = d.Class_id.map(room_by_class)
        if not d.Room.isin(info['included_rooms']).all():
            raise ValueError('Excluded room entered the analytical tables.')
        d['EnvironmentScope'] = 'school_indoor_context'
        d['EnvironmentDateKey'] = pd.to_datetime(d.ClassStart).dt.strftime('DATE__%Y-%m-%d')
        if 'EnvironmentEpisodeKey' in d:
            d['ContextWindowKey'] = d.EnvironmentEpisodeKey
        d.to_csv(path, index=False)
    summary_path = output_dir / 'processing_summary.json'
    summary = json.loads(summary_path.read_text(encoding='utf-8'))
    master = pd.read_csv(output_dir / 'session_master.csv')
    audit_columns = ['Pid','Class_id','Room','ClassStart','ClassEnd',
                     'EDA_QC_n_complete_seconds','EDA_zero_seconds','EDA_zero_fraction',
                     'EDA_longest_zero_run_seconds','EDA_QC_pass','EDA_QC_status',
                     'EnvPhysReady_before_EDA_QC','StrictBehaviorReady_before_EDA_QC',
                     'EnvPhysReady','StrictBehaviorReady']
    audit = master[audit_columns].copy()
    audit.to_csv(output_dir / '00_qc/eda_session_qc.csv', index=False)
    removed = audit[audit.EnvPhysReady_before_EDA_QC & ~audit.EDA_QC_pass]
    removed.to_csv(output_dir / '00_qc/excluded_eda_sessions.csv', index=False)
    beh = pd.read_csv(output_dir / 'behavior_session_analysis.csv')
    env = pd.read_csv(output_dir / 'envphys_session_analysis.csv')
    summary.update(environment_type='INDOOR', environment_scope='school_indoor_context',
                   room_mapping_used=False, individual_room_exposure_measured=False,
                   indoor_context_aggregation=info['aggregation'], fixed_sensor_panel=info['fixed_panel'],
                   included_rooms=info['included_rooms'],
                   n_envphys_dates=int(env.EnvironmentDateKey.nunique()),
                   n_behavior_dates=int(beh.EnvironmentDateKey.nunique()),
                   n_envphys_context_windows=int(env.EnvironmentEpisodeKey.nunique()),
                   n_behavior_context_windows=int(beh.EnvironmentEpisodeKey.nunique()),
                   mixedlm_context_group='EnvironmentDateKey (shared calendar date)',
                   pvrnn_context_holdout='DATE_LOO; all sessions on a test date excluded from training')
    summary['eda_qc'] = {
        'enabled': eda_max_zero_fraction is not None,
        'rule': 'Exclude whole session when exact-zero EDA fraction among jointly complete 1-s records is >= threshold.',
        'max_zero_fraction': eda_max_zero_fraction,
        'threshold_origin': 'Operational rule specified during data review, not preregistered or a universal sensor cutoff.',
        'uses_behavior_labels_or_model_results': False,
        'retained_signal_values_changed': False,
        'n_envphys_sessions_before_qc': int(master.EnvPhysReady_before_EDA_QC.sum()),
        'n_behavior_sessions_before_qc': int(master.StrictBehaviorReady_before_EDA_QC.sum()),
        'n_envphys_sessions_excluded_by_eda': int(len(removed)),
        'n_behavior_sessions_excluded_by_eda': int((master.StrictBehaviorReady_before_EDA_QC & ~master.EDA_QC_pass).sum()),
        'excluded_envphys_session_keys': removed[['Pid','Class_id']].to_dict('records')
    }
    summary['core_logic']['physiology'] += ' Whole-session EDA zero-value QC is applied before both model cohorts.'
    summary['core_logic']['environment'] = 'Clock-time alignment to fixed-panel INDOOR context; no physical room mapping; no additional interpolation.'
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print('\nINDOOR context preprocessing complete.')
    print(json.dumps({k: summary[k] for k in ('n_envphys_ready_sessions', 'n_strict_behavior_sessions', 'n_behavior_temporal_rows', 'n_envphys_dates', 'n_behavior_dates', 'fixed_sensor_panel')}, indent=2))

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base-dir', type=Path, required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--input-dir', type=Path, required=True)
    p.add_argument('--eda-max-zero-fraction', type=float, default=DEFAULT_MAX_ZERO_FRACTION)
    p.add_argument('--no-eda-qc', action='store_true', help='Explicit unfiltered comparator; use a separate run directory.')
    a = p.parse_args()
    preprocess(a.base_dir, a.output_dir, a.input_dir, None if a.no_eda_qc else a.eda_max_zero_fraction)
