"""Session-level EDA zero-value screen, independent of behavioral outcomes.

The default 95% threshold is an operational rule chosen during data review,
not a universal or preregistered sensor-quality threshold. This screen does
not classify all possible motion/contact artifacts. Retained signals are not
changed, interpolated, clipped or filled.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

DEFAULT_MAX_ZERO_FRACTION = 0.95


def apply_eda_session_qc(master, merged_1s, max_zero_fraction=DEFAULT_MAX_ZERO_FRACTION):
    if max_zero_fraction is not None and not (0 < float(max_zero_fraction) <= 1):
        raise ValueError('EDA zero-fraction threshold must be in (0,1], or None for the unfiltered comparator.')
    rows = []
    for (pid, cid), frame in merged_1s.groupby(['Pid','Class_id'], sort=False):
        d = frame.loc[frame.HasCoreEnvironmentPhysiology].sort_values('DateTime')
        zero = d.EDA.eq(0)
        n = len(d)
        fraction = float(zero.mean()) if n else np.nan
        boundary = zero.ne(zero.shift()) | pd.to_datetime(d.DateTime).diff().dt.total_seconds().ne(1)
        runs = d.loc[zero].groupby(boundary.cumsum().loc[zero]).size()
        longest = int(runs.max()) if len(runs) else 0
        passed = bool(n > 0 and (max_zero_fraction is None or fraction < max_zero_fraction))
        status = ('NO_COMPLETE_SECONDS' if n==0 else 'NOT_FILTERED_COMPARATOR' if max_zero_fraction is None
                  else 'EXCLUDE_EDA_MOSTLY_ZERO' if not passed else 'PASS_ZERO_VALUE_SCREEN')
        rows.append({'Pid':str(pid),'Class_id':str(cid),'EDA_QC_n_complete_seconds':n,
                     'EDA_zero_seconds':int(zero.sum()),'EDA_zero_fraction':fraction,
                     'EDA_longest_zero_run_seconds':longest,'EDA_QC_pass':passed,'EDA_QC_status':status})
    out = master.copy()
    out['Pid'] = out.Pid.astype(str)
    out['Class_id'] = out.Class_id.astype(str)
    out['EnvPhysReady_before_EDA_QC'] = out.EnvPhysReady
    out['StrictBehaviorReady_before_EDA_QC'] = out.StrictBehaviorReady
    audit = pd.DataFrame(rows)
    out = out.merge(audit, on=['Pid','Class_id'], how='left', validate='one_to_one')
    if out.EDA_QC_pass.isna().any():
        raise ValueError('Missing EDA quality audit for a session.')
    out['EnvPhysReady'] = out.EnvPhysReady & out.EDA_QC_pass
    out['StrictBehaviorReady'] = out.StrictBehaviorReady & out.EDA_QC_pass
    return out
