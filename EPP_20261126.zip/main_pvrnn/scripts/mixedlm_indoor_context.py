"""Environment--Physiology MixedLM with a participant temperature random slope.

This script is a standalone companion to the frozen PV-RNN analysis. It uses
the session-level Environment--Physiology table and fits, separately for EDA,
HR, and SkinTEMP:

    random-intercept model
        physiology ~ Temperature + CO2
        + participant random intercept
        + environment-date random intercept

    temperature-random-slope model
        physiology ~ Temperature + CO2
        + participant random intercept
        + participant-specific Temperature slope
        + environment-date random intercept

The random-intercept model is the primary analysis and is fitted with restricted
maximum likelihood (REML). The two random-effect structures are also fitted
with maximum likelihood (ML) and compared using AIC. The temperature-random-
slope model is finally refitted with REML as a sensitivity analysis.

Only Temperature receives a participant random slope. This follows the prior
analysis plan: Temperature was the focal environmental exposure and showed the
clearest Environment--Physiology signal, whereas CO2 effects were weak. Adding
both slopes would be difficult to support with 22 participants and uneven
within-participant exposure.

Expected input columns
----------------------
Pid, Class_id, EnvironmentDateKey, Temperature_mean, CO2_mean,
EDA_mean, HR_mean, SkinTEMP_mean

Optional input column
---------------------
n_complete_env_phys_seconds (rows below 300 seconds are removed)

Example
-------
python mixedlm_temperature_random_slope.py \
    --input-dir final_simple_tables \
    --output-dir mixedlm_random_slope_outputs
"""

from __future__ import annotations
from indoor_context_checks import validate_context_table

import argparse
import json
import re
import warnings
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
import statsmodels.formula.api as smf
from statsmodels.tools.sm_exceptions import ConvergenceWarning


MIN_COMPLETE_SECONDS = 300

MODEL_SPECS = {
    "EDA": "EDA_model_z ~ Temperature_mean_z + CO2_mean_z",
    "HR": "HR_mean_z ~ Temperature_mean_z + CO2_mean_z",
    "SkinTEMP": "SkinTEMP_mean_z ~ Temperature_mean_z + CO2_mean_z",
}

REQUIRED_COLUMNS = {
    "Pid",
    "Class_id",
    "EnvironmentDateKey",
    "Temperature_mean",
    "CO2_mean",
    "EDA_mean",
    "HR_mean",
    "SkinTEMP_mean",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Fit Environment--Physiology MixedLMs with an exploratory "
            "participant-specific Temperature random slope."
        )
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--input",
        type=Path,
        help="Path to envphys_session_analysis.csv.",
    )
    source.add_argument(
        "--input-dir",
        type=Path,
        help=(
            "Directory containing envphys_session_analysis.csv. If the exact "
            "name is absent, one envphys_session_analysis*.csv file is accepted."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("mixedlm_random_slope_outputs"),
        help="Directory for CSV and JSON outputs.",
    )
    parser.add_argument(
        "--show-original-ids",
        action="store_true",
        help=(
            "Show the original participant and date IDs in the figure. "
            "The default is anonymized P01/E01 labels."
        ),
    )
    return parser.parse_args()


def resolve_input_path(
    input_file: Optional[Path], input_dir: Optional[Path]
) -> Path:
    """Resolve either an explicit CSV path or a directory containing the CSV."""
    if input_file is not None:
        if not input_file.is_file():
            raise FileNotFoundError(f"Input file not found: {input_file}")
        return input_file

    if input_dir is None:
        raise ValueError("Provide either --input or --input-dir.")
    if not input_dir.is_dir():
        raise NotADirectoryError(f"Input directory not found: {input_dir}")

    exact = input_dir / "envphys_session_analysis.csv"
    if exact.is_file():
        return exact

    candidates = sorted(input_dir.glob("envphys_session_analysis*.csv"))
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise FileNotFoundError(
            "No envphys_session_analysis.csv or "
            f"envphys_session_analysis*.csv found in: {input_dir}"
        )

    names = ", ".join(path.name for path in candidates)
    raise RuntimeError(
        "Multiple candidate input files were found. Use --input to select one: "
        f"{names}"
    )


def zscore(series: pd.Series) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce").astype(float)
    mean = values.mean()
    sd = values.std(ddof=0)
    if not np.isfinite(sd) or sd <= 1e-12:
        raise ValueError(f"Cannot standardize {series.name}: SD is zero or missing.")
    return (values - mean) / sd


def benjamini_hochberg(p_values: Iterable[float]) -> np.ndarray:
    p = np.asarray(list(p_values), dtype=float)
    if p.ndim != 1 or len(p) == 0 or not np.isfinite(p).all():
        raise ValueError("BH-FDR requires a non-empty set of finite p-values.")

    order = np.argsort(p)
    ranked = p[order]
    adjusted = ranked * len(p) / np.arange(1, len(p) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0.0, 1.0)

    result = np.empty_like(adjusted)
    result[order] = adjusted
    return result


def load_and_prepare(path: Path) -> pd.DataFrame:
    data = pd.read_csv(path)
    validate_context_table(data)
    missing = REQUIRED_COLUMNS.difference(data.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    data = data.copy()
    data["Pid"] = data["Pid"].astype(str)
    data["Class_id"] = data["Class_id"].astype(str)
    data["EnvironmentDateKey"] = data["EnvironmentDateKey"].astype(str)

    if "n_complete_env_phys_seconds" in data.columns:
        complete_seconds = pd.to_numeric(
            data["n_complete_env_phys_seconds"], errors="coerce"
        )
        data = data.loc[complete_seconds >= MIN_COMPLETE_SECONDS].copy()

    numeric_columns = [
        "Temperature_mean",
        "CO2_mean",
        "EDA_mean",
        "HR_mean",
        "SkinTEMP_mean",
    ]
    for column in numeric_columns:
        data[column] = pd.to_numeric(data[column], errors="coerce")

    data = data.dropna(subset=list(REQUIRED_COLUMNS)).copy()
    if data.empty:
        raise ValueError("No complete sessions remain after filtering.")

    # One participant-by-class row is the independent session-level unit.
    if data.duplicated(["Pid", "Class_id"]).any():
        duplicate_count = int(data.duplicated(["Pid", "Class_id"]).sum())
        raise ValueError(
            f"Found {duplicate_count} duplicate Pid x Class_id rows. "
            "The MixedLM input must contain one row per session."
        )

    data["EDA_model"] = np.log1p(data["EDA_mean"].clip(lower=0.0))
    data["Temperature_mean_z"] = zscore(data["Temperature_mean"])
    data["CO2_mean_z"] = zscore(data["CO2_mean"])
    data["EDA_model_z"] = zscore(data["EDA_model"])
    data["HR_mean_z"] = zscore(data["HR_mean"])
    data["SkinTEMP_mean_z"] = zscore(data["SkinTEMP_mean"])

    return data.reset_index(drop=True)


def participant_coverage(data: pd.DataFrame) -> pd.DataFrame:
    coverage = (
        data.groupby("Pid", as_index=False)
        .agg(
            n_sessions=("Class_id", "size"),
            n_dates=("EnvironmentDateKey", "nunique"),
            Temperature_min=("Temperature_mean", "min"),
            Temperature_max=("Temperature_mean", "max"),
            CO2_min=("CO2_mean", "min"),
            CO2_max=("CO2_mean", "max"),
        )
    )
    coverage["Temperature_range"] = (
        coverage["Temperature_max"] - coverage["Temperature_min"]
    )
    coverage["CO2_range"] = coverage["CO2_max"] - coverage["CO2_min"]
    coverage["has_repeated_sessions"] = coverage["n_sessions"] >= 2
    coverage["has_within_person_temperature_variation"] = (
        coverage["Temperature_range"] > 1e-8
    )
    coverage["can_inform_temperature_slope"] = (
        coverage["has_repeated_sessions"]
        & coverage["has_within_person_temperature_variation"]
    )
    return coverage


def random_effect_formulas(include_temperature_slope: bool) -> Dict[str, str]:
    formulas = {
        "Date": "0 + C(EnvironmentDateKey)",
        "PidIntercept": "0 + C(Pid)",
    }
    if include_temperature_slope:
        # Independent participant-specific slope deviations with one shared
        # variance parameter. No intercept--slope covariance is estimated.
        formulas["PidTempSlope"] = "0 + C(Pid):Temperature_mean_z"
    return formulas


def fit_with_optimizers(
    formula: str,
    data: pd.DataFrame,
    variance_components: Dict[str, str],
    *,
    reml: bool,
) -> Tuple[object, str]:
    model = smf.mixedlm(
        formula,
        data=data,
        groups=np.ones(len(data)),
        re_formula="0",
        vc_formula=variance_components,
    )

    last_result = None
    last_method = "none"
    for method in ("powell", "lbfgs", "cg"):
        try:
            with warnings.catch_warnings():
                # A near-zero slope variance often places the estimate on the
                # parameter boundary; we report that estimate rather than
                # treating the warning itself as model support or failure.
                warnings.simplefilter("ignore", ConvergenceWarning)
                result = model.fit(
                    reml=reml,
                    method=method,
                    maxiter=3000,
                    disp=False,
                )
            last_result = result
            last_method = method
            if result.converged:
                return result, method
        except Exception:
            continue

    if last_result is None:
        fit_type = "REML" if reml else "ML"
        raise RuntimeError(f"{fit_type} MixedLM failed for formula: {formula}")

    return last_result, f"{last_method}_not_flagged_converged"


def variance_component_map(result) -> Dict[str, float]:
    names = list(getattr(result.model.exog_vc, "names", []))
    values = list(np.asarray(result.vcomp, dtype=float))
    return {str(name): float(value) for name, value in zip(names, values)}


def extract_temperature_slopes(
    result,
    fixed_temperature_beta: float,
) -> pd.DataFrame:
    """Return shrinkage estimates of participant-specific Temperature slopes."""
    if not result.random_effects:
        return pd.DataFrame()

    # All variance components are represented under one top-level group because
    # crossed participant and date effects are specified through vc_formula.
    random_effects = next(iter(result.random_effects.values()))
    rows = []

    for name, deviation in random_effects.items():
        name = str(name)
        if not name.startswith("PidTempSlope["):
            continue

        match = re.search(r"C\(Pid\)\[([^\]]+)\]", name)
        if match is None:
            continue

        participant = match.group(1)
        deviation = float(deviation)
        rows.append(
            {
                "Pid": str(participant),
                "fixed_temperature_beta": float(fixed_temperature_beta),
                "random_temperature_slope_deviation": deviation,
                "participant_temperature_slope": (
                    float(fixed_temperature_beta) + deviation
                ),
            }
        )

    return pd.DataFrame(rows)


def _extract_factor_level(effect_name: str, factor: str) -> Optional[str]:
    """Extract a categorical level from a statsmodels variance-component name."""
    match = re.search(
        rf"C\({re.escape(factor)}\)\[(?:T\.)?([^\]]+)\]",
        str(effect_name),
    )
    return None if match is None else str(match.group(1))


def extract_random_intercepts(result, outcome: str) -> pd.DataFrame:
    """Extract participant and date BLUPs from the primary REML model."""
    if not result.random_effects:
        return pd.DataFrame()

    # Crossed effects were fitted as variance components under one top-level
    # group, so all participant and date estimates are in this one Series.
    effects = next(iter(result.random_effects.values()))
    rows = []

    for effect_name, estimate in effects.items():
        effect_name = str(effect_name)
        estimate = float(np.asarray(estimate).squeeze())

        if effect_name.startswith("PidIntercept["):
            level = _extract_factor_level(effect_name, "Pid")
            group_type = "Participant"
        elif effect_name.startswith("Date["):
            level = _extract_factor_level(
                effect_name, "EnvironmentDateKey"
            )
            group_type = "Environment date"
        else:
            continue

        if level is None:
            raise RuntimeError(
                "Could not parse a random-intercept level from: "
                f"{effect_name}"
            )

        rows.append(
            {
                "outcome": outcome,
                "group_type": group_type,
                "group_id": level,
                "random_intercept": estimate,
            }
        )

    return pd.DataFrame(rows)


def _natural_sort_key(value: str):
    return [
        int(piece) if piece.isdigit() else piece.lower()
        for piece in re.split(r"(\d+)", str(value))
    ]


def prepare_random_intercept_outputs(
    intercepts: pd.DataFrame,
    data: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Add coverage counts and stable anonymous labels for plotting."""
    participant = intercepts.loc[
        intercepts["group_type"] == "Participant"
    ].copy()
    date = intercepts.loc[
        intercepts["group_type"] == "Environment date"
    ].copy()

    expected_participant_rows = data["Pid"].nunique() * len(MODEL_SPECS)
    expected_date_rows = (
        data["EnvironmentDateKey"].nunique() * len(MODEL_SPECS)
    )
    if len(participant) != expected_participant_rows:
        raise RuntimeError(
            "Unexpected number of participant random intercepts: "
            f"expected {expected_participant_rows}, found {len(participant)}."
        )
    if len(date) != expected_date_rows:
        raise RuntimeError(
            "Unexpected number of date random intercepts: "
            f"expected {expected_date_rows}, found {len(date)}."
        )

    participant_coverage = (
        data.groupby("Pid", as_index=False)
        .agg(
            n_sessions=("Class_id", "size"),
            n_dates=("EnvironmentDateKey", "nunique"),
        )
        .rename(columns={"Pid": "group_id"})
    )
    date_coverage = (
        data.groupby("EnvironmentDateKey", as_index=False)
        .agg(
            n_sessions=("Class_id", "size"),
            n_participants=("Pid", "nunique"),
        )
        .rename(columns={"EnvironmentDateKey": "group_id"})
    )

    participant = participant.merge(
        participant_coverage,
        on="group_id",
        how="left",
        validate="many_to_one",
    )
    date = date.merge(
        date_coverage,
        on="group_id",
        how="left",
        validate="many_to_one",
    )

    participant_ids = sorted(
        participant["group_id"].unique(), key=_natural_sort_key
    )
    date_ids = sorted(
        date["group_id"].unique(), key=_natural_sort_key
    )
    participant_map = {
        group_id: f"P{i:02d}"
        for i, group_id in enumerate(participant_ids, start=1)
    }
    date_map = {
        group_id: f"E{i:02d}"
        for i, group_id in enumerate(date_ids, start=1)
    }
    participant["display_id"] = participant["group_id"].map(participant_map)
    date["display_id"] = date["group_id"].map(date_map)

    id_key = pd.concat(
        [
            pd.DataFrame(
                {
                    "group_type": "Participant",
                    "group_id": participant_ids,
                    "display_id": [
                        participant_map[value] for value in participant_ids
                    ],
                }
            ),
            pd.DataFrame(
                {
                    "group_type": "Environment date",
                    "group_id": date_ids,
                    "display_id": [date_map[value] for value in date_ids],
                }
            ),
        ],
        ignore_index=True,
    )
    return participant, date, id_key


def _random_intercept_matrix(
    frame: pd.DataFrame,
    show_original_ids: bool,
) -> pd.DataFrame:
    label_column = "group_id" if show_original_ids else "display_id"
    matrix = frame.pivot(
        index=label_column,
        columns="outcome",
        values="random_intercept",
    )
    matrix = matrix.reindex(columns=list(MODEL_SPECS))
    ordered_index = sorted(matrix.index, key=_natural_sort_key)
    return matrix.reindex(ordered_index)


def make_random_intercept_figure(
    participant: pd.DataFrame,
    date: pd.DataFrame,
    output_dir: Path,
    show_original_ids: bool,
) -> None:
    """Create a compact two-panel heatmap for a double-column manuscript."""
    participant_matrix = _random_intercept_matrix(
        participant, show_original_ids
    )
    date_matrix = _random_intercept_matrix(date, show_original_ids)

    values = np.concatenate(
        [
            participant_matrix.to_numpy(dtype=float).ravel(),
            date_matrix.to_numpy(dtype=float).ravel(),
        ]
    )
    values = values[np.isfinite(values)]
    if len(values) == 0:
        raise RuntimeError("No finite random-intercept estimates to plot.")

    color_limit = float(np.max(np.abs(values)))
    color_limit = max(color_limit, 1e-6)
    norm = TwoSlopeNorm(
        vmin=-color_limit,
        vcenter=0.0,
        vmax=color_limit,
    )
    cmap = LinearSegmentedColormap.from_list(
        "blue_white_rust",
        ["#35689A", "#F7F7F5", "#B65345"],
    )

    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans"],
            "font.size": 8,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "xtick.labelsize": 7.5,
            "ytick.labelsize": 6.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig = plt.figure(figsize=(7.15, 6.7))
    grid = fig.add_gridspec(
        nrows=2,
        ncols=2,
        height_ratios=[1.0, 0.035],
        hspace=0.18,
        wspace=0.35,
    )
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])]
    colorbar_axis = fig.add_subplot(grid[1, :])

    panels = [
        (axes[0], participant_matrix, "A", "Participants"),
        (axes[1], date_matrix, "B", "Environment dates"),
    ]
    image = None
    for axis, matrix, panel_label, title in panels:
        image = axis.imshow(
            matrix.to_numpy(dtype=float),
            cmap=cmap,
            norm=norm,
            aspect="auto",
            interpolation="nearest",
        )
        axis.set_xticks(np.arange(matrix.shape[1]))
        axis.set_xticklabels(matrix.columns, rotation=0)
        axis.set_yticks(np.arange(matrix.shape[0]))
        axis.set_yticklabels(matrix.index)
        axis.tick_params(axis="both", which="major", length=0)
        axis.set_xlabel("")
        axis.set_ylabel("")
        axis.set_title(title, pad=7)
        axis.text(
            -0.13,
            1.035,
            panel_label,
            transform=axis.transAxes,
            fontsize=10,
            fontweight="bold",
            va="bottom",
            ha="left",
        )

        # Thin white cell boundaries improve readability without annotations.
        axis.set_xticks(
            np.arange(-0.5, matrix.shape[1], 1), minor=True
        )
        axis.set_yticks(
            np.arange(-0.5, matrix.shape[0], 1), minor=True
        )
        axis.grid(which="minor", color="white", linewidth=0.45)
        axis.tick_params(which="minor", bottom=False, left=False)
        for spine in axis.spines.values():
            spine.set_visible(False)

    colorbar = fig.colorbar(
        image,
        cax=colorbar_axis,
        orientation="horizontal",
    )
    colorbar.set_label("Estimated random intercept (SD units)", labelpad=4)
    colorbar.outline.set_linewidth(0.5)
    colorbar.ax.tick_params(length=2.5, width=0.5, labelsize=7)

    output_dir.mkdir(parents=True, exist_ok=True)
    stem = output_dir / "Figure2_random_intercepts"
    fig.savefig(f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    fig.savefig(f"{stem}.svg", bbox_inches="tight", facecolor="white")
    fig.savefig(
        f"{stem}.png",
        dpi=600,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(fig)


def fixed_effect_rows(result, outcome: str, model_name: str) -> list[dict]:
    """Extract the two prespecified Environment--Physiology fixed effects."""
    ci = result.conf_int()
    rows = []
    for predictor, label in (
        ("Temperature_mean_z", "Temperature"),
        ("CO2_mean_z", "CO2"),
    ):
        rows.append(
            {
                "outcome": outcome,
                "predictor": label,
                "beta_standardized": float(result.fe_params[predictor]),
                "SE": float(result.bse[predictor]),
                "z": float(result.tvalues[predictor]),
                "p": float(result.pvalues[predictor]),
                "ci95_low": float(ci.loc[predictor, 0]),
                "ci95_high": float(ci.loc[predictor, 1]),
                "model": model_name,
            }
        )
    return rows


def variance_component_rows(result, outcome: str, model_name: str) -> list[dict]:
    """Extract variance components and convert them to descriptive proportions."""
    components = variance_component_map(result)
    components["Residual"] = float(result.scale)
    total_variance = float(sum(components.values()))

    rows = []
    for component, value in components.items():
        rows.append(
            {
                "outcome": outcome,
                "component": component,
                "variance": float(value),
                "variance_proportion": (
                    float(value / total_variance)
                    if total_variance > 0
                    else np.nan
                ),
                "model": model_name,
            }
        )
    return rows


def add_fdr_columns(fixed: pd.DataFrame) -> pd.DataFrame:
    """Apply one BH-FDR correction to the six prespecified fixed-effect tests."""
    fixed = fixed.copy()
    fixed["q_BH_FDR"] = benjamini_hochberg(fixed["p"])
    fixed["nominal_p_lt_0_05"] = fixed["p"] < 0.05
    fixed["FDR_q_lt_0_05"] = fixed["q_BH_FDR"] < 0.05
    return fixed


def fit_all_models(data: pd.DataFrame):
    primary_fixed_rows = []
    primary_variance_rows = []
    slope_fixed_rows = []
    slope_variance_rows = []
    comparison_rows = []
    slope_frames = []
    random_intercept_frames = []

    base_vc = random_effect_formulas(include_temperature_slope=False)
    slope_vc = random_effect_formulas(include_temperature_slope=True)

    for outcome, formula in MODEL_SPECS.items():
        # Primary random-intercept analysis: REML estimates are reported.
        base_reml, base_reml_optimizer = fit_with_optimizers(
            formula, data, base_vc, reml=True
        )

        random_intercepts = extract_random_intercepts(base_reml, outcome)
        if not random_intercepts.empty:
            random_intercept_frames.append(random_intercepts)

        primary_fixed_rows.extend(
            fixed_effect_rows(
                base_reml,
                outcome,
                "random_intercepts_REML",
            )
        )
        primary_variance_rows.extend(
            variance_component_rows(
                base_reml,
                outcome,
                "random_intercepts_REML",
            )
        )

        # ML fits are used only to compare the random-effect structures by AIC.
        base_ml, base_ml_optimizer = fit_with_optimizers(
            formula, data, base_vc, reml=False
        )
        slope_ml, slope_ml_optimizer = fit_with_optimizers(
            formula, data, slope_vc, reml=False
        )

        # Random-slope sensitivity analysis: REML estimates are reported.
        slope_reml, slope_reml_optimizer = fit_with_optimizers(
            formula, data, slope_vc, reml=True
        )

        slope_fixed_rows.extend(
            fixed_effect_rows(
                slope_reml,
                outcome,
                "participant_temperature_random_slope_REML",
            )
        )
        slope_variance_rows.extend(
            variance_component_rows(
                slope_reml,
                outcome,
                "participant_temperature_random_slope_REML",
            )
        )

        delta_aic = float(slope_ml.aic - base_ml.aic)
        slope_ml_components = variance_component_map(slope_ml)
        slope_reml_components = variance_component_map(slope_reml)
        slope_variance_ml = float(
            slope_ml_components.get("PidTempSlope", np.nan)
        )
        slope_variance_reml = float(
            slope_reml_components.get("PidTempSlope", np.nan)
        )

        comparison_rows.append(
            {
                "outcome": outcome,
                "N_sessions": int(len(data)),
                "N_PIDs": int(data["Pid"].nunique()),
                "N_dates": int(data["EnvironmentDateKey"].nunique()),
                "AIC_random_intercepts_ML": float(base_ml.aic),
                "AIC_temperature_random_slope_ML": float(slope_ml.aic),
                "delta_AIC_slope_minus_intercepts": delta_aic,
                # Descriptive rule: at least a 2-point AIC reduction.
                "random_slope_supported_by_AIC": bool(delta_aic <= -2.0),
                "temperature_slope_variance_ML": slope_variance_ml,
                "temperature_slope_variance_REML": slope_variance_reml,
                "base_ML_converged": bool(base_ml.converged),
                "slope_ML_converged": bool(slope_ml.converged),
                "slope_REML_converged": bool(slope_reml.converged),
                "base_REML_converged": bool(base_reml.converged),
                "base_REML_optimizer": base_reml_optimizer,
                "base_ML_optimizer": base_ml_optimizer,
                "slope_ML_optimizer": slope_ml_optimizer,
                "slope_REML_optimizer": slope_reml_optimizer,
            }
        )

        fixed_temperature = float(slope_reml.fe_params["Temperature_mean_z"])
        participant_slopes = extract_temperature_slopes(
            slope_reml, fixed_temperature
        )
        if not participant_slopes.empty:
            participant_slopes["outcome"] = outcome
            slope_frames.append(participant_slopes)

    primary_fixed = add_fdr_columns(pd.DataFrame(primary_fixed_rows))
    primary_variance = pd.DataFrame(primary_variance_rows)
    slope_fixed = add_fdr_columns(pd.DataFrame(slope_fixed_rows))
    slope_variance = pd.DataFrame(slope_variance_rows)
    comparison = pd.DataFrame(comparison_rows)
    slopes = (
        pd.concat(slope_frames, ignore_index=True)
        if slope_frames
        else pd.DataFrame()
    )
    random_intercepts = (
        pd.concat(random_intercept_frames, ignore_index=True)
        if random_intercept_frames
        else pd.DataFrame()
    )
    return (
        primary_fixed,
        primary_variance,
        slope_fixed,
        slope_variance,
        comparison,
        slopes,
        random_intercepts,
    )


def write_outputs(
    output_dir: Path,
    data: pd.DataFrame,
    coverage: pd.DataFrame,
    primary_fixed: pd.DataFrame,
    primary_variance: pd.DataFrame,
    slope_fixed: pd.DataFrame,
    slope_variance: pd.DataFrame,
    comparison: pd.DataFrame,
    slopes: pd.DataFrame,
    random_intercepts: pd.DataFrame,
    show_original_ids: bool,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    coverage.to_csv(
        output_dir / "participant_environment_coverage.csv", index=False
    )
    primary_fixed.to_csv(
        output_dir / "mixedlm_primary_fixed_effects.csv", index=False
    )
    primary_variance.to_csv(
        output_dir / "mixedlm_primary_variance_components.csv", index=False
    )
    slope_fixed.to_csv(
        output_dir / "mixedlm_temperature_slope_fixed_effects.csv", index=False
    )
    slope_variance.to_csv(
        output_dir / "mixedlm_temperature_slope_variance_components.csv",
        index=False,
    )
    comparison.to_csv(
        output_dir / "mixedlm_model_comparison.csv", index=False
    )
    slopes.to_csv(
        output_dir / "participant_temperature_slopes.csv", index=False
    )

    participant_intercepts, date_intercepts, id_key = (
        prepare_random_intercept_outputs(random_intercepts, data)
    )
    random_intercepts.to_csv(
        output_dir / "mixedlm_random_intercepts_all.csv", index=False
    )
    participant_intercepts.to_csv(
        output_dir / "mixedlm_participant_random_intercepts.csv",
        index=False,
    )
    date_intercepts.to_csv(
        output_dir / "mixedlm_date_random_intercepts.csv",
        index=False,
    )
    id_key.to_csv(
        output_dir / "mixedlm_random_intercept_id_key.csv", index=False
    )
    make_random_intercept_figure(
        participant=participant_intercepts,
        date=date_intercepts,
        output_dir=output_dir,
        show_original_ids=show_original_ids,
    )

    eligible = coverage["can_inform_temperature_slope"]
    summary = {
        "analysis_unit": "one participant-by-class session",
        "N_sessions": int(len(data)),
        "N_participants": int(data["Pid"].nunique()),
        "N_environment_dates": int(
            data["EnvironmentDateKey"].nunique()
        ),
        "primary_model": (
            "Temperature + CO2 fixed effects; participant and environment-"
            "date random intercepts; REML"
        ),
        "sensitivity_model": (
            "Primary model plus an independent participant-specific "
            "Temperature random slope; REML"
        ),
        "participant_random_slope": "Temperature_mean_z",
        "random_slope_level": "Pid",
        "date_effect": "random intercept",
        "random_intercept_slope_covariance_estimated": False,
        "N_participants_able_to_inform_temperature_slope": int(eligible.sum()),
        "N_participants_unable_to_inform_temperature_slope": int(
            (~eligible).sum()
        ),
        "selection_rule": (
            "Compare random-intercept and Temperature-random-slope structures "
            "using ML AIC; delta AIC <= -2 is a descriptive support rule."
        ),
        "important_interpretation": (
            "Including a random slope tests participant variation in the "
            "Temperature--Physiology association. A near-zero slope variance "
            "means that such variation was not detectable in this sample."
        ),
        "random_intercept_figure": (
            "Two-panel heatmap of participant and environment-date "
            "random intercepts from the primary REML models."
        ),
    }
    with (output_dir / "mixedlm_analysis_summary.json").open(
        "w", encoding="utf-8"
    ) as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)


def main() -> None:
    args = parse_args()
    input_path = resolve_input_path(args.input, args.input_dir)
    data = load_and_prepare(input_path)
    coverage = participant_coverage(data)
    (
        primary_fixed,
        primary_variance,
        slope_fixed,
        slope_variance,
        comparison,
        slopes,
        random_intercepts,
    ) = fit_all_models(data)

    if not slopes.empty:
        slopes = slopes.merge(
            coverage[
                [
                    "Pid",
                    "n_sessions",
                    "n_dates",
                    "Temperature_range",
                    "can_inform_temperature_slope",
                ]
            ],
            on="Pid",
            how="left",
            validate="many_to_one",
        )

    write_outputs(
        args.output_dir,
        data,
        coverage,
        primary_fixed,
        primary_variance,
        slope_fixed,
        slope_variance,
        comparison,
        slopes,
        random_intercepts,
        args.show_original_ids,
    )

    display_columns = [
        "outcome",
        "temperature_slope_variance_REML",
        "delta_AIC_slope_minus_intercepts",
        "random_slope_supported_by_AIC",
        "slope_REML_converged",
    ]
    print(comparison[display_columns].to_string(index=False))
    print(f"\nInput: {input_path.resolve()}")
    print(f"\nOutputs written to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
