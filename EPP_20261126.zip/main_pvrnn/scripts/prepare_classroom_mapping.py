"""Build class-to-environment inputs from an original dated class table.

documented: use identical room/file identifiers or an explicitly sourced crosswalk.
historical: reconstruct the former occupancy-maximum assignments, with tie audits.
Occupancy candidates are diagnostics and are never treated as verified room IDs.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import numpy as np
import pandas as pd

HISTORICAL_ORDER = ('19','20','27','28','29','30','31','40','41','43',
                    'KB1','KB2','KB3','KB4','KB5','KB6')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def clean(value):
    if pd.isna(value):
        return ''
    value = str(value).strip()
    if value.endswith('.0'):
        value = value[:-2]
    return re.sub(r'\.csv$', '', value, flags=re.I)

def locate(base, folders, names, directory=False):
    for folder in folders:
        parent=Path(base)/folder
        if not parent.is_dir():
            continue
        entries={p.name.casefold(): p for p in parent.iterdir()}
        for name in names:
            path=entries.get(name.casefold())
            if path is not None and (path.is_dir() if directory else path.is_file()):
                return path
    raise FileNotFoundError(f'Cannot find {names} under {base}; extract the original dataset archives first.')

def load_classes(path):
    d=pd.read_csv(path)
    required={'Class_id','Room','Date','Start_time','Finish_time'}
    if not required.issubset(d):
        raise ValueError('This adapter requires the dated Figshare data: Class_id, Room, Date, Start_time, Finish_time. '
                         'The date-deidentified PhysioNet table is not interchangeable; dates will not be invented.')
    # Ignore any user-derived assignment columns accidentally present in a raw table.
    d=d.drop(columns=[c for c in ('Matched_CSV','Confidence','start_dt','end_dt','MappingStatus','MappingSource') if c in d])
    if d.Class_id.isna().any() or d.Class_id.duplicated().any():
        raise ValueError('Raw Class_id values must be present and unique.')
    date_text=d.Date.astype(str).str.replace(r'\.0$', '', regex=True)
    date=pd.to_datetime(date_text,format='%Y%m%d',errors='coerce')
    fallback=date.isna()
    date.loc[fallback]=pd.to_datetime(date_text.loc[fallback],errors='coerce')
    day=date.dt.strftime('%Y-%m-%d')
    d['start_dt']=pd.to_datetime(day+' '+d.Start_time.astype(str),errors='coerce')
    d['end_dt']=pd.to_datetime(day+' '+d.Finish_time.astype(str),errors='coerce')
    if d[['start_dt','end_dt']].isna().any().any():
        raise ValueError('Unparseable class dates/times; inspect the original table.')
    d.loc[d.end_dt<d.start_dt,'end_dt']+=pd.Timedelta(days=1)
    if (d.end_dt<=d.start_dt).any():
        raise ValueError('Class intervals must have positive duration.')
    return d

def load_environment(folder):
    cache={}
    records=[]
    ignored=[]
    for path in sorted(Path(folder).glob('*.csv')):
        d=pd.read_csv(path)
        if not {'Occupied','IndoorTemperature','IndoorCO2'}.issubset(d):
            ignored.append(path.name)
            continue
        candidates=[c for c in ('Timestamp','DateTime','Datetime') if c in d]
        column=candidates[0] if candidates else d.columns[0]
        text=d[column].astype(str)
        if not text.head(30).str.contains(r'(?:19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}',regex=True).any():
            raise ValueError(f'{path.name}: dated timestamps required. A Time/Day-only release needs an independently documented calendar bridge.')
        d['MappingTimestamp']=pd.to_datetime(d[column],errors='coerce')
        d['Occupied']=pd.to_numeric(d.Occupied,errors='coerce')
        if not d.Occupied.dropna().isin([0,1]).all():
            raise ValueError(f'{path.name}: Occupied must contain 0/1; never read occupancy by column number.')
        if d.MappingTimestamp.isna().any() or d.MappingTimestamp.duplicated().any():
            raise ValueError(f'{path.name}: missing or duplicated timestamps.')
        d=d.sort_values('MappingTimestamp').set_index('MappingTimestamp')
        sensor=clean(path.stem)
        if sensor in cache:
            raise ValueError(f'Duplicate environment identifier: {sensor}')
        cache[sensor]=d
        records.append({'SensorCSV':sensor,'file':str(path.resolve()),'sha256':digest(path),
                        'start':str(d.index.min()),'end':str(d.index.max()),'rows':len(d),
                        'occupancy_column':'Occupied','timestamp_column':str(column)})
    if not cache:
        raise ValueError('No environment CSV with Occupied, IndoorTemperature and IndoorCO2 was found.')
    return cache,records,ignored

def load_crosswalk(path, sensors):
    if path is None:
        return {}
    d=pd.read_csv(path).fillna('')
    if not {'Room','SensorCSV','Source','Status'}.issubset(d):
        raise ValueError('Crosswalk needs Room, SensorCSV, Source, Status.')
    accepted={}
    for row in d.to_dict('records'):
        room,sensor=clean(row['Room']),clean(row['SensorCSV'])
        if not sensor:
            continue
        if str(row['Status']).strip().lower() not in {'confirmed','documented'} or not str(row['Source']).strip():
            raise ValueError(f'{room}: a nonempty sensor link requires confirmed/documented Status and a Source.')
        if room.casefold() in {'out','outdoor','outside'}:
            raise ValueError('Outdoor classes cannot be assigned an indoor sensor through this crosswalk.')
        if room in accepted or sensor not in sensors:
            raise ValueError(f'Duplicate room or absent sensor in crosswalk: {room} -> {sensor}')
        accepted[room]=(sensor,str(row['Source']).strip())
    assigned=[value[0] for value in accepted.values()]
    if len(assigned)!=len(set(assigned)):
        raise ValueError('Different room identifiers map to one source. Resolve room aliases in the original metadata before using the crosswalk.')
    return accepted

def build(classes, environment, mode='documented', crosswalk=None):
    crosswalk=crosswalk or {}
    order=[name for name in HISTORICAL_ORDER if name in environment]
    order+=sorted(set(environment)-set(order))
    source_by_room={}
    for room in classes.Room.map(clean).unique():
        if room.casefold() in {'out','outdoor','outside'}:
            continue
        if room in crosswalk:
            source_by_room[room]=crosswalk[room]
        elif room in environment:
            source_by_room[room]=(room,'Exact identifier equality in original class table and environment filename')
    if mode=='documented':
        ids=[v[0] for v in source_by_room.values()]
        if len(ids)!=len(set(ids)):
            raise ValueError('Documented/direct links collide across distinct rooms.')

    out=classes.copy()
    matched=[];confidence=[];statuses=[];evidence=[];class_audit=[];room_evidence=[]
    for row in classes.itertuples(index=False):
        room=clean(row.Room)
        scores={}
        for name in order:
            frame=environment[name]
            # Inclusive end only in historical mode to exactly reconstruct the former code.
            right=(frame.index<=row.end_dt) if mode=='historical' else (frame.index<row.end_dt)
            q=frame.loc[(frame.index>=row.start_dt)&right,'Occupied']
            valid=q.dropna()
            score=float(valid.mean()) if len(valid) else None
            if score is not None:
                scores[name]=score
            class_audit.append({'Class_id':row.Class_id,'Room':room,'SensorCSV':name,
                                'n_occupancy_samples':len(valid),'occupancy_mean':score,
                                'start_dt':row.start_dt,'end_dt':row.end_dt})
        ties=[]
        if scores:
            highest=max(scores.values())
            ties=[name for name in order if name in scores and scores[name]==highest]
        name=None;score=np.nan;source=''
        if mode=='historical':
            score=-0.1
            if scores:
                name=ties[0];score=scores[name]
                status='HISTORICAL_OCCUPANCY_TIE' if len(ties)>1 else 'HISTORICAL_OCCUPANCY_MAX'
                source='Historical occupancy maximum; candidate order and inclusive endpoints preserved; room identity unvalidated'
            else:
                status='NO_ENVIRONMENT_DATE_COVERAGE'
        elif room.casefold() in {'out','outdoor','outside'}:
            status='OUTDOOR_NO_INDOOR_ASSIGNMENT'
        elif room not in source_by_room:
            status='NO_DOCUMENTED_ROOM_LINK'
        else:
            candidate,source=source_by_room[room]
            if candidate not in scores:
                status='NO_ENVIRONMENT_DATE_COVERAGE'
            else:
                name=candidate;status='DOCUMENTED_ROOM_LINK'
                # Occupancy is diagnostic, never identity confidence in documented mode.
        matched.append(name);confidence.append(score);statuses.append(status);evidence.append(source)
        room_evidence.append({'Class_id':row.Class_id,'Room':room,'Selected_CSV':name,
                              'MappingStatus':status,'n_top_occupancy_ties':len(ties),
                              'top_occupancy_candidates':'|'.join(ties),'MappingSource':source})
    out['Matched_CSV']=matched
    out['Confidence']=confidence
    out['MappingStatus']=statuses
    out['MappingSource']=evidence
    diagnostics=pd.DataFrame(class_audit)
    # Whole-room evidence uses only observed class intervals. No class entry does
    # not imply the room was vacant; no negative occupancy labels are invented.
    candidates=[]
    for (room,sensor),g in diagnostics.groupby(['Room','SensorCSV'],sort=True):
        valid=g.n_occupancy_samples>0
        n=int(g.loc[valid,'n_occupancy_samples'].sum())
        score=float((g.loc[valid,'occupancy_mean']*g.loc[valid,'n_occupancy_samples']).sum()/n) if n else np.nan
        candidates.append({'Room':room,'SensorCSV':sensor,'n_observed_classes':int(valid.sum()),
                           'n_observed_class_samples':n,'occupancy_fraction_in_observed_classes':score,
                           'evidence_status':'occupancy_diagnostic_not_room_identification'})
    return out,diagnostics,pd.DataFrame(candidates),pd.DataFrame(room_evidence)

def prepare(base_dir, output_dir, mode='documented', crosswalk=None, class_table=None):
    if mode=='historical' and crosswalk is not None:
        raise ValueError('Historical reconstruction does not use a crosswalk; remove --crosswalk or select documented mode.')
    base_dir=Path(base_dir).resolve();output_dir=Path(output_dir).resolve()
    table=Path(class_table) if class_table else locate(base_dir,('Participant_class_info','participant_class_info','Longitudinal','longitudinal','.'),('Class_table.csv','class_table.csv'))
    longitudinal=locate(base_dir,('.',),('Longitudinal','longitudinal'),directory=True)
    if table.name.casefold()=='classroom_data.csv':
        raise ValueError('Provide original Class_table.csv, not a previously generated Classroom_Data.csv.')
    classes=load_classes(table)
    environment,inventory,ignored=load_environment(longitudinal)
    links=load_crosswalk(crosswalk,environment)
    output,diagnostics,candidates,audit=build(classes,environment,mode,links)
    output_dir.mkdir(parents=True,exist_ok=True)
    output.to_csv(output_dir/'Classroom_Data.csv',index=False)
    diagnostics.to_csv(output_dir/'class_sensor_candidates.csv',index=False)
    candidates.to_csv(output_dir/'room_sensor_candidates.csv',index=False)
    audit.to_csv(output_dir/'mapping_audit.csv',index=False)
    pd.DataFrame(inventory).to_csv(output_dir/'environment_inventory.csv',index=False)
    template=pd.DataFrame({'Room':sorted(classes.Room.map(clean).unique()),'SensorCSV':'','Source':'','Status':'unresolved'})
    template.to_csv(output_dir/'room_crosswalk_template.csv',index=False)
    issues=[]
    if {'Week','Date'}.issubset(classes):
        for (week,weekday),g in classes.groupby(['Week','Weekday'] if 'Weekday' in classes else ['Week','Date']):
            if g.start_dt.dt.normalize().nunique()>1:
                issues.append({'Week':str(week),'Weekday':str(weekday),'Class_ids':g.Class_id.tolist(),
                               'dates':sorted(g.start_dt.dt.strftime('%Y-%m-%d').unique())})
    summary={'mapping_mode':mode,'room_identity_validated_by_occupancy':False,
             'class_table_source':str(table.resolve()),'class_table_sha256':digest(table),
             'crosswalk_source':str(Path(crosswalk).resolve()) if crosswalk else None,
             'crosswalk_sha256':digest(crosswalk) if crosswalk else None,
             'environment_files':inventory,'ignored_non_environment_csvs':ignored,
             'n_classes':len(output),'n_mapped':int(output.Matched_CSV.notna().sum()),
             'status_counts':output.MappingStatus.value_counts().to_dict(),
             'n_classes_with_tied_top_occupancy_candidates':int((audit.n_top_occupancy_ties>1).sum()),
             'raw_week_date_inconsistencies':issues,
             'note':'Explicit raw dates are retained. Occupancy scores are not matching probabilities. No physiological or behavior outcome is used for mapping.'}
    (output_dir/'mapping_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ('mapping_mode','n_classes','n_mapped','status_counts','n_classes_with_tied_top_occupancy_candidates')},indent=2))
    print('Prepared mapping and diagnostics:',output_dir)
    return output,summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base-dir',required=True,type=Path)
    p.add_argument('--output-dir',required=True,type=Path)
    p.add_argument('--mode',choices=('documented','historical'),default='documented')
    p.add_argument('--crosswalk',type=Path)
    p.add_argument('--class-table',type=Path)
    args=p.parse_args()
    prepare(args.base_dir,args.output_dir,args.mode,args.crosswalk,args.class_table)

if __name__=='__main__':
    main()
