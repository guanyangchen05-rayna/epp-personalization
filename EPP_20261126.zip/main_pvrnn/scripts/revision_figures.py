"""Consistent publication figures from saved fits/predictions; never trains models."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

COLORS={'No-ER':'#87929D','ER':'#287F83','reference_date':'#3D5A80','context_window':'#287F83',
        'context_window_time':'#B68735','PidIntercept':'#3D5A80','Date':'#B68735',
        'ContextWindow':'#287F83','Residual':'#DCE1E5'}
LABELS={'EDA':'EDA','HR':'HR','SkinTEMP':'Skin temperature','EngageScore':'Engagement','Arousal':'Arousal','Valence':'Valence'}
TARGETS=['EngageScore','Arousal','Valence'];OUTCOMES=['EDA','HR','SkinTEMP']
PROTOCOL_LABELS={'PARTICIPANT_LOO':'Participant-LOO','DATE_LOO':'Date-LOO'}
MANIFEST=[]
def style():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,
        'xtick.labelsize':7,'ytick.labelsize':8,'legend.fontsize':7,'axes.spines.top':False,
        'axes.spines.right':False,'axes.linewidth':.7,'lines.linewidth':1.2,'pdf.fonttype':42,
        'svg.fonttype':'none','savefig.dpi':400,'axes.titlepad':9,'figure.facecolor':'white'})
def clean(ax):
    ax.xaxis.set_major_locator(MaxNLocator(5));ax.grid(axis='x',color='#E7EAED',lw=.55,zorder=0)
    ax.set_axisbelow(True)
def save(fig,out,name,description):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();fb=fig.bbox
    outside=[]
    # Check significant figure/axis text extents. Legends use reserved layout space.
    texts=list(fig.texts)
    for ax in fig.axes:
        texts += [ax.title,ax.xaxis.label,ax.yaxis.label]
        # Locators may retain ticks just beyond the current viewing interval;
        # matplotlib does not draw those ticks, so do not flag their labels.
        for locations,labels,limits in [(ax.get_xticks(),ax.get_xticklabels(),ax.get_xlim()),(ax.get_yticks(),ax.get_yticklabels(),ax.get_ylim())]:
            lo,hi=sorted(limits)
            active=[label for value,label in zip(locations,labels) if lo-1e-10<=value<=hi+1e-10]
            texts.extend(active)
            boxes=[label.get_window_extent(renderer) for label in active if label.get_visible() and label.get_text()]
            for first,second in zip(boxes,boxes[1:]):
                if min(first.x1,second.x1)-max(first.x0,second.x0)>1 and min(first.y1,second.y1)-max(first.y0,second.y0)>1:
                    raise ValueError(f'{name}: adjacent tick labels overlap.')
        legend=ax.get_legend()
        if legend is not None:
            b=legend.get_window_extent(renderer)
            if b.x0<fb.x0-2 or b.y0<fb.y0-2 or b.x1>fb.x1+2 or b.y1>fb.y1+2:outside.append('legend')
    for txt in texts:
        if txt.get_visible() and txt.get_text():
            b=txt.get_window_extent(renderer)
            if b.x0<fb.x0-2 or b.y0<fb.y0-2 or b.x1>fb.x1+2 or b.y1>fb.y1+2:outside.append(txt.get_text())
    if outside:raise ValueError(f'{name}: text outside canvas: {outside}')
    for suffix in ['pdf','svg','png']:fig.savefig(out/(name+'.'+suffix),facecolor='white')
    MANIFEST.append(dict(figure=name,description=description,width_inches=float(fig.get_figwidth()),height_inches=float(fig.get_figheight()),text_bounds_checked=True))
    plt.close(fig)
def forest(out,name,df,predictors,labels,model='context_window_time',slope=False):
    fig,axes=plt.subplots(1,len(predictors),figsize=(7.1 if len(predictors)>1 else 3.45,2.8),layout='constrained',squeeze=False)
    for ax,pred,title in zip(axes[0],predictors,labels):
        q=df.loc[df.model.eq(model)&df.slope.eq(slope)&df.predictor.eq(pred)].set_index('outcome')
        for j,o in enumerate(OUTCOMES):
            if o not in q.index:continue
            r=q.loc[o];color=COLORS['ER']
            if np.isfinite([r.beta,r.ci95_low,r.ci95_high]).all():
                ax.errorbar(r.beta,j,xerr=[[max(0,r.beta-r.ci95_low)],[max(0,r.ci95_high-r.beta)]],fmt='o',color=color,capsize=2,ms=4)
            elif np.isfinite(r.beta):
                ax.plot(r.beta,j,'x',color=COLORS['No-ER'],ms=5,label='Wald CI unavailable')
        ax.axvline(0,c='#69737B',ls='--',lw=.8);ax.set_yticks(range(3),[LABELS[o] for o in OUTCOMES]);ax.invert_yaxis()
        ax.set_ylim(2.6,-.6);ax.set_title(title);ax.set_xlabel('Standardized coefficient (95% Wald CI)');clean(ax)
        if ax.get_legend_handles_labels()[0]:ax.legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.3))
    save(fig,out,name,f'{model}, slope={slope}; model-based Wald intervals, not causal effects.')
def mixed_figures(out,audit,mixed):
    path=audit/'audit_fixed_effects.csv'
    if path.exists():
        f=pd.read_csv(path)
        for model in ['reference_date','context_window','context_window_time']:
            forest(out,'LMM_effects_'+model,f,['Temperature_z','CO2_z'],['Temperature','CO$_2$'],model)
        forest(out,'LMM_within_between_temperature',f,['Temperature_between_z','Temperature_within_z'],['Between dates','Within dates'],'within_between_window_time')
        v=pd.read_csv(audit/'audit_variance_components.csv')
        v=v.loc[v.model.eq('context_window')&~v.slope]
        fig,ax=plt.subplots(figsize=(3.45,2.7),layout='constrained');left=np.zeros(3)
        for comp in ['PidIntercept','Date','ContextWindow','Residual']:
            vals=v.loc[v.component.eq(comp)].set_index('outcome').intercept_model_variance_proportion.reindex(OUTCOMES).fillna(0).to_numpy()*100
            ax.barh(range(3),vals,left=left,color=COLORS[comp],height=.55,label={'PidIntercept':'Participant','ContextWindow':'Time window'}.get(comp,comp))
            for j,x in enumerate(vals):
                if x>=12:ax.text(left[j]+x/2,j,f'{x:.0f}%',ha='center',va='center',fontsize=7,color='white' if comp!='Residual' else '#333333')
            left+=vals
        ax.set_yticks(range(3),[LABELS[o] for o in OUTCOMES]);ax.invert_yaxis();ax.set_xlim(0,100)
        ax.set_xlabel('Conditional variance proportion (%)');ax.set_title('Physiological variation');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.27),ncol=2,frameon=False)
        save(fig,out,'LMM_variance_components','Random-intercept model with participant, date and time-window components; adjusted for T/CO2. Slope variance is not treated as a constant fraction.')
        s=pd.read_csv(audit/'audit_participant_slopes.csv')
        for outcome in ['HR','SkinTEMP']:
            q=s.loc[s.model.eq('context_window')&s.outcome.eq(outcome)].sort_values('display_id')
            fig,ax=plt.subplots(figsize=(3.45,5.1),layout='constrained')
            for j,r in enumerate(q.itertuples(index=False)):
                color=COLORS['ER'] if r.can_inform_temperature_slope else '#AAB2B8'
                ax.errorbar(r.deviation,j,xerr=1.96*r.conditional_random_effect_SE,fmt='o',ms=3,c=color,capsize=1.5,mfc=color if r.can_inform_temperature_slope else 'white')
            ax.axvline(0,c='#69737B',ls='--',lw=.8);ax.set_yticks(range(len(q)),q.display_id);ax.invert_yaxis()
            ax.set_title(LABELS[outcome]+': temperature slopes');ax.set_xlabel('Deviation from mean slope\nConditional 95% interval');clean(ax)
            save(fig,out,'LMM_slopes_'+outcome,'Empirical Bayes random-slope deviations; intervals condition on fitted parameters and omit fixed-effect/variance-parameter uncertainty. Not individual significance tests; hollow points lack within-person variation.')
    elif mixed.exists():
        # Plotting existing main outputs is possible before the supplementary audit.
        path=mixed/'mixedlm_primary_fixed_effects.csv'
        if path.exists():
            f=pd.read_csv(path).rename(columns={'beta_standardized':'beta'})
            f['model']='reference_date';f['slope']=False
            f['predictor']=f.predictor.map({'Temperature':'Temperature_z','CO2':'CO2_z'})
            forest(out,'LMM_effects_reference_date',f,['Temperature_z','CO2_z'],['Temperature','CO$_2$'],'reference_date')

def pv_figures(out,pv):
    path=pv/'FINAL_pv_rnn_adaptation_summary_v3.csv'
    if not path.exists():return
    summary=pd.read_csv(path);protocols=['PARTICIPANT_LOO','DATE_LOO']
    if not set(protocols).issubset(set(summary.protocol)):raise ValueError('Expected both current participant/date protocols.')
    xmax=max(1.3,float(summary.RelativeRMSE_q75.max())+.12);xmin=min(.85,float(summary.RelativeRMSE_q25.min())-.07)
    for protocol in protocols:
        d=summary.loc[summary.protocol.eq(protocol)]
        fig,ax=plt.subplots(figsize=(3.45,3.0),layout='constrained')
        for mode,label,dy in [('NO_ER','No-ER',-.12),('ERROR_REGRESSION','ER',.12)]:
            q=d.loc[d.model.eq(mode)].set_index('target').reindex(TARGETS)
            if q.isna().all(axis=1).any():raise ValueError('Missing outcome/condition in PV summary.')
            ax.errorbar(q.RelativeRMSE_median,np.arange(3)+dy,xerr=[q.RelativeRMSE_median-q.RelativeRMSE_q25,q.RelativeRMSE_q75-q.RelativeRMSE_median],fmt='o',ms=4,capsize=2,color=COLORS[label],label=label)
        ax.axvline(1,c='#69737B',ls='--',lw=.8);ax.set_xlim(xmin,xmax);ax.set_ylim(2.55,-.55)
        ax.set_yticks(range(3),[LABELS[t] for t in TARGETS]);ax.set_xlabel('Relative RMSE');ax.set_title(PROTOCOL_LABELS[protocol])
        ax.legend(loc='upper center',bbox_to_anchor=(.5,-.25),ncol=2,frameon=False);clean(ax)
        ax.set_xticks([x for x in np.arange(.5,2.01,.1) if xmin<=x<=xmax])
        save(fig,out,'PV_'+protocol+'_performance',f'Replaces the {protocol} performance table; median and IQR across seeds. Dashed line: fold-training-mean baseline. N={int(d.N_sessions.iloc[0])}; seeds={int(d.N_seeds.iloc[0])}.')
        # Raw-scale RMSE and R2 remain available as supplementary visual summaries.
        fig,axes=plt.subplots(1,2,figsize=(7.1,2.8),layout='constrained')
        for ax,metric,title in [(axes[0],'RMSE','RMSE (original outcome scale)'),(axes[1],'R2','R$^2$')]:
            for mode,label,dy in [('NO_ER','No-ER',-.10),('ERROR_REGRESSION','ER',.10)]:
                q=d.loc[d.model.eq(mode)].set_index('target').reindex(TARGETS)
                ax.plot(q[metric+'_median'],np.arange(3)+dy,'o',c=COLORS[label],label=label,ms=4)
            if metric=='R2':ax.axvline(0,c='#69737B',ls='--',lw=.8)
            ax.set_yticks(range(3),[LABELS[t] for t in TARGETS]);ax.set_ylim(2.5,-.5);ax.set_xlabel(title);clean(ax)
        axes[1].legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.25),ncol=2)
        save(fig,out,'PV_'+protocol+'_raw_metrics','Seed-median raw RMSE and R2; point summaries only, no confidence intervals implied.')
    seed_paths=[pv/(p+'_seed_metrics.csv') for p in protocols]
    if all(x.exists() for x in seed_paths):
        points=[]
        for pth in seed_paths:
            d=pd.read_csv(pth);a=d.loc[d.model.eq('ERROR_REGRESSION')];b=d.loc[d.model.eq('NO_ER')]
            q=a.merge(b,on=['protocol','seed','target'],suffixes=('_er','_no'),validate='one_to_one')
            q['gain']=100*(q.RMSE_no-q.RMSE_er)/q.RMSE_no;points.append(q)
        points=pd.concat(points)
        fig,axes=plt.subplots(2,1,figsize=(3.45,4.7),sharex=True,layout='constrained')
        for ax,protocol in zip(axes,protocols):
            for j,t in enumerate(TARGETS):
                vals=points.loc[points.protocol.eq(protocol)&points.target.eq(t)].sort_values('seed').gain.to_numpy()
                ax.scatter(vals,j+np.linspace(-.13,.13,len(vals)),s=13,color=COLORS['No-ER'],zorder=3)
                lo,med,hi=np.quantile(vals,[.25,.5,.75]);ax.plot([lo,hi],[j,j],lw=3,c=COLORS['ER']);ax.plot(med,j,'D',c=COLORS['ER'],ms=4)
            ax.axvline(0,c='#69737B',ls='--',lw=.8);ax.set_yticks(range(3),[LABELS[t] for t in TARGETS]);ax.set_ylim(2.5,-.5);ax.set_title(PROTOCOL_LABELS[protocol]);clean(ax)
        axes[-1].set_xlabel('Paired RMSE gain (%)');save(fig,out,'PV_paired_seed_gains','Five paired seed gains, diamond=median, thick line=IQR. These are NOT bootstrap estimates.')
    boot=pv/'FINAL_pv_rnn_adaptation_bootstrap_v3.csv'
    if boot.exists():
        b=pd.read_csv(boot);fig,axes=plt.subplots(2,1,figsize=(3.45,4.7),sharex=True,layout='constrained')
        for ax,protocol in zip(axes,protocols):
            q=b.loc[b.protocol.eq(protocol)].set_index('target').reindex(TARGETS)
            for j,r in enumerate(q.itertuples()):
                ax.plot([r.RMSE_gain_pct_ci95_low,r.RMSE_gain_pct_ci95_high],[j,j],c=COLORS['ER'],lw=1.5)
                ax.plot(r.observed_RMSE_gain_pct,j,'D',c=COLORS['ER'],ms=4)
            ax.axvline(0,c='#69737B',ls='--',lw=.8);ax.set_yticks(range(3),[LABELS[t] for t in TARGETS]);ax.set_ylim(2.5,-.5);ax.set_title(PROTOCOL_LABELS[protocol]);clean(ax)
        axes[-1].set_xlabel('Seed-aggregated RMSE gain (%)')
        save(fig,out,'PV_cluster_bootstrap','Median-across-seed OOF predictions: observed gain and cluster-bootstrap 95% interval. Different estimand from paired-seed median gain. Only four date clusters.')
    diag=[]
    for protocol in protocols:
        path=pv/(protocol+'_adaptation_diagnostics.csv')
        if path.exists():diag.append(pd.read_csv(path))
    if diag:
        d=pd.concat(diag);fig,ax=plt.subplots(figsize=(3.45,2.5),layout='constrained')
        for i,protocol in enumerate(protocols):
            vals=d.loc[d.protocol.eq(protocol),'test_er_improvement_pct'].to_numpy()
            if not len(vals):continue
            rng=np.random.default_rng(41);ax.scatter(i+rng.uniform(-.15,.15,len(vals)),vals,s=9,color=COLORS['No-ER'],alpha=.65)
            lo,med,hi=np.quantile(vals,[.25,.5,.75]);ax.plot([i,i],[lo,hi],lw=4,c=COLORS['ER']);ax.plot(i,med,'D',c=COLORS['ER'],ms=4)
        ax.set_xticks([0,1],['Participant-LOO','Date-LOO']);ax.set_ylabel('Free-energy reduction (%)');ax.set_ylim(min(0,float(d.test_er_improvement_pct.min())-5),max(100,float(d.test_er_improvement_pct.max())+5))
        save(fig,out,'PV_free_energy_reduction','Fold-by-seed diagnostic reductions, not behavioral prediction gains; diamond=median, thick line=IQR.')

def supplementary_figures(out,audit):
    path=audit/'influence_checks.csv'
    if path.exists():
        d=pd.read_csv(path);d=d.loc[d.status.eq('passed')];fig,axes=plt.subplots(2,1,figsize=(3.45,4.5),sharex=True,layout='constrained')
        for ax,outcome in zip(axes,['HR','SkinTEMP']):
            for i,field in enumerate(['Pid','EnvironmentDateKey']):
                vals=d.loc[d.outcome.eq(outcome)&d.exclusion_type.eq(field),'delta_AIC'].to_numpy()
                ax.scatter(vals,i+np.linspace(-.13,.13,len(vals)),s=14,c=COLORS['ER'] if i==0 else COLORS['Date'])
            ax.axvline(-2,c='#69737B',ls='--',lw=.8);ax.set_yticks([0,1],['One participant\nremoved','One date\nremoved']);ax.set_ylim(1.5,-.5);ax.set_title(LABELS[outcome]);clean(ax)
        axes[-1].set_xlabel('$\\Delta$AIC: slope minus intercept model');save(fig,out,'LMM_influence_checks','Context-window model; every successful deletion refit shown. Dashed line=-2 descriptive AIC support rule. Failed fits remain in the CSV.')
    for stem in ['quality_sensitivity','sensor_sensitivity']:
        path=audit/(stem+'_fixed_effects.csv')
        if not path.exists():continue
        d=pd.read_csv(path);d=d.loc[d.status.eq('passed')&d.predictor.eq('Temperature_z')]
        scenarios=list(dict.fromkeys(d.scenario))
        fig,axes=plt.subplots(1,3,figsize=(7.1,max(3.1,.25*len(scenarios)+1.1)),layout='constrained',sharey=True)
        for ax,outcome in zip(axes,OUTCOMES):
            for j,s in enumerate(scenarios):
                q=d.loc[d.outcome.eq(outcome)&d.scenario.eq(s)]
                if len(q)!=1:continue
                r=q.iloc[0];ax.plot([r.ci95_low,r.ci95_high],[j,j],c=COLORS['ER']);ax.plot(r.beta,j,'o',c=COLORS['ER'],ms=3)
            ax.axvline(0,c='#69737B',ls='--',lw=.8);ax.set_title(LABELS[outcome]);ax.set_xlabel('Temperature coefficient');ax.set_ylim(len(scenarios)-.4,-.6);clean(ax)
        names=[s.replace('median_without_','Without ').replace('_',' ') for s in scenarios]
        axes[0].set_yticks(range(len(scenarios)),names)
        save(fig,out,'LMM_'+stem,'Separate sensitivity scenarios, model-based Wald intervals; subgroup effects standardized within each scenario. Not a selection rule.')
    path=audit/'indoor_outdoor_native_diagnostic.csv'
    if path.exists():
        d=pd.read_csv(path);fig,axes=plt.subplots(1,2,figsize=(7.1,2.7),layout='constrained')
        for ax,center in zip(axes,[False,True]):
            x=d[['IndoorTemperature','OutdoorTemperature']].copy()
            if center:x=x-d.groupby('Date')[list(x)].transform('mean')
            ax.scatter(x.OutdoorTemperature,x.IndoorTemperature,s=7,alpha=.35,c=COLORS['ER'],edgecolors='none')
            ax.set_xlabel('Outdoor temperature'+(' deviation' if center else '')+' ($^\\circ$C)');ax.set_ylabel('Indoor temperature'+(' deviation' if center else '')+' ($^\\circ$C)')
            ax.set_title('Within-date deviations' if center else 'Target-time native records')
        save(fig,out,'environment_indoor_outdoor','Descriptive native-bin diagnostic; no iid significance claim and no outdoor substitution into the models.')

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--analysis-dir',type=Path,required=True)
    p.add_argument('--audit-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True)
    a=p.parse_args(argv);style();MANIFEST.clear();a.output_dir.mkdir(parents=True,exist_ok=True)
    mixed=a.analysis_dir/'mixedlm';pv=a.analysis_dir/'pvrnn/02_pv_rnn_v3_model'
    if not pv.exists():
        choices=list(a.analysis_dir.rglob('FINAL_pv_rnn_adaptation_summary_v3.csv'))
        if len(choices)==1:pv=choices[0].parent
        elif len(choices)>1:raise ValueError('Multiple PV-RNN results found; pass the exact original analysis directory.')
    mixed_figures(a.output_dir,a.audit_dir,mixed);pv_figures(a.output_dir,pv);supplementary_figures(a.output_dir,a.audit_dir)
    if not MANIFEST:raise FileNotFoundError('No model/audit results found; no figures were generated.')
    (a.output_dir/'figure_manifest.json').write_text(json.dumps(MANIFEST,indent=2)+'\n',encoding='utf-8')
    print(f'Created {len(MANIFEST)} figure sets (PDF/SVG/400-dpi PNG): {a.output_dir}',flush=True)
    return 0
if __name__=='__main__':main()
