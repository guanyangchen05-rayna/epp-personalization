"""Run UNCHANGED v5 preprocessing and additionally export all retained 1-s data.

The v5 package only exported behavior_temporal_1s. Session means cannot recreate
22-person sequences. This adapter captures the SAME in-memory aligned table at
the EDA-QC boundary; it does not change alignment, labels, or retention rules.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import pandas as pd
import numpy as np
import preprocess_indoor_context as v5

KEYS=['Pid','Class_id']
CHANNELS=['IndoorTemperature','IndoorCO2','EDA','HR','TEMP']


def export(base_dir,input_dir,output_dir):
    output_dir=Path(output_dir)
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValueError('Use a NEW empty output directory; existing v5 outputs are never overwritten')
    captured={}; original=v5.apply_eda_session_qc
    def capture(master,merged,threshold):
        result=original(master,merged,threshold)
        captured['merged']=merged.copy()
        return result
    v5.apply_eda_session_qc=capture
    try: v5.preprocess(base_dir,output_dir,input_dir,eda_max_zero_fraction=.95)
    finally: v5.apply_eda_session_qc=original
    env=pd.read_csv(output_dir/'envphys_session_analysis.csv',dtype={'Pid':str,'Class_id':str})
    raw=captured['merged']
    for k in KEYS: raw[k]=raw[k].astype(str)
    keep=raw[KEYS+['DateTime']+CHANNELS].copy()
    keep=keep.loc[np.isfinite(keep[CHANNELS].to_numpy(float)).all(axis=1)]
    temporal=keep.merge(env[KEYS+['ClassStart','ClassEnd','Room','EnvironmentScope','EnvironmentDateKey']],
                        on=KEYS,how='inner',validate='many_to_one')
    temporal=temporal.sort_values(['ClassStart','Pid','DateTime'])
    if temporal.duplicated(KEYS+['DateTime']).any(): raise ValueError('Duplicate aligned seconds')
    if set(map(tuple,temporal[KEYS].to_numpy()))!=set(map(tuple,env[KEYS].to_numpy())):
        raise ValueError('Export changed envphys cohort')
    beh=pd.read_csv(output_dir/'behavior_temporal_1s.csv',dtype={'Pid':str,'Class_id':str})
    beh['DateTime']=pd.to_datetime(beh.DateTime,errors='raise')
    temporal['DateTime']=pd.to_datetime(temporal.DateTime,errors='raise')
    joined=beh[KEYS+['DateTime']+CHANNELS].merge(temporal[KEYS+['DateTime']+CHANNELS],
             on=KEYS+['DateTime'],suffixes=('_old','_new'),how='left',validate='one_to_one')
    for ch in CHANNELS:
        if not np.allclose(joined[ch+'_old'],joined[ch+'_new'],rtol=1e-7,atol=1e-8,equal_nan=False):
            raise ValueError(f'Behavior temporal values differ: {ch}')
    temporal.to_csv(output_dir/'envphys_temporal_1s.csv',index=False)
    info=dict(n_rows=len(temporal),n_sessions=len(env),n_participants=env.Pid.nunique(),
              behavior_temporal_values_unchanged=True,EDA_zero_threshold=.95,
              new_retention_rule=False,source='v5 aligned in-memory merged_1s')
    (output_dir/'v6_temporal_export.json').write_text(json.dumps(info,indent=2)+'\n')
    print(json.dumps(info,indent=2),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base-dir',type=Path,required=True)
    p.add_argument('--input-dir',type=Path,required=True,help='Existing v5 tables/00_input directory')
    p.add_argument('--output-dir',type=Path,required=True)
    a=p.parse_args(); export(a.base_dir,a.input_dir,a.output_dir)
