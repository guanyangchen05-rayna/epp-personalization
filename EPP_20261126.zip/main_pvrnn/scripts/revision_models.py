"""Supplementary Gaussian mixed-model specifications; main analysis is unchanged."""
from __future__ import annotations
import warnings
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy.stats import norm
from indoor_context_checks import validate_context_table

OUTCOMES = {'EDA':'EDA_z', 'HR':'HR_z', 'SkinTEMP':'SkinTEMP_z'}
ENV_TERMS = ['Temperature_z','CO2_z']
WB_TERMS = ['Temperature_between_z','Temperature_within_z','CO2_between_z','CO2_within_z']

def boolean(values):
    v=values.astype('string').str.lower().str.strip()
    if not v.isin(['true','false','1','0']).all():
        raise ValueError('Eligibility flag must contain explicit True/False values.')
    return v.isin(['true','1'])

def read_sessions(path):
    d=pd.read_csv(path, dtype={'Pid':str,'Class_id':str})
    validate_context_table(d)
    required=['Pid','Class_id','ClassStart','ClassEnd','EnvironmentDateKey',
              'Temperature_mean','CO2_mean','EDA_mean','HR_mean','SkinTEMP_mean',
              'n_complete_env_phys_seconds','complete_env_phys_fraction_of_class']
    missing=set(required)-set(d)
    if missing: raise ValueError(f'Missing session columns: {sorted(missing)}')
    if d.duplicated(['Pid','Class_id']).any(): raise ValueError('Duplicate participant-by-class records.')
    if 'EnvPhysReady' in d and not boolean(d.EnvPhysReady).all():
        raise ValueError('Main audit input includes ineligible sessions; use envphys_session_analysis.csv.')
    if d.n_complete_env_phys_seconds.lt(300).any(): raise ValueError('Main audit input violates 300-second rule.')
    cols=['Temperature_mean','CO2_mean','EDA_mean','HR_mean','SkinTEMP_mean']
    if not np.isfinite(d[cols].to_numpy(float)).all(): raise ValueError('Nonfinite values; no silent row removal is allowed.')
    expected='POOLED_INDOOR__'+pd.to_datetime(d.ClassStart).dt.strftime('%Y-%m-%dT%H:%M:%S')+'__'+pd.to_datetime(d.ClassEnd).dt.strftime('%Y-%m-%dT%H:%M:%S')
    if 'ContextWindowKey' in d and not d.ContextWindowKey.eq(expected).all():
        raise ValueError('ContextWindowKey must be the exact shared start/end window, not room identity.')
    d['ContextWindowKey']=expected
    if d.groupby('ContextWindowKey').EnvironmentDateKey.nunique().gt(1).any():
        raise ValueError('A context window crosses date groups.')
    for col in ['Temperature_mean','CO2_mean']:
        spread=d.groupby('ContextWindowKey')[col].agg(lambda x:x.max()-x.min())
        if spread.gt(1e-7).any(): raise ValueError(f'{col} differs within the same shared window.')
    return d.reset_index(drop=True)

def prepare(d):
    d=d.copy().reset_index(drop=True)
    def z(v):
        v=np.asarray(v,float);sd=v.std(ddof=0)
        if not np.isfinite(sd) or sd<1e-10: raise ValueError('Unidentifiable constant covariate/outcome.')
        return (v-v.mean())/sd
    d['Temperature_z']=z(d.Temperature_mean);d['CO2_z']=z(d.CO2_mean)
    d['EDA_z']=z(np.log1p(d.EDA_mean.clip(lower=0)))
    d['HR_z']=z(d.HR_mean);d['SkinTEMP_z']=z(d.SkinTEMP_mean)
    mid=pd.to_datetime(d.ClassStart)+(pd.to_datetime(d.ClassEnd)-pd.to_datetime(d.ClassStart))/2
    hour=mid.dt.hour+mid.dt.minute/60+mid.dt.second/3600
    d['Hour_c']=hour-12.;d['Hour_c2']=d.Hour_c**2
    # Equal weight per DISTINCT observed context window, not per student.
    windows=d[['ContextWindowKey','EnvironmentDateKey','Temperature_mean','CO2_mean']].drop_duplicates('ContextWindowKey')
    for var in ['Temperature','CO2']:
        col=var+'_mean';mean_by_date=windows.groupby('EnvironmentDateKey')[col].mean()
        between=d.EnvironmentDateKey.map(mean_by_date)
        # Same units for within/between coefficients: one global session SD.
        scale=d[col].std(ddof=0)
        d[var+'_between_z']=(between-d[col].mean())/scale
        d[var+'_within_z']=(d[col]-between)/scale
        if not np.allclose(d[var+'_between_z']+d[var+'_within_z'],d[var+'_z']):
            raise AssertionError('Within-between identity failed.')
    return d

def specification(name, slope=False):
    vc={'PidIntercept':'0 + C(Pid)'}
    terms=ENV_TERMS.copy();slope_col='Temperature_z'
    if name not in ['reference_date','context_window','context_window_time','date_fixed_window_time','within_between_window_time']:
        raise ValueError(name)
    if name!='date_fixed_window_time':vc['Date']='0 + C(EnvironmentDateKey)'
    if name!='reference_date':vc['ContextWindow']='0 + C(ContextWindowKey)'
    if name in ['context_window_time','date_fixed_window_time','within_between_window_time']:
        terms+=['Hour_c','Hour_c2']
    if name=='date_fixed_window_time':terms+=['C(EnvironmentDateKey)']
    if name=='within_between_window_time':
        terms=WB_TERMS+['Hour_c','Hour_c2'];slope_col='Temperature_within_z'
    if slope:vc['PidTempSlope']='0 + C(Pid):'+slope_col
    return terms,vc,slope_col

def fit(d,outcome,name,slope=False,reml=True):
    terms,vc,slope_col=specification(name,slope)
    formula=OUTCOMES[outcome]+' ~ '+' + '.join(terms)
    model=smf.mixedlm(formula,d,groups=np.ones(len(d)),re_formula='0',vc_formula=vc)
    rank=np.linalg.matrix_rank(model.exog)
    if rank<model.exog.shape[1]:raise ValueError(f'Rank-deficient fixed effects ({rank}/{model.exog.shape[1]}): {name}')
    attempts=[];candidates=[]
    # Compare converged likelihoods instead of accepting the first optimizer.
    for method in ['lbfgs','powell']:
        try:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                r=model.fit(reml=reml,method=method,maxiter=1500,disp=False)
            row={'optimizer':method,'converged':bool(r.converged),'llf':float(r.llf),
                 'warnings':list(dict.fromkeys(str(x.message) for x in w))}
            attempts.append(row)
            if r.converged and np.isfinite(r.llf):candidates.append((r,method))
        except Exception as exc:attempts.append({'optimizer':method,'converged':False,'error':str(exc)})
    if not candidates:raise RuntimeError(f'No converged finite fit: {outcome}/{name}/slope={slope}: {attempts}')
    r,method=max(candidates,key=lambda x:x[0].llf)
    vc_values=dict(zip(r.model.exog_vc.names,map(float,r.vcomp)))
    return r,dict(model=name,outcome=outcome,slope=slope,reml=reml,optimizer=method,
                  llf=float(r.llf),AIC=None if reml else float(r.aic),
                  N_sessions=len(d),N_participants=d.Pid.nunique(),N_dates=d.EnvironmentDateKey.nunique(),
                  N_windows=d.ContextWindowKey.nunique(),temperature_slope_predictor=slope_col,
                  variance_components=vc_values,residual_variance=float(r.scale),attempts=attempts)

def fixed_rows(r,meta):
    rows=[]
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter('always')
        errors=r.bse_fe
    if captured:meta['inference_warnings']=list(dict.fromkeys(str(x.message) for x in captured))
    for term,beta in r.fe_params.items():
        se=float(errors[term]);p=float(2*norm.sf(abs(beta/se))) if np.isfinite(se) and se>0 else np.nan
        rows.append({k:meta[k] for k in ['model','outcome','slope','reml','N_sessions','N_participants','N_dates','N_windows']} |
                    dict(predictor=term,beta=float(beta),SE=se,p=p,ci95_low=float(beta-1.95996398454*se),
                         ci95_high=float(beta+1.95996398454*se),inference_available=bool(np.isfinite(p))))
    return rows

def adjust_families(df):
    df=df.copy();df['q_BH_FDR']=np.nan;df['FDR_family_size']=0
    for _,g in df.groupby(['model','slope','reml'],dropna=False):
        idx=g.index[g.predictor.isin(ENV_TERMS+WB_TERMS)]
        # Missing Wald tests stay missing; planned missing tests count as p=1.
        pv=df.loc[idx,'p'].fillna(1).to_numpy();n=len(pv)
        order=np.argsort(pv);qq=np.minimum.accumulate((pv[order]*n/np.arange(1,n+1))[::-1])[::-1]
        q=np.empty(n);q[order]=np.minimum(qq,1)
        df.loc[idx,'q_BH_FDR']=q;df.loc[idx,'FDR_family_size']=n
        df.loc[idx[df.loc[idx,'p'].isna()],'q_BH_FDR']=np.nan
    return df

def slope_rows(r,d,meta):
    var=meta['variance_components'].get('PidTempSlope')
    if var is None:return []
    effect=next(iter(r.random_effects.values()))
    cov=next(iter(r.random_effects_cov.values()))
    fixed=float(r.fe_params[meta['temperature_slope_predictor']]);rows=[]
    ids=sorted(d.Pid.astype(str).unique(),key=lambda x:(len(x),x))
    for i,pid in enumerate(ids,1):
        marker=f'C(Pid)[{pid}]';matches=[k for k in effect.index if k.startswith('PidTempSlope[') and marker in k]
        if len(matches)!=1:raise ValueError(f'Cannot identify random slope for {pid}: {matches}')
        key=matches[0];se=float(np.sqrt(max(0,cov.loc[key,key])))
        sub=d[d.Pid.eq(pid)];within=sub.Temperature_mean.nunique()>1 and len(sub)>1
        rows.append(dict(model=meta['model'],outcome=meta['outcome'],Pid=pid,display_id=f'P{i:02}',
                         slope=fixed+float(effect[key]),deviation=float(effect[key]),conditional_random_effect_SE=se,
                         conditional_low=fixed+float(effect[key])-1.96*se,conditional_high=fixed+float(effect[key])+1.96*se,
                         n_sessions=len(sub),n_dates=sub.EnvironmentDateKey.nunique(),can_inform_temperature_slope=within))
    return rows
