"""Heterogeneity figures; distinguish diagnostic flags from usable intervals."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from revision_figures import style,clean,save,MANIFEST,COLORS,LABELS,OUTCOMES,pv_figures

MODEL_LABELS={'reference_date':'Prior date model','context_window':'Shared time window',
              'context_window_time':'Time window + time of day','date_fixed_window_time':'Date fixed effects + time',
              'within_between_window_time':'Within/between dates + time'}

def select_pv_directory(analysis_dir, explicit=None):
    """Prefer the configured full-run location; never choose by mtime/order."""
    filename='FINAL_pv_rnn_adaptation_summary_v3.csv'
    analysis_dir=Path(analysis_dir)
    if explicit is not None:
        chosen=Path(explicit)
        if not (chosen/filename).is_file():raise FileNotFoundError(f'--pv-dir lacks {filename}: {chosen}')
        return chosen
    # run_indoor_context writes full training here and smoke results under
    # analysis/smoke/pvrnn. Both can legitimately coexist in one source run.
    for chosen in [analysis_dir/'pvrnn/02_pv_rnn_v3_model',analysis_dir/'02_pv_rnn_v3_model',analysis_dir]:
        if (chosen/filename).is_file():return chosen
    choices=sorted(p for p in analysis_dir.rglob(filename)
                   if not any(part.lower()=='smoke' or part.lower().startswith('smoke_')
                              for part in p.relative_to(analysis_dir).parts[:-1]))
    if len(choices)>1:
        candidates='\n'.join(str(p.parent) for p in choices)
        raise ValueError('Multiple non-smoke PV result directories. Set --pv-dir to the intended full model directory:\n'+candidates)
    return choices[0].parent if choices else None

def component_comparison(out,audit):
    d=pd.read_csv(audit/'heterogeneity_component_comparison.csv')
    fig,axes=plt.subplots(1,2,figsize=(7.1,4.0),layout='constrained',sharey=True)
    models=list(MODEL_LABELS)
    for ax,contrast,title in zip(axes,['participant_intercept','temperature_slope'],['Participant baselines','Participant temperature slopes']):
        for j,model in enumerate(models):
            for outcome,offset,color in zip(OUTCOMES,[-.18,0,.18],[COLORS['PidIntercept'],COLORS['ER'],COLORS['Date']]):
                q=d.loc[d.model.eq(model)&d.contrast.eq(contrast)&d.outcome.eq(outcome)]
                if len(q)!=1:continue
                r=q.iloc[0];valid=bool(r.nested_likelihood_order_valid)
                ax.plot(r.delta_AIC,j+offset,'o' if valid else 'x',ms=4,c=color,label=LABELS[outcome] if j==0 else None)
        ax.set_yticks(range(len(models)),list(MODEL_LABELS.values()));ax.set_ylim(len(models)-.5,-.6)
        ax.axvline(0,c='#69737B',lw=.8);ax.axvline(-2,c='#69737B',lw=.8,ls='--')
        ax.set_title(title);ax.set_xlabel(r'$\Delta$AIC: with minus without component');clean(ax)
    axes[1].legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.23),ncol=3)
    save(fig,out,'HET_component_support','ML on identical rows/fixed effects. Negative values favor the component; -2 is descriptive, not a significance threshold. Within/between model slopes concern within-date temperature, unlike the other rows. Crosses flag invalid nested likelihood ordering.')

def variance_and_participants(out,audit):
    v=pd.read_csv(audit/'heterogeneity_variance_components.csv')
    d=v.loc[v.model.eq('context_window')&~v.slope&v.variant.eq('original')]
    fig,ax=plt.subplots(figsize=(3.45,2.9),layout='constrained');left=np.zeros(3)
    for component,label in [('PidIntercept','Participant'),('Date','Date'),('ContextWindow','Time window'),('Residual','Residual')]:
        values=d.loc[d.component.eq(component)].set_index('outcome').intercept_model_variance_proportion.reindex(OUTCOMES).fillna(0).to_numpy()*100
        ax.barh(range(3),values,left=left,height=.55,color=COLORS[component],label=label)
        for j,value in enumerate(values):
            if value>=12:ax.text(left[j]+value/2,j,f'{value:.0f}%',ha='center',va='center',fontsize=7,color='#333333' if component=='Residual' else 'white')
        left+=values
    ax.set_yticks(range(3),[LABELS[o] for o in OUTCOMES]);ax.set_ylim(2.6,-.6);ax.set_xlim(0,100)
    ax.set_xlabel('Estimated variance proportion (%)');ax.set_title('Physiological variation')
    ax.legend(frameon=False,ncol=2,loc='upper center',bbox_to_anchor=(.5,-.25))
    save(fig,out,'HET_baseline_variance','Original context-window REML intercept model; descriptive variance proportions conditional on T/CO2. Positive variance is not itself a significance test; inspect component comparisons and boundary checks.')
    p=pd.read_csv(audit/'heterogeneity_participant_effects.csv')
    for component,title in [('PidIntercept','Adjusted participant baselines'),('PidTempSlope','Participant temperature slopes')]:
        fig,axes=plt.subplots(1,3,figsize=(7.1,5.3),layout='constrained',sharey=True)
        for ax,outcome in zip(axes,OUTCOMES):
            q=p.loc[p.model.eq('context_window')&p.component.eq(component)&p.outcome.eq(outcome)&p.variant.eq('original')].sort_values('display_id')
            for j,r in enumerate(q.itertuples(index=False)):
                informative=bool(r.informs_repeated_measure_difference)
                ax.errorbar(r.deviation,j,xerr=1.96*r.conditional_random_effect_SE,fmt='o',ms=3,c=COLORS['ER'],capsize=1.5,mfc=COLORS['ER'] if informative else 'white')
            ax.set_yticks(range(len(q)),q.display_id);ax.set_ylim(len(q)-.3,-.8);ax.axvline(0,c='#69737B',lw=.8,ls='--')
            ax.set_title(LABELS[outcome]);ax.set_xlabel('Deviation from group mean\nConditional 95% interval');clean(ax)
        fig.suptitle(title,fontsize=10)
        save(fig,out,'HET_participant_'+('baselines' if component=='PidIntercept' else 'slopes'),
             'Original context-window empirical Bayes deviations. Conditional intervals omit fixed-effect and variance-parameter uncertainty; not participant significance tests or stable physiological traits. Hollow markers indicate sparse/uninformative repeated measurements. Slopes are shown for every outcome, including unsupported EDA slopes.')

def boundary_figures(out,audit):
    d=pd.read_csv(audit/'heterogeneity_fixed_effects.csv')
    models=['context_window','context_window_time']
    for model in models:
        fig,axes=plt.subplots(1,2,figsize=(7.1,3.2),layout='constrained',sharey=True)
        for ax,predictor,title in zip(axes,['Temperature_z','CO2_z'],['Temperature','CO$_2$']):
            for j,outcome in enumerate(OUTCOMES):
                for variant,offset,color,label in [('original',-.11,COLORS['No-ER'],'Original'),('boundary_companion',.11,COLORS['ER'],'Boundary check')]:
                    q=d.loc[d.model.eq(model)&~d.slope&d.outcome.eq(outcome)&d.predictor.eq(predictor)&d.variant.eq(variant)]
                    if len(q)!=1:continue
                    r=q.iloc[0];ok=r.wald_status=='available_unflagged'
                    if ok:
                        ax.errorbar(r.beta,j+offset,xerr=[[r.beta-r.ci95_low],[r.ci95_high-r.beta]],fmt='o',c=color,ms=4,capsize=2,label=label if j==0 else None)
                    else:
                        ax.plot(r.beta,j+offset,'o',mfc='white',mec=color,ms=4,label=label if j==0 else None)
            ax.set_yticks(range(3),[LABELS[o] for o in OUTCOMES]);ax.set_ylim(2.6,-.6)
            ax.axvline(0,c='#69737B',lw=.8,ls='--');ax.set_title(title);ax.set_xlabel('Standardized coefficient');clean(ax)
        axes[1].legend(frameon=False,loc='upper center',bbox_to_anchor=(.5,-.25),ncol=2)
        fig.suptitle(MODEL_LABELS[model],fontsize=10)
        save(fig,out,'HET_boundary_'+model,'Original and explicitly labelled nuisance-boundary companion fits. Flagged original/companion estimates use hollow points WITHOUT potentially misleading Wald intervals. Displayed intervals are approximate; unflagged does not establish small-sample validity. No automatic main-model selection.')

def sensitivity_figures(out,audit):
    path=audit/'heterogeneity_baseline_sensitivity.csv'
    if not path.exists():return
    d=pd.read_csv(path);scenarios=list(dict.fromkeys(d.scenario))
    fig,axes=plt.subplots(1,3,figsize=(7.1,max(4.1,.25*len(scenarios)+1.4)),layout='constrained',sharey=True)
    for ax,outcome in zip(axes,OUTCOMES):
        for j,name in enumerate(scenarios):
            r=d.loc[d.outcome.eq(outcome)&d.scenario.eq(name)].iloc[0]
            if r.status=='passed' and r.nested_likelihood_order_valid:
                ax.plot(r.delta_AIC,j,'o',ms=4,c=COLORS['ER'])
            else:ax.text(.02,j,'Fit/likelihood check failed',transform=ax.get_yaxis_transform(),fontsize=6,color='#A35B49')
        ax.set_yticks(range(len(scenarios)),[x.replace('without_DATE__','Drop ').replace('coverage_ge_50pct','Coverage >=50%').replace('eda_zero_threshold_','EDA zero <').replace('before_eda_screen','Before EDA screen').replace('main','Main cohort') for x in scenarios])
        ax.set_ylim(len(scenarios)-.3,-.7);ax.axvline(0,c='#69737B',lw=.8);ax.axvline(-2,c='#69737B',lw=.8,ls='--')
        ax.set_title(LABELS[outcome]);ax.set_xlabel(r'Participant intercept $\Delta$AIC');clean(ax)
    save(fig,out,'HET_baseline_sensitivity','Identical-row ML comparisons of participant intercept inclusion, within each sensitivity cohort. Main, leave-one-date-out, >=50% coverage, and pre-QC/.90/.99 when available. Failed fits remain visible; no selection of favorable thresholds.')

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--analysis-dir',type=Path,required=True)
    p.add_argument('--audit-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--pv-dir',type=Path,help='Explicit full PV model directory when the source uses a nonstandard layout.')
    a=p.parse_args(argv)
    if not (a.audit_dir/'heterogeneity_component_comparison.csv').exists():raise FileNotFoundError('Run heterogeneity core before figures.')
    # A failed/incomplete core is never silently presented as a complete set.
    manifest=a.audit_dir/'heterogeneity_core_manifest.json'
    if manifest.exists() and json.loads(manifest.read_text()).get('status')!='completed':raise ValueError('Heterogeneity core is incomplete; rerun it first.')
    sensitivity_manifest=a.audit_dir/'heterogeneity_sensitivity_manifest.json'
    if sensitivity_manifest.exists() and json.loads(sensitivity_manifest.read_text()).get('status')!='completed':
        raise ValueError('Baseline sensitivity is incomplete; rerun it before exporting the combined figures.')
    pv=select_pv_directory(a.analysis_dir,a.pv_dir)
    style();MANIFEST.clear();a.output_dir.mkdir(parents=True,exist_ok=True)
    component_comparison(a.output_dir,a.audit_dir);variance_and_participants(a.output_dir,a.audit_dir)
    boundary_figures(a.output_dir,a.audit_dir);sensitivity_figures(a.output_dir,a.audit_dir)
    if pv is not None:
        print('PV figures use:',pv,flush=True);pv_figures(a.output_dir,pv)
    else:print('No full PV summary found; exporting heterogeneity figures only.',flush=True)
    (a.output_dir/'figure_manifest.json').write_text(json.dumps(MANIFEST,indent=2)+'\n',encoding='utf-8')
    print(f'Created {len(MANIFEST)} figure sets (PDF/SVG/400-dpi PNG): {a.output_dir}',flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
