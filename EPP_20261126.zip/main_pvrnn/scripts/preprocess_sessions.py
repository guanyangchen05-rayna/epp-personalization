#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Build the canonical participant-by-class tables and the behavior temporal view.

Extracted from cell index 1 of 819820(1).ipynb (300 complete-second threshold).
Class-to-file assignments are read from Classroom_Data.csv; this script does
not infer or validate physical classroom identity. See docs/data_provenance.md.
Environment is aligned within classes. Physiology is aggregated to 1 second
without interpolation. Surveys are linked to the most recently completed
participant class within 90 minutes. The behavior temporal table contains
exactly the same sessions as the behavior session table.

Use --base-dir for the historical raw-data layout and --output-dir for tables.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd


# =============================================================================
# 0. CONFIG
# =============================================================================

BASE_DIR = Path("data/raw")
OUT_DIR = BASE_DIR / "final_simple_tables"
QC_DIR = OUT_DIR / "00_qc"

# Environment
ENV_FREQ = "5min"
ENV_MATCH_TOLERANCE = pd.Timedelta("6min")

# Keep the already-audited conservative environment rules.
MIN_NATIVE_ENV_POINTS = 4
MIN_ENV_COVERAGE = 0.80
MAX_ENV_GAP_MINUTES = 10.0

CORE_ENV = [
    "IndoorTemperature",
    "IndoorCO2",
]

# Physiology
PHYS_FREQ = "1s"
PHYS_VARS = [
    "EDA",
    "HR",
    "TEMP",
]

# Minimum amount of jointly complete aligned data required for a
# participant x class session to enter the Env-Phys analytical cohort.
#
# This final threshold requires at least one full 5-min native environmental
# sampling interval of jointly complete Env+Phys data for a session summary.
MIN_COMPLETE_SECONDS_PER_SESSION = 300

# Survey
MAX_POST_CLASS_SURVEY_LAG = pd.Timedelta("90min")

TARGETS = [
    "EngageScore",
    "Arousal",
    "Valence",
]


# =============================================================================
# 1. GENERIC HELPERS
# =============================================================================

def clean_id(x) -> Optional[str]:
    if pd.isna(x):
        return None

    s = str(x).strip()

    if (
        not s
        or s.lower()
        in {"nan", "none", "null"}
    ):
        return None

    s = re.sub(
        r"\.csv$",
        "",
        s,
        flags=re.IGNORECASE,
    )

    if s.endswith(".0"):
        s = s[:-2]

    return s


def find_existing(
    base: Path,
    candidates: list[Path],
    required: bool = True,
) -> Optional[Path]:
    for rel in candidates:
        p = base / rel

        if p.exists():
            return p

    if required:
        raise FileNotFoundError(
            "Could not find any of:\n"
            + "\n".join(
                str(base / x)
                for x in candidates
            )
        )

    return None


def parse_date_value(v) -> pd.Timestamp:
    if pd.isna(v):
        return pd.NaT

    s = str(v).strip()

    if s.endswith(".0"):
        s = s[:-2]

    digits = "".join(
        ch
        for ch in s
        if ch.isdigit()
    )

    if (
        len(digits) == 8
        and digits.startswith(
            ("19", "20")
        )
    ):
        try:
            return pd.to_datetime(
                digits,
                format="%Y%m%d",
            )
        except Exception:
            pass

    return pd.to_datetime(
        s,
        dayfirst=True,
        errors="coerce",
    )


def combine_date_time(
    date_ts: pd.Timestamp,
    time_value,
) -> pd.Timestamp:
    if (
        pd.isna(date_ts)
        or pd.isna(time_value)
    ):
        return pd.NaT

    parsed = pd.to_datetime(
        str(time_value),
        errors="coerce",
    )

    if pd.isna(parsed):
        return pd.NaT

    return pd.Timestamp.combine(
        pd.Timestamp(
            date_ts
        ).date(),
        parsed.time(),
    )


def max_gap_minutes(
    stamps: pd.Series,
    class_start: pd.Timestamp,
    class_end: pd.Timestamp,
) -> float:
    """
    Largest gap across the class interval, including:
        class start -> first environment sample
        consecutive environment samples
        last sample -> class end
    """

    x = (
        pd.to_datetime(
            stamps,
            errors="coerce",
        )
        .dropna()
        .sort_values()
        .drop_duplicates()
    )

    if x.empty:
        return np.inf

    vals = np.concatenate(
        [
            np.asarray(
                [np.datetime64(class_start)]
            ),
            x.values.astype(
                "datetime64[ns]"
            ),
            np.asarray(
                [np.datetime64(class_end)]
            ),
        ]
    )

    vals = np.sort(vals)

    gaps = (
        np.diff(vals)
        .astype(
            "timedelta64[s]"
        )
        .astype(float)
        / 60.0
    )

    if len(gaps) == 0:
        return 0.0

    return float(
        np.nanmax(gaps)
    )


def safe_std(x) -> float:
    x = pd.to_numeric(
        pd.Series(x),
        errors="coerce",
    ).dropna()

    if len(x) <= 1:
        return 0.0

    value = float(
        x.std(ddof=1)
    )

    return (
        value
        if np.isfinite(value)
        else 0.0
    )


def safe_range(x) -> float:
    x = pd.to_numeric(
        pd.Series(x),
        errors="coerce",
    ).dropna()

    if x.empty:
        return np.nan

    return float(
        x.max() - x.min()
    )


def slope_per_minute(
    values,
    timestamps,
) -> float:
    y = pd.to_numeric(
        pd.Series(values),
        errors="coerce",
    )

    t = pd.to_datetime(
        pd.Series(timestamps),
        errors="coerce",
    )

    mask = (
        y.notna()
        & t.notna()
    )

    y = y[mask].to_numpy(
        dtype=float
    )

    t = t[mask]

    if (
        len(y) < 2
        or np.nanstd(y) < 1e-12
    ):
        return 0.0

    x = (
        (
            t
            - t.iloc[0]
        )
        .dt.total_seconds()
        .to_numpy(
            dtype=float
        )
        / 60.0
    )

    return float(
        np.polyfit(
            x,
            y,
            1,
        )[0]
    )


# =============================================================================
# 2. CLASSROOM DATA
# =============================================================================

def load_classroom_mapping(
    path: Path,
) -> pd.DataFrame:
    """
    Classroom_Data.csv is the single accepted source for:
        Class_id
        class start/end
        Class_id -> Matched_CSV
    """

    d = pd.read_csv(
        path,
        low_memory=False,
    )

    if "Class_id" not in d.columns:
        raise KeyError(
            "Classroom_Data.csv must contain Class_id."
        )

    if "Matched_CSV" not in d.columns:
        raise KeyError(
            "Classroom_Data.csv must contain Matched_CSV."
        )

    out = d.copy()

    out["Class_id"] = (
        out["Class_id"]
        .map(clean_id)
    )

    out["Matched_CSV"] = (
        out["Matched_CSV"]
        .map(clean_id)
    )

    if (
        "start_dt" in out.columns
        and "end_dt" in out.columns
    ):
        out["ClassStart"] = (
            pd.to_datetime(
                out["start_dt"],
                errors="coerce",
            )
        )

        out["ClassEnd"] = (
            pd.to_datetime(
                out["end_dt"],
                errors="coerce",
            )
        )

        out["ClassDate"] = (
            out["ClassStart"]
            .dt.normalize()
        )

    else:
        needed = {
            "Date",
            "Start_time",
            "Finish_time",
        }

        if not needed.issubset(
            out.columns
        ):
            raise KeyError(
                "Need either start_dt/end_dt "
                "or Date/Start_time/Finish_time."
            )

        out["ClassDate"] = (
            out["Date"]
            .map(parse_date_value)
        )

        out["ClassStart"] = [
            combine_date_time(
                dd,
                tt,
            )
            for dd, tt
            in zip(
                out["ClassDate"],
                out["Start_time"],
            )
        ]

        out["ClassEnd"] = [
            combine_date_time(
                dd,
                tt,
            )
            for dd, tt
            in zip(
                out["ClassDate"],
                out["Finish_time"],
            )
        ]

    overnight = (
        out["ClassEnd"]
        < out["ClassStart"]
    )

    out.loc[
        overnight,
        "ClassEnd",
    ] += pd.Timedelta(days=1)

    if "Confidence" in out.columns:
        out[
            "MappingConfidence"
        ] = pd.to_numeric(
            out["Confidence"],
            errors="coerce",
        )

    else:
        out[
            "MappingConfidence"
        ] = np.nan

    keep = [
        "Class_id",
        "ClassDate",
        "ClassStart",
        "ClassEnd",
        "Matched_CSV",
        "MappingConfidence",
    ]

    for optional in [
        "Room",
        "Subject",
        "Class_len",
        "Week",
        "Weekday",
        "Class_no",
        "is_Form",
    ]:
        if optional in out.columns:
            keep.append(
                optional
            )

    out = out[
        keep
    ]

    out = (
        out
        .dropna(
            subset=[
                "Class_id",
                "ClassStart",
                "ClassEnd",
            ]
        )
        .drop_duplicates(
            "Class_id",
            keep="first",
        )
        .sort_values(
            "ClassStart"
        )
        .reset_index(
            drop=True
        )
    )

    return out


# =============================================================================
# 3. ATTENDANCE STRUCTURE
# =============================================================================

def find_wearable_root(
    base: Path,
) -> Path:
    candidates = [
        base
        / "Class_wearable_data",

        base
        / "Class_wearable_data1",

        base
        / "Classwearabledata",
    ]

    for p in candidates:
        if (
            p.exists()
            and p.is_dir()
        ):
            return p

    raise FileNotFoundError(
        "Could not find wearable root."
    )


def build_attendance_sessions(
    wearable_root: Path,
    classes: pd.DataFrame,
) -> pd.DataFrame:
    """
    Scan ALL class folders, not just environment-valid classes.

    This matters for survey mapping:
    a survey belonging to an environment-invalid class must NOT be
    reassigned backward to an earlier environment-valid class.
    """

    class_meta = (
        classes
        .set_index(
            "Class_id"
        )
        .to_dict(
            "index"
        )
    )

    rows = []

    for class_dir in (
        wearable_root.iterdir()
    ):
        if not class_dir.is_dir():
            continue

        cid = clean_id(
            class_dir.name
        )

        if (
            cid is None
            or cid not in class_meta
        ):
            continue

        meta = class_meta[
            cid
        ]

        for pdir in (
            class_dir.iterdir()
        ):
            if not pdir.is_dir():
                continue

            pid = clean_id(
                pdir.name
            )

            if pid is None:
                continue

            rows.append({
                "Pid":
                    pid,

                "Class_id":
                    cid,

                "ClassDate":
                    meta[
                        "ClassDate"
                    ],

                "ClassStart":
                    meta[
                        "ClassStart"
                    ],

                "ClassEnd":
                    meta[
                        "ClassEnd"
                    ],

                "Matched_CSV":
                    meta[
                        "Matched_CSV"
                    ],
            })

    if not rows:
        return pd.DataFrame()

    return (
        pd.DataFrame(
            rows
        )
        .drop_duplicates(
            [
                "Pid",
                "Class_id",
            ],
            keep="first",
        )
        .sort_values(
            [
                "ClassStart",
                "Class_id",
                "Pid",
            ]
        )
        .reset_index(
            drop=True
        )
    )


# =============================================================================
# 4. ENVIRONMENT
# =============================================================================

def parse_environment_datetime(
    d: pd.DataFrame,
) -> pd.Series:
    if "Timestamp" in d.columns:
        raw = d["Timestamp"]

    elif "DateTime" in d.columns:
        raw = d["DateTime"]

    else:
        raw = d.iloc[:, 0]

    numeric = pd.to_numeric(
        raw,
        errors="coerce",
    )

    if (
        numeric.notna().mean()
        > 0.95
        and numeric.max(
            skipna=True
        )
        > 1e8
    ):
        return pd.to_datetime(
            numeric,
            unit="s",
            errors="coerce",
        )

    out = pd.to_datetime(
        raw,
        errors="coerce",
    )

    bad = out.isna()

    if bad.any():
        out.loc[
            bad
        ] = pd.to_datetime(
            raw.loc[
                bad
            ],
            dayfirst=True,
            errors="coerce",
        )

    return out


class EnvironmentCache:
    def __init__(
        self,
        longitudinal_dir: Path,
    ):
        self.longitudinal_dir = (
            longitudinal_dir
        )

        self.cache = {}

    def load(
        self,
        sensor_name: str,
    ) -> Optional[pd.DataFrame]:
        sensor_name = clean_id(
            sensor_name
        )

        if sensor_name is None:
            return None

        if sensor_name in self.cache:
            return self.cache[
                sensor_name
            ]

        path = (
            self.longitudinal_dir
            / f"{sensor_name}.csv"
        )

        if not path.exists():
            self.cache[
                sensor_name
            ] = None

            return None

        d = pd.read_csv(
            path,
            low_memory=False,
        )

        if not set(
            CORE_ENV
        ).issubset(
            d.columns
        ):
            self.cache[
                sensor_name
            ] = None

            return None

        d = d.copy()

        d[
            "EnvTimestamp"
        ] = (
            parse_environment_datetime(
                d
            )
        )

        for c in CORE_ENV:
            d[c] = pd.to_numeric(
                d[c],
                errors="coerce",
            )

        d = (
            d.dropna(
                subset=[
                    "EnvTimestamp"
                ]
            )
            .sort_values(
                "EnvTimestamp"
            )
            .drop_duplicates(
                "EnvTimestamp",
                keep="first",
            )
            .reset_index(
                drop=True
            )
        )

        self.cache[
            sensor_name
        ] = d

        return d


def audit_environment_classes(
    classes: pd.DataFrame,
    env_cache: EnvironmentCache,
):
    """
    Return:
        env_qc
        env_segments

    env_segments[cid] contains only class-local environment context.
    """

    audit_rows = []
    env_segments = {}

    for _, r in (
        classes.iterrows()
    ):
        cid = r[
            "Class_id"
        ]

        sensor = clean_id(
            r[
                "Matched_CSV"
            ]
        )

        row = {
            "Class_id":
                cid,

            "ClassStart":
                r[
                    "ClassStart"
                ],

            "ClassEnd":
                r[
                    "ClassEnd"
                ],

            "Matched_CSV":
                sensor,

            "status":
                None,

            "n_native_env_points":
                0,

            "temperature_coverage":
                0.0,

            "co2_coverage":
                0.0,

            "max_gap_minutes":
                np.inf,
        }

        if sensor is None:
            row[
                "status"
            ] = "DROP_NO_MAPPING"

            audit_rows.append(
                row
            )

            continue

        env = env_cache.load(
            sensor
        )

        if env is None:
            row[
                "status"
            ] = (
                "DROP_ENV_FILE_MISSING_OR_BAD"
            )

            audit_rows.append(
                row
            )

            continue

        lo = (
            r["ClassStart"]
            .floor(
                ENV_FREQ
            )
        )

        hi = (
            r["ClassEnd"]
            .ceil(
                ENV_FREQ
            )
        )

        seg = env[
            (
                env[
                    "EnvTimestamp"
                ]
                >= lo
            )
            &
            (
                env[
                    "EnvTimestamp"
                ]
                <= hi
            )
        ].copy()

        if seg.empty:
            row[
                "status"
            ] = (
                "DROP_NO_ENV_ROWS_IN_CLASS"
            )

            audit_rows.append(
                row
            )

            continue

        expected_n = max(
            len(
                pd.date_range(
                    lo,
                    hi,
                    freq=ENV_FREQ,
                )
            ),
            1,
        )

        temp_valid = (
            seg[
                "IndoorTemperature"
            ]
            .notna()
        )

        co2_valid = (
            seg[
                "IndoorCO2"
            ]
            .notna()
        )

        both = (
            temp_valid
            & co2_valid
        )

        temp_cov = min(
            float(
                temp_valid.sum()
                / expected_n
            ),
            1.0,
        )

        co2_cov = min(
            float(
                co2_valid.sum()
                / expected_n
            ),
            1.0,
        )

        gap = (
            max_gap_minutes(
                seg.loc[
                    both,
                    "EnvTimestamp",
                ],
                r[
                    "ClassStart"
                ],
                r[
                    "ClassEnd"
                ],
            )
        )

        row.update({
            "n_native_env_points":
                int(
                    len(seg)
                ),

            "temperature_coverage":
                temp_cov,

            "co2_coverage":
                co2_cov,

            "max_gap_minutes":
                gap,
        })

        passed = bool(
            len(seg)
            >= MIN_NATIVE_ENV_POINTS
            and temp_cov
            >= MIN_ENV_COVERAGE
            and co2_cov
            >= MIN_ENV_COVERAGE
            and gap
            <= MAX_ENV_GAP_MINUTES
        )

        if not passed:
            row[
                "status"
            ] = "DROP_ENV_QC_FAIL"

            audit_rows.append(
                row
            )

            continue

        row[
            "status"
        ] = "PASS"

        # Include at most one preceding native interval so a physiology
        # second just after class start can use the last preceding reading.
        context = env[
            (
                env[
                    "EnvTimestamp"
                ]
                >= (
                    r[
                        "ClassStart"
                    ]
                    - ENV_MATCH_TOLERANCE
                )
            )
            &
            (
                env[
                    "EnvTimestamp"
                ]
                <= r[
                    "ClassEnd"
                ]
            )
        ].copy()

        context[
            "Class_id"
        ] = cid

        context[
            "Matched_CSV"
        ] = sensor

        env_segments[
            cid
        ] = context

        audit_rows.append(
            row
        )

    return (
        pd.DataFrame(
            audit_rows
        ),
        env_segments,
    )


def build_class_environment_summary(
    classes_valid: pd.DataFrame,
    env_segments: dict,
) -> pd.DataFrame:
    """
    ONE row = ONE class.

    Environment summaries are calculated from the class environmental
    timeline itself, independent of participant physiology availability.
    """

    rows = []

    class_meta = (
        classes_valid
        .set_index(
            "Class_id"
        )
        .to_dict(
            "index"
        )
    )

    for cid, env in (
        env_segments.items()
    ):
        meta = class_meta[
            cid
        ]

        # Summary uses only readings inside the actual class interval.
        q = env[
            (
                env[
                    "EnvTimestamp"
                ]
                >= meta[
                    "ClassStart"
                ]
            )
            &
            (
                env[
                    "EnvTimestamp"
                ]
                <= meta[
                    "ClassEnd"
                ]
            )
        ].copy()

        if q.empty:
            continue

        row = {
            "Class_id":
                cid,

            "Matched_CSV":
                meta[
                    "Matched_CSV"
                ],

            "ClassStart":
                meta[
                    "ClassStart"
                ],

            "ClassEnd":
                meta[
                    "ClassEnd"
                ],

            "ClassDate":
                meta[
                    "ClassDate"
                ],

            "EnvironmentEpisodeKey":
                (
                    str(
                        meta[
                            "Matched_CSV"
                        ]
                    )
                    + "__"
                    + pd.Timestamp(
                        meta[
                            "ClassStart"
                        ]
                    ).strftime(
                        "%Y-%m-%dT%H:%M:%S"
                    )
                    + "__"
                    + pd.Timestamp(
                        meta[
                            "ClassEnd"
                        ]
                    ).strftime(
                        "%Y-%m-%dT%H:%M:%S"
                    )
                ),
        }

        for col, prefix in [
            (
                "IndoorTemperature",
                "Temperature",
            ),
            (
                "IndoorCO2",
                "CO2",
            ),
        ]:
            vals = pd.to_numeric(
                q[col],
                errors="coerce",
            )

            row[
                f"{prefix}_mean"
            ] = float(
                vals.mean()
            )

            row[
                f"{prefix}_std"
            ] = safe_std(
                vals
            )

            row[
                f"{prefix}_min"
            ] = float(
                vals.min()
            )

            row[
                f"{prefix}_max"
            ] = float(
                vals.max()
            )

            row[
                f"{prefix}_range"
            ] = safe_range(
                vals
            )

            row[
                f"{prefix}_slope_per_min"
            ] = slope_per_minute(
                vals,
                q[
                    "EnvTimestamp"
                ],
            )

        rows.append(
            row
        )

    return pd.DataFrame(
        rows
    )


# =============================================================================
# 5. WEARABLE PHYSIOLOGY
# =============================================================================

def parse_wearable_datetime(
    d: pd.DataFrame,
    class_date: pd.Timestamp,
    class_start: pd.Timestamp,
    class_end: pd.Timestamp,
) -> tuple[pd.Series, int]:
    """
    Supports the official project formats:
      A. Date column contains full timestamps.
      B. Date contains recording start clock time; Time contains elapsed seconds.
      C. Date is a per-sample clock time.

    A {-1,0,+1} h shift is selected ONLY to maximize overlap with the
    official class interval and is recorded in QC.
    """

    cols = {
        str(c).strip().lower():
            c
        for c in d.columns
    }

    raw_date = None

    if "date" in cols:
        raw_date = (
            d[
                cols[
                    "date"
                ]
            ]
            .astype(str)
            .str.strip()
        )

    has_calendar = False

    if raw_date is not None:
        sample = (
            raw_date
            .dropna()
            .head(30)
            .astype(str)
        )

        date_regex = (
            r"(?:"
            r"\b(?:19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b"
            r"|"
            r"\b\d{1,2}[-/]\d{1,2}[-/](?:19|20)\d{2}\b"
            r")"
        )

        has_calendar = bool(
            sample.str.contains(
                date_regex,
                regex=True,
                na=False,
            ).mean()
            > 0.5
        )

    # A. Full timestamps
    if (
        raw_date is not None
        and has_calendar
    ):
        dt = pd.to_datetime(
            raw_date,
            dayfirst=True,
            errors="coerce",
        )

    # B. Recording start clock + elapsed seconds
    elif "time" in cols:
        rel = pd.to_numeric(
            d[
                cols[
                    "time"
                ]
            ],
            errors="coerce",
        )

        base_time = None

        if raw_date is not None:
            for val in (
                raw_date
                .dropna()
                .head(20)
            ):
                val = str(
                    val
                ).strip()

                if ":" not in val:
                    continue

                parsed = pd.to_datetime(
                    val,
                    format="%H:%M:%S",
                    errors="coerce",
                )

                if pd.isna(parsed):
                    parsed = pd.to_datetime(
                        val,
                        format="%H:%M:%S.%f",
                        errors="coerce",
                    )

                if pd.isna(parsed):
                    parsed = pd.to_datetime(
                        val,
                        format="%H:%M",
                        errors="coerce",
                    )

                if pd.notna(parsed):
                    base_time = (
                        parsed.time()
                    )

                    break

        if base_time is None:
            base_dt = pd.Timestamp(
                class_start
            )

        else:
            base_dt = pd.Timestamp.combine(
                pd.Timestamp(
                    class_date
                ).date(),
                base_time,
            )

        dt = (
            base_dt
            + pd.to_timedelta(
                rel,
                unit="s",
            )
        )

    # C. Per-sample clock time
    elif raw_date is not None:
        base_date = pd.Timestamp(
            class_date
        ).strftime(
            "%Y-%m-%d"
        )

        dt = pd.to_datetime(
            (
                base_date
                + " "
                + raw_date
            ),
            errors="coerce",
        )

    else:
        dt = pd.Series(
            pd.NaT,
            index=d.index,
            dtype="datetime64[ns]",
        )

    best_shift = 0
    best_score = -1.0

    for shift in (
        -1,
        0,
        1,
    ):
        shifted = (
            dt
            + pd.Timedelta(
                hours=shift
            )
        )

        inside = (
            shifted.notna()
            &
            (
                shifted
                >= (
                    class_start
                    - pd.Timedelta(
                        minutes=5
                    )
                )
            )
            &
            (
                shifted
                <= (
                    class_end
                    + pd.Timedelta(
                        minutes=5
                    )
                )
            )
        )

        score = (
            float(
                inside.mean()
            )
            if len(inside)
            else 0.0
        )

        if score > best_score:
            best_score = score
            best_shift = shift

    return (
        dt
        + pd.Timedelta(
            hours=best_shift
        ),
        best_shift,
    )


def load_phys_signal_1s(
    path: Path,
    sensor: str,
    class_date: pd.Timestamp,
    class_start: pd.Timestamp,
    class_end: pd.Timestamp,
):
    audit = {
        "signal":
            sensor,

        "source_exists":
            path.exists(),

        "selected_hour_shift":
            np.nan,

        "n_raw_rows":
            0,

        "n_rows_in_class":
            0,

        "n_1s_bins":
            0,
    }

    if not path.exists():
        return (
            None,
            audit,
        )

    d = pd.read_csv(
        path,
        low_memory=False,
    )

    audit[
        "n_raw_rows"
    ] = int(
        len(d)
    )

    if d.empty:
        return (
            None,
            audit,
        )

    cols = {
        str(c).strip().lower():
            c
        for c in d.columns
    }

    sensor_col = None

    if sensor.lower() in cols:
        sensor_col = cols[
            sensor.lower()
        ]

    else:
        ignore = {
            "date",
            "time",
            "datetime",
            "timestamp",
        }

        candidates = [
            c
            for c in d.columns
            if str(
                c
            ).strip().lower()
            not in ignore
        ]

        if candidates:
            sensor_col = (
                candidates[0]
            )

    if sensor_col is None:
        return (
            None,
            audit,
        )

    dt, shift = (
        parse_wearable_datetime(
            d,
            class_date,
            class_start,
            class_end,
        )
    )

    audit[
        "selected_hour_shift"
    ] = int(
        shift
    )

    value = pd.to_numeric(
        d[
            sensor_col
        ],
        errors="coerce",
    )

    out = pd.DataFrame({
        "DateTime":
            dt,

        sensor:
            value,
    }).dropna(
        subset=[
            "DateTime",
            sensor,
        ]
    )

    # Strict class interval only.
    out = out[
        (
            out[
                "DateTime"
            ]
            >= class_start
        )
        &
        (
            out[
                "DateTime"
            ]
            <= class_end
        )
    ].copy()

    audit[
        "n_rows_in_class"
    ] = int(
        len(out)
    )

    if out.empty:
        return (
            None,
            audit,
        )

    # Common 1-s grid; NO interpolation.
    out = (
        out
        .set_index(
            "DateTime"
        )[
            [
                sensor
            ]
        ]
        .resample(
            PHYS_FREQ
        )
        .mean()
        .dropna()
        .reset_index()
    )

    audit[
        "n_1s_bins"
    ] = int(
        len(out)
    )

    return (
        out,
        audit,
    )


def build_physiology_1s(
    wearable_root: Path,
    classes_valid: pd.DataFrame,
    valid_class_ids: set[str],
):
    class_meta = (
        classes_valid[
            classes_valid[
                "Class_id"
            ].isin(
                valid_class_ids
            )
        ]
        .set_index(
            "Class_id"
        )
        .to_dict(
            "index"
        )
    )

    output_rows = []
    audit_rows = []

    for cid in sorted(
        valid_class_ids,
        key=lambda x:
            class_meta[
                x
            ][
                "ClassStart"
            ],
    ):
        class_dir = (
            wearable_root
            / cid
        )

        if (
            not class_dir.exists()
            or not class_dir.is_dir()
        ):
            continue

        meta = class_meta[
            cid
        ]

        for pdir in sorted(
            [
                p
                for p
                in class_dir.iterdir()
                if (
                    p.is_dir()
                    and clean_id(
                        p.name
                    )
                    is not None
                )
            ],
            key=lambda p:
                str(
                    clean_id(
                        p.name
                    )
                ),
        ):
            pid = clean_id(
                pdir.name
            )

            frames = []
            audits = {}

            for sensor in PHYS_VARS:
                frame, audit = (
                    load_phys_signal_1s(
                        (
                            pdir
                            / f"{sensor}.csv"
                        ),
                        sensor,
                        meta[
                            "ClassDate"
                        ],
                        meta[
                            "ClassStart"
                        ],
                        meta[
                            "ClassEnd"
                        ],
                    )
                )

                audits[
                    sensor
                ] = audit

                if frame is not None:
                    frames.append(
                        frame
                    )

            audit_row = {
                "Pid":
                    pid,

                "Class_id":
                    cid,

                "ClassStart":
                    meta[
                        "ClassStart"
                    ],

                "ClassEnd":
                    meta[
                        "ClassEnd"
                    ],
            }

            for sensor in PHYS_VARS:
                a = audits[
                    sensor
                ]

                audit_row[
                    f"{sensor}_source_exists"
                ] = a[
                    "source_exists"
                ]

                audit_row[
                    f"{sensor}_shift_h"
                ] = a[
                    "selected_hour_shift"
                ]

                audit_row[
                    f"{sensor}_raw_rows"
                ] = a[
                    "n_raw_rows"
                ]

                audit_row[
                    f"{sensor}_rows_in_class"
                ] = a[
                    "n_rows_in_class"
                ]

                audit_row[
                    f"{sensor}_1s_bins"
                ] = a[
                    "n_1s_bins"
                ]

            if not frames:
                audit_row[
                    "n_union_1s_rows"
                ] = 0

                audit_row[
                    "n_complete_phys_1s_rows"
                ] = 0

                audit_rows.append(
                    audit_row
                )

                continue

            merged = frames[0]

            for f in frames[1:]:
                merged = merged.merge(
                    f,
                    on="DateTime",
                    how="outer",
                )

            merged = (
                merged
                .sort_values(
                    "DateTime"
                )
                .reset_index(
                    drop=True
                )
            )

            for sensor in PHYS_VARS:
                if sensor not in (
                    merged.columns
                ):
                    merged[
                        sensor
                    ] = np.nan

            merged[
                "Pid"
            ] = pid

            merged[
                "Class_id"
            ] = cid

            merged[
                "ClassDate"
            ] = meta[
                "ClassDate"
            ]

            merged[
                "ClassStart"
            ] = meta[
                "ClassStart"
            ]

            merged[
                "ClassEnd"
            ] = meta[
                "ClassEnd"
            ]

            merged[
                "Matched_CSV"
            ] = meta[
                "Matched_CSV"
            ]

            merged[
                "HasCorePhysiology"
            ] = (
                merged[
                    PHYS_VARS
                ]
                .notna()
                .all(
                    axis=1
                )
            )

            audit_row[
                "n_union_1s_rows"
            ] = int(
                len(
                    merged
                )
            )

            audit_row[
                "n_complete_phys_1s_rows"
            ] = int(
                merged[
                    "HasCorePhysiology"
                ].sum()
            )

            audit_rows.append(
                audit_row
            )

            output_rows.append(
                merged
            )

    if output_rows:
        physiology = pd.concat(
            output_rows,
            ignore_index=True,
            sort=False,
        )

        physiology = (
            physiology
            .sort_values(
                [
                    "ClassStart",
                    "Class_id",
                    "Pid",
                    "DateTime",
                ]
            )
            .reset_index(
                drop=True
            )
        )

    else:
        physiology = (
            pd.DataFrame()
        )

    return (
        physiology,
        pd.DataFrame(
            audit_rows
        ),
    )


# =============================================================================
# 6. CLASS-SPECIFIC ENVIRONMENT + PHYSIOLOGY
# =============================================================================

def merge_environment_to_physiology(
    physiology: pd.DataFrame,
    env_segments: dict,
) -> pd.DataFrame:
    chunks = []

    for cid, g in (
        physiology.groupby(
            "Class_id",
            sort=False,
        )
    ):
        if cid not in (
            env_segments
        ):
            continue

        env = (
            env_segments[
                cid
            ][
                [
                    "EnvTimestamp",
                    *CORE_ENV,
                ]
            ]
            .sort_values(
                "EnvTimestamp"
            )
        )

        gg = (
            g.sort_values(
                "DateTime"
            )
            .copy()
        )

        # pandas can infer different datetime resolutions across CSV parsing and
        # resampling paths. Equal clock times must have identical join dtypes;
        # microseconds -> nanoseconds is exact and does not shift timestamps.
        gg["DateTime"] = pd.to_datetime(gg["DateTime"]).astype("datetime64[ns]")
        env["EnvTimestamp"] = pd.to_datetime(env["EnvTimestamp"]).astype("datetime64[ns]")

        merged = pd.merge_asof(
            gg,
            env,
            left_on="DateTime",
            right_on="EnvTimestamp",
            direction="backward",
            tolerance=(
                ENV_MATCH_TOLERANCE
            ),
        )

        merged[
            "HasCoreEnvironment"
        ] = (
            merged[
                CORE_ENV
            ]
            .notna()
            .all(
                axis=1
            )
        )

        merged[
            "HasCoreEnvironmentPhysiology"
        ] = (
            merged[
                "HasCoreEnvironment"
            ]
            &
            merged[
                "HasCorePhysiology"
            ]
        )

        chunks.append(
            merged
        )

    if not chunks:
        return pd.DataFrame()

    return (
        pd.concat(
            chunks,
            ignore_index=True,
            sort=False,
        )
        .sort_values(
            [
                "ClassStart",
                "Class_id",
                "Pid",
                "DateTime",
            ]
        )
        .reset_index(
            drop=True
        )
    )


# =============================================================================
# 7. SURVEY
# =============================================================================

LIKERT_MAP = {
    "strongly disagree":
        1.0,

    "somewhat disagree":
        2.0,

    "neither agree nor disagree":
        3.0,

    "neither agree nor disagree.":
        3.0,

    "neutral":
        3.0,

    "somewhat agree":
        4.0,

    "strongly agree":
        5.0,
}


def load_survey_source(
    base: Path,
) -> tuple[
    pd.DataFrame,
    str,
]:
    """
    FINAL pipeline requires the official survey file.
    No legacy merged-table fallback is used here.
    """

    path = find_existing(
        base,
        [
            Path(
                "Survey"
            )
            / "Student_survey.csv",

            Path(
                "Survey"
            )
            / "Studentsurvey.csv",

            Path(
                "Student_survey.csv"
            ),

            Path(
                "Studentsurvey.csv"
            ),
        ],
        required=True,
    )

    return (
        pd.read_csv(
            path,
            low_memory=False,
        ),
        str(path),
    )


def prepare_survey(
    survey: pd.DataFrame,
) -> pd.DataFrame:
    d = survey.copy()

    if (
        "Pid" not in d.columns
        or "Time" not in d.columns
    ):
        raise KeyError(
            "Survey must contain Pid and Time."
        )

    d[
        "Pid"
    ] = (
        d[
            "Pid"
        ]
        .map(clean_id)
    )

    d[
        "SurveyDateTime"
    ] = (
        pd.to_datetime(
            d[
                "Time"
            ],
            dayfirst=True,
            errors="coerce",
        )
    )

    engage_items = [
        "Engage_1",
        "Engage_2",
        "Engage_3",
        "Engage_4",
        "Engage_5",
    ]

    for col in engage_items:
        if col not in (
            d.columns
        ):
            d[
                col
            ] = np.nan

        text = (
            d[
                col
            ]
            .astype(str)
            .str.strip()
            .str.lower()
        )

        mapped = (
            text.map(
                LIKERT_MAP
            )
        )

        numeric = pd.to_numeric(
            d[
                col
            ],
            errors="coerce",
        )

        d[
            col
        ] = (
            mapped.fillna(
                numeric
            )
        )

    for col in [
        "Arousal",
        "Valence",
    ]:
        if col in d.columns:
            d[
                col
            ] = pd.to_numeric(
                d[
                    col
                ],
                errors="coerce",
            )

        else:
            d[
                col
            ] = np.nan

    # Reverse-scored engagement items.
    d[
        "Engage_2_R"
    ] = (
        6.0
        - d[
            "Engage_2"
        ]
    )

    d[
        "Engage_4_R"
    ] = (
        6.0
        - d[
            "Engage_4"
        ]
    )

    # Canonical all-five-item score.
    # skipna=False means all five items are required.
    d[
        "EngageScore"
    ] = (
        d[
            [
                "Engage_1",
                "Engage_2_R",
                "Engage_3",
                "Engage_4_R",
                "Engage_5",
            ]
        ]
        .mean(
            axis=1,
            skipna=False,
        )
    )

    d = (
        d.dropna(
            subset=[
                "Pid",
                "SurveyDateTime",
            ]
        )
        .sort_values(
            [
                "Pid",
                "SurveyDateTime",
            ]
        )
        .reset_index(
            drop=True
        )
    )

    return d


def map_surveys_strict(
    survey: pd.DataFrame,
    attendance: pd.DataFrame,
):
    """
    FINAL strict rule only:

    For each survey:
      find the participant's most recently COMPLETED class
      ending no more than 90 min before survey submission.

    There is NO current-class fallback.

    Multiple surveys -> same Pid x Class:
      keep the survey closest to class end.
    """

    mapped_rows = []

    attendance = (
        attendance.copy()
    )

    for _, r in (
        survey.iterrows()
    ):
        pid = r[
            "Pid"
        ]

        st = r[
            "SurveyDateTime"
        ]

        candidates = (
            attendance[
                attendance[
                    "Pid"
                ].eq(
                    pid
                )
            ]
            .copy()
        )

        base = {
            "Pid":
                pid,

            "SurveyDateTime":
                st,

            "SurveyMapStatus":
                None,

            "Class_id":
                None,

            "SurveyLagFromClassEndMin":
                np.nan,

            "EngageScore":
                r.get(
                    "EngageScore",
                    np.nan,
                ),

            "Arousal":
                r.get(
                    "Arousal",
                    np.nan,
                ),

            "Valence":
                r.get(
                    "Valence",
                    np.nan,
                ),
        }

        if candidates.empty:
            base[
                "SurveyMapStatus"
            ] = "NO_ATTENDANCE_SESSION"

            mapped_rows.append(
                base
            )

            continue

        completed = candidates[
            (
                candidates[
                    "ClassEnd"
                ]
                <= st
            )
            &
            (
                (
                    st
                    - candidates[
                        "ClassEnd"
                    ]
                )
                <= MAX_POST_CLASS_SURVEY_LAG
            )
        ].copy()

        if completed.empty:
            base[
                "SurveyMapStatus"
            ] = (
                "NO_RECENT_COMPLETED_CLASS"
            )

            mapped_rows.append(
                base
            )

            continue

        completed = (
            completed
            .sort_values(
                "ClassEnd",
                ascending=False,
            )
        )

        chosen = (
            completed.iloc[0]
        )

        lag_min = float(
            (
                st
                - pd.Timestamp(
                    chosen[
                        "ClassEnd"
                    ]
                )
            ).total_seconds()
            / 60.0
        )

        base.update({
            "SurveyMapStatus":
                "MAPPED_STRICT",

            "Class_id":
                chosen[
                    "Class_id"
                ],

            "SurveyLagFromClassEndMin":
                lag_min,
        })

        mapped_rows.append(
            base
        )

    qc = pd.DataFrame(
        mapped_rows
    )

    mapped = qc[
        qc[
            "SurveyMapStatus"
        ].eq(
            "MAPPED_STRICT"
        )
    ].copy()

    if mapped.empty:
        return (
            qc,
            pd.DataFrame(),
        )

    # If >1 survey maps to same session:
    # keep the closest to class end.
    mapped = (
        mapped
        .sort_values(
            [
                "Pid",
                "Class_id",
                "SurveyLagFromClassEndMin",
                "SurveyDateTime",
            ]
        )
    )

    labels = (
        mapped
        .drop_duplicates(
            subset=[
                "Pid",
                "Class_id",
            ],
            keep="first",
        )
        [
            [
                "Pid",
                "Class_id",
                "SurveyDateTime",
                "SurveyLagFromClassEndMin",
                *TARGETS,
            ]
        ]
        .rename(
            columns={
                "SurveyDateTime":
                    "BehaviorLabelTime",

                "SurveyLagFromClassEndMin":
                    "BehaviorLabelLagMin",
            }
        )
        .reset_index(
            drop=True
        )
    )

    return (
        qc,
        labels,
    )


# =============================================================================
# 8. BUILD THE ONE CANONICAL SESSION TABLE
# =============================================================================

def build_session_master(
    merged_1s: pd.DataFrame,
    class_env_summary: pd.DataFrame,
    strict_labels: pd.DataFrame,
) -> pd.DataFrame:
    """
    ONE ROW = ONE Pid x Class session.

    Physiology summaries use only seconds where:
        Temperature + CO2 + EDA + HR + TEMP are all jointly available.

    Environment summaries come from the CLASS environmental timeline itself,
    not from participant-specific valid physiology seconds.
    """

    if merged_1s.empty:
        raise RuntimeError(
            "Merged 1-s table is empty."
        )

    rows = []

    for (
        pid,
        cid,
    ), g in (
        merged_1s.groupby(
            [
                "Pid",
                "Class_id",
            ],
            sort=False,
        )
    ):
        g = (
            g.sort_values(
                "DateTime"
            )
            .copy()
        )

        valid = g[
            g[
                "HasCoreEnvironmentPhysiology"
            ]
        ].copy()

        class_start = (
            g[
                "ClassStart"
            ].iloc[0]
        )

        class_end = (
            g[
                "ClassEnd"
            ].iloc[0]
        )

        duration_sec = max(
            int(
                (
                    pd.Timestamp(
                        class_end
                    )
                    - pd.Timestamp(
                        class_start
                    )
                ).total_seconds()
            )
            + 1,
            1,
        )

        n_valid = int(
            len(
                valid
            )
        )

        row = {
            "Pid":
                str(pid),

            "Class_id":
                str(cid),

            "ClassDate":
                pd.Timestamp(
                    class_start
                ).normalize(),

            "ClassStart":
                class_start,

            "ClassEnd":
                class_end,

            "Matched_CSV":
                g[
                    "Matched_CSV"
                ].iloc[0],

            "n_union_1s_rows":
                int(
                    len(g)
                ),

            "n_complete_env_phys_seconds":
                n_valid,

            "complete_env_phys_fraction_of_class":
                float(
                    n_valid
                    / duration_sec
                ),

            "EnvPhysReady":
                bool(
                    n_valid
                    >= MIN_COMPLETE_SECONDS_PER_SESSION
                ),
        }

        # Physiology summaries.
        for col, prefix in [
            (
                "EDA",
                "EDA",
            ),
            (
                "HR",
                "HR",
            ),
            (
                "TEMP",
                "SkinTEMP",
            ),
        ]:
            vals = pd.to_numeric(
                valid[
                    col
                ],
                errors="coerce",
            )

            row[
                f"{prefix}_mean"
            ] = (
                float(
                    vals.mean()
                )
                if len(vals)
                else np.nan
            )

            row[
                f"{prefix}_std"
            ] = (
                safe_std(
                    vals
                )
                if len(vals)
                else np.nan
            )

            row[
                f"{prefix}_median"
            ] = (
                float(
                    vals.median()
                )
                if len(vals)
                else np.nan
            )

            row[
                f"{prefix}_range"
            ] = (
                safe_range(
                    vals
                )
                if len(vals)
                else np.nan
            )

            row[
                f"{prefix}_slope_per_min"
            ] = (
                slope_per_minute(
                    vals,
                    valid[
                        "DateTime"
                    ],
                )
                if len(vals)
                else np.nan
            )

        rows.append(
            row
        )

    session = pd.DataFrame(
        rows
    )

    # Add environment summaries.
    session = session.merge(
        class_env_summary,
        on=[
            "Class_id",
            "Matched_CSV",
            "ClassStart",
            "ClassEnd",
            "ClassDate",
        ],
        how="left",
        validate="many_to_one",
    )

    # Add strict session-level behavior.
    if not strict_labels.empty:
        session = session.merge(
            strict_labels,
            on=[
                "Pid",
                "Class_id",
            ],
            how="left",
            validate="one_to_one",
        )

    else:
        for c in [
            "BehaviorLabelTime",
            "BehaviorLabelLagMin",
            *TARGETS,
        ]:
            session[
                c
            ] = np.nan

    session[
        "HasCompleteBehavior"
    ] = (
        session[
            TARGETS
        ]
        .notna()
        .all(
            axis=1
        )
    )

    session[
        "StrictBehaviorReady"
    ] = (
        session[
            "EnvPhysReady"
        ]
        &
        session[
            "HasCompleteBehavior"
        ]
    )

    return (
        session
        .sort_values(
            [
                "ClassStart",
                "Pid",
            ]
        )
        .reset_index(
            drop=True
        )
    )


# =============================================================================
# 9. TEMPORAL VIEW OF THE SAME STRICT BEHAVIOR SESSIONS
# =============================================================================

def build_behavior_temporal_1s(
    merged_1s: pd.DataFrame,
    session_master: pd.DataFrame,
) -> pd.DataFrame:
    """
    This is NOT a second cohort.

    It is a temporal representation of exactly the same
    StrictBehaviorReady Pid x Class sessions used in SEM/tabular prediction.
    """

    strict = (
        session_master[
            session_master[
                "StrictBehaviorReady"
            ]
        ][
            [
                "Pid",
                "Class_id",
                "BehaviorLabelTime",
                "BehaviorLabelLagMin",
                *TARGETS,
            ]
        ]
        .copy()
    )

    if strict.empty:
        return pd.DataFrame()

    x = (
        merged_1s[
            merged_1s[
                "HasCoreEnvironmentPhysiology"
            ]
        ]
        .copy()
    )

    x[
        "Pid"
    ] = (
        x[
            "Pid"
        ]
        .astype(str)
    )

    x[
        "Class_id"
    ] = (
        x[
            "Class_id"
        ]
        .astype(str)
    )

    out = x.merge(
        strict,
        on=[
            "Pid",
            "Class_id",
        ],
        how="inner",
        validate="many_to_one",
    )

    out[
        "BehaviorLabelLevel"
    ] = "SESSION"

    keep = [
        "Pid",
        "Class_id",
        "ClassDate",
        "ClassStart",
        "ClassEnd",
        "Matched_CSV",
        "DateTime",
        "IndoorTemperature",
        "IndoorCO2",
        "EDA",
        "HR",
        "TEMP",
        "BehaviorLabelTime",
        "BehaviorLabelLagMin",
        "BehaviorLabelLevel",
        *TARGETS,
    ]

    return (
        out[
            keep
        ]
        .sort_values(
            [
                "ClassStart",
                "Pid",
                "DateTime",
            ]
        )
        .reset_index(
            drop=True
        )
    )


# =============================================================================
# 10. MAIN
# =============================================================================

def main(
    base_dir: Path = BASE_DIR,
    output_dir: Optional[Path] = None,
    classroom_table: Optional[Path] = None,
):
    base_dir = Path(
        base_dir
    )

    out_dir = (
        Path(output_dir)
        if output_dir is not None
        else base_dir / OUT_DIR.name
    )

    qc_dir = (
        out_dir
        / QC_DIR.name
    )

    out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    qc_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    if classroom_table is None:
        raise ValueError(
            "Run run_pipeline.py --stage preprocess to build the mapping from "
            "original inputs, or explicitly supply its generated --classroom-table. "
            "No previous Classroom_Data.csv is selected automatically."
        )
    classroom_path = Path(classroom_table)

    longitudinal_dir = (
        find_existing(
            base_dir,
            [
                Path(
                    "Longitudinal"
                ),
            ],
        )
    )

    wearable_root = (
        find_wearable_root(
            base_dir
        )
    )

    print(
        "=" * 84
    )

    print(
        "SIMPLIFIED FINAL DATA PIPELINE"
    )

    print(
        "=" * 84
    )

    # -------------------------------------------------------------------------
    # 1. Classes and attendance.
    # -------------------------------------------------------------------------

    print(
        "\n[1] Classroom mapping"
    )

    classes = (
        load_classroom_mapping(
            classroom_path
        )
    )

    attendance = (
        build_attendance_sessions(
            wearable_root,
            classes,
        )
    )

    print(
        f"    Class rows: "
        f"{len(classes)}"
    )

    print(
        f"    Attendance PIDs: "
        f"{attendance['Pid'].nunique()}"
    )

    print(
        f"    Attendance Pid x Class: "
        f"{len(attendance)}"
    )

    # -------------------------------------------------------------------------
    # 2. Environment QC.
    # -------------------------------------------------------------------------

    print(
        "\n[2] Environment QC"
    )

    env_cache = (
        EnvironmentCache(
            longitudinal_dir
        )
    )

    (
        env_qc,
        env_segments,
    ) = (
        audit_environment_classes(
            classes,
            env_cache,
        )
    )

    env_qc.to_csv(
        qc_dir
        / "class_environment_qc.csv",
        index=False,
    )

    valid_class_ids = set(
        env_qc.loc[
            env_qc[
                "status"
            ].eq(
                "PASS"
            ),
            "Class_id",
        ]
        .astype(str)
    )

    classes_valid = (
        classes[
            classes[
                "Class_id"
            ].isin(
                valid_class_ids
            )
        ]
        .copy()
    )

    class_env_summary = (
        build_class_environment_summary(
            classes_valid,
            env_segments,
        )
    )

    print(
        env_qc[
            "status"
        ]
        .value_counts(
            dropna=False
        )
        .to_string()
    )

    print(
        f"    Environment-valid classes: "
        f"{len(valid_class_ids)}"
    )

    # -------------------------------------------------------------------------
    # 3. Physiology.
    # -------------------------------------------------------------------------

    print(
        "\n[3] Physiology reconstruction"
    )

    (
        physiology,
        wearable_qc,
    ) = (
        build_physiology_1s(
            wearable_root,
            classes_valid,
            valid_class_ids,
        )
    )

    wearable_qc.to_csv(
        qc_dir
        / "wearable_qc.csv",
        index=False,
    )

    if physiology.empty:
        raise RuntimeError(
            "No physiology reconstructed."
        )

    print(
        f"    Physiology rows: "
        f"{len(physiology):,}"
    )

    print(
        f"    Physiology PIDs: "
        f"{physiology['Pid'].nunique()}"
    )

    print(
        f"    Physiology Pid x Class: "
        f"{physiology[['Pid','Class_id']].drop_duplicates().shape[0]}"
    )

    # -------------------------------------------------------------------------
    # 4. Merge class environment to physiology.
    # -------------------------------------------------------------------------

    print(
        "\n[4] Class-specific Env + Phys merge"
    )

    merged_1s = (
        merge_environment_to_physiology(
            physiology,
            env_segments,
        )
    )

    if merged_1s.empty:
        raise RuntimeError(
            "Env + Phys merge produced zero rows."
        )

    print(
        f"    Joint complete seconds: "
        f"{int(merged_1s['HasCoreEnvironmentPhysiology'].sum()):,}"
    )

    print(
        f"    Joint completeness: "
        f"{merged_1s['HasCoreEnvironmentPhysiology'].mean():.2%}"
    )

    # -------------------------------------------------------------------------
    # 5. Strict survey mapping.
    # -------------------------------------------------------------------------

    print(
        "\n[5] Strict survey -> session mapping"
    )

    (
        survey_raw,
        survey_source,
    ) = (
        load_survey_source(
            base_dir
        )
    )

    survey = (
        prepare_survey(
            survey_raw
        )
    )

    (
        survey_qc,
        strict_labels,
    ) = (
        map_surveys_strict(
            survey,
            attendance,
        )
    )

    survey_qc.to_csv(
        qc_dir
        / "survey_mapping_qc.csv",
        index=False,
    )

    print(
        f"    Survey source: "
        f"{survey_source}"
    )

    print(
        f"    Survey responses: "
        f"{len(survey)}"
    )

    print(
        survey_qc[
            "SurveyMapStatus"
        ]
        .value_counts(
            dropna=False
        )
        .to_string()
    )

    print(
        f"    Strict mapped Pid x Class labels: "
        f"{len(strict_labels)}"
    )

    # -------------------------------------------------------------------------
    # 6. ONE canonical session table.
    # -------------------------------------------------------------------------

    print(
        "\n[6] Building canonical session table"
    )

    session_master = (
        build_session_master(
            merged_1s,
            class_env_summary,
            strict_labels,
        )
    )

    envphys = (
        session_master[
            session_master[
                "EnvPhysReady"
            ]
        ]
        .copy()
    )

    behavior = (
        session_master[
            session_master[
                "StrictBehaviorReady"
            ]
        ]
        .copy()
    )

    temporal = (
        build_behavior_temporal_1s(
            merged_1s,
            session_master,
        )
    )

    # Save.
    session_master.to_csv(
        out_dir
        / "session_master.csv",
        index=False,
    )

    envphys.to_csv(
        out_dir
        / "envphys_session_analysis.csv",
        index=False,
    )

    behavior.to_csv(
        out_dir
        / "behavior_session_analysis.csv",
        index=False,
    )

    temporal.to_csv(
        out_dir
        / "behavior_temporal_1s.csv",
        index=False,
    )

    # -------------------------------------------------------------------------
    # 7. Final audit.
    # -------------------------------------------------------------------------

    behavior_sessions = set(
        zip(
            behavior[
                "Pid"
            ].astype(str),
            behavior[
                "Class_id"
            ].astype(str),
        )
    )

    temporal_sessions = set(
        zip(
            temporal[
                "Pid"
            ].astype(str),
            temporal[
                "Class_id"
            ].astype(str),
        )
    )

    same_behavior_cohort = (
        behavior_sessions
        == temporal_sessions
    )

    if not same_behavior_cohort:
        raise RuntimeError(
            "Behavior session table and temporal table "
            "do not contain exactly the same Pid x Class cohort."
        )

    summary = {
        "design":
            (
                "ONE canonical Pid x Class session table; "
                "temporal table is only an alternate representation "
                "of the same strict behavior sessions."
            ),

        "classroom_mapping_source":
            str(
                classroom_path
            ),

        "survey_source":
            survey_source,

        "n_attendance_pids":
            int(
                attendance[
                    "Pid"
                ].nunique()
            ),

        "n_attendance_pid_class":
            int(
                len(
                    attendance
                )
            ),

        "n_environment_valid_classes":
            int(
                len(
                    valid_class_ids
                )
            ),

        "n_physiology_pids":
            int(
                physiology[
                    "Pid"
                ].nunique()
            ),

        "n_physiology_pid_class":
            int(
                physiology[
                    [
                        "Pid",
                        "Class_id",
                    ]
                ]
                .drop_duplicates()
                .shape[0]
            ),

        "n_session_master_rows":
            int(
                len(
                    session_master
                )
            ),

        "n_envphys_ready_pids":
            int(
                envphys[
                    "Pid"
                ].nunique()
            ),

        "n_envphys_ready_sessions":
            int(
                len(
                    envphys
                )
            ),

        "n_strict_behavior_pids":
            int(
                behavior[
                    "Pid"
                ].nunique()
            ),

        "n_strict_behavior_sessions":
            int(
                len(
                    behavior
                )
            ),

        "n_behavior_temporal_rows":
            int(
                len(
                    temporal
                )
            ),

        "behavior_session_and_temporal_cohort_identical":
            bool(
                same_behavior_cohort
            ),

        "minimum_complete_seconds_per_session":
            int(
                MIN_COMPLETE_SECONDS_PER_SESSION
            ),

        "core_logic": {
            "environment":
                (
                    "Class_id -> Matched_CSV; class-level QC; "
                    "no cross-class filling."
                ),

            "physiology":
                (
                    "EDA/HR/TEMP reconstructed inside class; "
                    "1-s aggregation; no interpolation."
                ),

            "behavior":
                (
                    "One strict survey label per Pid x Class; "
                    "most recently completed class <=90 min."
                ),

            "mixedlm_cohort":
                "EnvPhysReady sessions",

            "sem_cohort":
                "StrictBehaviorReady sessions",

            "tabular_prediction_cohort":
                "StrictBehaviorReady sessions",

            "temporal_prediction_cohort":
                (
                    "Exactly the same StrictBehaviorReady sessions; "
                    "different temporal representation only."
                ),
        },
    }

    with open(
        out_dir
        / "processing_summary.json",
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            summary,
            f,
            indent=2,
            ensure_ascii=False,
            default=str,
        )

    print(
        "\n" + "=" * 84
    )

    print(
        "FINAL SIMPLE TABLES"
    )

    print(
        "=" * 84
    )

    print(
        f"Session master: "
        f"{len(session_master)} sessions"
    )

    print(
        f"Env-Phys analysis: "
        f"{envphys['Pid'].nunique()} PIDs | "
        f"{len(envphys)} sessions"
    )

    print(
        f"Strict behavior analysis: "
        f"{behavior['Pid'].nunique()} PIDs | "
        f"{len(behavior)} sessions"
    )

    print(
        f"Temporal representation: "
        f"{len(temporal):,} 1-s rows | "
        f"{len(temporal_sessions)} sessions"
    )

    print(
        "Session and temporal tables "
        "share identical behavior cohort:",
        same_behavior_cohort,
    )

    print(
        "\nSaved to:",
        out_dir,
    )

    print(
        "\nMain files:"
        "\n  session_master.csv"
        "\n  envphys_session_analysis.csv"
        "\n  behavior_session_analysis.csv"
        "\n  behavior_temporal_1s.csv"
        "\n  processing_summary.json"
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dir", type=Path, default=BASE_DIR)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--classroom-table", type=Path, default=None)
    args = parser.parse_args()
    main(base_dir=args.base_dir, output_dir=args.output_dir, classroom_table=args.classroom_table)
