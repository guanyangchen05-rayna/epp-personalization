"""Create visibly labeled synthetic v5-shaped tables for installation checks only."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd


def make(folder):
    folder=Path(folder)
    if folder.exists() and any(folder.iterdir()):raise ValueError('Use an empty demo directory')
    folder.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(99);sessions=[];seconds=[]
    for k,(pid,rep) in enumerate([(1,0),(1,1),(2,0),(2,1),(3,0),(3,1),(4,0),(5,0)]):
        start=pd.Timestamp('2020-01-01 09:00')+pd.Timedelta(days=k%4)
        key=f'C{k}';n=12*40
        sessions.append(dict(Pid=str(pid),Class_id=key,ClassStart=str(start),
                ClassEnd=str(start+pd.Timedelta(minutes=12)),Room='R1',
                EnvironmentScope='school_indoor_context',EnvironmentDateKey=start.strftime('DATE__%Y-%m-%d'),
                EDA_QC_pass=True,n_complete_env_phys_seconds=n,
                EngageScore=float(rng.uniform(2,4)),Arousal=float(rng.uniform(1,4)),Valence=float(rng.uniform(1,4))))
        for t in range(n):
            minute,sec=divmod(t,40);clock=start+pd.Timedelta(minutes=minute,seconds=sec)
            seconds.append(dict(Pid=str(pid),Class_id=key,DateTime=str(clock),
                IndoorTemperature=20+k%4+np.sin(minute/4),IndoorCO2=700+20*(k%4)+minute*3,
                EDA=1+pid*.1+.03*np.sin(minute),HR=65+pid+np.cos(minute),TEMP=31+pid*.1+minute*.02))
    meta=pd.DataFrame(sessions);temp=pd.DataFrame(seconds)
    chosen=['C0','C1','C2','C6','C7'];beh=meta[meta.Class_id.isin(chosen)]
    meta.to_csv(folder/'envphys_session_analysis.csv',index=False)
    beh.to_csv(folder/'behavior_session_analysis.csv',index=False)
    temp.to_csv(folder/'envphys_temporal_1s.csv',index=False)
    temp[temp.Class_id.isin(chosen)].to_csv(folder/'behavior_temporal_1s.csv',index=False)
    (folder/'SYNTHETIC_NOT_STUDY_DATA.txt').write_text('Installation/smoke demonstration only.\n')
    return folder


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path,required=True)
    make(p.parse_args().output_dir)
