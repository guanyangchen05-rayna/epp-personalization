"""Separate participant baseline heterogeneity from temperature-slope variation."""
from __future__ import annotations
import argparse, importlib.metadata, json, platform, sys
from pathlib import Path
import numpy as np
import pandas as pd
from revision_models import read_sessions, prepare, OUTCOMES, boolean
from revision_audit import digest, save_json
from heterogeneity_models import (fit, fixed_rows, variance_rows, participant_rows,
                                 compare, NUISANCE_COMPONENTS, BOUNDARY_RATIO, adjust_environment_families)

MODELS=['reference_date','context_window','context_window_time',
        'date_fixed_window_time','within_between_window_time']

def checkpoint(out, name, rows):
    pd.DataFrame(rows).to_csv(out/name,index=False)

def core(raw,out):
    d=prepare(raw); fixed=[]; variances=[]; participants=[]; comparisons=[]; diagnostics=[]; stability=[]
    for model in MODELS:
        for outcome in OUTCOMES:
            print(f'[heterogeneity] {model} / {outcome}',flush=True)
            cache={}
            for slope in [False,True]:
                for reml in [False,True]:
                    r,meta=fit(d,outcome,model,slope=slope,reml=reml)
                    meta['variant']='original';diagnostics.append(meta);cache[slope,reml]=(r,meta)
                    if not reml: continue
                    fixed.extend(fixed_rows(r,meta,'original'));variances.extend(variance_rows(meta,'original'))
                    participants.extend(participant_rows(r,d,meta,'original', 'PidTempSlope' if slope else 'PidIntercept'))
                    # Only near-zero DATE/WINDOW nuisance components can be removed.
                    # The participant component under study is always retained.
                    drop=sorted(set(meta['near_zero_components']) & NUISANCE_COMPONENTS)
                    if drop:
                        rr,mm=fit(d,outcome,model,slope=slope,reml=True,drop=drop)
                        mm['variant']='boundary_companion';diagnostics.append(mm)
                        fixed.extend(fixed_rows(rr,mm,'boundary_companion'));variances.extend(variance_rows(mm,'boundary_companion'))
                        participants.extend(participant_rows(rr,d,mm,'boundary_companion', 'PidTempSlope' if slope else 'PidIntercept'))
                        aa=pd.DataFrame(fixed_rows(r,meta,'original')).set_index('predictor')
                        bb=pd.DataFrame(fixed_rows(rr,mm,'boundary_companion')).set_index('predictor')
                        for term in aa.index:
                            before=aa.loc[term];after=bb.loc[term]
                            stability.append(dict(model=model,outcome=outcome,slope=slope,predictor=term,
                                dropped_components=','.join(drop),original_beta=before.beta,companion_beta=after.beta,
                                original_SE=before.SE,companion_SE=after.SE,
                                original_p=before.p,companion_p=after.p,
                                companion_minus_original_llf=mm['llf']-meta['llf'],
                                companion_wald_status=after.wald_status))
            for contrast in ['participant_intercept','temperature_slope']:
                slope=contrast=='temperature_slope'
                row,metas=compare(d,outcome,model,contrast,full=cache[slope,False])
                row['status']='passed';comparisons.append(row)
                diagnostics.extend(m | {'variant':'ML_component_comparison'} for m in metas)
            # Save after every outcome so an interrupted run is reviewable.
            checkpoint(out,'heterogeneity_component_comparison.csv',comparisons)
            # Separate planned variant families; no adjustment for searching
            # across variants. Flagged p-values remain labelled.
            checkpoint(out,'heterogeneity_fixed_effects.csv',adjust_environment_families(pd.DataFrame(fixed)).to_dict('records'))
            checkpoint(out,'heterogeneity_variance_components.csv',variances)
            checkpoint(out,'heterogeneity_participant_effects.csv',participants)
            checkpoint(out,'heterogeneity_boundary_checks.csv',stability)
            save_json(out/'heterogeneity_fit_diagnostics.json',diagnostics)
    support=[]
    for outcome in OUTCOMES:
        q=d.groupby('Pid').agg(n_sessions=('Class_id','size'),n_dates=('EnvironmentDateKey','nunique'),
                               n_distinct_temperature=('Temperature_mean','nunique'))
        for pid,row in q.iterrows(): support.append(dict(outcome=outcome,Pid=pid,**row.to_dict()))
    checkpoint(out,'heterogeneity_participant_coverage.csv',support)

def sensitivity(raw,tables,out):
    comparisons=[];variances=[];diagnostics=[]
    scenarios=[('main',raw),('coverage_ge_50pct',raw.loc[raw.complete_env_phys_fraction_of_class.ge(.5)])]
    scenarios += [('without_'+str(date),raw.loc[raw.EnvironmentDateKey.ne(date)]) for date in sorted(raw.EnvironmentDateKey.unique())]
    master=tables/'session_master.csv'
    if master.exists():
        m=pd.read_csv(master,dtype={'Pid':str,'Class_id':str})
        if {'EnvPhysReady_before_EDA_QC','EDA_zero_fraction'}.issubset(m):
            before=m.loc[boolean(m.EnvPhysReady_before_EDA_QC)].copy()
            # Master tables can lack ContextWindowKey; construct/validate it
            # through the same main-input reader without altering the source.
            before_path=out/'sensitivity_pre_eda_input.csv'
            # Before-QC eligibility differs deliberately; retain all prior
            # eligible sessions instead of testing the post-QC EnvPhysReady.
            before=before.drop(columns=['EnvPhysReady'],errors='ignore')
            before.to_csv(before_path,index=False);before=read_sessions(before_path)
            scenarios += [('before_eda_screen',before),
                          ('eda_zero_threshold_0.90',before.loc[before.EDA_zero_fraction.lt(.90)]),
                          ('eda_zero_threshold_0.99',before.loc[before.EDA_zero_fraction.lt(.99)])]
    for name,sub in scenarios:
        for outcome in OUTCOMES:
            print(f'[heterogeneity sensitivity] {name} / {outcome}',flush=True)
            try:
                d=prepare(sub)
                row,metas=compare(d,outcome,'context_window','participant_intercept')
                item=dict(scenario=name,status='passed',variance_status='pending',**row)
                comparisons.append(item);diagnostics.extend(m|{'scenario':name} for m in metas)
            except Exception as exc:
                comparisons.append(dict(scenario=name,model='context_window',outcome=outcome,status='failed',variance_status='not_attempted',error=str(exc)))
                checkpoint(out,'heterogeneity_baseline_sensitivity.csv',comparisons)
                continue
            try:
                r,meta=fit(d,outcome,'context_window',reml=True)
                diagnostics.append(meta|{'scenario':name,'variant':'original'})
                for v in variance_rows(meta,'original'):variances.append(dict(scenario=name,**v))
                drop=sorted(set(meta['near_zero_components']) & NUISANCE_COMPONENTS)
                if drop:
                    rr,mm=fit(d,outcome,'context_window',reml=True,drop=drop)
                    diagnostics.append(mm|{'scenario':name,'variant':'boundary_companion'})
                    for v in variance_rows(mm,'boundary_companion'):variances.append(dict(scenario=name,**v))
                item['variance_status']='passed'
            except Exception as exc:
                item.update(variance_status='failed',variance_error=str(exc))
                diagnostics.append(dict(scenario=name,outcome=outcome,reml=True,status='failed',error=str(exc)))
            checkpoint(out,'heterogeneity_baseline_sensitivity.csv',comparisons)
            checkpoint(out,'heterogeneity_sensitivity_variances.csv',variances)
            save_json(out/'heterogeneity_sensitivity_diagnostics.json',diagnostics)

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--stage',choices=['core','sensitivity','all'],default='core');a=p.parse_args(argv)
    cfg=json.loads(a.config.read_text(encoding='utf-8'))
    if cfg.get('environment_mode')!='school_indoor_context':raise ValueError('Expected completed indoor-context configuration.')
    tables=Path(cfg['table_dir']).resolve();out=a.output_dir.resolve()
    protected=[tables,Path(cfg['output_dir']).resolve(),Path(cfg['raw_dir']).resolve()]
    if any(out==x or x in out.parents for x in protected):raise ValueError('Use a new output directory outside the source run.')
    out.mkdir(parents=True,exist_ok=True);source=tables/'envphys_session_analysis.csv';raw=read_sessions(source)
    summary=json.loads((tables/'processing_summary.json').read_text(encoding='utf-8'))
    if summary.get('eda_qc',{}).get('max_zero_fraction')!=cfg.get('eda_qc_max_zero_fraction',.95):
        raise ValueError('QC metadata and source configuration differ.')
    record=dict(stage=a.stage,status='running',config=cfg,input_sha256=digest(source),
                N_sessions=len(raw),N_participants=raw.Pid.nunique(),boundary_ratio=BOUNDARY_RATIO,
                python=sys.version,platform=platform.platform(),
                packages={n:importlib.metadata.version(n) for n in ['numpy','pandas','scipy','statsmodels','patsy']},
                source_hashes={n.name:digest(n) for n in Path(__file__).parent.glob('heterogeneity_*.py')},
                original_tables_unchanged=True,pvrnn_training_performed=False)
    path=out/('heterogeneity_'+a.stage+'_manifest.json');save_json(path,record)
    try:
        if a.stage in ['core','all']:core(raw,out)
        if a.stage in ['sensitivity','all']:sensitivity(raw,tables,out)
        record['status']='completed'
    except BaseException as exc:
        record.update(status='interrupted' if isinstance(exc,KeyboardInterrupt) else 'failed',error=str(exc));raise
    finally:save_json(path,record)
    print('Heterogeneity audit complete:',out,flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
