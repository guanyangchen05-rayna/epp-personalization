"""Describe historical assignments; this does not establish correct room identity."""
import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path

def audit(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    required = {'Class_id', 'Room', 'Matched_CSV', 'start_dt', 'end_dt'}
    if not rows or not required.issubset(rows[0]):
        raise ValueError('Need Class_id, Room, Matched_CSV, start_dt and end_dt')
    groups, room_files, files = defaultdict(list), defaultdict(set), Counter()
    mapped = 0
    for row in rows:
        sensor = row['Matched_CSV'].strip()
        if not sensor or sensor.lower() in {'nan', 'none'}:
            continue
        mapped += 1
        files[sensor] += 1
        room_files[row['Room']].add(sensor)
        groups[(sensor, row['start_dt'], row['end_dt'])].append(row)
    collisions = []
    for (sensor, start, end), group in groups.items():
        rooms = sorted({r['Room'] for r in group})
        if len(rooms) > 1:
            collisions.append({'file': sensor, 'start': start, 'end': end, 'rooms': rooms,
                               'class_ids': [r['Class_id'] for r in group]})
    return {'status': 'historical_assignment_not_validated', 'n_classes': len(rows),
            'n_mapped': mapped, 'n_unmapped': len(rows) - mapped,
            'file_counts': dict(files), 'files_by_room': {k: sorted(v) for k, v in room_files.items()},
            'same_interval_multiple_room_assignments': collisions,
            'note': 'Exact-interval diagnostic only; partial overlaps are not tested. Confidence is an occupancy score in the historical matching code, not a probability of correct identity.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mapping', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = audit(args.mapping)
    text = json.dumps(result, indent=2, ensure_ascii=False) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
    else:
        print(text)

if __name__ == '__main__':
    main()
