"""
PV-RNN LABEL-FREE TEST-TIME ADAPTATION EXPERIMENT V3
====================================================

Scientific question
-------------------
Can prediction-error-based test-time adaptation improve session-level
behavior/affect estimation for an unseen participant or unseen classroom
date using only the CURRENT unlabeled Environment + Physiology sequence?

This V3 deliberately REMOVES the earlier "past physiological profile" idea.
There is no personal history requirement and no GLOBAL/PERSONAL profile branch.

Core comparison
---------------
The SAME trained PV-RNN is evaluated twice on every held-out session:

  1) NO_ER
     Fresh test adaptive variables A_t are initialized to zero and are NOT
     optimized. The model therefore uses its learned population dynamics/prior
     without adapting to the held-out sensory sequence.

  2) ERROR_REGRESSION
     Network weights are frozen. Fresh test adaptive variables A_t are optimized
     only from reconstruction error + KL on the held-out CURRENT
     Environment + Physiology sequence. No held-out behavior labels are used.

Because both conditions use the same trained network weights, same fold, same
seed, same inputs, and same behavior head, ERROR_REGRESSION vs NO_ER isolates
the value of label-free latent-state adaptation.

PV-RNN mechanisms retained
--------------------------
- hierarchical deterministic recurrent states with multiple time constants;
- stochastic latent states;
- learned priors;
- approximate posteriors parameterized by adaptive variables A_t;
- joint training of shared network weights and training-sequence A_t;
- free-energy objective = reconstruction error + meta-prior-weighted KL;
- test-time error regression with frozen network weights;
- observations affect latent inference through prediction error rather than
  direct recurrent input.

Behavioral unit
---------------
One Pid x Class session = one Engagement/Arousal/Valence target/loss.
60-s windows are sequence elements only, not independent labels.

Primary protocol
----------------
PARTICIPANT_LOO:
All behavior labels of one participant are held out. Unlike V2, ALL behavior
participants are eligible because no historical physiology is required.

Secondary protocol
------------------
DATE_LOO:
A complete classroom/environment date is held out. ALL behavior dates
are eligible.

Claim boundary
--------------
This is offline full-session inference: the complete current session is used
to infer A_t before producing the session-level outcome estimate. It should not
be described as real-time future prediction.

Quick:
    %run pv_rnn_label_free_adaptation_v3.py --quick \
        --table-dir "D:/researchgrass/ingauge_and_engage_dataset/final_simple_tables"

Full:
    %run pv_rnn_label_free_adaptation_v3.py \
        --table-dir "D:/researchgrass/ingauge_and_engage_dataset/final_simple_tables"
"""

from __future__ import annotations
from indoor_context_checks import validate_context_table, validate_fold_coverage

import argparse
import json
import math
import os
import random
import time
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

import torch
import torch.nn as nn

try:
    import statsmodels.formula.api as smf
except Exception:
    smf = None

warnings.filterwarnings("ignore", category=FutureWarning)


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

SEQ_COLS = ["IndoorTemperature", "IndoorCO2", "EDA", "HR", "TEMP"]
TARGETS = ["EngageScore", "Arousal", "Valence"]

MODEL_MODES = ("NO_ER", "ERROR_REGRESSION")

# Historical profile = stable/slowly varying physiology only.
# Environment is deliberately not part of the participant profile.
PROFILE_COLS = [
    "EDA_mean",
    "EDA_std",
    "HR_mean",
    "HR_std",
    "SkinTEMP_mean",
    "SkinTEMP_std",
]

MIXED_OUTCOMES = {
    "EDA": "EDA_model_z",
    "HR": "HR_mean_z",
    "SkinTEMP": "SkinTEMP_mean_z",
}


@dataclass
class Config:
    table_dir: Path
    output_dir: Path
    window_seconds: int = 60
    min_seconds_per_window: int = 30

    # Small hierarchical PV-RNN. Deliberately restrained because the primary
    # calibration cohort contains only 12 behavior sessions / 8 participants.
    hidden_size: int = 8          # fast deterministic layer d^1
    slow_hidden_size: int = 4     # slow deterministic layer d^2
    latent_dim: int = 3           # fast stochastic layer z^1
    slow_latent_dim: int = 2      # slow stochastic layer z^2
    tau_fast: float = 2.0
    tau_slow: float = 5.0

    profile_hidden: int = 4
    dropout: float = 0.25

    # Network/adaptive-variable learning.
    lr: float = 1e-3
    adaptive_lr: float = 5e-3
    weight_decay: float = 1e-2
    epochs: int = 150
    seeds: Tuple[int, ...] = (11, 23, 37, 51, 71)

    # Variational free-energy objective.
    reconstruction_weight: float = 1.0
    meta_prior_fast: float = 1e-3
    meta_prior_slow: float = 1e-3
    behavior_weight: float = 1.0

    # Test-time error regression. For session-level prediction, the complete
    # observed session is used as the inference window.
    error_regression_steps: int = 150
    error_regression_lr: float = 5e-2

    min_complete_seconds: int = 300
    bootstrap_reps: int = 2000
    run_mixedlm: bool = False
    device: str = "cpu"


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--table-dir", type=str, default=None)
    p.add_argument("--output-dir", type=str, default=None)
    p.add_argument("--quick", action="store_true")
    p.add_argument("--resume", action="store_true",
                   help="Reuse already completed protocol CSVs when they match the current seed set.")
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--seeds", type=str, default=None,
                   help="Comma-separated integer seeds, e.g. 11,23,37")
    p.add_argument("--skip-mixedlm", action="store_true")
    p.add_argument("--latent-dim", type=int, default=None)
    p.add_argument("--slow-latent-dim", type=int, default=None)
    p.add_argument("--meta-prior-fast", type=float, default=None)
    p.add_argument("--meta-prior-slow", type=float, default=None)
    p.add_argument("--er-steps", type=int, default=None,
                   help="Test-time error-regression optimization steps.")
    p.add_argument("--er-lr", type=float, default=None,
                   help="Test-time adaptive-variable learning rate.")
    p.add_argument("--bootstrap-reps", type=int, default=None)

    # Jupyter injects -f <kernel.json>; ignore unrelated arguments.
    args, _unknown = p.parse_known_args()
    return args


def resolve_table_dir(requested: Optional[str]) -> Path:
    """Resolve the folder containing the three canonical final tables.

    This makes the script safe in three common situations:
      1) `%run script.py --table-dir ".../final_simple_tables"`
      2) running the script from the project root
      3) pasting the whole script into Jupyter, where CLI args are unavailable
    """
    required = (
        "envphys_session_analysis",
        "behavior_session_analysis",
        "behavior_temporal_1s",
    )

    def has_required_files(folder: Path) -> bool:
        if not folder.exists() or not folder.is_dir():
            return False
        for stem in required:
            exact = folder / f"{stem}.csv"
            copied = list(folder.glob(f"{stem}*.csv"))
            if not exact.exists() and not copied:
                return False
        return True

    candidates = []

    if requested:
        candidates.append(Path(requested).expanduser())

    cwd = Path.cwd()
    candidates.extend([
        cwd / "final_simple_tables",
        cwd,
        cwd.parent / "final_simple_tables",
        Path(r"D:/researchgrass/ingauge_and_engage_dataset/final_simple_tables"),
    ])

    # Also try a folder adjacent to the script when __file__ is available.
    try:
        script_dir = Path(__file__).resolve().parent
        candidates.extend([
            script_dir / "final_simple_tables",
            script_dir,
        ])
    except Exception:
        pass

    # Deduplicate while preserving order.
    seen = set()
    unique_candidates = []
    for c in candidates:
        try:
            key = str(c.resolve())
        except Exception:
            key = str(c)
        if key not in seen:
            seen.add(key)
            unique_candidates.append(c)

    for candidate in unique_candidates:
        if has_required_files(candidate):
            return candidate.resolve()

    attempted = "\n".join(f"  - {c}" for c in unique_candidates)
    raise FileNotFoundError(
        "Could not locate the final analysis tables.\n"
        "Expected these files in one folder:\n"
        "  envphys_session_analysis.csv\n"
        "  behavior_session_analysis.csv\n"
        "  behavior_temporal_1s.csv\n\n"
        f"Current working directory: {Path.cwd()}\n"
        f"Attempted folders:\n{attempted}\n\n"
        "Fix: either put the script in the project root / final_simple_tables, "
        "or run with an explicit --table-dir path."
    )


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        torch.use_deterministic_algorithms(True, warn_only=True)
    except Exception:
        pass


def resolve_file(table_dir: Path, stem: str) -> Path:
    """Prefer exact filename; accept copied variants such as '(1)' for audits."""
    exact = table_dir / f"{stem}.csv"
    if exact.exists():
        return exact
    candidates = sorted(table_dir.glob(f"{stem}*.csv"))
    if not candidates:
        raise FileNotFoundError(f"Could not find {stem}.csv under {table_dir}")
    return candidates[0]


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_r2(y: np.ndarray, pred: np.ndarray) -> float:
    if len(y) < 2 or np.nanstd(y) < 1e-12:
        return np.nan
    return float(r2_score(y, pred))


def metric_rows(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    baseline_pred: np.ndarray,
    protocol: str,
    model_name: str,
    seed: int,
    n_sessions: int,
) -> List[dict]:
    rows = []
    for j, target in enumerate(TARGETS):
        rmse = math.sqrt(mean_squared_error(y_true[:, j], y_pred[:, j]))
        mae = mean_absolute_error(y_true[:, j], y_pred[:, j])
        base_rmse = math.sqrt(mean_squared_error(y_true[:, j], baseline_pred[:, j]))
        rel = rmse / base_rmse if base_rmse > 1e-12 else np.nan
        rows.append({
            "protocol": protocol,
            "model": model_name,
            "seed": seed,
            "target": target,
            "N_sessions": n_sessions,
            "RMSE": float(rmse),
            "MAE": float(mae),
            "R2": safe_r2(y_true[:, j], y_pred[:, j]),
            "BaselineRMSE": float(base_rmse),
            "RelativeRMSE": float(rel),
            "RMSE_improvement_pct_vs_mean": float((1.0 - rel) * 100.0),
        })
    return rows


# -----------------------------------------------------------------------------
# Load / QC
# -----------------------------------------------------------------------------

def load_tables(cfg: Config):
    env_path = resolve_file(cfg.table_dir, "envphys_session_analysis")
    beh_sess_path = resolve_file(cfg.table_dir, "behavior_session_analysis")
    beh_temp_path = resolve_file(cfg.table_dir, "behavior_temporal_1s")

    env = pd.read_csv(env_path)
    beh = pd.read_csv(beh_sess_path)
    temp = pd.read_csv(beh_temp_path)

    for df in (env, beh):
        validate_context_table(df)
        df["Pid"] = df["Pid"].astype(str)
        df["Class_id"] = df["Class_id"].astype(str)
        df["ClassStart_dt"] = pd.to_datetime(df["ClassStart"])
        df["ClassEnd_dt"] = pd.to_datetime(df["ClassEnd"])

    temp["Pid"] = temp["Pid"].astype(str)
    temp["Class_id"] = temp["Class_id"].astype(str)
    temp["DateTime"] = pd.to_datetime(temp["DateTime"])
    temp["ClassStart_dt"] = pd.to_datetime(temp["ClassStart"])

    if "n_complete_env_phys_seconds" in env.columns:
        env = env.loc[env["n_complete_env_phys_seconds"] >= cfg.min_complete_seconds].copy()
    if "StrictBehaviorReady" in beh.columns:
        beh = beh.loc[beh["StrictBehaviorReady"].astype(bool)].copy()

    needed_temp = set(SEQ_COLS + TARGETS + ["Pid", "Class_id", "DateTime", "ClassStart_dt"])
    missing = needed_temp.difference(temp.columns)
    if missing:
        raise ValueError(f"behavior_temporal_1s missing columns: {sorted(missing)}")

    for c in TARGETS:
        if c not in beh.columns:
            raise ValueError(f"behavior_session_analysis missing target {c}")

    # Session sets must match between behavior session and temporal table.
    beh_keys = set(zip(beh["Pid"], beh["Class_id"]))
    temp_keys = set(zip(temp["Pid"], temp["Class_id"]))
    if beh_keys != temp_keys:
        raise ValueError(
            f"Behavior session/temporal cohort mismatch: "
            f"session_only={len(beh_keys-temp_keys)}, temporal_only={len(temp_keys-beh_keys)}"
        )

    return env, beh, temp


# -----------------------------------------------------------------------------
# Optional statistical bridge: MixedLM used as heterogeneity/background evidence
# -----------------------------------------------------------------------------

def zscore_series(s: pd.Series) -> pd.Series:
    x = pd.to_numeric(s, errors="coerce").astype(float)
    sd = x.std(ddof=0)
    if not np.isfinite(sd) or sd < 1e-12:
        return pd.Series(np.zeros(len(x)), index=s.index)
    return (x - x.mean()) / sd


def bh_fdr(pvals: Sequence[float]) -> np.ndarray:
    p = np.asarray(pvals, dtype=float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * n / np.arange(1, n + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.clip(q, 0, 1)
    out = np.empty(n, dtype=float)
    out[order] = q
    return out


def run_mixedlm_bridge(env: pd.DataFrame, outdir: Path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    This is deliberately a *bridge*, not the paper's main personalization test.
    It shows how much physiology varies by participant and shared date while
    controlling for Temperature and CO2 at the session level.
    """
    if smf is None:
        print("[MixedLM] statsmodels unavailable; skipping.")
        return pd.DataFrame(), pd.DataFrame()

    d = env.copy()
    d["Temperature_mean_z"] = zscore_series(d["Temperature_mean"])
    d["CO2_mean_z"] = zscore_series(d["CO2_mean"])
    d["EDA_model_z"] = zscore_series(np.log1p(np.clip(d["EDA_mean"].astype(float), a_min=0, a_max=None)))
    d["HR_mean_z"] = zscore_series(d["HR_mean"])
    d["SkinTEMP_mean_z"] = zscore_series(d["SkinTEMP_mean"])

    fixed_rows, var_rows = [], []
    for outcome, ycol in MIXED_OUTCOMES.items():
        f = f"{ycol} ~ Temperature_mean_z + CO2_mean_z"
        try:
            model = smf.mixedlm(
                f,
                d,
                groups=np.ones(len(d)),
                re_formula="0",
                vc_formula={
                    "Date": "0 + C(EnvironmentDateKey)",
                    "Pid": "0 + C(Pid)",
                },
            )
            res = model.fit(reml=True, method="powell", maxiter=3000, disp=False)

            ci = res.conf_int()
            for pred, label in [("Temperature_mean_z", "Temperature"), ("CO2_mean_z", "CO2")]:
                fixed_rows.append({
                    "outcome": outcome,
                    "predictor": label,
                    "beta_standardized": float(res.params[pred]),
                    "SE": float(res.bse[pred]),
                    "p": float(res.pvalues[pred]),
                    "ci95_low": float(ci.loc[pred, 0]),
                    "ci95_high": float(ci.loc[pred, 1]),
                    "N_sessions": int(len(d)),
                    "N_PIDs": int(d["Pid"].nunique()),
                    "N_dates": int(d["EnvironmentDateKey"].nunique()),
                    "converged": bool(res.converged),
                })

            # statsmodels returns variance components in alphabetical vc_formula order.
            # Recover names defensively from model exog_vc.names when available.
            vc_names = list(getattr(res.model.exog_vc, "names", []))
            vc_vals = list(np.asarray(res.vcomp, dtype=float))
            comp = dict(zip(vc_names, vc_vals))
            residual = float(res.scale)
            total = residual + sum(vc_vals)
            for name, val in comp.items():
                var_rows.append({
                    "outcome": outcome,
                    "component": name,
                    "variance": float(val),
                    "variance_proportion": float(val / total) if total > 0 else np.nan,
                })
            var_rows.append({
                "outcome": outcome,
                "component": "Residual",
                "variance": residual,
                "variance_proportion": float(residual / total) if total > 0 else np.nan,
            })
        except Exception as e:
            fixed_rows.append({"outcome": outcome, "error": repr(e)})

    fixed = pd.DataFrame(fixed_rows)
    var = pd.DataFrame(var_rows)
    if len(fixed) and "p" in fixed.columns and fixed["p"].notna().sum() == 6:
        mask = fixed["p"].notna()
        fixed.loc[mask, "q_BH_FDR"] = bh_fdr(fixed.loc[mask, "p"].to_numpy())
    fixed.to_csv(outdir / "mixedlm_bridge_fixed_effects.csv", index=False)
    var.to_csv(outdir / "mixedlm_bridge_variance_components.csv", index=False)
    return fixed, var


# -----------------------------------------------------------------------------
# Build one temporal sequence per behavior session
# -----------------------------------------------------------------------------

def build_session_sequences(
    temp: pd.DataFrame,
    cfg: Config,
) -> Tuple[Dict[Tuple[str, str], np.ndarray], pd.DataFrame]:
    sequences: Dict[Tuple[str, str], np.ndarray] = {}
    qc_rows = []

    for (pid, class_id), g in temp.groupby(["Pid", "Class_id"], sort=False):
        g = g.sort_values("DateTime").copy()
        start = pd.to_datetime(g["ClassStart_dt"].iloc[0])
        elapsed = (g["DateTime"] - start).dt.total_seconds()
        g["window_id"] = np.floor(elapsed / cfg.window_seconds).astype(int)

        win_rows = []
        for wid, w in g.groupby("window_id"):
            complete = w[SEQ_COLS].dropna()
            if len(complete) < cfg.min_seconds_per_window:
                continue
            vals = complete[SEQ_COLS].mean(axis=0).to_numpy(dtype=np.float32)
            if np.isfinite(vals).all():
                win_rows.append(vals)

        if not win_rows:
            raise ValueError(f"No valid windows for Pid={pid}, Class={class_id}")
        arr = np.stack(win_rows).astype(np.float32)
        sequences[(str(pid), str(class_id))] = arr
        qc_rows.append({
            "Pid": str(pid),
            "Class_id": str(class_id),
            "n_raw_seconds": int(len(g)),
            "n_valid_windows": int(len(arr)),
            "window_seconds": cfg.window_seconds,
            "min_seconds_per_window": cfg.min_seconds_per_window,
        })

    return sequences, pd.DataFrame(qc_rows)


# -----------------------------------------------------------------------------
# Strict historical participant profile
# -----------------------------------------------------------------------------

def _history_rows_for_target(
    env: pd.DataFrame,
    pid: str,
    target_start: pd.Timestamp,
    excluded_date: Optional[str] = None,
) -> pd.DataFrame:
    """
    Return ONLY physiological sessions that ended before the target session.

    For HISTORY_DATE_LOO we additionally remove the held-out date from
    every history calculation, including training-session profiles. This keeps
    the context-held-out protocol clean even when a later training target would
    otherwise have the held-out date in its past.
    """
    hist = env.loc[
        (env["Pid"].astype(str) == str(pid)) &
        (env["ClassEnd_dt"] < pd.Timestamp(target_start))
    ].copy()

    if excluded_date is not None:
        hist = hist.loc[
            hist["EnvironmentDateKey"].astype(str) != str(excluded_date)
        ].copy()

    return hist


def _summarize_history(hist: pd.DataFrame) -> Optional[np.ndarray]:
    if len(hist) == 0:
        return None
    vals = []
    for c in PROFILE_COLS:
        x = pd.to_numeric(hist[c], errors="coerce").to_numpy(dtype=float)
        x = x[np.isfinite(x)]
        vals.append(float(np.median(x)) if len(x) else np.nan)
    arr = np.asarray(vals, dtype=float)
    if not np.isfinite(arr).all():
        return None
    return arr


def personal_profile_for_indices(
    env: pd.DataFrame,
    beh: pd.DataFrame,
    indices: Sequence[int],
    excluded_date: Optional[str] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Build fold-specific personal profiles from strictly earlier physiology.

    Returns
    -------
    profiles : (N, len(PROFILE_COLS)) array; missing histories are NaN rows.
    available : (N,) bool array
    n_history_sessions : (N,) integer array
    """
    profiles = []
    available = []
    n_hist = []

    for idx in indices:
        r = beh.loc[idx]
        hist = _history_rows_for_target(
            env=env,
            pid=str(r["Pid"]),
            target_start=pd.Timestamp(r["ClassStart_dt"]),
            excluded_date=excluded_date,
        )
        p = _summarize_history(hist)
        profiles.append(
            p if p is not None else np.full(len(PROFILE_COLS), np.nan, dtype=float)
        )
        available.append(p is not None)
        n_hist.append(int(len(hist)))

    return (
        np.vstack(profiles),
        np.asarray(available, dtype=bool),
        np.asarray(n_hist, dtype=int),
    )


def build_history_profiles(env: pd.DataFrame, beh: pd.DataFrame) -> pd.DataFrame:
    """
    General audit of genuine prior physiology before each behavior session.

    This audit is NOT used directly as the fold-specific model input because the
    date-held-out protocol may need to exclude the held-out context from
    training histories. Fold-specific profiles are rebuilt inside prepare_fold.
    """
    rows = []
    for idx, r in beh.iterrows():
        hist = _history_rows_for_target(
            env=env,
            pid=str(r["Pid"]),
            target_start=pd.Timestamp(r["ClassStart_dt"]),
            excluded_date=None,
        )
        p = _summarize_history(hist)

        out = {
            "session_index": int(idx),
            "Pid": str(r["Pid"]),
            "Class_id": str(r["Class_id"]),
            "ClassStart": r["ClassStart"],
            "EnvironmentDateKey": r["EnvironmentDateKey"],
            "history_n_sessions": int(len(hist)),
            "history_available": bool(p is not None),
        }
        for j, c in enumerate(PROFILE_COLS):
            out[c] = float(p[j]) if p is not None else np.nan
        rows.append(out)

    return pd.DataFrame(rows).set_index("session_index")


def training_global_profile(
    train_personal_raw: np.ndarray,
    train_available: np.ndarray,
) -> np.ndarray:
    """
    Population calibration reference built only from outer-training sessions.

    We take the median of genuine training-session history profiles. It contains
    no target behavior information and no target-participant behavior labels.
    """
    genuine = train_personal_raw[train_available]
    if len(genuine) == 0:
        return np.zeros(len(PROFILE_COLS), dtype=float)

    g = np.nanmedian(genuine, axis=0)
    g = np.where(np.isfinite(g), g, 0.0)
    return g.astype(float)


# -----------------------------------------------------------------------------
# Model: canonical-style hierarchical PV-RNN with adaptive variables
# -----------------------------------------------------------------------------

def _diag_gaussian_kl(
    mu_q: torch.Tensor,
    logvar_q: torch.Tensor,
    mu_p: torch.Tensor,
    logvar_p: torch.Tensor,
) -> torch.Tensor:
    """Dimension-normalized KL[q(z)||p(z)]; one value per sample.

    V2 uses mean-over-latent-dim rather than sum-over-latent-dim so that the
    effective meta-prior is not mechanically changed by choosing a different
    number of stochastic units in the fast versus slow layer.
    """
    var_q = torch.exp(logvar_q)
    var_p = torch.exp(logvar_p)
    kl = 0.5 * (
        logvar_p - logvar_q
        + (var_q + (mu_q - mu_p).pow(2)) / (var_p + 1e-8)
        - 1.0
    )
    return kl.mean(dim=-1)


class FullPVRNN(nn.Module):
    """
    Two-timescale canonical-style PV-RNN adapted for individual calibration.

    V2 profile-injection rule
    -------------------------
    The participant profile can affect ONLY:
      (a) the initial deterministic states;
      (b) the learned priors p(z_t | d_{t-1}, profile).

    The profile is deliberately absent from:
      - posterior-base networks,
      - deterministic recurrent dynamics,
      - sensory reconstruction head,
      - behavior/affect readout.

    Thus GLOBAL vs PERSONAL differences must propagate through prior
    initialization / latent inference rather than an output shortcut.

    Observed x_t remains a reconstruction TARGET, never a direct recurrent
    input. During test-time error regression, network weights are frozen and
    only fresh adaptive variables A_t are optimized.
    """

    def __init__(
        self,
        input_dim: int,
        hidden_size: int,
        slow_hidden_size: int,
        latent_dim: int,
        slow_latent_dim: int,
        tau_fast: float,
        tau_slow: float,
        profile_dim: int,
        profile_hidden: int,
        dropout: float,
        use_profile: bool,
        output_dim: int,
    ):
        super().__init__()
        self.input_dim = int(input_dim)
        self.fast_d = int(hidden_size)
        self.slow_d = int(slow_hidden_size)
        self.fast_z = int(latent_dim)
        self.slow_z = int(slow_latent_dim)
        self.tau_fast = float(tau_fast)
        self.tau_slow = float(tau_slow)
        self.use_profile = bool(use_profile)
        self.profile_hidden = int(profile_hidden if use_profile else 0)

        if self.use_profile:
            self.profile_net = nn.Sequential(
                nn.Linear(profile_dim, profile_hidden),
                nn.Tanh(),
            )
            ctx_dim = profile_hidden
        else:
            self.profile_net = None
            ctx_dim = 0
        self.ctx_dim = ctx_dim

        # Profile-conditioned priors: this is the principal calibration entry.
        self.prior_fast = nn.Linear(
            self.fast_d + self.slow_d + ctx_dim,
            2 * self.fast_z,
        )
        self.prior_slow = nn.Linear(
            self.slow_d + ctx_dim,
            2 * self.slow_z,
        )

        # Posterior base terms do NOT receive profile directly.
        self.post_base_fast = nn.Linear(
            self.fast_d + self.slow_d,
            2 * self.fast_z,
        )
        self.post_base_slow = nn.Linear(
            self.slow_d,
            2 * self.slow_z,
        )

        # Recurrent dynamics do NOT receive profile directly.
        self.fast_dyn = nn.Linear(
            self.fast_d + self.slow_d + self.fast_z,
            self.fast_d,
        )
        self.slow_dyn = nn.Linear(
            self.slow_d + self.fast_d + self.slow_z,
            self.slow_d,
        )

        # Profile-dependent initial deterministic states.
        if self.use_profile:
            self.init_fast = nn.Linear(ctx_dim, self.fast_d)
            self.init_slow = nn.Linear(ctx_dim, self.slow_d)
        else:
            self.init_fast = None
            self.init_slow = None

        # Generative sensory output depends only on latent-integrated d states.
        self.sensory_head = nn.Sequential(
            nn.Linear(
                self.fast_d + self.slow_d,
                self.fast_d + self.slow_d,
            ),
            nn.Tanh(),
            nn.Linear(self.fast_d + self.slow_d, self.input_dim),
        )

        # Session-level behavior/affect head cannot see the profile directly.
        fusion_dim = self.fast_d + self.slow_d
        self.behavior_head = nn.Sequential(
            nn.LayerNorm(fusion_dim),
            nn.Dropout(dropout),
            nn.Linear(fusion_dim, output_dim),
        )

    @property
    def adaptive_width(self) -> int:
        return 2 * (self.fast_z + self.slow_z)

    @staticmethod
    def _split_gaussian(params: torch.Tensor):
        mu, logvar = torch.chunk(params, 2, dim=-1)
        return mu, torch.clamp(logvar, min=-7.0, max=3.0)

    def _ctx(self, profile, batch_size, dtype, device):
        if self.use_profile:
            if profile is None:
                raise ValueError(
                    "profile required for profile-conditioned PV-RNN"
                )
            return self.profile_net(profile)
        return torch.zeros(
            (batch_size, 0),
            dtype=dtype,
            device=device,
        )

    def _initial_states(self, ctx, batch_size, dtype, device):
        if self.use_profile:
            h_f = self.init_fast(ctx)
            h_s = self.init_slow(ctx)
        else:
            h_f = torch.zeros(
                (batch_size, self.fast_d),
                dtype=dtype,
                device=device,
            )
            h_s = torch.zeros(
                (batch_size, self.slow_d),
                dtype=dtype,
                device=device,
            )
        return h_f, h_s, torch.tanh(h_f), torch.tanh(h_s)

    def forward(
        self,
        x_target: torch.Tensor,
        lengths: torch.Tensor,
        adaptive_A: torch.Tensor,
        profile: Optional[torch.Tensor] = None,
        sample_latent: bool = True,
        return_details: bool = True,
    ):
        B, T, _ = x_target.shape
        dtype, device = x_target.dtype, x_target.device

        ctx = self._ctx(profile, B, dtype, device)
        h_f, h_s, d_f, d_s = self._initial_states(
            ctx, B, dtype, device
        )

        recon_sum = torch.zeros((), dtype=dtype, device=device)
        recon_count = torch.zeros((), dtype=dtype, device=device)
        kl_f_sum = torch.zeros((), dtype=dtype, device=device)
        kl_s_sum = torch.zeros((), dtype=dtype, device=device)
        latent_abs_sum = torch.zeros((), dtype=dtype, device=device)
        latent_count = torch.zeros((), dtype=dtype, device=device)

        # One host/device synchronization rather than one per time step.
        T_eff = min(T, int(lengths.max().item()))
        active_mask = (
            torch.arange(T_eff, device=device).unsqueeze(0)
            < lengths.unsqueeze(1)
        )

        for t in range(T_eff):
            active = active_mask[:, t]

            # ----- profile-conditioned priors -----
            p_f_in = torch.cat([d_f, d_s, ctx], dim=-1)
            p_s_in = torch.cat([d_s, ctx], dim=-1)
            mu_pf, lv_pf = self._split_gaussian(
                self.prior_fast(p_f_in)
            )
            mu_ps, lv_ps = self._split_gaussian(
                self.prior_slow(p_s_in)
            )

            # ----- posterior bases: no direct profile input -----
            qb_f = self.post_base_fast(torch.cat([d_f, d_s], dim=-1))
            qb_s = self.post_base_slow(d_s)

            A_t = adaptive_A[:, t, :]
            cut1 = self.fast_z
            cut2 = cut1 + self.fast_z
            cut3 = cut2 + self.slow_z

            A_mu_f = A_t[:, :cut1]
            A_lv_f = A_t[:, cut1:cut2]
            A_mu_s = A_t[:, cut2:cut3]
            A_lv_s = A_t[:, cut3:]

            base_mu_f, base_lv_f = self._split_gaussian(qb_f)
            base_mu_s, base_lv_s = self._split_gaussian(qb_s)

            mu_qf = base_mu_f + A_mu_f
            lv_qf = torch.clamp(base_lv_f + A_lv_f, -7.0, 3.0)
            mu_qs = base_mu_s + A_mu_s
            lv_qs = torch.clamp(base_lv_s + A_lv_s, -7.0, 3.0)

            if sample_latent:
                z_f = (
                    mu_qf
                    + torch.exp(0.5 * lv_qf)
                    * torch.randn_like(mu_qf)
                )
                z_s = (
                    mu_qs
                    + torch.exp(0.5 * lv_qs)
                    * torch.randn_like(mu_qs)
                )
            else:
                z_f, z_s = mu_qf, mu_qs

            # ----- recurrent dynamics: no direct profile input -----
            f_drive = self.fast_dyn(
                torch.cat([d_f, d_s, z_f], dim=-1)
            )
            s_drive = self.slow_dyn(
                torch.cat([d_s, d_f, z_s], dim=-1)
            )

            h_f_cand = (
                (1.0 - 1.0 / self.tau_fast) * h_f
                + (1.0 / self.tau_fast) * f_drive
            )
            h_s_cand = (
                (1.0 - 1.0 / self.tau_slow) * h_s
                + (1.0 / self.tau_slow) * s_drive
            )
            d_f_cand = torch.tanh(h_f_cand)
            d_s_cand = torch.tanh(h_s_cand)

            mask = active.unsqueeze(1)
            h_f = torch.where(mask, h_f_cand, h_f)
            h_s = torch.where(mask, h_s_cand, h_s)
            d_f = torch.where(mask, d_f_cand, d_f)
            d_s = torch.where(mask, d_s_cand, d_s)

            # ----- generative sensory reconstruction: d states only -----
            x_hat = self.sensory_head(
                torch.cat([d_f, d_s], dim=-1)
            )

            per_sample_recon = (
                (x_hat - x_target[:, t, :])
                .pow(2)
                .mean(dim=-1)
            )
            recon_sum = recon_sum + per_sample_recon[active].sum()
            recon_count = recon_count + active.sum().to(dtype)

            # KL is already normalized by latent dimensionality.
            kl_f = _diag_gaussian_kl(
                mu_qf, lv_qf, mu_pf, lv_pf
            )
            kl_s = _diag_gaussian_kl(
                mu_qs, lv_qs, mu_ps, lv_ps
            )
            kl_f_sum = kl_f_sum + kl_f[active].sum()
            kl_s_sum = kl_s_sum + kl_s[active].sum()

            latent_abs = 0.5 * (
                mu_qf.abs().mean(dim=-1)
                + mu_qs.abs().mean(dim=-1)
            )
            latent_abs_sum = (
                latent_abs_sum + latent_abs[active].sum()
            )
            latent_count = latent_count + active.sum().to(dtype)

        # No direct profile shortcut to the behavior/affect output.
        rep = torch.cat([d_f, d_s], dim=-1)
        behavior_pred = self.behavior_head(rep)

        recon_mse = recon_sum / torch.clamp(
            recon_count, min=1.0
        )
        kl_fast = kl_f_sum / torch.clamp(
            recon_count, min=1.0
        )
        kl_slow = kl_s_sum / torch.clamp(
            recon_count, min=1.0
        )
        latent_mag = latent_abs_sum / torch.clamp(
            latent_count, min=1.0
        )

        details = {
            "reconstruction_mse": recon_mse,
            "kl_fast": kl_fast,
            "kl_slow": kl_slow,
            "mean_abs_latent_mu": latent_mag,
            "representation": rep,
        }

        if return_details:
            return behavior_pred, details
        return behavior_pred


def pad_sequences(arrays: Sequence[np.ndarray], device: str):
    lengths = torch.tensor([len(a) for a in arrays], dtype=torch.long)
    max_len = int(lengths.max())
    feat_dim = arrays[0].shape[1]
    x = torch.zeros((len(arrays), max_len, feat_dim), dtype=torch.float32)
    for i, a in enumerate(arrays):
        x[i, :len(a)] = torch.from_numpy(a.astype(np.float32))
    return x.to(device), lengths.to(device)


def make_adaptive_parameter(
    n_sequences: int,
    max_len: int,
    adaptive_width: int,
    device: str,
) -> nn.Parameter:
    # Zero means the posterior initially falls back to its learned base mapping.
    return nn.Parameter(
        torch.zeros(
            (n_sequences, max_len, adaptive_width),
            dtype=torch.float32,
            device=device,
        )
    )


def pv_free_energy(details: dict, cfg: Config) -> torch.Tensor:
    return (
        cfg.reconstruction_weight * details["reconstruction_mse"]
        + cfg.meta_prior_fast * details["kl_fast"]
        + cfg.meta_prior_slow * details["kl_slow"]
    )


# -----------------------------------------------------------------------------
# Fold preprocessing
# -----------------------------------------------------------------------------

def get_session_arrays(
    beh: pd.DataFrame,
    sequences: Dict[Tuple[str, str], np.ndarray],
    indices: Sequence[int],
) -> List[np.ndarray]:
    out = []
    for idx in indices:
        r = beh.loc[idx]
        out.append(sequences[(str(r["Pid"]), str(r["Class_id"]))])
    return out


def fit_sequence_scaler(arrays: Sequence[np.ndarray]) -> StandardScaler:
    sc = StandardScaler()
    sc.fit(np.concatenate(arrays, axis=0))
    return sc


def apply_sequence_scaler(
    arrays: Sequence[np.ndarray],
    sc: StandardScaler,
) -> List[np.ndarray]:
    return [sc.transform(a).astype(np.float32) for a in arrays]


def prepare_fold(
    beh: pd.DataFrame,
    sequences: Dict[Tuple[str, str], np.ndarray],
    train_idx: Sequence[int],
    test_idx: Sequence[int],
):
    """Prepare one profile-free outer fold.

    Every held-out session is represented by the same five current-session
    channels:
        Temperature, CO2, EDA, HR, SkinTEMP.

    The sequence scaler and behavior scaler are fitted on outer-training data
    only. No target-participant behavior labels are used in participant LOO.
    """
    train_seq_raw = get_session_arrays(
        beh, sequences, train_idx
    )
    test_seq_raw = get_session_arrays(
        beh, sequences, test_idx
    )

    y_train = beh.loc[list(train_idx), TARGETS].to_numpy(dtype=float)
    y_test = beh.loc[list(test_idx), TARGETS].to_numpy(dtype=float)

    y_scaler = StandardScaler().fit(y_train)
    y_train_z = y_scaler.transform(y_train).astype(np.float32)

    seq_scaler = fit_sequence_scaler(train_seq_raw)
    train_seq = apply_sequence_scaler(
        train_seq_raw,
        seq_scaler,
    )
    test_seq = apply_sequence_scaler(
        test_seq_raw,
        seq_scaler,
    )

    baseline = np.tile(
        y_train.mean(axis=0, keepdims=True),
        (len(test_idx), 1),
    )

    return {
        "train_seq": train_seq,
        "test_seq": test_seq,
        "y_train": y_train,
        "y_train_z": y_train_z,
        "y_test": y_test,
        "y_scaler": y_scaler,
        "baseline": baseline,
    }


# -----------------------------------------------------------------------------
# Train / predict
# -----------------------------------------------------------------------------

def train_one_model(
    fold_data: dict,
    cfg: Config,
    seed: int,
) -> FullPVRNN:
    """Train one shared PV-RNN for a fold/seed.

    Training-sequence adaptive variables A_t are optimized from the generative
    free-energy objective. Behavior labels supervise the shared behavior head,
    but A_t is detached in the behavior-loss pass so behavior labels do not
    directly infer sequence-specific posterior states.
    """
    seed_everything(seed)
    device = cfg.device

    x_train, lengths = pad_sequences(fold_data["train_seq"], device)
    y = torch.tensor(
        fold_data["y_train_z"],
        dtype=torch.float32,
        device=device,
    )

    model = FullPVRNN(
        input_dim=int(fold_data["train_seq"][0].shape[1]),
        hidden_size=cfg.hidden_size,
        slow_hidden_size=cfg.slow_hidden_size,
        latent_dim=cfg.latent_dim,
        slow_latent_dim=cfg.slow_latent_dim,
        tau_fast=cfg.tau_fast,
        tau_slow=cfg.tau_slow,
        profile_dim=len(PROFILE_COLS),  # unused because use_profile=False
        profile_hidden=cfg.profile_hidden,
        dropout=cfg.dropout,
        use_profile=False,
        output_dim=len(TARGETS),
    ).to(device)

    A_train = make_adaptive_parameter(
        n_sequences=x_train.shape[0],
        max_len=x_train.shape[1],
        adaptive_width=model.adaptive_width,
        device=device,
    )

    opt = torch.optim.AdamW(
        [
            {
                "params": model.parameters(),
                "lr": cfg.lr,
                "weight_decay": cfg.weight_decay,
            },
            {
                "params": [A_train],
                "lr": cfg.adaptive_lr,
                "weight_decay": 0.0,
            },
        ]
    )
    behavior_loss_fn = nn.MSELoss()

    last = {}
    model.train()
    for epoch in range(cfg.epochs):
        opt.zero_grad(set_to_none=True)

        _, gen = model(
            x_target=x_train,
            lengths=lengths,
            adaptive_A=A_train,
            profile=None,
            sample_latent=True,
            return_details=True,
        )
        free_energy = pv_free_energy(gen, cfg)

        behavior_pred, _ = model(
            x_target=x_train,
            lengths=lengths,
            adaptive_A=A_train.detach(),
            profile=None,
            sample_latent=False,
            return_details=True,
        )
        behavior_loss = behavior_loss_fn(behavior_pred, y)

        loss = free_energy + cfg.behavior_weight * behavior_loss
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        nn.utils.clip_grad_norm_([A_train], max_norm=5.0)
        opt.step()

        if epoch == cfg.epochs - 1:
            last = {
                "train_free_energy": float(free_energy.detach().cpu()),
                "train_reconstruction_mse": float(
                    gen["reconstruction_mse"].detach().cpu()
                ),
                "train_kl_fast": float(gen["kl_fast"].detach().cpu()),
                "train_kl_slow": float(gen["kl_slow"].detach().cpu()),
                "train_behavior_loss": float(behavior_loss.detach().cpu()),
                "train_adaptive_A_mean_abs": float(
                    A_train.detach().abs().mean().cpu()
                ),
                "train_adaptive_parameter_count": int(A_train.numel()),
            }

    model.training_diagnostics = last
    return model


def _error_regress_test_adaptive_variables(
    model: FullPVRNN,
    x_test: torch.Tensor,
    lengths: torch.Tensor,
    profile: Optional[torch.Tensor],
    cfg: Config,
) -> Tuple[nn.Parameter, dict]:
    """
    Full-session error regression for session-level prediction.

    Network parameters are frozen. Only fresh test adaptive variables A_t are
    optimized from reconstruction error + KL. No behavior target is available
    or used here.
    """
    # Freeze trained shared model.
    req_grad_state = [p.requires_grad for p in model.parameters()]
    for p in model.parameters():
        p.requires_grad_(False)

    A_test = make_adaptive_parameter(
        n_sequences=x_test.shape[0],
        max_len=x_test.shape[1],
        adaptive_width=model.adaptive_width,
        device=cfg.device,
    )
    opt_A = torch.optim.Adam([A_test], lr=cfg.error_regression_lr)

    model.eval()

    # Before error regression.
    with torch.enable_grad():
        _, d0 = model(
            x_target=x_test,
            lengths=lengths,
            adaptive_A=A_test,
            profile=profile,
            sample_latent=False,
            return_details=True,
        )
        fe0 = pv_free_energy(d0, cfg)
        before = {
            "test_free_energy_before_er": float(fe0.detach().cpu()),
            "test_reconstruction_before_er": float(d0["reconstruction_mse"].detach().cpu()),
        }

    for _ in range(cfg.error_regression_steps):
        opt_A.zero_grad(set_to_none=True)
        _, details = model(
            x_target=x_test,
            lengths=lengths,
            adaptive_A=A_test,
            profile=profile,
            sample_latent=False,
            return_details=True,
        )
        free_energy = pv_free_energy(details, cfg)
        free_energy.backward()
        nn.utils.clip_grad_norm_([A_test], max_norm=5.0)
        opt_A.step()

    with torch.enable_grad():
        _, d1 = model(
            x_target=x_test,
            lengths=lengths,
            adaptive_A=A_test,
            profile=profile,
            sample_latent=False,
            return_details=True,
        )
        fe1 = pv_free_energy(d1, cfg)

    after = {
        **before,
        "test_free_energy_after_er": float(fe1.detach().cpu()),
        "test_reconstruction_after_er": float(d1["reconstruction_mse"].detach().cpu()),
        "test_kl_fast_after_er": float(d1["kl_fast"].detach().cpu()),
        "test_kl_slow_after_er": float(d1["kl_slow"].detach().cpu()),
        "test_mean_abs_latent_mu": float(d1["mean_abs_latent_mu"].detach().cpu()),
        "test_adaptive_A_mean_abs": float(A_test.detach().abs().mean().cpu()),
        "test_er_improvement_pct": float(
            100.0 * (
                before["test_free_energy_before_er"] - float(fe1.detach().cpu())
            ) / max(abs(before["test_free_energy_before_er"]), 1e-12)
        ),
    }

    # Restore model requires_grad flags.
    for p, rg in zip(model.parameters(), req_grad_state):
        p.requires_grad_(rg)

    return A_test.detach(), after


def predict_before_and_after_er(
    model: FullPVRNN,
    fold_data: dict,
    cfg: Config,
):
    """Return matched NO_ER and ERROR_REGRESSION predictions.

    NO_ER:
        A_test = 0; no test-time optimization.

    ERROR_REGRESSION:
        same trained model; weights frozen; A_test optimized from current
        unlabeled Environment+Physiology sequence only.
    """
    device = cfg.device
    x_test, lengths = pad_sequences(fold_data["test_seq"], device)

    # ---------------------------
    # Condition 1: NO_ER
    # ---------------------------
    A_zero = torch.zeros(
        (
            x_test.shape[0],
            x_test.shape[1],
            model.adaptive_width,
        ),
        dtype=torch.float32,
        device=device,
    )

    model.eval()
    with torch.no_grad():
        pred_noer_z, d0 = model(
            x_target=x_test,
            lengths=lengths,
            adaptive_A=A_zero,
            profile=None,
            sample_latent=False,
            return_details=True,
        )

    fe0 = float(pv_free_energy(d0, cfg).detach().cpu())
    pred_noer = fold_data["y_scaler"].inverse_transform(
        pred_noer_z.cpu().numpy()
    )

    # ---------------------------
    # Condition 2: ERROR_REGRESSION
    # ---------------------------
    A_er, er_diag = _error_regress_test_adaptive_variables(
        model=model,
        x_test=x_test,
        lengths=lengths,
        profile=None,
        cfg=cfg,
    )

    with torch.no_grad():
        pred_er_z, d1 = model(
            x_target=x_test,
            lengths=lengths,
            adaptive_A=A_er,
            profile=None,
            sample_latent=False,
            return_details=True,
        )

    pred_er = fold_data["y_scaler"].inverse_transform(
        pred_er_z.cpu().numpy()
    )

    diag = {
        **getattr(model, "training_diagnostics", {}),
        **er_diag,
        "no_er_free_energy": fe0,
        "no_er_reconstruction_mse": float(
            d0["reconstruction_mse"].cpu()
        ),
        "no_er_kl_fast": float(d0["kl_fast"].cpu()),
        "no_er_kl_slow": float(d0["kl_slow"].cpu()),
        "no_er_mean_abs_latent_mu": float(
            d0["mean_abs_latent_mu"].cpu()
        ),
        "er_reconstruction_mse": float(
            d1["reconstruction_mse"].cpu()
        ),
        "er_kl_fast": float(d1["kl_fast"].cpu()),
        "er_kl_slow": float(d1["kl_slow"].cpu()),
        "er_mean_abs_latent_mu": float(
            d1["mean_abs_latent_mu"].cpu()
        ),
    }

    return {
        "NO_ER": pred_noer,
        "ERROR_REGRESSION": pred_er,
    }, diag


def count_trainable_parameters(
    input_dim: int,
    cfg: Config,
) -> int:
    model = FullPVRNN(
        input_dim=input_dim,
        hidden_size=cfg.hidden_size,
        slow_hidden_size=cfg.slow_hidden_size,
        latent_dim=cfg.latent_dim,
        slow_latent_dim=cfg.slow_latent_dim,
        tau_fast=cfg.tau_fast,
        tau_slow=cfg.tau_slow,
        profile_dim=len(PROFILE_COLS),
        profile_hidden=cfg.profile_hidden,
        dropout=cfg.dropout,
        use_profile=False,
        output_dim=len(TARGETS),
    )
    return int(
        sum(p.numel() for p in model.parameters() if p.requires_grad)
    )


# -----------------------------------------------------------------------------
# Outer protocols
# -----------------------------------------------------------------------------

def build_date_folds(
    beh: pd.DataFrame,
):
    """Secondary robustness: hold out each complete behavior date."""
    folds = []
    for ep in sorted(
        beh["EnvironmentDateKey"].astype(str).unique()
    ):
        test_idx = beh.index[
            beh["EnvironmentDateKey"].astype(str) == str(ep)
        ].tolist()
        train_idx = beh.index[
            beh["EnvironmentDateKey"].astype(str) != str(ep)
        ].tolist()

        if len(train_idx) >= 5 and len(test_idx) >= 1:
            folds.append(
                {
                    "fold_id": f"date={ep}",
                    "train_idx": train_idx,
                    "test_idx": test_idx,
                }
            )
    return folds


def build_pid_folds(
    beh: pd.DataFrame,
):
    """Primary transfer: hold out every behavior session of one participant."""
    folds = []
    for pid in sorted(beh["Pid"].astype(str).unique()):
        test_idx = beh.index[
            beh["Pid"].astype(str) == str(pid)
        ].tolist()
        train_idx = beh.index[
            beh["Pid"].astype(str) != str(pid)
        ].tolist()

        if len(train_idx) >= 5 and len(test_idx) >= 1:
            folds.append(
                {
                    "fold_id": f"pid={pid}",
                    "train_idx": train_idx,
                    "test_idx": test_idx,
                }
            )
    return folds


def _paired_seed_gain_table(
    seed_metrics: pd.DataFrame,
    protocol: str,
) -> pd.DataFrame:
    better = "ERROR_REGRESSION"
    ref = "NO_ER"
    label = "ER_vs_NO_ER"

    a = seed_metrics[
        seed_metrics["model"] == better
    ].copy()
    b = seed_metrics[
        seed_metrics["model"] == ref
    ].copy()

    paired = a.merge(
        b,
        on=["protocol", "seed", "target"],
        suffixes=("_better", "_ref"),
    )

    rows = []
    for _, r in paired.iterrows():
        ref_rmse = float(r["RMSE_ref"])
        better_rmse = float(r["RMSE_better"])
        rows.append({
            "protocol": protocol,
            "comparison": label,
            "seed": int(r["seed"]),
            "target": r["target"],
            "RMSE_better": better_rmse,
            "RMSE_ref": ref_rmse,
            "RMSE_gain": ref_rmse - better_rmse,
            "RMSE_gain_pct": (
                100.0 * (ref_rmse - better_rmse) / ref_rmse
                if ref_rmse > 1e-12 else np.nan
            ),
            "RelativeRMSE_better": float(
                r["RelativeRMSE_better"]
            ),
            "RelativeRMSE_ref": float(
                r["RelativeRMSE_ref"]
            ),
            "RelativeRMSE_gain": (
                float(r["RelativeRMSE_ref"])
                - float(r["RelativeRMSE_better"])
            ),
        })

    return pd.DataFrame(rows)


def _seed_gain_summary(paired: pd.DataFrame) -> pd.DataFrame:
    if paired.empty:
        return pd.DataFrame()

    return (
        paired.groupby(
            ["protocol", "comparison", "target"],
            as_index=False,
        )
        .agg(
            N_seeds=("seed", "nunique"),
            RMSE_gain_pct_median=("RMSE_gain_pct", "median"),
            RMSE_gain_pct_q25=(
                "RMSE_gain_pct",
                lambda x: np.quantile(x, .25),
            ),
            RMSE_gain_pct_q75=(
                "RMSE_gain_pct",
                lambda x: np.quantile(x, .75),
            ),
            RelativeRMSE_gain_median=(
                "RelativeRMSE_gain",
                "median",
            ),
        )
    )


def run_protocol(
    protocol: str,
    folds,
    beh: pd.DataFrame,
    sequences,
    cfg: Config,
    outdir: Path,
):
    validate_fold_coverage(folds, beh, protocol)
    seed_metric_rows = []
    all_oof = []
    fold_audit_rows = []
    adaptation_diag_rows = []

    protocol_t0 = time.perf_counter()
    n_total_fits = len(cfg.seeds) * len(folds)
    fit_counter = 0

    for seed_i, seed in enumerate(cfg.seeds, start=1):
        print(
            f"\n[{protocol}] seed {seed_i}/{len(cfg.seeds)} = {seed}",
            flush=True,
        )
        pred_store = {m: [] for m in MODEL_MODES}
        truth_store = []
        baseline_store = []

        for fold_i, fold in enumerate(folds, start=1):
            fold_id = fold["fold_id"]
            train_idx = fold["train_idx"]
            test_idx = fold["test_idx"]

            fit_counter += 1
            fit_t0 = time.perf_counter()
            print(
                f"  fold {fold_i}/{len(folds)} | {fold_id} | "
                f"[{fit_counter}/{n_total_fits}] train + ER ...",
                end=" ",
                flush=True,
            )

            fold_data = prepare_fold(
                beh=beh,
                sequences=sequences,
                train_idx=train_idx,
                test_idx=test_idx,
            )

            y_test_fold = beh.loc[
                test_idx, TARGETS
            ].to_numpy(dtype=float)
            session_meta = beh.loc[
                test_idx,
                ["Pid", "Class_id", "EnvironmentDateKey"],
            ]
            baseline_fold = fold_data["baseline"]

            if seed == cfg.seeds[0]:
                fold_audit_rows.append({
                    "protocol": protocol,
                    "fold": fold_id,
                    "N_train_sessions": len(train_idx),
                    "N_test_sessions": len(test_idx),
                    "N_train_PIDs": int(
                        beh.loc[train_idx, "Pid"].nunique()
                    ),
                    "N_test_PIDs": int(
                        beh.loc[test_idx, "Pid"].nunique()
                    ),
                    "N_train_dates": int(
                        beh.loc[
                            train_idx,
                            "EnvironmentDateKey",
                        ].nunique()
                    ),
                    "N_test_dates": int(
                        beh.loc[
                            test_idx,
                            "EnvironmentDateKey",
                        ].nunique()
                    ),
                })

            model = train_one_model(
                fold_data=fold_data,
                cfg=cfg,
                seed=seed,
            )
            preds, diag = predict_before_and_after_er(
                model=model,
                fold_data=fold_data,
                cfg=cfg,
            )

            elapsed_fit = time.perf_counter() - fit_t0
            print(
                f"done in {elapsed_fit/60:.1f} min | "
                f"FE gain={diag['test_er_improvement_pct']:.1f}%",
                flush=True,
            )

            adaptation_diag_rows.append({
                "protocol": protocol,
                "seed": int(seed),
                "fold": fold_id,
                **diag,
            })

            for model_name in MODEL_MODES:
                pred = preds[model_name]
                pred_store[model_name].append(pred)

                for local_i, idx in enumerate(test_idx):
                    meta = session_meta.loc[idx]
                    row = {
                        "protocol": protocol,
                        "seed": seed,
                        "fold": fold_id,
                        "model": model_name,
                        "session_index": int(idx),
                        "Pid": str(meta["Pid"]),
                        "Class_id": str(meta["Class_id"]),
                        "EnvironmentDateKey": str(
                            meta["EnvironmentDateKey"]
                        ),
                    }
                    for j, t in enumerate(TARGETS):
                        row[f"true_{t}"] = float(
                            y_test_fold[local_i, j]
                        )
                        row[f"pred_{t}"] = float(
                            pred[local_i, j]
                        )
                        row[f"baseline_{t}"] = float(
                            baseline_fold[local_i, j]
                        )
                    all_oof.append(row)

            truth_store.append(y_test_fold)
            baseline_store.append(baseline_fold)

        y_true = np.vstack(truth_store)
        baseline = np.vstack(baseline_store)

        for model_name in MODEL_MODES:
            pred = np.vstack(pred_store[model_name])
            seed_metric_rows.extend(
                metric_rows(
                    y_true=y_true,
                    y_pred=pred,
                    baseline_pred=baseline,
                    protocol=protocol,
                    model_name=model_name,
                    seed=seed,
                    n_sessions=len(y_true),
                )
            )

    seed_metrics = pd.DataFrame(seed_metric_rows)
    oof = pd.DataFrame(all_oof)
    fold_audit = pd.DataFrame(fold_audit_rows)
    adaptation_diag = pd.DataFrame(adaptation_diag_rows)

    seed_metrics.to_csv(
        outdir / f"{protocol}_seed_metrics.csv",
        index=False,
    )
    oof.to_csv(
        outdir / f"{protocol}_oof_predictions.csv",
        index=False,
    )
    fold_audit.to_csv(
        outdir / f"{protocol}_fold_audit.csv",
        index=False,
    )
    adaptation_diag.to_csv(
        outdir / f"{protocol}_adaptation_diagnostics.csv",
        index=False,
    )

    summary = (
        seed_metrics
        .groupby(
            ["protocol", "model", "target"],
            as_index=False,
        )
        .agg(
            N_seeds=("seed", "nunique"),
            N_sessions=("N_sessions", "median"),
            RMSE_median=("RMSE", "median"),
            RMSE_q25=("RMSE", lambda x: np.quantile(x, .25)),
            RMSE_q75=("RMSE", lambda x: np.quantile(x, .75)),
            RelativeRMSE_median=("RelativeRMSE", "median"),
            RelativeRMSE_q25=(
                "RelativeRMSE",
                lambda x: np.quantile(x, .25),
            ),
            RelativeRMSE_q75=(
                "RelativeRMSE",
                lambda x: np.quantile(x, .75),
            ),
            MAE_median=("MAE", "median"),
            R2_median=("R2", "median"),
        )
    )
    summary.to_csv(
        outdir / f"{protocol}_summary.csv",
        index=False,
    )

    paired = _paired_seed_gain_table(seed_metrics, protocol)
    paired.to_csv(
        outdir / f"{protocol}_paired_adaptation_gain_by_seed.csv",
        index=False,
    )

    gain_summary = _seed_gain_summary(paired)
    gain_summary.to_csv(
        outdir / f"{protocol}_adaptation_gain_summary.csv",
        index=False,
    )

    protocol_elapsed = time.perf_counter() - protocol_t0
    print(
        f"[{protocol}] completed in "
        f"{protocol_elapsed/3600:.2f} h",
        flush=True,
    )

    return (
        seed_metrics,
        summary,
        paired,
        gain_summary,
        oof,
        fold_audit,
        adaptation_diag,
    )



# -----------------------------------------------------------------------------
# Cluster bootstrap on median-across-seed OOF predictions
# -----------------------------------------------------------------------------

def _median_oof_by_session(
    oof: pd.DataFrame,
    target: str,
) -> pd.DataFrame:
    cols = [
        "protocol",
        "model",
        "session_index",
        "Pid",
        "Class_id",
        "EnvironmentDateKey",
        f"true_{target}",
        f"baseline_{target}",
    ]
    base = (
        oof[cols + [f"pred_{target}"]]
        .groupby(
            [
                "protocol",
                "model",
                "session_index",
                "Pid",
                "Class_id",
                "EnvironmentDateKey",
                f"true_{target}",
                f"baseline_{target}",
            ],
            as_index=False,
        )[f"pred_{target}"]
        .median()
    )

    meta = (
        base[
            [
                "session_index",
                "Pid",
                "Class_id",
                "EnvironmentDateKey",
                f"true_{target}",
                f"baseline_{target}",
            ]
        ]
        .drop_duplicates("session_index")
        .set_index("session_index")
    )

    pred_wide = base.pivot(
        index="session_index",
        columns="model",
        values=f"pred_{target}",
    )

    d = meta.join(pred_wide, how="inner").reset_index()
    return d


def _rmse(y: np.ndarray, p: np.ndarray) -> float:
    return float(math.sqrt(mean_squared_error(y, p)))


def _mae(y: np.ndarray, p: np.ndarray) -> float:
    return float(mean_absolute_error(y, p))


def _bootstrap_one_comparison(
    d: pd.DataFrame,
    target: str,
    better_model: str,
    ref_model: str,
    cluster_col: str,
    reps: int,
    seed: int,
) -> dict:
    y_col = f"true_{target}"
    y = d[y_col].to_numpy(dtype=float)
    p_better = d[better_model].to_numpy(dtype=float)
    p_ref = d[ref_model].to_numpy(dtype=float)

    rmse_better = _rmse(y, p_better)
    rmse_ref = _rmse(y, p_ref)
    mae_better = _mae(y, p_better)
    mae_ref = _mae(y, p_ref)

    observed_rmse_gain_pct = (
        100.0 * (rmse_ref - rmse_better) / rmse_ref
        if rmse_ref > 1e-12 else np.nan
    )
    observed_mae_gain_pct = (
        100.0 * (mae_ref - mae_better) / mae_ref
        if mae_ref > 1e-12 else np.nan
    )

    groups = {
        str(g): sub.index.to_numpy()
        for g, sub in d.groupby(cluster_col, sort=False)
    }
    cluster_ids = list(groups.keys())

    rng = np.random.default_rng(seed)
    boot_rmse_gain_pct = []
    boot_mae_gain_pct = []

    for _ in range(reps):
        sampled = rng.choice(
            cluster_ids,
            size=len(cluster_ids),
            replace=True,
        )
        idx = np.concatenate([groups[str(g)] for g in sampled])

        y_b = d.loc[idx, y_col].to_numpy(dtype=float)
        better_b = d.loc[idx, better_model].to_numpy(dtype=float)
        ref_b = d.loc[idx, ref_model].to_numpy(dtype=float)

        r_better = _rmse(y_b, better_b)
        r_ref = _rmse(y_b, ref_b)
        m_better = _mae(y_b, better_b)
        m_ref = _mae(y_b, ref_b)

        if r_ref > 1e-12:
            boot_rmse_gain_pct.append(
                100.0 * (r_ref - r_better) / r_ref
            )
        if m_ref > 1e-12:
            boot_mae_gain_pct.append(
                100.0 * (m_ref - m_better) / m_ref
            )

    rg = np.asarray(boot_rmse_gain_pct, dtype=float)
    mg = np.asarray(boot_mae_gain_pct, dtype=float)

    return {
        "target": target,
        "comparison": f"{better_model}_vs_{ref_model}",
        "better_model": better_model,
        "reference_model": ref_model,
        "cluster_col": cluster_col,
        "N_sessions": int(len(d)),
        "N_clusters": int(d[cluster_col].nunique()),
        "bootstrap_reps_requested": int(reps),
        "bootstrap_reps_success_rmse": int(len(rg)),
        "observed_RMSE_gain_pct": float(observed_rmse_gain_pct),
        "RMSE_gain_pct_boot_median": (
            float(np.median(rg)) if len(rg) else np.nan
        ),
        "RMSE_gain_pct_ci95_low": (
            float(np.quantile(rg, .025)) if len(rg) else np.nan
        ),
        "RMSE_gain_pct_ci95_high": (
            float(np.quantile(rg, .975)) if len(rg) else np.nan
        ),
        "P_boot_RMSE_gain_gt_0": (
            float(np.mean(rg > 0)) if len(rg) else np.nan
        ),
        "observed_MAE_gain_pct": float(observed_mae_gain_pct),
        "MAE_gain_pct_ci95_low": (
            float(np.quantile(mg, .025)) if len(mg) else np.nan
        ),
        "MAE_gain_pct_ci95_high": (
            float(np.quantile(mg, .975)) if len(mg) else np.nan
        ),
    }


def cluster_bootstrap_model_comparisons(
    protocol: str,
    oof: pd.DataFrame,
    cfg: Config,
    outdir: Path,
) -> pd.DataFrame:
    """Cluster bootstrap after median-across-seed OOF aggregation."""
    cluster_col = (
        "Pid"
        if protocol == "PARTICIPANT_LOO"
        else "EnvironmentDateKey"
    )

    rows = []
    for ti, target in enumerate(TARGETS):
        d = _median_oof_by_session(oof, target)
        rows.append(
            {
                "protocol": protocol,
                **_bootstrap_one_comparison(
                    d=d,
                    target=target,
                    better_model="ERROR_REGRESSION",
                    ref_model="NO_ER",
                    cluster_col=cluster_col,
                    reps=cfg.bootstrap_reps,
                    seed=10000 + ti * 100,
                ),
            }
        )

    out = pd.DataFrame(rows)
    out.to_csv(
        outdir / f"{protocol}_cluster_bootstrap_adaptation.csv",
        index=False,
    )
    return out



# -----------------------------------------------------------------------------
# Plot
# -----------------------------------------------------------------------------

def make_summary_plot(
    all_summary: pd.DataFrame,
    outdir: Path,
):
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return

    for protocol in all_summary["protocol"].unique():
        d = all_summary[
            all_summary["protocol"] == protocol
        ].copy()

        labels = []
        vals = []
        for target in TARGETS:
            for model in MODEL_MODES:
                r = d[
                    (d["target"] == target) &
                    (d["model"] == model)
                ]
                if len(r):
                    labels.append(f"{target}\n{model}")
                    vals.append(
                        float(r["RelativeRMSE_median"].iloc[0])
                    )

        if not vals:
            continue

        fig, ax = plt.subplots(figsize=(11, 5.0))
        ax.bar(np.arange(len(vals)), vals)
        ax.axhline(1.0, linewidth=1)
        ax.set_xticks(np.arange(len(vals)))
        ax.set_xticklabels(
            labels,
            rotation=35,
            ha="right",
        )
        ax.set_ylabel("Median RelativeRMSE")
        ax.set_title(protocol)
        fig.tight_layout()
        fig.savefig(
            outdir / f"{protocol}_relative_rmse_v3.png",
            dpi=200,
        )
        plt.close(fig)


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


def main():
    args = parse_args()

    table_dir = resolve_table_dir(args.table_dir)
    output_dir = (
        Path(args.output_dir)
        if args.output_dir
        else table_dir.parent / "pv_rnn_label_free_adaptation_v3_outputs"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    model_dir = output_dir / "02_pv_rnn_v3_model"
    model_dir.mkdir(parents=True, exist_ok=True)

    if args.quick:
        seeds = (11,)
        epochs = 25 if args.epochs is None else args.epochs
        er_steps = 40 if args.er_steps is None else args.er_steps
        bootstrap_reps = (
            200 if args.bootstrap_reps is None
            else args.bootstrap_reps
        )
    else:
        if args.seeds:
            seeds = tuple(
                int(x.strip())
                for x in args.seeds.split(",")
                if x.strip()
            )
        else:
            seeds = (11, 23, 37, 51, 71)

        epochs = 150 if args.epochs is None else args.epochs
        er_steps = 150 if args.er_steps is None else args.er_steps
        bootstrap_reps = (
            2000 if args.bootstrap_reps is None
            else args.bootstrap_reps
        )

    device = (
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    cfg = Config(
        table_dir=table_dir,
        output_dir=output_dir,
        seeds=seeds,
        epochs=epochs,
        latent_dim=(
            args.latent_dim
            if args.latent_dim is not None
            else 3
        ),
        slow_latent_dim=(
            args.slow_latent_dim
            if args.slow_latent_dim is not None
            else 2
        ),
        meta_prior_fast=(
            args.meta_prior_fast
            if args.meta_prior_fast is not None
            else 1e-3
        ),
        meta_prior_slow=(
            args.meta_prior_slow
            if args.meta_prior_slow is not None
            else 1e-3
        ),
        error_regression_steps=er_steps,
        error_regression_lr=(
            args.er_lr
            if args.er_lr is not None
            else 5e-2
        ),
        bootstrap_reps=bootstrap_reps,
        run_mixedlm=False,
        device=device,
    )

    print("=" * 92)
    print(
        "PV-RNN LABEL-FREE TEST-TIME ADAPTATION EXPERIMENT V3"
    )
    print("=" * 92)
    print(f"Run mode: {'QUICK' if args.quick else 'FULL'}")
    print(f"Device: {cfg.device}")
    print(f"Seeds: {cfg.seeds}")
    print(f"Epochs: {cfg.epochs}")
    print(
        f"Fast/slow latent dims: "
        f"{cfg.latent_dim}/{cfg.slow_latent_dim}"
    )
    print(
        f"Fast/slow deterministic dims: "
        f"{cfg.hidden_size}/{cfg.slow_hidden_size}"
    )
    print(
        f"Time constants tau: "
        f"{cfg.tau_fast}/{cfg.tau_slow}"
    )
    print(
        f"Meta-priors: "
        f"{cfg.meta_prior_fast}/{cfg.meta_prior_slow}"
    )
    print(
        f"Error-regression steps/lr: "
        f"{cfg.error_regression_steps}/"
        f"{cfg.error_regression_lr}"
    )
    print(
        f"Cluster bootstrap reps: {cfg.bootstrap_reps}"
    )
    print(f"Table dir: {cfg.table_dir}")
    print(f"Output dir: {cfg.output_dir}")

    env, beh, temporal = load_tables(cfg)

    print("\n[QC]")
    print(
        f"  EnvPhys: {env['Pid'].nunique()} PIDs | "
        f"{len(env)} sessions | "
        f"{env['EnvironmentDateKey'].nunique()} dates"
    )
    print(
        f"  Behavior: {beh['Pid'].nunique()} PIDs | "
        f"{len(beh)} sessions | "
        f"{beh['EnvironmentDateKey'].nunique()} dates"
    )

    print("\n[1] Build five-channel 60-s session sequences")
    sequences, sequence_qc = build_session_sequences(
        temp=temporal,
        cfg=cfg,
    )
    sequence_qc.to_csv(
        model_dir / "sequence_qc.csv",
        index=False,
    )
    print(
        f"  Sequence sessions available: {len(sequences)}"
    )

    param_audit = pd.DataFrame([
        {
            "model": "PV_RNN_SHARED",
            "sequence_input_dim": 5,
            "test_conditions": "NO_ER vs ERROR_REGRESSION",
            "trainable_parameters": count_trainable_parameters(
                input_dim=5,
                cfg=cfg,
            ),
        }
    ])
    param_audit.to_csv(
        model_dir / "model_parameter_audit.csv",
        index=False,
    )
    print("\n  Architecture audit:")
    print(param_audit.to_string(index=False))
    print(
        "  NO_ER and ERROR_REGRESSION reuse the SAME trained "
        "network weights for each fold/seed."
    )

    # --------------------------------------------------------------
    # PRIMARY: participant LOO
    # --------------------------------------------------------------
    print(
        "\n[2] PRIMARY transfer: PARTICIPANT_LOO"
    )
    pid_folds = build_pid_folds(beh)
    print(f"  Outer folds: {len(pid_folds)}")
    for fold in pid_folds:
        print(
            f"    {fold['fold_id']}: "
            f"train={len(fold['train_idx'])} "
            f"test={len(fold['test_idx'])}"
        )

    (
        pid_metrics,
        pid_summary,
        pid_paired,
        pid_gain,
        pid_oof,
        pid_fold_audit,
        pid_diag,
    ) = run_protocol(
        protocol="PARTICIPANT_LOO",
        folds=pid_folds,
        beh=beh,
        sequences=sequences,
        cfg=cfg,
        outdir=model_dir,
    )

    pid_boot = cluster_bootstrap_model_comparisons(
        protocol="PARTICIPANT_LOO",
        oof=pid_oof,
        cfg=cfg,
        outdir=model_dir,
    )

    print("\n  Median RelativeRMSE across seeds:")
    print(
        pid_summary[
            [
                "model",
                "target",
                "N_sessions",
                "RelativeRMSE_median",
                "RMSE_median",
                "R2_median",
            ]
        ].to_string(index=False)
    )

    print("\n  Paired adaptation gain: ERROR_REGRESSION vs NO_ER")
    print(
        pid_gain[
            [
                "target",
                "RMSE_gain_pct_median",
                "RMSE_gain_pct_q25",
                "RMSE_gain_pct_q75",
            ]
        ].to_string(index=False)
    )

    print("\n  PID-cluster bootstrap: ERROR_REGRESSION vs NO_ER")
    print(
        pid_boot[
            [
                "target",
                "observed_RMSE_gain_pct",
                "RMSE_gain_pct_ci95_low",
                "RMSE_gain_pct_ci95_high",
                "P_boot_RMSE_gain_gt_0",
            ]
        ].to_string(index=False)
    )

    # --------------------------------------------------------------
    # SECONDARY: date LOO
    # --------------------------------------------------------------
    print(
        "\n[3] SECONDARY context robustness: DATE_LOO"
    )
    ep_folds = build_date_folds(beh)
    print(f"  Outer folds: {len(ep_folds)}")
    for fold in ep_folds:
        print(
            f"    {fold['fold_id']}: "
            f"train={len(fold['train_idx'])} "
            f"test={len(fold['test_idx'])}"
        )

    (
        ep_metrics,
        ep_summary,
        ep_paired,
        ep_gain,
        ep_oof,
        ep_fold_audit,
        ep_diag,
    ) = run_protocol(
        protocol="DATE_LOO",
        folds=ep_folds,
        beh=beh,
        sequences=sequences,
        cfg=cfg,
        outdir=model_dir,
    )

    ep_boot = cluster_bootstrap_model_comparisons(
        protocol="DATE_LOO",
        oof=ep_oof,
        cfg=cfg,
        outdir=model_dir,
    )

    print("\n  Median RelativeRMSE across seeds:")
    print(
        ep_summary[
            [
                "model",
                "target",
                "N_sessions",
                "RelativeRMSE_median",
                "RMSE_median",
                "R2_median",
            ]
        ].to_string(index=False)
    )

    print("\n  Paired adaptation gain: ERROR_REGRESSION vs NO_ER")
    print(
        ep_gain[
            [
                "target",
                "RMSE_gain_pct_median",
                "RMSE_gain_pct_q25",
                "RMSE_gain_pct_q75",
            ]
        ].to_string(index=False)
    )

    print(
        "\n  Date-cluster bootstrap: "
        "ERROR_REGRESSION vs NO_ER"
    )
    print(
        ep_boot[
            [
                "target",
                "observed_RMSE_gain_pct",
                "RMSE_gain_pct_ci95_low",
                "RMSE_gain_pct_ci95_high",
                "P_boot_RMSE_gain_gt_0",
            ]
        ].to_string(index=False)
    )

    all_summary = pd.concat(
        [pid_summary, ep_summary],
        ignore_index=True,
    )
    all_gain = pd.concat(
        [pid_gain, ep_gain],
        ignore_index=True,
    )
    all_boot = pd.concat(
        [pid_boot, ep_boot],
        ignore_index=True,
    )

    all_summary.to_csv(
        model_dir / "FINAL_pv_rnn_adaptation_summary_v3.csv",
        index=False,
    )
    all_gain.to_csv(
        model_dir / "FINAL_pv_rnn_adaptation_gain_v3.csv",
        index=False,
    )
    all_boot.to_csv(
        model_dir / "FINAL_pv_rnn_adaptation_bootstrap_v3.csv",
        index=False,
    )

    make_summary_plot(all_summary, model_dir)

    interpretation = {
        "environment_scope": "school_indoor_context",
        "individual_classroom_exposure": False,
        "context_group": "calendar_date",
        "version": (
            "PV-RNN V3: label-free current-session "
            "test-time adaptation"
        ),
        "scientific_focus": (
            "Test whether prediction-error-based error regression "
            "improves session-level behavior/affect estimation for "
            "unseen participants or unseen classroom dates using "
            "only current unlabeled Environment+Physiology."
        ),
        "past_physiology_profile_used": False,
        "critical_comparison": (
            "ERROR_REGRESSION vs NO_ER using the SAME trained "
            "PV-RNN weights within each fold and seed."
        ),
        "input_channels": SEQ_COLS,
        "test_conditions": {
            "NO_ER": (
                "Fresh A_t initialized to zero; no test-time "
                "optimization."
            ),
            "ERROR_REGRESSION": (
                "Network weights frozen; fresh A_t optimized only "
                "from held-out current-session reconstruction error "
                "plus KL. No held-out behavior labels used."
            ),
        },
        "canonical_mechanisms": [
            "multiple-timescale deterministic recurrent states",
            "stochastic latent states",
            "learned priors",
            "adaptive variables A_t",
            "free-energy minimization",
            "test-time error regression",
        ],
        "primary_protocol": (
            "PARTICIPANT_LOO over all behavior participants."
        ),
        "secondary_protocol": (
            "DATE_LOO over all behavior dates."
        ),
        "behavior_unit": (
            "One Pid x Class session = one behavior target/loss."
        ),
        "claim_boundary": (
            "Offline full-session state inference; not real-time "
            "future prediction. Latent variables are computational "
            "states, not neural states or sensory-precision estimates."
        ),
        "cohort": {
            "behavior_sessions": int(len(beh)),
            "behavior_pids": int(beh["Pid"].nunique()),
            "behavior_dates": int(
                beh["EnvironmentDateKey"].nunique()
            ),
            "participant_folds": int(len(pid_folds)),
            "date_folds": int(len(ep_folds)),
        },
    }

    with open(
        output_dir / "PV_RNN_V3_EXPERIMENT_INTERPRETATION.json",
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            interpretation,
            f,
            ensure_ascii=False,
            indent=2,
        )

    print("\n" + "=" * 92)
    print("COMPLETE")
    print("=" * 92)
    print(f"Outputs: {output_dir}")
    print("Review first:")
    print(
        "  1) 02_pv_rnn_v3_model/"
        "PARTICIPANT_LOO_summary.csv"
    )
    print(
        "  2) 02_pv_rnn_v3_model/"
        "PARTICIPANT_LOO_adaptation_gain_summary.csv"
    )
    print(
        "  3) 02_pv_rnn_v3_model/"
        "PARTICIPANT_LOO_cluster_bootstrap_adaptation.csv"
    )
    print(
        "  4) 02_pv_rnn_v3_model/"
        "PARTICIPANT_LOO_adaptation_diagnostics.csv"
    )
    print(
        "  5) 02_pv_rnn_v3_model/"
        "DATE_LOO_summary.csv"
    )
    print(
        "  6) 02_pv_rnn_v3_model/"
        "DATE_LOO_adaptation_gain_summary.csv"
    )
    print(
        "  7) 02_pv_rnn_v3_model/"
        "DATE_LOO_cluster_bootstrap_adaptation.csv"
    )
    print(
        "  8) PV_RNN_V3_EXPERIMENT_INTERPRETATION.json"
    )


if __name__ == "__main__":
    main()
