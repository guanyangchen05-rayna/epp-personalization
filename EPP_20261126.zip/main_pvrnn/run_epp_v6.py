"""Versioned EPP pilot experiment, layered on frozen v5 preprocessing."""
from __future__ import annotations
import argparse
from dataclasses import asdict
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import importlib.metadata
import json
import platform
import sys
import traceback
import numpy as np
import pandas as pd
import torch
from epp_v6.model import Settings
from epp_v6.data import load_cohort,sha256
from epp_v6.behavior import run_behavior
from epp_v6.individual import describe,validate,recovery
from epp_v6.chain import align_reports,training_reports

ROOT=Path(__file__).resolve().parent


def parse_args(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--table-dir',type=Path,required=True)
    p.add_argument('--output-dir',type=Path,default=Path('results/epp_v6'))
    p.add_argument('--stage',choices=['all','check','behavior','parameters','validation','chain','recovery'],default='all')
    p.add_argument('--cohorts',default='22,11',help='22,11 or either cohort alone')
    p.add_argument('--config',type=Path)
    p.add_argument('--quick',action='store_true',help='Smoke budgets, NEVER paper results')
    p.add_argument('--allow-other-counts',action='store_true',help='Explicit synthetic/changed-cohort override')
    p.add_argument('--seeds',help='Explicit comma-separated seed override, recorded in manifest')
    p.add_argument('--threads',type=int,default=1)
    return p.parse_args(argv)


def load_settings(args):
    data={} if args.config is None else json.loads(args.config.read_text())
    allowed=set(Settings.__dataclass_fields__)
    if set(data)-allowed: raise ValueError(f'Unknown configuration keys: {sorted(set(data)-allowed)}')
    for k in ('seeds','log_precision_grid'):
        if k in data:data[k]=tuple(data[k])
    cfg=Settings(**data)
    if args.seeds:cfg.seeds=tuple(int(v) for v in args.seeds.split(','))
    if args.quick:
        cfg.epochs=2;cfg.er_steps=3;cfg.seeds=(11,);cfg.bootstrap_reps=30
        cfg.log_precision_grid=(-1.,0.,1.);cfg.recovery_reps=1
        cfg.recovery_include_midpoints=False
    return cfg.validate()


def verify_parent():
    expected=json.loads((ROOT/'config/v6_parent_hashes.json').read_text())
    for path,value in expected.items():
        if sha256(ROOT/path)!=value:raise ValueError(f'Parent v5 source changed: {path}')
    return expected


def main(argv=None):
    a=parse_args(argv);cfg=load_settings(a);parents=verify_parent()
    names=a.cohorts.split(',')
    if len(names)!=len(set(names)) or any(n not in ('22','11') for n in names):
        raise ValueError('Choose unique cohort names 22 and/or 11')
    if a.stage=='behavior' and '11' not in names:raise ValueError('Behavior requires --cohorts 11')
    if a.threads<1:raise ValueError('threads must be positive')
    torch.set_num_threads(a.threads)
    cohorts={n:load_cohort(a.table_dir,n,enforce_counts=not a.allow_other_counts) for n in names}
    needs_chain=a.stage in ('all','check','validation','chain')
    needs_reports=a.stage!='behavior'
    report_cohort=(cohorts.get('11') or load_cohort(a.table_dir,'11',enforce_counts=not a.allow_other_counts)) if needs_reports else None
    if '22' in cohorts and '11' in cohorts:
        full={tuple(k):v for k,v in zip(cohorts['22'].meta[['Pid','Class_id']].to_numpy(),cohorts['22'].arrays)}
        for key,arr in zip(cohorts['11'].meta[['Pid','Class_id']].to_numpy(),cohorts['11'].arrays):
            if tuple(key) not in full or not np.array_equal(arr,full[tuple(key)]):
                raise ValueError('11-person sequences must exactly match the same sessions in 22-person cohort')
        full_times={tuple(k):t for k,t in zip(cohorts['22'].meta[['Pid','Class_id']].to_numpy(),cohorts['22'].times)}
        for key,t in zip(cohorts['11'].meta[['Pid','Class_id']].to_numpy(),cohorts['11'].times):
            if not np.array_equal(t,full_times[tuple(key)]):
                raise ValueError('11-person minute IDs must match the 22-person cohort')
    # Fail before any expensive fitting if the declared complete reports cannot
    # support participant-excluded readout training in either requested cohort.
    if needs_reports:
        for n,c in cohorts.items():
            report_values=align_reports(c,report_cohort)
            for pid in c.meta.Pid.unique():
                training_reports(report_values,np.flatnonzero(~c.meta.Pid.eq(pid)))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    out=a.output_dir.resolve()/stamp;out.mkdir(parents=True,exist_ok=False)
    versions={}
    for dep in ['torch','numpy','pandas','scipy','scikit-learn','statsmodels','matplotlib']:
        try:versions[dep]=importlib.metadata.version(dep)
        except importlib.metadata.PackageNotFoundError:versions[dep]=None
    manifest=dict(version='0.6.2-chain',status='running',stage=a.stage,configuration=asdict(cfg),
                  quick=a.quick,nonpaper_count_override=a.allow_other_counts,python=sys.version,
                  platform=platform.platform(),dependencies=versions,parent_v5_sources=parents,
                  implementation_sources={str(p.relative_to(ROOT)):sha256(p) for p in
                      sorted((ROOT/'epp_v6').glob('*.py'))+[ROOT/'run_epp_v6.py']},
                  input_tables={n:c.input_hashes for n,c in cohorts.items()},
                  study_scope='offline_pilot_not_causal_or_trait_identification',
                  shared_environment_panel_uses_all_eligible_timestamps=True,
                  individual_parameter='standardized_physiological_residual_log_precision',
                  individual_fits_use_report_labels=False,
                  main_behavior_evaluation_uses_individual_parameters=False,
                  full_chain_validation_uses_individual_parameters=needs_chain,
                  full_chain_readout_trains_on_other_participant_reports_only=True,
                  full_chain_rho_calibration_uses_report_labels=False,
                  full_chain_behavior_and_physiology_share_test_inference=True,
                  question_1_primary_cohort='22' if '22' in names else '11',
                  question_2_matched_training_cohort='11',
                  complete_report_source=None if report_cohort is None else report_cohort.input_hashes,
                  three_observation_domains_are_not_three_neural_layers=True,
                  elapsed_gaps_explicitly_modeled=True,
                  gap_policy='prior_transitions_without_observation_loss',
                  timeline_origin='first_retained_minute',
                  validation_gap_unit='retained_bins_with_real_elapsed_transitions',
                  pre_gap_checkpoint_reuse=False)
    path=out/'run_manifest.json'
    def save():path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    save();print(f'RUN_DIR={out}',flush=True)
    try:
        for n,c in cohorts.items():
            dest=out/('cohort_'+n);dest.mkdir();c.meta.to_csv(dest/'session_index.csv',index=False)
            c.qc.to_csv(dest/'sequence_QC.csv',index=False)
            print(f'[cohort {n}] sessions={len(c.meta)} participants={c.meta.Pid.nunique()} '
                  f'dates={c.meta.EnvironmentDateKey.nunique()}',flush=True)
            g=c.qc.loc[c.qc.omitted_bins>0,['Pid','Class_id','n_bins','omitted_bins','max_internal_gap_bins']]
            print(f'[timefix] real minute intervals enabled; sessions with internal gaps={len(g)}',flush=True)
            if len(g):print(g.to_string(index=False),flush=True)
        if a.stage in ('all','behavior') and '11' in cohorts:
            run_behavior(cohorts['11'],cfg,out/'behavior_11')
        for n,c in cohorts.items():
            if a.stage in ('all','parameters'):describe(c,cfg,out/f'cohort_{n}'/'parameters',report_cohort=report_cohort)
            if a.stage in ('all','validation','chain'):
                validate(c,cfg,out/f'cohort_{n}'/'validation',report_cohort=report_cohort)
            if a.stage in ('all','recovery'):recovery(c,cfg,out/f'cohort_{n}'/'recovery',report_cohort=report_cohort)
        if a.stage in ('all','validation','chain'):
            tables=[]
            for n in names:
                summary_path=out/f'cohort_{n}/validation/chain_joint_summary.csv'
                t=pd.read_csv(summary_path);t['primary_analysis']=(t.cohort.astype(str)==manifest['question_1_primary_cohort']) & t.primary_cross_session
                tables.append(t)
            pd.concat(tables,ignore_index=True).to_csv(out/'question1_joint_validation.csv',index=False)
        if a.stage!='check':
            from epp_v6.plots import make_figures
            make_figures(out)
        manifest['status']='completed'
    except Exception as e:
        manifest['status']='failed';manifest['error']=repr(e);save();raise
    finally:
        manifest['finished_at']=datetime.now(timezone.utc).isoformat();save()
    print(f'COMPLETE: {out}',flush=True)
    return out


if __name__=='__main__':main()
