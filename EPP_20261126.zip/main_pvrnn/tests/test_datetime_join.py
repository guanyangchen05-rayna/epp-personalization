"""Regression: CSV timestamps and resampled timestamps may use us/ns units."""
from pathlib import Path
import sys
import unittest
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from preprocess_sessions import merge_environment_to_physiology

class DatetimeJoinTests(unittest.TestCase):
    def test_mixed_us_ns_units_align_without_time_shift_or_gap_filling(self):
        for left_unit,right_unit in [('ns','us'),('us','ns')]:
            with self.subTest(left=left_unit,right=right_unit):
                times=pd.to_datetime(['2019-10-28 09:00:00.123456','2019-10-28 09:04:59.123456','2019-10-28 09:05:00.123456'],format='mixed')
                phys=pd.DataFrame({'Class_id':['1']*3,'Pid':['1']*3,'ClassStart':pd.Timestamp('2019-10-28 09:00'),
                                   'DateTime':times.astype('datetime64['+left_unit+']'),'HasCorePhysiology':True})
                env=pd.DataFrame({'EnvTimestamp':pd.to_datetime(['2019-10-28 09:00','2019-10-28 09:05']).astype('datetime64['+right_unit+']'),
                                  'IndoorTemperature':[20.,np.nan],'IndoorCO2':[600.,np.nan]})
                self.assertNotEqual(phys.DateTime.dtype,env.EnvTimestamp.dtype)
                out=merge_environment_to_physiology(phys,{'1':env})
                self.assertEqual(str(out.DateTime.dtype),'datetime64[ns]')
                self.assertEqual(out.DateTime.tolist(),times.tolist())
                self.assertEqual(out.IndoorTemperature.iloc[:2].tolist(),[20.,20.])
                self.assertTrue(pd.isna(out.IndoorTemperature.iloc[2]))
                self.assertEqual(out.HasCoreEnvironmentPhysiology.tolist(),[True,True,False])

if __name__=='__main__':unittest.main()
