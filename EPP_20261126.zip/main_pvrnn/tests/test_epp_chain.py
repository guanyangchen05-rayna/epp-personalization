"""Full-chain transfer: held-out participants/reports, shared masks and rho."""
from pathlib import Path
import copy
import json
import sys
import tempfile
import unittest
import numpy as np
import pandas as pd
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))
from epp_v6.model import Settings,train,FiveArrowPVRNN
from epp_v6.data import load_cohort,TARGETS
from epp_v6.chain import align_reports,training_reports,report_record,summarize_chain
from epp_v6.individual import validate,score_hidden_physiology,recovery
from make_epp_demo import make

torch.set_num_threads(1)


class PartialReportTests(unittest.TestCase):
    def test_precision_actually_changes_inference_and_its_behavior_readout(self):
        class SharedState(torch.nn.Module):
            adaptive_width=1
            def forward(self,l,A,sample=False,window_ids=None):
                state=A.sum(1)
                reconstruction=state[:,None,:].expand(-1,A.shape[1],5)
                return dict(reconstruction=reconstruction,kl_fast=A[:,:,0]*0,
                            kl_slow=A[:,:,0]*0,prediction=state.expand(-1,3))
        model=SharedState();cfg=Settings(er_steps=100)
        x=np.zeros((12,5),np.float32);x[:,2:]=2
        low=score_hidden_physiology(model,x,cfg,-1,6,return_prediction=True)
        high=score_hidden_physiology(model,x,cfg,1,6,return_prediction=True)
        self.assertGreater(high['prediction_standardized'][0],low['prediction_standardized'][0]+.2)
        poison=x.copy();poison[6:,2:]=1e10
        other=score_hidden_physiology(model,poison,cfg,1,6,return_prediction=True)
        self.assertEqual(high['prediction_standardized'],other['prediction_standardized'])
        self.assertEqual(high['inference_objective'],other['inference_objective'])

    def test_missing_reports_have_no_value_or_gradient_effect(self):
        arrays=[np.ones((7,5),np.float32),np.zeros((6,5),np.float32),np.full((5,5),.5,np.float32)]
        cfg=Settings(epochs=2,er_steps=1,seeds=(11,))
        y=np.array([[1,2,3],[np.nan,np.nan,np.nan],[3,2,1]],np.float32)
        mask=np.array([True,False,True]);a,ha=train(arrays,cfg,11,y,label_mask=mask)
        y[1]=1e20;b,hb=train(arrays,cfg,11,y,label_mask=mask)
        self.assertEqual(ha,hb)
        for key in a.state_dict():torch.testing.assert_close(a.state_dict()[key],b.state_dict()[key],rtol=0,atol=0)
        self.assertTrue(all(np.isfinite(r['behavior_loss']) and r['behavior_loss']>0 for r in ha))

    def test_bad_masks_and_selected_missing_labels_fail(self):
        arrays=[np.ones((5,5),np.float32)]*2;cfg=Settings(epochs=1)
        with self.assertRaises(ValueError):train(arrays,cfg,11,np.ones((2,3)),label_mask=np.array([False,False]))
        with self.assertRaises(ValueError):train(arrays,cfg,11,np.full((2,3),np.nan),label_mask=np.array([True,False]))

    def test_only_canonical_reports_enter_training_and_scaling(self):
        with tempfile.TemporaryDirectory() as folder:
            p=make(Path(folder)/'tables');c=load_cohort(p,'22',False);r=load_cohort(p,'11',False)
            y=align_reports(c,r)
            self.assertEqual(np.isfinite(y).all(1).sum(),len(r.meta))
            # The synthetic full meta has labels on EVERY row, but the three
            # noncanonical rows must remain unlabelled in this experiment.
            self.assertEqual(np.isnan(y).all(1).sum(),3)
            idx=np.flatnonzero(~c.meta.Pid.eq('1'));s,z,mask=training_reports(y,idx)
            np.testing.assert_array_equal(s.mean_,y[idx][mask].mean(0))
            self.assertTrue(np.isnan(z[~mask]).all())
            c.meta[TARGETS]=999
            np.testing.assert_array_equal(y,align_reports(c,r))
            r.times[0]=r.times[0]+1
            with self.assertRaisesRegex(ValueError,'timestamps differ'):align_reports(c,r)

    def test_readout_uses_the_returned_state_prediction_and_original_scale(self):
        from sklearn.preprocessing import StandardScaler
        s=StandardScaler().fit(np.array([[1,1,1],[5,3,3]],float))
        ident=dict(cohort='22',Pid='1',Class_id='C0',seed=11,validation_scope='held_out_session_prefix_to_masked_suffix')
        common=dict(prediction_standardized=[0,0,0]);personal=dict(prediction_standardized=[1,1,1])
        rows=report_record(ident,[5,3,3],common,personal,common,s,0,1)
        self.assertTrue(all(r['individual_squared_error']==0 for r in rows))
        self.assertEqual([r['common_prediction'] for r in rows],[3,2,2])


class CrossFittedChainTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.root=Path(cls.temp.name)
        tables=make(cls.root/'tables');cls.c=load_cohort(tables,'22',False);cls.r=load_cohort(tables,'11',False)
        # Preserve a true gap through shared training, calibration and scoring.
        for cohort in [cls.c,cls.r]:
            i=int(cohort.meta.index[cohort.meta.Class_id.eq('C0')][0])
            cohort.times[i]=np.r_[np.arange(4),np.arange(49,57)]
        cls.cfg=Settings(epochs=1,er_steps=2,seeds=(11,),bootstrap_reps=20,log_precision_grid=(-1.,0.,1.))
        validate(cls.c,cls.cfg,cls.root/'base',report_cohort=cls.r)
        cls.pred=pd.read_csv(cls.root/'base/chain_predictions.csv',dtype={'Pid':str,'Class_id':str})
        cls.phys=pd.read_csv(cls.root/'base/parameter_validation.csv',dtype={'Pid':str,'Class_id':str})
        cls.audit=json.loads((cls.root/'base/validation_audit.json').read_text())

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def test_held_out_person_reports_change_only_scores_not_model_rho_or_predictions(self):
        r=copy.deepcopy(self.r);r.meta.loc[r.meta.Pid.eq('1'),TARGETS]=[1,1,1]
        validate(self.c,self.cfg,self.root/'poison',report_cohort=r)
        p=pd.read_csv(self.root/'poison/chain_predictions.csv',dtype={'Pid':str,'Class_id':str})
        cols=['Class_id','target','common_prediction','individual_prediction','unit_prediction',
              'common_log_precision','individual_log_precision','training_mean_prediction']
        a=self.pred[self.pred.Pid.eq('1')][cols].reset_index(drop=True)
        b=p[p.Pid.eq('1')][cols].reset_index(drop=True)
        pd.testing.assert_frame_equal(a,b)
        for scope in ['base','poison']:
            ckpt=torch.load(self.root/f'{scope}/backbone_pid_1_seed_11.pt',weights_only=True)
            if scope=='base':original=ckpt
            else:
                for key in original['state_dict']:
                    torch.testing.assert_close(original['state_dict'][key],ckpt['state_dict'][key],rtol=0,atol=0)

    def test_backbone_and_both_scalers_exclude_target_person(self):
        y=align_reports(self.c,self.r)
        for pid in self.c.meta.Pid.unique():
            ckpt=torch.load(self.root/f'base/backbone_pid_{pid}_seed_11.pt',weights_only=True)
            self.assertTrue(all(k['Pid']!=pid for k in ckpt['training_keys']))
            self.assertTrue(all(k['Pid']!=pid for k in ckpt['report_training_keys']))
            indices=np.flatnonzero(~self.c.meta.Pid.eq(pid));valid=np.isfinite(y[indices]).all(1)
            np.testing.assert_allclose(ckpt['target_scaler_mean'],y[indices][valid].mean(0),rtol=0,atol=0)
            np.testing.assert_allclose(ckpt['scaler_mean'],np.concatenate(self.c.subset(indices)).mean(0,dtype=float),rtol=0,atol=0)

    def test_unlabelled_other_session_can_calibrate_a_report_linked_test(self):
        r=next(r for r in self.audit if r['Class_id']=='C2')
        self.assertEqual(json.loads(r['calibration_sessions']),['C3'])
        self.assertEqual(r['validation_scope'],'held_out_session_prefix_to_masked_suffix')
        self.assertTrue(self.pred.Class_id.eq('C2').any())
        self.assertFalse(self.pred.Class_id.eq('C3').any())

    def test_equal_precisions_give_identical_report_and_physiology_estimates(self):
        p=self.pred[self.pred.common_log_precision.eq(self.pred.individual_log_precision)]
        self.assertGreater(len(p),0)
        np.testing.assert_array_equal(p.common_prediction,p.individual_prediction)
        f=self.phys[self.phys.log_precision.eq(self.phys.pooled_log_precision)]
        np.testing.assert_array_equal(f.population_MSE,f.individual_MSE)

    def test_report_and_physiology_share_frozen_inference_and_never_use_test_labels(self):
        for r in self.audit:
            self.assertTrue(r['report_training_excludes_target_person'])
            self.assertTrue(r['fixed_backbone_for_common_and_individual'])
            self.assertTrue(r['report_and_physiology_share_inference'])
            self.assertFalse(r['target_report_used_for_training'])
            self.assertFalse(r['target_report_used_for_rho_selection'])
            self.assertFalse(r['target_report_used_for_A'])
        # Read the checkpoint, independently repeat one condition, and compare
        # both its hidden-P MSE and its report output to the exported records.
        pid='1';row=self.c.meta.index[self.c.meta.Class_id.eq('C0')][0]
        ckpt=torch.load(self.root/'base/backbone_pid_1_seed_11.pt',weights_only=True)
        model=FiveArrowPVRNN(self.cfg).eval();model.load_state_dict(ckpt['state_dict'])
        from sklearn.preprocessing import StandardScaler
        scaler=StandardScaler();scaler.mean_=np.asarray(ckpt['scaler_mean'])
        scaler.scale_=np.asarray(ckpt['scaler_scale']);scaler.n_features_in_=5
        array=scaler.transform(self.c.arrays[row]).astype(np.float32)
        f=self.phys[self.phys.Class_id.eq('C0')].iloc[0]
        result=score_hidden_physiology(model,array,self.cfg,f.log_precision,int(f.calibration_prefix_bins),
            times=self.c.times[row],return_prediction=True)
        self.assertAlmostEqual(result['MSE_physiology'],f.individual_MSE,places=7)
        yp=np.asarray(result['prediction_standardized'])*ckpt['target_scaler_scale']+ckpt['target_scaler_mean']
        p=self.pred[self.pred.Class_id.eq('C0')].set_index('target').reindex(TARGETS)
        np.testing.assert_allclose(p.individual_prediction,yp,rtol=1e-7,atol=1e-7)

    def test_summary_and_coverage_have_exact_sessions_and_no_fake_reports(self):
        coverage=pd.read_csv(self.root/'base/chain_report_coverage.csv')
        self.assertEqual(len(coverage),len(self.c.meta))
        self.assertEqual((coverage.status=='scored').sum(),len(self.r.meta))
        self.assertEqual(len(self.pred),3*len(self.r.meta))
        joint=pd.read_csv(self.root/'base/chain_joint_summary.csv')
        for _,g in joint.groupby('validation_scope'):
            self.assertEqual(g.n_sessions.nunique(),1)
            self.assertEqual(g.n_participants.nunique(),1)


class SummaryTests(unittest.TestCase):
    def test_recovery_includes_off_grid_truths_and_uses_readout_training_protocol(self):
        with tempfile.TemporaryDirectory() as folder:
            p=make(Path(folder)/'tables');c=load_cohort(p,'22',False);r=load_cohort(p,'11',False)
            cfg=Settings(epochs=1,er_steps=1,seeds=(11,),recovery_reps=1,log_precision_grid=(-1.,0.,1.))
            rows=recovery(c,cfg,Path(folder)/'recovery',report_cohort=r)
            self.assertEqual(set(rows.true_log_precision),{-1.,-.5,0.,.5,1.})
            self.assertEqual(int((~rows.true_on_estimation_grid).sum()),2)
            info=json.loads((Path(folder)/'recovery/recovery_summary.json').read_text())
            self.assertTrue(info['shared_training_uses_available_reports'])
            self.assertEqual(info['off_grid_n_simulations'],2)
            self.assertFalse(info['automatic_validity_claim'])

    def test_paired_metrics_bootstrap_and_matched_joint_subset(self):
        phys=[];reports=[];scope='held_out_session_prefix_to_masked_suffix'
        for seed in [11,23]:
            for pid,sid in [('1','A'),('2','B'),('3','unlabelled')]:
                common,individual=(100.,0.) if pid=='3' else (4.,1.)
                ident=dict(cohort='22',Pid=pid,Class_id=sid,seed=seed,validation_scope=scope)
                phys.append(dict(**ident,status='completed',population_MSE=common,individual_MSE=individual))
                if pid!='3':
                    reports.append(dict(**ident,target='Valence',observed=3.,common_prediction=1.,individual_prediction=2.,
                                        common_squared_error=4.,individual_squared_error=1.))
        with tempfile.TemporaryDirectory() as folder:
            summarize_chain(pd.DataFrame(phys),pd.DataFrame(reports),Settings(bootstrap_reps=30),folder)
            j=pd.read_csv(Path(folder)/'chain_joint_summary.csv').set_index('target')
            self.assertEqual(j.loc['Physiology','n_sessions'],2)
            self.assertAlmostEqual(j.loc['Physiology','gain_pct'],75.)
            self.assertAlmostEqual(j.loc['Valence','gain_pct'],50.)
            self.assertAlmostEqual(j.loc['Valence','gain_ci95_low'],50.)
            self.assertAlmostEqual(j.loc['Valence','gain_ci95_high'],50.)


if __name__=='__main__':unittest.main()
