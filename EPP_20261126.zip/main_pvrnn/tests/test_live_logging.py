"""Exercise real worker output, heartbeat and interruption cleanup."""
import contextlib
import importlib.util
import io
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('indoor_launcher',ROOT/'run_indoor_context.py')
launcher=importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)

class LiveLoggingTests(unittest.TestCase):
    def test_live_output_and_quiet_heartbeat_are_logged(self):
        with tempfile.TemporaryDirectory() as folder:
            log=Path(folder)/'worker.log';console=io.StringIO()
            cmd=[sys.executable,'-u','-c',"import time; print('ready',flush=True); time.sleep(.2); print('finished',flush=True)"]
            with contextlib.redirect_stdout(console):
                rc=launcher.run_logged_worker(cmd,log,ROOT,os.environ.copy(),'test',heartbeat_seconds=.04)
            self.assertEqual(rc,0)
            self.assertIn('ready',console.getvalue())
            self.assertIn('finished',log.read_text())
            self.assertIn('still running',console.getvalue())

    def test_interrupt_stops_only_the_owned_worker(self):
        with tempfile.TemporaryDirectory() as folder:
            process_holder=[]
            original=launcher.subprocess.Popen
            def start(*args,**kwargs):
                p=original(*args,**kwargs);process_holder.append(p);return p
            with patch.object(launcher.subprocess,'Popen',side_effect=start):
                with patch.object(launcher.queue.Queue,'get',side_effect=KeyboardInterrupt):
                    with self.assertRaises(KeyboardInterrupt):
                        launcher.run_logged_worker([sys.executable,'-u','-c','import time; time.sleep(20)'],
                            Path(folder)/'worker.log',ROOT,os.environ.copy(),'test')
            self.assertEqual(len(process_holder),1)
            self.assertIsNotNone(process_holder[0].poll())

if __name__=='__main__':unittest.main()
