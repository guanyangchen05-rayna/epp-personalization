"""Scientific invariants: v5 parity, gradient isolation, masks, identity and rho."""
from pathlib import Path
import importlib.util
import json
import sys
import tempfile
import unittest
import subprocess
import contextlib
import io
from unittest.mock import patch
import numpy as np
import pandas as pd
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))
from epp_v6.model import Settings,FiveArrowPVRNN,SimpleRNN,pad,objective,infer,train,diagnostics
from epp_v6.data import load_cohort,outer_folds,scaled_training,transform
from epp_v6.individual import profile_parameter,score_hidden_physiology,validate
from epp_v6.behavior import bootstrap
from make_epp_demo import make

torch.set_num_threads(1)


class ModelInvariants(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(51);self.cfg=Settings(epochs=2,er_steps=5,seeds=(11,),bootstrap_reps=20)
        self.model=FiveArrowPVRNN(self.cfg).eval()
        self.x,self.l=pad([np.ones((8,5),np.float32),np.zeros((5,5),np.float32)])

    def test_parameter_counts(self):
        self.assertEqual(sum(p.numel() for p in self.model.parameters()),668)
        self.assertEqual(sum(p.numel() for p in SimpleRNN().parameters()),643)

    def test_forward_and_loss_match_original_v5(self):
        spec=importlib.util.spec_from_file_location('v5parity',ROOT/'scripts/pvrnn_indoor_context.py')
        legacy=importlib.util.module_from_spec(spec);sys.modules[spec.name]=legacy;spec.loader.exec_module(legacy)
        old=legacy.FullPVRNN(input_dim=5,hidden_size=8,slow_hidden_size=4,latent_dim=3,
             slow_latent_dim=2,tau_fast=2.,tau_slow=5.,profile_dim=6,profile_hidden=4,
             dropout=.25,use_profile=False,output_dim=3).eval()
        self.model.load_state_dict(old.state_dict(),strict=True)
        A=torch.randn(2,8,10)*.1
        with torch.no_grad():
            yp,d=old(self.x,self.l,A,sample_latent=False)
            out=self.model(self.l,A)
        torch.testing.assert_close(out['prediction'],yp,rtol=1e-6,atol=1e-7)
        torch.testing.assert_close(out['representation'],d['representation'],rtol=1e-6,atol=1e-7)
        cfg=legacy.Config(table_dir=Path('.'),output_dir=Path('.'))
        torch.testing.assert_close(objective(out,self.x,self.l,self.cfg),legacy.pv_free_energy(d,cfg),
                                   rtol=1e-6,atol=1e-7)

    def test_noer_is_target_value_independent(self):
        A=torch.zeros(2,8,10)
        out1=self.model(self.l,A);out2=self.model(self.l,A)
        torch.testing.assert_close(out1['prediction'],out2['prediction'],rtol=0,atol=0)
        self.assertNotEqual(float(objective(out1,self.x,self.l,self.cfg).detach()),
                            float(objective(out2,self.x+20,self.l,self.cfg).detach()))

    def test_supervised_pass_cannot_update_A(self):
        A=torch.zeros(2,8,10,requires_grad=True)
        yp=self.model(self.l,A.detach())['prediction']
        yp.square().mean().backward()
        self.assertIsNone(A.grad)
        self.assertTrue(any(p.grad is not None for p in self.model.behavior_head.parameters()))

    def test_er_freezes_weights_and_keeps_best_unsupervised_iterate(self):
        before={k:v.detach().clone() for k,v in self.model.state_dict().items()}
        flags=[p.requires_grad for p in self.model.parameters()];was=self.model.training
        A0=torch.zeros(2,8,10)
        start=float(objective(self.model(self.l,A0),self.x,self.l,self.cfg).detach())
        out,A,d=infer(self.model,self.x,self.l,self.cfg)
        self.assertLessEqual(d['objective'],start+1e-6)
        self.assertGreater(A.abs().sum().item(),0)
        for k,v in self.model.state_dict().items():torch.testing.assert_close(v,before[k],rtol=0,atol=0)
        self.assertEqual(flags,[p.requires_grad for p in self.model.parameters()])
        self.assertEqual(was,self.model.training)

    def test_masked_physiology_cannot_influence_inference(self):
        mask=torch.zeros_like(self.x,dtype=torch.bool);mask[:,:,:2]=True
        poisoned=self.x.clone();poisoned[:,:,2:]=float('nan')
        _,A1,d1=infer(self.model,self.x,self.l,self.cfg,mask)
        _,A2,d2=infer(self.model,poisoned,self.l,self.cfg,mask)
        torch.testing.assert_close(A1,A2,rtol=0,atol=0)
        self.assertEqual(d1,d2)

    def test_er_restores_flags_on_error(self):
        self.model.train();flags=[p.requires_grad for p in self.model.parameters()]
        with self.assertRaises(ValueError):infer(self.model,self.x,self.l,self.cfg,torch.zeros_like(self.x,dtype=torch.bool))
        self.assertTrue(self.model.training)
        self.assertEqual(flags,[p.requires_grad for p in self.model.parameters()])

    def test_padding_does_not_change_objective_or_representation(self):
        A=torch.zeros(1,8,10);l=torch.tensor([5]);x=torch.ones(1,8,5)
        out=self.model(l,A);loss=objective(out,x,l,self.cfg)
        short=self.model(l,A[:,:5]);loss2=objective(short,x[:,:5],l,self.cfg)
        torch.testing.assert_close(out['prediction'],short['prediction'])
        torch.testing.assert_close(loss,loss2)
        x[:,5:]=float('nan')
        torch.testing.assert_close(objective(out,x,l,self.cfg),loss)

    def test_two_reconstruction_groups_equal_five_channel_mean(self):
        out=self.model(self.l,torch.zeros(2,8,10));d=diagnostics(out,self.x,self.l)
        self.assertAlmostEqual(d['MSE_all'],.4*d['MSE_environment']+.6*d['MSE_physiology'],places=6)

    def test_loss_includes_precision_normalizer(self):
        out=self.model(self.l,torch.zeros(2,8,10))
        x=out['reconstruction'].detach().clone()+1
        # Squared residual=1: normalized Gaussian residual loss minimized at rho=0.
        z=float(objective(out,x,self.l,self.cfg,log_precision=0).detach())
        self.assertGreater(float(objective(out,x,self.l,self.cfg,log_precision=-1).detach()),z)
        self.assertGreater(float(objective(out,x,self.l,self.cfg,log_precision=1).detach()),z)


class DataInvariants(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=make(Path(self.tmp.name)/'tables')
    def tearDown(self):self.tmp.cleanup()

    def test_exact_cohort_and_minute_windows(self):
        c=load_cohort(self.path,'22',False)
        self.assertEqual(len(c.meta),8);self.assertEqual(c.meta.Pid.nunique(),5)
        self.assertTrue(all(a.shape==(12,5) for a in c.arrays))
        b=load_cohort(self.path,'11',False)
        self.assertEqual(len(b.meta),5)
        with self.assertRaises((ValueError,FileNotFoundError)):load_cohort(self.path,'11',True)

    def test_duplicates_rejected_instead_of_inflating_seconds(self):
        p=self.path/'envphys_temporal_1s.csv';d=pd.read_csv(p);pd.concat([d,d.iloc[:1]]).to_csv(p,index=False)
        with self.assertRaisesRegex(ValueError,'Duplicate'):load_cohort(self.path,'22',False)

    def test_environment_exposure_scope_rejected(self):
        p=self.path/'envphys_session_analysis.csv';d=pd.read_csv(p);d['EnvironmentScope']='room';d.to_csv(p,index=False)
        with self.assertRaises(ValueError):load_cohort(self.path,'22',False)

    def test_fold_isolation_and_training_only_scaling(self):
        c=load_cohort(self.path,'22',False)
        for group in ['Pid','EnvironmentDateKey']:
            for _,tr,te in outer_folds(c.meta,group):
                self.assertFalse(set(c.meta.iloc[tr][group]) & set(c.meta.iloc[te][group]))
                scaler,arrays=scaled_training(c,tr)
                torch.testing.assert_close(torch.tensor(scaler.mean_),torch.tensor(np.concatenate(c.subset(tr)).mean(0,dtype=float)))
                held=[v+100000 for v in c.subset(te)]
                transform(scaler,held)
                np.testing.assert_array_equal(scaler.mean_,np.concatenate(c.subset(tr)).mean(0,dtype=float))

    def test_frozen_QC_failure_is_not_silently_dropped(self):
        p=self.path/'behavior_session_analysis.csv';d=pd.read_csv(p);d.loc[0,'EDA_QC_pass']=False;d.to_csv(p,index=False)
        with self.assertRaises(ValueError):load_cohort(self.path,'11',False)

    def test_missing_22_time_series_does_not_fallback_to_session_means(self):
        (self.path/'envphys_temporal_1s.csv').unlink()
        with self.assertRaises(FileNotFoundError):load_cohort(self.path,'22',False)

    def test_additional_export_preserves_all_four_v5_canonical_tables(self):
        from prepare_indoor_context import prepare
        import preprocess_indoor_context as v5
        from export_envphys_temporal_v6 import export
        base=Path(self.tmp.name);raw=base/'raw'
        for folder in ['Participant_class_info','Longitudinal','Survey']:(raw/folder).mkdir(parents=True)
        pd.DataFrame({'Class_id':[1,2],'Room':['R1','R2'],'Date':[20191028]*2,
                      'Start_time':['09:00']*2,'Finish_time':['09:20']*2}).to_csv(raw/'Participant_class_info/Class_table.csv',index=False)
        native=pd.date_range('2019-10-28 08:55',periods=7,freq='5min')
        for name,t,c in [('A',20.,600.),('B',24.,1000.)]:
            pd.DataFrame({'Timestamp':native,'IndoorTemperature':t,'IndoorCO2':c,
                          'UsabilityMask':True,'Occupied':0}).to_csv(raw/f'Longitudinal/{name}.csv',index=False)
        sec=pd.date_range('2019-10-28 09:00',periods=1201,freq='s')
        for cid,pid in [(1,1),(2,2)]:
            dest=raw/f'Class_wearable_data/{cid}/{pid}';dest.mkdir(parents=True)
            for name,v in [('EDA',1.),('HR',70.),('TEMP',32.)]:
                pd.DataFrame({'Date':sec,name:v}).to_csv(dest/f'{name}.csv',index=False)
        pd.DataFrame([dict(Pid=1,Time='28/10/2019 09:21',Engage_1=4,Engage_2=2,
                         Engage_3=4,Engage_4=2,Engage_5=4,Arousal=2,Valence=3)]).to_csv(raw/'Survey/Student_survey.csv',index=False)
        with contextlib.redirect_stdout(io.StringIO()):
            prepare(raw,base/'prepared',minimum_sensors=2)
            v5.preprocess(raw,base/'old',base/'prepared')
            export(raw,base/'prepared',base/'new')
        for name in ['session_master.csv','envphys_session_analysis.csv','behavior_session_analysis.csv','behavior_temporal_1s.csv']:
            self.assertEqual((base/'old'/name).read_bytes(),(base/'new'/name).read_bytes(),name)
        c=load_cohort(base/'new','22',False)
        self.assertEqual(len(c.meta),2)
        self.assertEqual(sum(len(a) for a in c.arrays),40)


class ParameterInvariants(unittest.TestCase):
    def test_bootstrap_keeps_paired_predictions_and_cluster_unit(self):
        rows=[]
        for seed in (11,23):
            for i in range(4):
                for mode,offset in [('NO_ER',1.),('ERROR_REGRESSION',.5),('SIMPLE_RNN',.75)]:
                    rows.append(dict(protocol='PARTICIPANT_LOO',Pid=str(i//2),Class_id=str(i),
                        EnvironmentDateKey='DATE__2020-01-01',target='Valence',mode=mode,seed=seed,
                        observed=float(i),prediction=float(i)+offset))
        out=bootstrap(pd.DataFrame(rows),Settings(bootstrap_reps=20))
        self.assertEqual(len(out),2)
        r=out[out.comparison=='ER_vs_NO_ER'].iloc[0]
        self.assertAlmostEqual(r.gain_pct,50.)
        self.assertAlmostEqual(r.ci95_low,50.)
        self.assertEqual(r.n_clusters,2)

    def test_known_noise_parameter_recovery_with_fixed_mean(self):
        class Zero(torch.nn.Module):
            adaptive_width=5
            def forward(self,l,A,sample=False):
                z=A[:,:,:5]*0
                return {'reconstruction':z,'kl_fast':z[:,:,0],'kl_slow':z[:,:,0],
                        'prediction':z[:,0,:3]}
        rng=np.random.default_rng(12);rho=1.
        a=rng.normal(size=(30,5)).astype(np.float32)
        a[:,2:]*=np.sqrt(np.exp(-rho)/np.mean(a[:,2:]**2))
        cfg=Settings(er_steps=2,seeds=(11,),log_precision_grid=(-1.,0.,1.))
        best,curve=profile_parameter(Zero(),[a],cfg)
        self.assertEqual(best['log_precision'],rho)
        self.assertFalse(best['confidence_interval_available'])

    def test_independent_scoring_never_exposes_hidden_physiology(self):
        cfg=Settings(er_steps=2);model=FiveArrowPVRNN(cfg).eval()
        a=np.ones((12,5),dtype=np.float32)
        original=infer;seen=[]
        def spy(m,x,l,c,observed=None,**kw):
            seen.append(observed.clone());return original(m,x,l,c,observed,**kw)
        with patch('epp_v6.individual.infer',side_effect=spy):
            score_hidden_physiology(model,a,cfg,0.)
            score_hidden_physiology(model,a,cfg,0.,6)
        self.assertFalse(seen[0][:,:,2:].any())
        self.assertFalse(seen[1][:,6:,2:].any())
        self.assertTrue(seen[1][:,:6,2:].all())

    def test_behavior_labels_cannot_change_individual_validation(self):
        with tempfile.TemporaryDirectory() as folder:
            tables=make(Path(folder)/'tables');c=load_cohort(tables,'11',False)
            cfg=Settings(epochs=1,er_steps=1,seeds=(11,),log_precision_grid=(-1.,0.,1.))
            first=validate(c,cfg,Path(folder)/'a')
            c.meta[['EngageScore','Arousal','Valence']]=999
            second=validate(c,cfg,Path(folder)/'b')
            pd.testing.assert_frame_equal(first,second)
            audit=json.loads((Path(folder)/'a/validation_audit.json').read_text())
            self.assertTrue(all(r['backbone_excludes_target_person'] for r in audit))


if __name__=='__main__':unittest.main()
