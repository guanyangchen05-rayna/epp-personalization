"""Room identity cannot be established by resolving an occupancy tie arbitrarily."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
try:
    import pandas as pd
except ImportError:
    pd=None

ROOT=Path(__file__).resolve().parents[1]
if pd is not None:
    spec=importlib.util.spec_from_file_location('mapping',ROOT/'scripts/prepare_classroom_mapping.py')
    mapping=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mapping)

@unittest.skipIf(pd is None,'Install numpy/pandas')
class MappingTests(unittest.TestCase):
    def setUp(self):
        self.classes=pd.DataFrame({'Class_id':[1,2,3],'Room':['R1','R2','Out'],
            'start_dt':pd.to_datetime(['2019-10-28 09:00']*3),
            'end_dt':pd.to_datetime(['2019-10-28 09:10']*3)})
        index=pd.date_range('2019-10-28 09:00',periods=3,freq='5min')
        self.env={s:pd.DataFrame({'Occupied':[1.,1.,1.]},index=index) for s in ('19','20')}

    def test_documented_does_not_turn_occupancy_ties_into_room_links(self):
        output,_,_,audit=mapping.build(self.classes,self.env)
        self.assertEqual(output.Matched_CSV.notna().sum(),0)
        self.assertEqual(audit.n_top_occupancy_ties.tolist(),[2,2,2])
        self.assertEqual(output.MappingStatus.iloc[-1],'OUTDOOR_NO_INDOOR_ASSIGNMENT')

    def test_historical_mode_preserves_old_tie_order_and_outdoor_behavior(self):
        output,_,_,audit=mapping.build(self.classes,self.env,'historical')
        self.assertEqual(output.Matched_CSV.tolist(),['19','19','19'])
        self.assertTrue(output.MappingStatus.eq('HISTORICAL_OCCUPANCY_TIE').all())
        self.assertEqual(audit.top_occupancy_candidates.iloc[0],'19|20')

    def test_explicit_links_stay_room_specific_despite_equal_occupancy(self):
        output,*_=mapping.build(self.classes,self.env,'documented',{'R1':('19','fixture'),'R2':('20','fixture')})
        self.assertEqual(output.Matched_CSV.iloc[:2].tolist(),['19','20'])
        self.assertTrue(output.Confidence.isna().all())
        self.assertTrue(pd.isna(output.Matched_CSV.iloc[-1]))

    def test_no_date_overlap_stays_unmapped(self):
        classes=self.classes.copy()
        classes[['start_dt','end_dt']]-=pd.Timedelta(days=50)
        output,*_=mapping.build(classes,self.env,'historical')
        self.assertEqual(output.Matched_CSV.notna().sum(),0)
        self.assertTrue(output.Confidence.eq(-0.1).all())

    def test_endpoints_are_explicit_and_differ_by_mode(self):
        env={k:v.copy() for k,v in self.env.items()}
        env['19'].iloc[-1,0]=0
        _,hist,*_=mapping.build(self.classes,env,'historical')
        _,doc,*_=mapping.build(self.classes,env,'documented')
        h=hist[(hist.Class_id==1)&(hist.SensorCSV=='19')].iloc[0]
        d=doc[(doc.Class_id==1)&(doc.SensorCSV=='19')].iloc[0]
        self.assertAlmostEqual(h.occupancy_mean,2/3)
        self.assertAlmostEqual(d.occupancy_mean,1.)

    def test_unsupported_and_colliding_crosswalks_are_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'links.csv'
            pd.DataFrame({'Room':['R1','R2'],'SensorCSV':['19','19'],'Source':['fixture']*2,
                          'Status':['documented']*2}).to_csv(path,index=False)
            with self.assertRaises(ValueError):mapping.load_crosswalk(path,self.env)
            pd.DataFrame({'Room':['R1'],'SensorCSV':['19'],'Source':[''],
                          'Status':['documented']}).to_csv(path,index=False)
            with self.assertRaises(ValueError):mapping.load_crosswalk(path,self.env)

    def test_occupied_is_read_by_name_and_time_only_release_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'19.csv'
            pd.DataFrame({'Timestamp':['2019-10-28 09:00:00'],'Hour':[9],
                          'IndoorCO2':[500],'Occupied':[1],'IndoorTemperature':[20]}).to_csv(path,index=False)
            data,*_=mapping.load_environment(folder)
            self.assertEqual(data['19'].Occupied.iloc[0],1)
            pd.DataFrame({'Time':['09:00:00'],'Day':[1],'IndoorCO2':[500],
                          'Occupied':[1],'IndoorTemperature':[20]}).to_csv(path,index=False)
            with self.assertRaises(ValueError):mapping.load_environment(folder)

if __name__=='__main__':
    unittest.main()
