"""Protect the substantive distinctions and boundary diagnostics in v0.5."""
import importlib.util,sys,unittest,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT))

@unittest.skipUnless(importlib.util.find_spec('statsmodels'),'statsmodels unavailable')
class HeterogeneityTests(unittest.TestCase):
    def test_pv_full_run_precedes_smoke_and_archived_copies(self):
        from heterogeneity_figures import select_pv_directory
        with tempfile.TemporaryDirectory() as f:
            root=Path(f);full=root/'pvrnn/02_pv_rnn_v3_model'
            for p in [full,root/'smoke/pvrnn/02_pv_rnn_v3_model',root/'backup/pv']:
                p.mkdir(parents=True);(p/'FINAL_pv_rnn_adaptation_summary_v3.csv').write_text('full or smoke fixture')
            self.assertEqual(select_pv_directory(root),full)
    def test_pv_fallback_excludes_smoke_without_picking_arbitrary_full_copy(self):
        from heterogeneity_figures import select_pv_directory
        with tempfile.TemporaryDirectory() as f:
            root=Path(f);full=root/'custom/full'
            for p in [full,root/'smoke/pv']:
                p.mkdir(parents=True);(p/'FINAL_pv_rnn_adaptation_summary_v3.csv').write_text('fixture')
            self.assertEqual(select_pv_directory(root),full)
            second=root/'other/full';second.mkdir(parents=True);(second/'FINAL_pv_rnn_adaptation_summary_v3.csv').write_text('fixture')
            with self.assertRaisesRegex(ValueError,'--pv-dir'):select_pv_directory(root)
            self.assertEqual(select_pv_directory(root,second),second)
    def test_pv_smoke_only_is_not_used_and_bad_explicit_path_errors(self):
        from heterogeneity_figures import select_pv_directory
        with tempfile.TemporaryDirectory() as f:
            root=Path(f);smoke=root/'smoke/pv';smoke.mkdir(parents=True)
            (smoke/'FINAL_pv_rnn_adaptation_summary_v3.csv').write_text('fixture')
            self.assertIsNone(select_pv_directory(root))
            with self.assertRaises(FileNotFoundError):select_pv_directory(root,root/'missing')
    def test_boundary_detector_is_relative_and_names_nuisance(self):
        from heterogeneity_models import near_zero,NUISANCE_COMPONENTS
        x=near_zero({'Date':1e-11,'ContextWindow':.3,'PidTempSlope':1e-11},.5)
        self.assertEqual(set(x),{'Date','PidTempSlope'})
        self.assertEqual(set(x)&NUISANCE_COMPONENTS,{'Date'})
    def test_finite_interval_is_separate_from_inference_diagnostics(self):
        from heterogeneity_models import fixed_rows
        r=SimpleNamespace(fe_params=pd.Series({'Temperature_z':.3}),bse_fe=pd.Series({'Temperature_z':.05}))
        m=dict(model='context_window',outcome='SkinTEMP',slope=False,inference_flags=['variance_boundary'],dropped_components='')
        row=fixed_rows(r,m,'original')[0]
        self.assertTrue(row['numerical_interval_available']);self.assertEqual(row['wald_status'],'diagnostic_flag')
        r.bse_fe.iloc[0]=np.nan
        self.assertEqual(fixed_rows(r,m,'original')[0]['wald_status'],'unavailable')
    def test_companion_fdr_retains_planned_missing_outcomes(self):
        from heterogeneity_models import adjust_environment_families
        x=pd.DataFrame([dict(model='context_window',slope=False,variant='boundary_companion',predictor='Temperature_z',p=.01),
                        dict(model='context_window',slope=False,variant='boundary_companion',predictor='CO2_z',p=np.nan)])
        y=adjust_environment_families(x)
        self.assertEqual(y.FDR_family_size.iloc[0],6);self.assertAlmostEqual(y.q_BH_FDR.iloc[0],.06)
        self.assertTrue(pd.isna(y.q_BH_FDR.iloc[1]))
    def test_baseline_contrast_removes_only_participant_and_uses_ml(self):
        from heterogeneity_models import compare
        data=pd.DataFrame({'Pid':['1','2'],'EnvironmentDateKey':['a','b'],'ContextWindowKey':['x','y']})
        meta=dict(AIC=10.,llf=-1.,inference_flags=[])
        with patch('heterogeneity_models.fit',return_value=(None,meta)) as f:
            row,_=compare(data,'HR','context_window','participant_intercept',full=(None,meta))
        self.assertEqual(f.call_args.kwargs['drop'],('PidIntercept',));self.assertFalse(f.call_args.kwargs['reml'])
        self.assertEqual(row['contrast'],'participant_intercept')
    def test_negative_nested_likelihood_is_flagged(self):
        from heterogeneity_models import compare
        data=pd.DataFrame({'Pid':['1','2'],'EnvironmentDateKey':['a','b'],'ContextWindowKey':['x','y']})
        full=dict(AIC=20.,llf=-8.,inference_flags=[]);null=dict(AIC=10.,llf=-4.,inference_flags=[])
        with patch('heterogeneity_models.fit',return_value=(None,null)):
            row,_=compare(data,'HR','context_window','temperature_slope',full=(None,full))
        self.assertFalse(row['nested_likelihood_order_valid'])
    def test_within_date_slope_support_uses_actual_slope_covariate(self):
        from heterogeneity_models import participant_rows
        key='PidTempSlope[C(Pid)[1]:Temperature_within_z]'
        r=SimpleNamespace(random_effects={1:pd.Series({key:.1})},random_effects_cov={1:pd.DataFrame([[.01]],index=[key],columns=[key])})
        d=pd.DataFrame({'Pid':['1','1'],'Temperature_mean':[20.,21.],'Temperature_within_z':[.1,.1],
                        'EnvironmentDateKey':['a','b']})
        m=dict(model='within_between_window_time',outcome='HR',variance_components={'PidTempSlope':.2},temperature_slope_predictor='Temperature_within_z')
        row=participant_rows(r,d,m,'original','PidTempSlope')[0]
        self.assertFalse(row['informs_repeated_measure_difference'])
    def test_flagged_forest_does_not_plot_wald_bar(self):
        from heterogeneity_figures import boundary_figures
        from revision_figures import style
        style();rows=[]
        for model in ['context_window','context_window_time']:
            for outcome in ['EDA','HR','SkinTEMP']:
                for predictor in ['Temperature_z','CO2_z']:
                    rows.append(dict(model=model,slope=False,outcome=outcome,predictor=predictor,variant='original',
                                     beta=.3,SE=.01,ci95_low=.28,ci95_high=.32,wald_status='diagnostic_flag'))
        with tempfile.TemporaryDirectory() as f:
            root=Path(f);pd.DataFrame(rows).to_csv(root/'heterogeneity_fixed_effects.csv',index=False)
            with patch('heterogeneity_figures.save') as saver:
                boundary_figures(root,root)
                self.assertEqual(saver.call_count,2)
                for call in saver.call_args_list:
                    fig=call.args[0]
                    self.assertTrue(all(len(ax.containers)==0 for ax in fig.axes))
                    import matplotlib.pyplot as plt
                    plt.close(fig)
    def test_pre_qc_sensitivity_retains_correct_threshold_cohorts(self):
        from test_revision import RevisionTests
        from heterogeneity_audit import sensitivity
        d=RevisionTests().fixture();d['EDA_zero_fraction']=0.
        d.loc[0,'EDA_zero_fraction']=1.;d.loc[1,'EDA_zero_fraction']=.9696
        d['EnvPhysReady_before_EDA_QC']=True;d.loc[[0,1],'EnvPhysReady']=False
        main=d.loc[d.EnvPhysReady].copy()
        def fake_compare(data,outcome,model,contrast):
            return dict(N_sessions=len(data),delta_AIC=-3.,nested_likelihood_order_valid=True,outcome=outcome),[]
        def fake_fit(data,outcome,model,reml=True):
            return None,dict(model=model,outcome=outcome,slope=False,variance_components={'PidIntercept':.2,'Date':.1,'ContextWindow':.1},
                             residual_variance=.6,inference_flags=[],near_zero_components=[])
        with tempfile.TemporaryDirectory() as f:
            root=Path(f);tables=root/'tables';out=root/'out';tables.mkdir();out.mkdir();d.to_csv(tables/'session_master.csv',index=False)
            with patch('heterogeneity_audit.compare',side_effect=fake_compare),patch('heterogeneity_audit.fit',side_effect=fake_fit):
                sensitivity(main,tables,out)
            x=pd.read_csv(out/'heterogeneity_baseline_sensitivity.csv')
            counts=x.groupby('scenario').N_sessions.first()
            self.assertEqual(counts['before_eda_screen'],60)
            self.assertEqual(counts['eda_zero_threshold_0.90'],58)
            self.assertEqual(counts['eda_zero_threshold_0.99'],59)
            with patch('heterogeneity_audit.compare',side_effect=fake_compare),patch('heterogeneity_audit.fit',side_effect=RuntimeError('REML failed')):
                sensitivity(main,tables,out)
            x=pd.read_csv(out/'heterogeneity_baseline_sensitivity.csv')
            self.assertFalse(x.duplicated(['scenario','outcome']).any())
            self.assertTrue(x.status.eq('passed').all())
            self.assertTrue(x.variance_status.eq('failed').all())
if __name__=='__main__':unittest.main()
