"""Elapsed-time regression tests; missing minutes never become observations."""
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))
from epp_v6.model import (Settings,FiveArrowPVRNN,SimpleRNN,pad,window_ids_tensor,
                          minute_gaps,infer,objective,train,train_simple)
from epp_v6.data import load_cohort
from epp_v6.individual import validate,score_hidden_physiology
from make_epp_demo import make

torch.set_num_threads(1)


class ElapsedTimeTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(14)
        self.cfg=Settings(epochs=2,er_steps=3,seeds=(11,),log_precision_grid=(-1.,0.,1.))
        self.model=FiveArrowPVRNN(self.cfg).eval()

    def test_contiguous_timestamps_preserve_exact_output_and_training(self):
        arrays=[np.ones((6,5),np.float32),np.zeros((4,5),np.float32)]
        x,l=pad(arrays);A=torch.randn(2,6,10)*.1
        ids=window_ids_tensor([np.arange(6)+30,np.arange(4)+7],l,6)
        old=self.model(l,A);new=self.model(l,A,window_ids=ids)
        for key in old:torch.testing.assert_close(old[key],new[key],rtol=0,atol=0)
        a,ha=train(arrays,self.cfg,11)
        b,hb=train(arrays,self.cfg,11,times=[np.arange(6)+30,np.arange(4)+7])
        self.assertEqual(ha,hb)
        for k in a.state_dict():torch.testing.assert_close(a.state_dict()[k],b.state_dict()[k],rtol=0,atol=0)

    def test_gap_matches_dense_reference_with_prior_at_missing_minutes(self):
        # Independent reference: a dense model with q explicitly set equal to
        # p at missing times. Priors/posteriors are NOT tied in the model.
        ids=np.array([10,11,15,17]);A=torch.randn(1,4,10)*.1
        sparse=self.model(torch.tensor([4]),A,window_ids=torch.tensor(ids[None,:]))
        positions=ids-ids[0];total=int(positions[-1])+1
        dense_A=torch.zeros(1,total,10);observed=dict(zip(positions,range(4)))
        rep=torch.zeros(1,12)
        for j in range(total):
            if j in observed:dense_A[:,j]=A[:,observed[j]]
            else:
                df,ds=rep[:,:8],rep[:,8:]
                mp,lp=self.model.split(self.model.prior_fast(rep))
                mq,lq=self.model.split(self.model.post_base_fast(rep))
                ms,ls=self.model.split(self.model.prior_slow(ds))
                qs,vs=self.model.split(self.model.post_base_slow(ds))
                dense_A[:,j]=torch.cat([mp-mq,lp-lq,ms-qs,ls-vs],-1).detach()
            dense=self.model(torch.tensor([j+1]),dense_A[:,:j+1])
            rep=dense['representation'].detach()
        torch.testing.assert_close(sparse['reconstruction'],dense['reconstruction'][:,positions],rtol=1e-6,atol=1e-7)
        torch.testing.assert_close(sparse['representation'],dense['representation'],rtol=1e-6,atol=1e-7)
        compressed=self.model(torch.tensor([4]),A)
        self.assertGreater((sparse['representation']-compressed['representation']).abs().max().item(),1e-5)

    def test_padding_and_batch_do_not_add_virtual_transitions(self):
        lengths=torch.tensor([4,2]);A=torch.randn(2,4,10)*.1
        times=[np.array([0,1,47,48]),np.array([100,103])]
        ids=window_ids_tensor(times,lengths,4)
        out=self.model(lengths,A,window_ids=ids)
        for i,n in enumerate(lengths.tolist()):
            one=self.model(torch.tensor([n]),A[i:i+1,:n],window_ids=torch.tensor(times[i][None,:]))
            torch.testing.assert_close(out['representation'][i],one['representation'][0],rtol=1e-6,atol=1e-7)
        self.assertEqual(int(minute_gaps(ids,lengths,4).sum()),47)

    def test_no_gap_observations_are_created_and_hidden_targets_cannot_leak(self):
        x,l=pad([np.ones((8,5),np.float32)])
        ids=window_ids_tensor([np.array([0,1,2,3,49,50,51,52])],l,8)
        mask=torch.zeros_like(x,dtype=torch.bool);mask[:,:,:2]=True;mask[:,:4,2:]=True
        poison=x.clone();poison[:,4:,2:]=float('nan')
        out,A,d=infer(self.model,x,l,self.cfg,mask,window_ids=ids)
        other,B,e=infer(self.model,poison,l,self.cfg,mask,window_ids=ids)
        self.assertEqual(out['reconstruction'].shape,x.shape)
        self.assertEqual(A.shape,(1,8,10))
        torch.testing.assert_close(A,B,rtol=0,atol=0);self.assertEqual(d,e)

    def test_long_gap_has_finite_training_and_reaches_parameters(self):
        arrays=[np.ones((8,5),np.float32),np.zeros((6,5),np.float32)]
        times=[np.array([0,1,2,48,49,50,51,52]),np.arange(6)]
        m,h=train(arrays,self.cfg,11,times=times)
        self.assertTrue(all(np.isfinite(r['free_energy']) for r in h))
        r=train_simple(arrays,np.zeros((2,3),np.float32),self.cfg,11,times=times)
        x,l=pad(arrays);ids=window_ids_tensor(times,l,8)
        self.assertTrue(torch.isfinite(r(x,l,window_ids=ids)).all())

    def test_simple_rnn_uses_state_only_steps_and_no_gap_path_is_exact(self):
        r=SimpleRNN().eval();x=torch.randn(1,3,5);l=torch.tensor([3])
        torch.testing.assert_close(r(x,l),r(x,l,window_ids=torch.tensor([[5,6,7]])),rtol=0,atol=0)
        sparse=r(x,l,window_ids=torch.tensor([[0,1,4]]))
        dense=torch.cat([x[:,:2],torch.zeros(1,2,5),x[:,2:]],1)
        torch.testing.assert_close(sparse,r(dense,torch.tensor([5])),rtol=1e-6,atol=1e-7)

    def test_invalid_minute_ids_are_rejected(self):
        for v in [np.array([0,0,2]),np.array([0.,1.,2.]),np.array([0,2,1]),np.array([-1,0,1])]:
            with self.assertRaises(ValueError):window_ids_tensor([v],torch.tensor([3]),3)

    def test_calibration_and_scoring_both_receive_original_minute_ids(self):
        with tempfile.TemporaryDirectory() as folder:
            c=load_cohort(make(Path(folder)/'tables'),'11',False)
            c.times[0]=np.r_[np.arange(4),np.arange(49,57)]
            import epp_v6.individual as ind
            actual=ind.profile_parameter;received=[]
            def spy(*args,**kw):
                received.extend(kw.get('times',[]));return actual(*args,**kw)
            cfg=Settings(epochs=1,er_steps=1,seeds=(11,),log_precision_grid=(-1.,0.,1.))
            with patch('epp_v6.individual.profile_parameter',side_effect=spy):
                rows=validate(c,cfg,Path(folder)/'out')
            self.assertTrue(any(np.array_equal(t,c.times[0]) for t in received))
            self.assertTrue(rows.scored_physiology_used_for_A.eq(False).all())
            import json
            audit=json.loads((Path(folder)/'out/validation_audit.json').read_text())
            record=next(r for r in audit if r['Class_id']=='C0')
            self.assertEqual(record['test_minute_ids'],c.times[0].tolist())
            self.assertTrue(record['elapsed_gaps_explicitly_modeled'])


if __name__=='__main__':unittest.main()
