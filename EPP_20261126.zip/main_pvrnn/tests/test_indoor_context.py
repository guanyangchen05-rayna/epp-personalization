"""Checks for source-quality filtering, fixed panels and date isolation."""
import ast
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from prepare_indoor_context import pool_environment, parse_usability
from indoor_context_checks import validate_context_table, validate_fold_coverage

class IndoorContextTests(unittest.TestCase):
    def classes(self):
        return pd.DataFrame({'Class_id':[1,2], 'Room':['R1','Out'],
                             'start_dt':pd.to_datetime(['2019-10-28 09:00','2019-10-28 09:00']),
                             'end_dt':pd.to_datetime(['2019-10-28 09:20','2019-10-28 09:20'])})
    def environment(self):
        idx=pd.date_range('2019-10-28 08:55',periods=7,freq='5min')
        return {name:pd.DataFrame({'IndoorTemperature':t,'IndoorCO2':c,
                                   'UsabilityMask':mask,'Occupied':0,
                                   'OutdoorTemperature':9999.,'OutdoorCO2':9999.},index=idx)
                for name,t,c,mask in [('A',20.,600.,True),('B',24.,1000.,True),('BAD',100.,9000.,False)]}

    def test_false_quality_and_outdoor_columns_never_enter_pool(self):
        out,pool,qc,summary=pool_environment(self.environment(),self.classes(),minimum_sensors=2)
        self.assertEqual(summary['fixed_panel'],['A','B'])
        self.assertTrue(pool.IndoorTemperature.eq(22.).all())
        self.assertTrue(pool.IndoorCO2.eq(800.).all())
        self.assertEqual(out.loc[0,'Matched_CSV'],'POOLED_INDOOR')
        self.assertTrue(pd.isna(out.loc[1,'Matched_CSV']))
        self.assertFalse(summary['room_mapping_used'])
        # Occupancy is deliberately zero: no occupancy filter may select inputs.
        self.assertEqual(summary['panel_size'],2)

    def test_mean_sensitivity_uses_identical_panel_and_different_aggregation(self):
        env=self.environment()
        env['C']=env['A'].assign(IndoorTemperature=40.,IndoorCO2=1400.)
        _,median,_,m=pool_environment(env,self.classes(),minimum_sensors=2,aggregation='median')
        _,mean,_,a=pool_environment(env,self.classes(),minimum_sensors=2,aggregation='mean')
        self.assertEqual(m['fixed_panel'],a['fixed_panel'])
        self.assertTrue(median.IndoorTemperature.eq(24.).all())
        self.assertTrue(mean.IndoorTemperature.eq(28.).all())

    def test_panel_does_not_change_to_hide_a_missing_sensor(self):
        env=self.environment();env['B'].loc[env['B'].index[2],'UsabilityMask']=False
        with self.assertRaisesRegex(ValueError,'Only 1 sensors'):
            pool_environment(env,self.classes(),minimum_sensors=2)

    def test_unusable_native_values_remain_missing_outside_selected_context(self):
        env=self.environment()
        for d in env.values():d.loc[d.index[-1],'UsabilityMask']=False
        _,pool,_,_=pool_environment(env,self.classes(),minimum_sensors=2)
        self.assertTrue(pd.isna(pool.iloc[-1].IndoorTemperature))
        self.assertEqual(pool.iloc[-1].n_valid_panel_sensors,0)

    def test_invalid_quality_values_are_not_truthy_strings(self):
        with self.assertRaises(ValueError):parse_usability(pd.Series(['False','unknown']),'A')
        self.assertEqual(parse_usability(pd.Series(['False','True',None]),'A').tolist(),[False,True,False])

    def test_context_and_date_fold_checks(self):
        d=pd.DataFrame({'Pid':['1','2','1','2'], 'EnvironmentScope':'school_indoor_context',
                        'ClassStart':['2019-10-28 09:00']*2+['2019-10-29 09:00']*2,
                        'EnvironmentDateKey':['DATE__2019-10-28']*2+['DATE__2019-10-29']*2,'Room':'R1'})
        validate_context_table(d)
        good=[{'train_idx':[2,3],'test_idx':[0,1]},{'train_idx':[0,1],'test_idx':[2,3]}]
        validate_fold_coverage(good,d,'DATE_LOO')
        with self.assertRaises(ValueError):
            validate_fold_coverage([{'train_idx':[1,3],'test_idx':[0,2]}],d,'DATE_LOO')
        with self.assertRaises(ValueError):validate_fold_coverage(good[:1],d,'DATE_LOO')

    def test_pvrnn_architecture_and_training_numerics_are_preserved(self):
        text=(ROOT/'scripts/pvrnn_frozen_v3.py').read_text()
        for a,b in [('EPISODE','DATE'),('Episode','Date'),('episode','date')]:text=text.replace(a,b)
        old=ast.parse(text)
        new=ast.parse((ROOT/'scripts/pvrnn_indoor_context.py').read_text())
        names=['Config','FullPVRNN','prepare_fold','train_one_model','predict_before_and_after_er','build_session_sequences']
        oldnodes={n.name:n for n in old.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
        newnodes={n.name:n for n in new.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
        checked=0
        for name in names:
            if name in oldnodes:
                self.assertEqual(ast.dump(oldnodes[name]),ast.dump(newnodes[name]),name)
                checked+=1
        self.assertEqual(checked,6)

    def test_actual_date_folds_hold_out_every_session_of_the_day(self):
        tree=ast.parse((ROOT/'scripts/pvrnn_indoor_context.py').read_text())
        node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_date_folds')
        ns={'pd':pd}
        exec(compile(ast.Module(body=[node],type_ignores=[]),'<date folds>','exec'),ns)
        d=pd.DataFrame({'Pid':[str(i%4) for i in range(12)],
                        'EnvironmentDateKey':['DATE__2019-10-28']*4+['DATE__2019-10-29']*4+['DATE__2019-10-30']*4})
        folds=ns['build_date_folds'](d)
        self.assertEqual(len(folds),3)
        validate_fold_coverage(folds,d,'DATE_LOO')
        self.assertTrue(all(len(f['test_idx'])==4 for f in folds))

    def test_integrated_original_dataset_entry_preserves_survey_attendance(self):
        with tempfile.TemporaryDirectory() as folder:
            raw=Path(folder)/'raw';tables=Path(folder)/'tables'
            for name in ['Participant_class_info','Longitudinal','Survey']:(raw/name).mkdir(parents=True)
            pd.DataFrame({'Class_id':[1,2,3],'Room':['R1','R2','Out'],'Date':[20191028]*3,
                          'Start_time':['09:00','09:00','10:00'],'Finish_time':['09:20','09:20','10:20']}).to_csv(raw/'Participant_class_info/Class_table.csv',index=False)
            pd.DataFrame({'Class_id':[1], 'Matched_CSV':['WRONG']}).to_csv(raw/'Participant_class_info/Classroom_Data.csv',index=False)
            for name,d in self.environment().items():
                d.rename_axis('Timestamp').reset_index().to_csv(raw/f'Longitudinal/{name}.csv',index=False)
            seconds=pd.date_range('2019-10-28 09:00',periods=1201,freq='s')
            for cid,pid in [(1,1),(2,2)]:
                dest=raw/f'Class_wearable_data/{cid}/{pid}';dest.mkdir(parents=True)
                for signal,value in [('EDA',1.),('HR',70.),('TEMP',32.)]:
                    pd.DataFrame({'Date':seconds,signal:value}).to_csv(dest/f'{signal}.csv',index=False)
            (raw/'Class_wearable_data/3/1').mkdir(parents=True)
            pd.DataFrame([{'Pid':1,'Time':'28/10/2019 09:21','Engage_1':4,'Engage_2':2,'Engage_3':4,'Engage_4':2,'Engage_5':4,'Arousal':2,'Valence':3},
                          {'Pid':1,'Time':'28/10/2019 10:21','Engage_1':1,'Engage_2':5,'Engage_3':1,'Engage_4':5,'Engage_5':1,'Arousal':1,'Valence':1}]).to_csv(raw/'Survey/Student_survey.csv',index=False)
            cfg=json.loads((ROOT/'config/indoor_context.json').read_text())
            cfg.update(raw_dir=str(raw),table_dir=str(tables),output_dir=str(Path(folder)/'analysis'),minimum_sensors=2)
            config=Path(folder)/'config.json';config.write_text(json.dumps(cfg))
            result=subprocess.run([sys.executable,str(ROOT/'run_indoor_context.py'),'--config',str(config),'--stage','preprocess'],capture_output=True,text=True,cwd=folder)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            env=pd.read_csv(tables/'envphys_session_analysis.csv');beh=pd.read_csv(tables/'behavior_session_analysis.csv')
            self.assertEqual(len(env),2);self.assertTrue(env.Temperature_mean.eq(22.).all())
            self.assertTrue(env.EnvironmentDateKey.eq('DATE__2019-10-28').all())
            self.assertEqual(len(beh),1);self.assertEqual(beh.iloc[0].Class_id,1)
            self.assertAlmostEqual(beh.iloc[0].EngageScore,4.)
            qc=pd.read_csv(tables/'00_qc/survey_mapping_qc.csv')
            self.assertIn(3,qc.Class_id.tolist())
            summary=json.loads((tables/'processing_summary.json').read_text())
            self.assertEqual(summary['environment_type'],'INDOOR')
            self.assertFalse(summary['room_mapping_used'])
            self.assertFalse((raw/'Longitudinal/POOLED_INDOOR.csv').exists())

if __name__=='__main__':unittest.main()
