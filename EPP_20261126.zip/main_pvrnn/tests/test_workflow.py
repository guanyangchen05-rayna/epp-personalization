"""Focused workflow checks; no statistical result is inferred from these tests."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('pipeline', ROOT / 'run_pipeline.py')
pipeline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pipeline)

class WorkflowTests(unittest.TestCase):
    def config(self, *extra):
        return pipeline.load_config(pipeline.parse_args(list(extra)))

    def test_external_cwd_dry_run_has_no_writes(self):
        with tempfile.TemporaryDirectory() as folder:
            result = subprocess.run([sys.executable, str(ROOT / 'run_pipeline.py'), '--dry-run'],
                                    cwd=folder, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(list(Path(folder).iterdir()), [])
            self.assertIn(str(ROOT / 'data/processed'), result.stdout)
            self.assertIn('--seeds 11,23,37,51,71', result.stdout)

    def test_missing_exact_inputs_do_not_use_a_copy(self):
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder) / 'envphys_session_analysis(1).csv').write_text('Pid\n1\n')
            cfg = self.config('--table-dir', folder)
            with self.assertRaises(FileNotFoundError):
                pipeline.require_inputs('mixedlm', cfg)

    def test_missing_model_dependencies_do_not_start_raw_preprocessing(self):
        from unittest.mock import patch
        cfg = self.config()
        with patch.object(pipeline, 'require_dependencies', side_effect=RuntimeError('missing')):
            with patch.object(pipeline, 'require_inputs') as require:
                with self.assertRaises(RuntimeError):
                    pipeline.main(['--stage', 'all'])
                require.assert_not_called()

    def test_smoke_changes_training_budget_not_inputs(self):
        full, smoke = self.config(), self.config('--smoke')
        self.assertEqual(full['table_dir'], smoke['table_dir'])
        self.assertEqual(smoke['seeds'], [11])
        self.assertEqual(smoke['epochs'], 1)
        self.assertEqual(smoke['er_steps'], 1)
        self.assertEqual(smoke['bootstrap_reps'], 20)

    def test_failed_stage_stops_before_next_stage_and_records_failure(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(pipeline, 'require_dependencies'), patch.object(pipeline, 'require_inputs'), patch.object(pipeline.platform, 'platform', return_value='test-platform'):
                with patch.object(pipeline, 'input_hashes', return_value={}):
                    with patch.object(pipeline.importlib.metadata, 'version', return_value='test'):
                        with patch.object(pipeline.subprocess, 'run', return_value=subprocess.CompletedProcess([], 9)) as run:
                            with self.assertRaises(RuntimeError):
                                pipeline.main(['--output-dir', folder])
                            self.assertEqual(run.call_count, 1)
            record = next((Path(folder) / 'runs').glob('*/run_manifest.json'))
            data = json.loads(record.read_text())
            self.assertEqual(data['status'], 'failed')
            self.assertEqual(data['stages'][0]['returncode'], 9)
            self.assertEqual(len(data['stages']), 1)

if __name__ == '__main__':
    unittest.main()
