"""Startup regression tests use temporary toy file trees, never study data."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from epp_v6.startup import choose_tables, remember_tables, REQUIRED_TABLES, preflight_and_run


class StartupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def tables(self, relative, content='a'):
        path = self.root/relative
        path.mkdir(parents=True, exist_ok=True)
        for name in REQUIRED_TABLES:
            (path/name).write_text('{}' if name.endswith('.json') else content)
        return path

    def test_stale_hint_discovers_timestamped_export(self):
        actual = self.tables('data/processed_epp_v6_20261020')
        self.assertEqual(choose_tables(self.root, hints=[self.root/'data/processed_epp_v6']), actual)

    def test_explicit_missing_path_does_not_fall_back(self):
        self.tables('data/processed_epp_v6_20261020')
        with self.assertRaisesRegex(FileNotFoundError, 'incomplete'):
            choose_tables(self.root, explicit=self.root/'missing')

    def test_distinct_exports_require_selection(self):
        self.tables('data/one', 'a')
        self.tables('data/two', 'b')
        with self.assertRaisesRegex(RuntimeError, 'Several different'):
            choose_tables(self.root)

    def test_identical_exports_accepted_despite_provenance_timestamp(self):
        one = self.tables('data/one')
        two = self.tables('data/two')
        (two/'processing_summary.json').write_text('{"exported_at":"different"}')
        self.assertIn(choose_tables(self.root), [one, two])

    def test_valid_explicit_overrides_ambiguous_search(self):
        one = self.tables('data/one', 'a')
        self.tables('data/two', 'b')
        self.assertEqual(choose_tables(self.root, explicit=one), one)

    def test_saved_validated_directory_survives_kernel_reset(self):
        one = self.tables('elsewhere/export')
        remember_tables(self.root, one)
        self.assertEqual(choose_tables(self.root), one)

    def test_missing_one_table_fails_with_filename(self):
        one = self.tables('data/incomplete')
        (one/'behavior_temporal_1s.csv').unlink()
        with self.assertRaisesRegex(FileNotFoundError, 'behavior_temporal_1s.csv'):
            choose_tables(self.root)

    def test_failed_preflight_never_trains_or_saves_pointer(self):
        one = self.tables('data/one')
        with patch('epp_v6.startup.run_visible', side_effect=[None, RuntimeError('bad cohort')]) as run:
            with self.assertRaisesRegex(RuntimeError, 'bad cohort'):
                preflight_and_run(self.root, tables=one, run_full=True)
        self.assertEqual(run.call_count, 2)
        self.assertFalse((self.root/'epp_active_tables.json').exists())

    def test_success_runs_check_before_full_without_quick(self):
        one = self.tables('data/one')
        with patch('epp_v6.startup.run_visible') as run:
            preflight_and_run(self.root, tables=one, run_full=True)
        commands = [call.args[0] for call in run.call_args_list]
        self.assertEqual(commands[1][-2:], ['--stage', 'check'])
        self.assertEqual(commands[2][-2:], ['--stage', 'all'])
        self.assertNotIn('--quick', commands[2])
        self.assertTrue((self.root/'epp_active_tables.json').is_file())

    def test_verifier_allows_notebook_edits_but_catches_source_damage(self):
        source = Path(__file__).resolve().parents[1]/'verify_release.py'
        spec = importlib.util.spec_from_file_location('startup_verify_test', source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        contents = {'model.py': b'print(1)\n', 'work.ipynb': b'{}\n'}
        for name, raw in contents.items():
            (self.root/name).write_bytes(raw)
        manifest = {'version':'test', 'editable_files':['work.ipynb'],
                    'files':{n:hashlib.sha256(v).hexdigest() for n,v in contents.items()}}
        (self.root/module.MANIFEST).write_text(json.dumps(manifest))
        (self.root/'work.ipynb').write_text('{"cells":[]}')
        (self.root/'model.py').write_bytes(b'print(1)\r\n')
        self.assertEqual(module.verify(self.root), 0)
        (self.root/'model.py').write_bytes(b'print(2)\n')
        self.assertEqual(module.verify(self.root), 1)


if __name__ == '__main__':
    unittest.main()
