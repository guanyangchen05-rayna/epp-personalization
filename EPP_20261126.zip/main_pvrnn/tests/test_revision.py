"""Supplementary-analysis checks: grouping, decomposition, inference and safety."""
import importlib.util,json,sys,tempfile,unittest
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT))

@unittest.skipUnless(importlib.util.find_spec('statsmodels') and importlib.util.find_spec('patsy'),'statsmodels/patsy not installed')
class RevisionTests(unittest.TestCase):
    def fixture(self):
        rows=[];rng=np.random.default_rng(5)
        for day in range(6):
            for window in range(2):
                start=pd.Timestamp('2019-10-20')+pd.Timedelta(days=day,hours=9+window)
                for pid in range(5):
                    rows.append(dict(Pid=str(pid),Class_id=str(day*2+window),ClassStart=str(start),ClassEnd=str(start+pd.Timedelta(minutes=40)),
                                     ContextWindowKey='POOLED_INDOOR__'+start.strftime('%Y-%m-%dT%H:%M:%S')+'__'+(start+pd.Timedelta(minutes=40)).strftime('%Y-%m-%dT%H:%M:%S'),
                                     EnvironmentDateKey=start.strftime('DATE__%Y-%m-%d'),EnvironmentScope='school_indoor_context',Room='R1',
                                     Temperature_mean=18+day+window*.8,CO2_mean=600+day*8+window*80,
                                     EDA_mean=.1+pid*.03+rng.uniform(0,.2),HR_mean=70+pid+rng.normal(),SkinTEMP_mean=29+day*.3+rng.normal(),
                                     n_complete_env_phys_seconds=1500,complete_env_phys_fraction_of_class=.6,EnvPhysReady=True))
        return pd.DataFrame(rows)
    def test_within_between_uses_unique_windows_and_exact_identity(self):
        from revision_models import prepare
        d=self.fixture();d=pd.concat([d,d.loc[d.Class_id.eq('0')]],ignore_index=True)
        x=prepare(d)
        for v in ['Temperature','CO2']:
            np.testing.assert_allclose(x[v+'_between_z']+x[v+'_within_z'],x[v+'_z'])
        # Unequal student counts do not change the date's equal-window mean.
        between=x.loc[x.EnvironmentDateKey.eq('DATE__2019-10-20'),'Temperature_between_z']*d.Temperature_mean.std(ddof=0)+d.Temperature_mean.mean()
        self.assertTrue(np.allclose(between,18.4))
    def test_context_group_does_not_use_room_and_rejects_duplicates(self):
        from revision_models import read_sessions
        with tempfile.TemporaryDirectory() as f:
            p=Path(f)/'input.csv';d=self.fixture();d.to_csv(p,index=False);r=read_sessions(p)
            self.assertEqual(r.ContextWindowKey.nunique(),12)
            pd.concat([d,d.iloc[:1]]).to_csv(p,index=False)
            with self.assertRaisesRegex(ValueError,'Duplicate'):read_sessions(p)
    def test_date_fixed_specification_excludes_between_date_terms(self):
        from revision_models import specification
        terms,vc,_=specification('date_fixed_window_time',True)
        self.assertIn('C(EnvironmentDateKey)',terms);self.assertNotIn('Date',vc)
        self.assertFalse(any('between' in t for t in terms));self.assertIn('ContextWindow',vc)
        terms,vc,col=specification('within_between_window_time',True)
        self.assertEqual(col,'Temperature_within_z')
        self.assertIn('Temperature_within_z',vc['PidTempSlope'])
    def test_missing_inference_remains_missing_and_counts_in_fdr_family(self):
        from revision_models import adjust_families
        x=pd.DataFrame([dict(model='m',slope=False,reml=True,predictor='Temperature_z',p=.01),
                        dict(model='m',slope=False,reml=True,predictor='CO2_z',p=np.nan)])
        z=adjust_families(x);self.assertAlmostEqual(z.q_BH_FDR.iloc[0],.02)
        self.assertTrue(pd.isna(z.q_BH_FDR.iloc[1]));self.assertTrue(z.FDR_family_size.eq(2).all())
    def test_nested_window_model_uses_all_rows_and_returns_fit_diagnostics(self):
        from revision_models import prepare,fit,fixed_rows
        d=prepare(self.fixture());r,m=fit(d,'HR','context_window',reml=False)
        self.assertEqual(m['N_sessions'],60);self.assertEqual(m['N_windows'],12)
        self.assertEqual(set(m['variance_components']),{'Date','ContextWindow','PidIntercept'})
        self.assertEqual(len(m['attempts']),2);self.assertTrue(np.isfinite(m['AIC']))
        self.assertTrue(any(v['predictor']=='Temperature_z' for v in fixed_rows(r,m)))
    def test_launcher_refuses_outputs_inside_original_analysis(self):
        import run_revision
        with tempfile.TemporaryDirectory() as f:
            root=Path(f);cfg=dict(environment_mode='school_indoor_context',table_dir=str(root/'tables'),output_dir=str(root/'analysis'),raw_dir=str(root/'raw'))
            path=root/'run_config.json';path.write_text(json.dumps(cfg))
            with self.assertRaisesRegex(ValueError,'outside the original'):
                run_revision.main(['--source-config',str(path),'--output-dir',str(root/'analysis/revision'),'--dry-run'])
    def test_figure_writer_records_unavailable_ci_without_dropping_outcome(self):
        from revision_figures import forest,style,MANIFEST
        style();MANIFEST.clear()
        x=pd.DataFrame([dict(model='m',slope=False,outcome=o,predictor='Temperature_z',beta=.2,ci95_low=np.nan if o=='EDA' else 0.,ci95_high=.5) for o in ['EDA','HR','SkinTEMP']])
        with tempfile.TemporaryDirectory() as f:
            forest(Path(f),'test',x,['Temperature_z'],['Temperature'],'m')
            self.assertTrue((Path(f)/'test.pdf').is_file());self.assertTrue(MANIFEST[-1]['text_bounds_checked'])
    def test_environment_reconstruction_preserves_cohort_and_excludes_outdoor_inputs(self):
        from revision_models import read_sessions
        from revision_audit import environment
        from unittest.mock import patch
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as f:
            root=Path(f);tables=root/'tables';tables.mkdir();(tables/'00_input').mkdir()
            raw=root/'raw';(raw/'Longitudinal').mkdir(parents=True);out=root/'audit';out.mkdir()
            d=self.fixture();p=tables/'input.csv';d.to_csv(p,index=False);d=read_sessions(p)
            idx=pd.date_range('2019-10-20',periods=6*24*12,freq='5min');day=(idx.normalize()-idx[0]).days;window=(idx.hour>=10).astype(int)
            base=18+day+window*.8;co2=600+day*8+window*80
            for name,dt,dc in [('A',-2,-50),('B',0,0),('KB1',20,1000)]:
                pd.DataFrame({'Timestamp':idx,'IndoorTemperature':base+dt,'IndoorCO2':co2+dc,'OutdoorTemperature':-100+day,
                              'Occupied':0,'UsabilityMask':True}).to_csv(raw/f'Longitudinal/{name}.csv',index=False)
            (tables/'00_input/indoor_context_summary.json').write_text(json.dumps({'fixed_panel':['A','B','KB1']}))
            def fake_fit(dd,outcome,model,reml=True):
                self.assertEqual(len(dd),60)
                r=SimpleNamespace(fe_params=pd.Series({'Temperature_z':.2,'CO2_z':.1}),bse_fe=pd.Series({'Temperature_z':.1,'CO2_z':.1}))
                m=dict(model=model,outcome=outcome,slope=False,reml=reml,N_sessions=len(dd),N_participants=5,N_dates=6,N_windows=12)
                return r,m
            # This isolates source aggregation; Gaussian fits have a separate test.
            with patch('revision_audit.fit',side_effect=fake_fit):environment(d,tables,raw,out)
            x=pd.read_csv(out/'sensor_sensitivity_window_values.csv')
            self.assertEqual(x.scenario.nunique(),6)
            main=x.loc[x.scenario.eq('median_fixed_panel')].set_index('ContextWindowKey')
            np.testing.assert_allclose(d.ContextWindowKey.map(main.Temperature_mean),d.Temperature_mean)
            without=x.loc[x.scenario.eq('median_without_KB')].set_index('ContextWindowKey')
            np.testing.assert_allclose(d.ContextWindowKey.map(without.Temperature_mean),d.Temperature_mean-1)
            self.assertTrue((out/'indoor_outdoor_correlation.csv').exists())
if __name__=='__main__':unittest.main()
