"""Outcome-independent whole-session EDA zero-value screening."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from eda_session_qc import apply_eda_session_qc

class EDASessionQCTests(unittest.TestCase):
    def fixture(self):
        master=pd.DataFrame({'Pid':['1','2','3'],'Class_id':['1','2','3'],
                             'EnvPhysReady':[True]*3,'StrictBehaviorReady':[True]*3})
        rows=[]
        for pid,cid,nzero,value in [('1','1',100,0.),('2','2',95,.1),('3','3',0,.00001)]:
            d=pd.DataFrame({'Pid':pid,'Class_id':cid,'DateTime':pd.date_range('2019-10-28 09:00',periods=100,freq='s'),
                            'HasCoreEnvironmentPhysiology':True,'EDA':value})
            if nzero:d.loc[:nzero-1,'EDA']=0.
            rows.append(d)
        return master,pd.concat(rows,ignore_index=True)

    def test_threshold_applies_to_both_cohorts_and_keeps_low_nonzero_signal(self):
        master,seconds=self.fixture();out=apply_eda_session_qc(master,seconds,.95)
        self.assertEqual(out.EDA_QC_pass.tolist(),[False,False,True])
        self.assertEqual(out.EnvPhysReady.tolist(),[False,False,True])
        self.assertEqual(out.StrictBehaviorReady.tolist(),[False,False,True])
        self.assertEqual(out.EDA_zero_fraction.tolist(),[1.,.95,0.])
        self.assertEqual(out.EDA_longest_zero_run_seconds.tolist(),[100,95,0])
        self.assertTrue(out.EnvPhysReady_before_EDA_QC.all())
        self.assertTrue(out.StrictBehaviorReady_before_EDA_QC.all())

    def test_original_values_are_not_modified_and_labels_do_not_affect_qc(self):
        master,seconds=self.fixture();before=seconds.copy(deep=True)
        a=apply_eda_session_qc(master.assign(Arousal=1),seconds)
        b=apply_eda_session_qc(master.assign(Arousal=4),seconds)
        self.assertEqual(a.EDA_QC_pass.tolist(),b.EDA_QC_pass.tolist())
        pd.testing.assert_frame_equal(seconds,before)
        comparator=apply_eda_session_qc(master,seconds,None)
        self.assertTrue(comparator.EnvPhysReady.all())

    def test_zero_run_breaks_at_missing_clock_seconds(self):
        master,seconds=self.fixture()
        mask=seconds.Pid.eq('1') & seconds.DateTime.ge(pd.Timestamp('2019-10-28 09:00:50'))
        seconds.loc[mask,'DateTime']+=pd.Timedelta(seconds=10)
        out=apply_eda_session_qc(master,seconds)
        self.assertEqual(out.loc[out.Pid.eq('1'),'EDA_longest_zero_run_seconds'].iloc[0],50)

    def test_models_refuse_unfiltered_or_different_threshold_tables(self):
        import importlib.util
        sys.path.insert(0,str(ROOT))
        spec=importlib.util.spec_from_file_location('qc_launcher',ROOT/'run_indoor_context.py')
        launcher=importlib.util.module_from_spec(spec);spec.loader.exec_module(launcher)
        with tempfile.TemporaryDirectory() as folder:
            tables=Path(folder)
            for name in ['envphys_session_analysis.csv','behavior_session_analysis.csv','behavior_temporal_1s.csv']:
                (tables/name).write_text('Pid\n1\n')
            cfg={'raw_dir':folder,'table_dir':folder,'eda_qc_max_zero_fraction':.95}
            summary=tables/'processing_summary.json'
            summary.write_text('{}')
            for stage in ['mixedlm','pvrnn']:
                with self.assertRaisesRegex(ValueError,'configured EDA QC'):
                    launcher.require_inputs(stage,cfg)
            summary.write_text(json.dumps({'eda_qc':{'max_zero_fraction':.95}}))
            launcher.require_inputs('mixedlm',cfg)
            launcher.require_inputs('pvrnn',cfg)

    def test_original_dataset_to_model_tables_filters_bad_sessions_consistently(self):
        with tempfile.TemporaryDirectory() as folder:
            raw=Path(folder)/'raw';tables=Path(folder)/'tables'
            for name in ['Participant_class_info','Longitudinal','Survey']:(raw/name).mkdir(parents=True)
            pd.DataFrame({'Class_id':[1,2,3],'Room':['R1','R2','R3'],'Date':[20191028]*3,
                          'Start_time':['09:00']*3,'Finish_time':['09:20']*3}).to_csv(raw/'Participant_class_info/Class_table.csv',index=False)
            nt=pd.date_range('2019-10-28 08:55',periods=7,freq='5min')
            for name,temp in [('A',20.),('B',24.)]:
                pd.DataFrame({'Timestamp':nt,'IndoorTemperature':temp,'IndoorCO2':700.,'Occupied':1,'UsabilityMask':True}).to_csv(raw/f'Longitudinal/{name}.csv',index=False)
            times=pd.date_range('2019-10-28 09:00',periods=1201,freq='s')
            for pid in [1,2,3]:
                dest=raw/f'Class_wearable_data/{pid}/{pid}';dest.mkdir(parents=True)
                eda=np.full(1201,.001)
                if pid==1:eda[:]=0
                if pid==2:eda[:1141]=0
                for signal,val in [('EDA',eda),('HR',70.),('TEMP',32.)]:
                    pd.DataFrame({'Date':times,signal:val}).to_csv(dest/f'{signal}.csv',index=False)
            pd.DataFrame([{'Pid':pid,'Time':'28/10/2019 09:21','Engage_1':4,'Engage_2':2,'Engage_3':4,'Engage_4':2,'Engage_5':4,'Arousal':2,'Valence':3} for pid in [1,2,3]]).to_csv(raw/'Survey/Student_survey.csv',index=False)
            cfg=json.loads((ROOT/'config/indoor_context.json').read_text());cfg.update(raw_dir=str(raw),table_dir=str(tables),output_dir=str(Path(folder)/'analysis'),minimum_sensors=2)
            path=Path(folder)/'config.json';path.write_text(json.dumps(cfg))
            run=subprocess.run([sys.executable,str(ROOT/'run_indoor_context.py'),'--config',str(path),'--stage','preprocess'],capture_output=True,text=True)
            self.assertEqual(run.returncode,0,run.stdout+run.stderr)
            for name in ['envphys_session_analysis.csv','behavior_session_analysis.csv','behavior_temporal_1s.csv']:
                d=pd.read_csv(tables/name);self.assertEqual(set(d.Pid),{3})
            qc=pd.read_csv(tables/'00_qc/eda_session_qc.csv');self.assertEqual(len(qc),3)
            removed=pd.read_csv(tables/'00_qc/excluded_eda_sessions.csv');self.assertEqual(set(removed.Pid),{1,2})
            summary=json.loads((tables/'processing_summary.json').read_text())
            self.assertEqual(summary['eda_qc']['n_envphys_sessions_before_qc'],3)
            self.assertEqual(summary['n_envphys_ready_sessions'],1)
            self.assertEqual(summary['eda_qc']['n_behavior_sessions_excluded_by_eda'],2)

if __name__=='__main__':unittest.main()
