"""Synthetic integration check of class-local preprocessing and survey linkage."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

try:
    import pandas as pd
except ImportError:
    pd = None

ROOT = Path(__file__).resolve().parents[1]

@unittest.skipIf(pd is None, 'Install numpy/pandas for the synthetic preprocessing check')
class PreprocessingIntegration(unittest.TestCase):
    def test_class_specific_sources_missing_physiology_and_survey_assignment(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder) / 'raw'
            tables = Path(folder) / 'tables'
            for name in ('Participant_class_info', 'Longitudinal', 'Survey'):
                (base / name).mkdir(parents=True)
            mapping = pd.DataFrame([
                {'Class_id': 1, 'Room': 'R1', 'Matched_CSV': 'A', 'start_dt': '2019-10-28 09:00:00', 'end_dt': '2019-10-28 09:20:00'},
                {'Class_id': 2, 'Room': 'R2', 'Matched_CSV': 'B', 'start_dt': '2019-10-28 09:00:00', 'end_dt': '2019-10-28 09:20:00'},
                {'Class_id': 3, 'Room': 'R1', 'Matched_CSV': None, 'start_dt': '2019-10-28 10:00:00', 'end_dt': '2019-10-28 10:20:00'},
            ])
            original=mapping.drop(columns=['Matched_CSV','start_dt','end_dt']).copy()
            original['Date']=20191028
            original['Start_time']=['09:00','09:00','10:00']
            original['Finish_time']=['09:20','09:20','10:20']
            original.to_csv(base / 'Participant_class_info/Class_table.csv', index=False)
            # A stale derived table must not be consulted by the new entry point.
            mapping.assign(Matched_CSV='WRONG').to_csv(base / 'Participant_class_info/Classroom_Data.csv', index=False)
            crosswalk=Path(folder)/'room_crosswalk.csv'
            pd.DataFrame({'Room':['R1','R2'],'SensorCSV':['A','B'],
                          'Status':['documented','documented'],
                          'Source':['synthetic fixture','synthetic fixture']}).to_csv(crosswalk,index=False)
            native = pd.date_range('2019-10-28 09:00:00', periods=5, freq='5min')
            for sensor, temperature, co2 in [('A', 20., 500.), ('B', 30., 900.)]:
                pd.DataFrame({'Timestamp': native, 'IndoorTemperature': temperature,
                              'IndoorCO2': co2, 'Occupied': 1}).to_csv(base / f'Longitudinal/{sensor}.csv', index=False)
            seconds = pd.date_range('2019-10-28 09:00:00', periods=1201, freq='s')
            for cid, pid in [(1, 1), (2, 2)]:
                destination = base / f'Class_wearable_data/{cid}/{pid}'
                destination.mkdir(parents=True)
                for signal, value in [('EDA', 1.), ('HR', 70.), ('TEMP', 32.)]:
                    frame = pd.DataFrame({'Date': seconds, signal: value})
                    if cid == 1 and signal == 'HR':
                        frame = frame.drop(index=range(100, 110))
                    frame.to_csv(destination / f'{signal}.csv', index=False)
            # Keep unmapped attendance so its survey cannot be moved to class 1.
            (base / 'Class_wearable_data/3/1').mkdir(parents=True)
            surveys = pd.DataFrame([
                {'Pid': 1, 'Time': '28/10/2019 09:21:00', 'Engage_1': 4, 'Engage_2': 2, 'Engage_3': 4, 'Engage_4': 2, 'Engage_5': 4, 'Arousal': 2, 'Valence': 3},
                {'Pid': 2, 'Time': '28/10/2019 09:21:00', 'Engage_1': 4, 'Engage_2': 2, 'Engage_3': 4, 'Engage_4': 2, 'Engage_5': None, 'Arousal': 2, 'Valence': 3},
                {'Pid': 1, 'Time': '28/10/2019 10:21:00', 'Engage_1': 1, 'Engage_2': 5, 'Engage_3': 1, 'Engage_4': 5, 'Engage_5': 1, 'Arousal': 1, 'Valence': 1},
            ])
            surveys.to_csv(base / 'Survey/Student_survey.csv', index=False)
            result = subprocess.run([sys.executable, str(ROOT / 'run_pipeline.py'),
                                     '--stage', 'preprocess', '--raw-dir', str(base),
                                     '--table-dir', str(tables), '--output-dir', str(Path(folder) / 'results'),
                                     '--crosswalk',str(crosswalk)],
                                    cwd=folder, capture_output=True, text=True)
            logs = list((Path(folder) / 'results').glob('runs/*/preprocess.log'))
            all_logs=list((Path(folder) / 'results').glob('runs/*/*.log'))
            detail = '\n'.join(p.read_text() for p in all_logs) if all_logs else result.stderr
            self.assertEqual(result.returncode, 0, detail)
            env = pd.read_csv(tables / 'envphys_session_analysis.csv').set_index('Class_id')
            behavior = pd.read_csv(tables / 'behavior_session_analysis.csv')
            temporal = pd.read_csv(tables / 'behavior_temporal_1s.csv')
            qc = pd.read_csv(tables / '00_qc/survey_mapping_qc.csv')
            self.assertEqual(set(env.index), {1, 2})
            self.assertAlmostEqual(env.loc[1, 'Temperature_mean'], 20.)
            self.assertAlmostEqual(env.loc[2, 'Temperature_mean'], 30.)
            self.assertEqual(env.loc[1, 'n_complete_env_phys_seconds'], 1191)
            self.assertEqual(set(behavior.Class_id), {1})
            self.assertAlmostEqual(behavior.iloc[0].EngageScore, 4.)
            self.assertEqual(set(temporal.Class_id), {1})
            self.assertEqual(len(temporal), 1191)
            self.assertEqual(set(qc.Class_id), {1, 2, 3})

if __name__ == '__main__':
    unittest.main()
