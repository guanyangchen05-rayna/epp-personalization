"""Run preprocessing, MixedLM and PV-RNN with explicit paths and run records."""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TABLES = ('envphys_session_analysis.csv', 'behavior_session_analysis.csv',
          'behavior_temporal_1s.csv')
DEPS = {'prepare': ('numpy', 'pandas'), 'preprocess': ('numpy', 'pandas'),
        'mixedlm': ('numpy', 'pandas', 'scipy', 'statsmodels', 'matplotlib'),
        'pvrnn': ('numpy', 'pandas', 'scipy', 'scikit-learn', 'torch', 'matplotlib')}

def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def resolve_path(value):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=ROOT / 'config/default.json')
    parser.add_argument('--stage', choices=('all', 'prepare', 'preprocess', 'mixedlm', 'pvrnn'), default='all')
    parser.add_argument('--mapping-mode', choices=('documented','historical'))
    parser.add_argument('--crosswalk', help='Sourced Room-to-SensorCSV CSV for documented mode.')
    parser.add_argument('--class-table', help='Original dated Class_table.csv; derived Classroom_Data is not accepted.')
    parser.add_argument('--raw-dir')
    parser.add_argument('--table-dir')
    parser.add_argument('--output-dir')
    parser.add_argument('--dry-run', action='store_true', help='Print commands; do not execute or write files.')
    parser.add_argument('--smoke', action='store_true', help='PV-RNN wiring check: 1 seed, 1 epoch, 1 ER step, 20 bootstrap samples; not paper results.')
    return parser.parse_args(argv)

def load_config(args):
    cfg = json.loads(args.config.read_text(encoding='utf-8'))
    cfg.setdefault('mapping_mode', 'documented')
    cfg.setdefault('crosswalk', None)
    cfg.setdefault('class_table', None)
    if args.mapping_mode:
        cfg['mapping_mode'] = args.mapping_mode
    if cfg['mapping_mode'] not in ('documented','historical'):
        raise ValueError('mapping_mode must be documented or historical')
    for name in ('crosswalk','class_table'):
        value=getattr(args,name) or cfg.get(name)
        cfg[name]=str(resolve_path(value)) if value else None
    for name in ('raw_dir', 'table_dir', 'output_dir'):
        value = getattr(args, name) or cfg[name]
        cfg[name] = str(resolve_path(value))
    for key in ('epochs', 'er_steps', 'bootstrap_reps'):
        if not isinstance(cfg[key], int) or isinstance(cfg[key], bool) or cfg[key] < 1:
            raise ValueError(f'{key} must be a positive integer')
    if not isinstance(cfg['seeds'], list) or not cfg['seeds'] or any(type(s) is not int for s in cfg['seeds']):
        raise ValueError('seeds must be a non-empty list of integers')
    if len(cfg['seeds']) != len(set(cfg['seeds'])):
        raise ValueError('seeds must be unique')
    if not isinstance(cfg['er_lr'], (int, float)) or cfg['er_lr'] <= 0:
        raise ValueError('er_lr must be positive')
    if type(cfg['cpu_only']) is not bool:
        raise ValueError('cpu_only must be true or false')
    if args.smoke:
        cfg.update(seeds=[11], epochs=1, er_steps=1, bootstrap_reps=20)
        cfg['output_dir'] = str(Path(cfg['output_dir']) / 'smoke')
    return cfg

def build_commands(cfg, stage):
    selected = ('prepare', 'preprocess', 'mixedlm', 'pvrnn') if stage == 'all' else (('prepare','preprocess') if stage=='preprocess' else (stage,))
    table = Path(cfg['table_dir'])
    results = Path(cfg['output_dir'])
    prepared = table / '00_input'
    prepare = [sys.executable, '-u', str(ROOT / 'scripts/prepare_classroom_mapping.py'),
               '--base-dir',cfg['raw_dir'],'--output-dir',str(prepared),'--mode',cfg['mapping_mode']]
    if cfg.get('crosswalk'):
        prepare.extend(['--crosswalk',cfg['crosswalk']])
    if cfg.get('class_table'):
        prepare.extend(['--class-table',cfg['class_table']])
    commands = {
        'prepare': prepare,
        'preprocess': [sys.executable, str(ROOT / 'scripts/preprocess_sessions.py'),
                       '--base-dir', cfg['raw_dir'], '--output-dir', str(table),
                       '--classroom-table',str(prepared / 'Classroom_Data.csv')],
        'mixedlm': [sys.executable, str(ROOT / 'scripts/mixedlm_analysis.py'),
                    '--input', str(table / TABLES[0]), '--output-dir', str(results / 'mixedlm')],
        'pvrnn': [sys.executable, str(ROOT / 'scripts/pvrnn_frozen_v3.py'),
                  '--table-dir', str(table), '--output-dir', str(results / 'pvrnn'),
                  '--epochs', str(cfg['epochs']), '--seeds', ','.join(map(str, cfg['seeds'])),
                  '--er-steps', str(cfg['er_steps']), '--er-lr', str(cfg['er_lr']),
                  '--bootstrap-reps', str(cfg['bootstrap_reps']), '--skip-mixedlm'],
    }
    return [(name, commands[name]) for name in selected]

def require_dependencies(stages):
    missing = []
    for package in sorted({d for stage in stages for d in DEPS[stage]}):
        try:
            importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            missing.append(package)
    if missing:
        raise RuntimeError('Missing packages: ' + ', '.join(missing) + '. Install requirements.txt in your chosen environment.')

def require_inputs(stage, cfg):
    raw, tables = Path(cfg['raw_dir']), Path(cfg['table_dir'])
    if stage == 'prepare':
        if not raw.is_dir():
            raise FileNotFoundError(f'Raw dataset directory missing: {raw}')
        return
    if stage == 'preprocess':
        mapping = tables / '00_input/Classroom_Data.csv'
        wearable = next((raw / name for name in ('Class_wearable_data', 'Class_wearable_data1', 'Classwearabledata')
                         if (raw / name).is_dir()), None)
        survey = next((raw / name for name in ('Survey/Student_survey.csv', 'Survey/Studentsurvey.csv',
                                               'Student_survey.csv', 'Studentsurvey.csv')
                       if (raw / name).is_file()), None)
        if not mapping.is_file() or not (raw / 'Longitudinal').is_dir() or wearable is None or survey is None:
            raise FileNotFoundError('Raw inputs incomplete. See data/README.md for the historical dataset layout.')
        with mapping.open(encoding='utf-8-sig', newline='') as stream:
            reader=csv.DictReader(stream)
            fields = set(reader.fieldnames or [])
            rows=list(reader)
        if not {'Class_id', 'Matched_CSV'}.issubset(fields):
            raise ValueError('Classroom_Data.csv must contain Class_id and Matched_CSV; official class_table.csv alone is insufficient.')
        if not any(r.get('Matched_CSV','').strip() for r in rows):
            raise ValueError('No supported room/file links were found. Mapping diagnostics are in '+str(mapping.parent)+
                             '. Provide a sourced --crosswalk, or explicitly choose --mapping-mode historical to reconstruct the former unvalidated assignments.')
    else:
        needed = TABLES if stage == 'pvrnn' else TABLES[:1]
        absent = [str(tables / name) for name in needed if not (tables / name).is_file()]
        if absent:
            raise FileNotFoundError('Required exact input files missing: ' + ', '.join(absent))

def input_hashes(stage, cfg):
    if stage not in ('prepare','preprocess'):
        names = TABLES if stage == 'pvrnn' else TABLES[:1]
        return {name: sha256(Path(cfg['table_dir']) / name) for name in names}
    raw = Path(cfg['raw_dir'])
    if stage=='prepare':
        # The preparation script records all 16 source hashes and the selected
        # original class-table/crosswalk hashes in mapping_summary.json.
        paths=[Path(cfg[name]) for name in ('class_table','crosswalk') if cfg.get(name)]
        return {str(p):sha256(p) for p in paths if p.is_file()}
    paths = [Path(cfg['table_dir']) / '00_input/Classroom_Data.csv',
             raw / 'Survey/Student_survey.csv', raw / 'Student_survey.csv']
    # Metadata inputs only; raw wearable/environment trees are not fully hashed.
    return {str(p): sha256(p) for p in paths if p.is_file()}

def main(argv=None):
    args = parse_args(argv)
    cfg = load_config(args)
    plan = build_commands(cfg, args.stage)
    for stage, command in plan:
        print(f'[{stage}] {shlex.join(command)}', flush=True)
    if args.dry_run:
        return 0
    require_dependencies([stage for stage, _ in plan])
    # Prevent an expensive all-stage run failing later because model dependencies are absent.
    for stage, _ in plan[:1]:
        require_inputs(stage, cfg)
    tag = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    run_dir = Path(cfg['output_dir']) / 'runs' / tag
    run_dir.mkdir(parents=True)
    packages = {}
    for package in sorted({d for stage, _ in plan for d in DEPS[stage]}):
        packages[package] = importlib.metadata.version(package)
    record = {'created_utc': tag, 'config': cfg, 'smoke_only': args.smoke,
              'python': sys.version, 'platform': platform.platform(), 'packages': packages,
              'mapping_status': 'pending_preparation' if any(s=='prepare' for s,_ in plan) else 'provided_analysis_tables_mapping_not_checked_in_this_run',
              'source_hashes': {str(p.relative_to(ROOT)): sha256(p) for p in (ROOT / 'scripts').glob('*.py')},
              'raw_tree_fully_hashed': False, 'stages': []}
    record_path = run_dir / 'run_manifest.json'
    def save():
        record_path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    env = os.environ.copy()
    env.setdefault('MPLBACKEND', 'Agg')
    if cfg['cpu_only']:
        env['CUDA_VISIBLE_DEVICES'] = ''
    save()
    try:
        for stage, command in plan:
            require_inputs(stage, cfg)
            entry = {'stage': stage, 'command': command, 'input_sha256': input_hashes(stage, cfg), 'status': 'running'}
            record['stages'].append(entry)
            save()
            log_path = run_dir / f'{stage}.log'
            print(f'Running {stage}; log: {log_path}', flush=True)
            with log_path.open('w', encoding='utf-8') as stream:
                result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
            entry.update(returncode=result.returncode, status='passed' if result.returncode == 0 else 'failed')
            if stage=='prepare' and result.returncode==0:
                mapping_summary=Path(cfg['table_dir']) / '00_input/mapping_summary.json'
                entry['mapping_summary_sha256']=sha256(mapping_summary)
                prepared_info=json.loads(mapping_summary.read_text(encoding='utf-8'))
                record['mapping_status']='historical_assignment_not_validated' if prepared_info['mapping_mode']=='historical' else 'documented_links_only'
                record['mapping_summary']=prepared_info
            save()
            if result.returncode:
                raise RuntimeError(f'{stage} failed; inspect {log_path}')
        record['status'] = 'completed'
    except Exception as exc:
        record.update(status='failed', error=str(exc))
        save()
        raise
    save()
    print(f'Completed. Run record: {record_path}', flush=True)
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError, KeyError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        raise SystemExit(1)
