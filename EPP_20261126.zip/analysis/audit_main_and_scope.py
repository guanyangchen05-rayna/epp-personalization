"""Recompute saved main-study summaries and the personalization temporal scope.

No torch, model fitting, or inference. Requires numpy/pandas. Main input is
EPP_manuscript_reproducibility; formal input is the extracted two40 run.
"""
from pathlib import Path
import argparse, hashlib, json
import numpy as np
import pandas as pd

p = argparse.ArgumentParser()
p.add_argument('--repro-root', type=Path, required=True)
p.add_argument('--formal-run', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
a.out.mkdir(parents=True, exist_ok=True)
root = a.repro_root / 'main_pvrnn'
run = root / 'results/epp_v6/20261020T142629_112453Z'
pred = pd.read_csv(run / 'behavior_11/out_of_fold_predictions.csv', dtype={'Pid': str, 'Class_id': str})
assert len(pred) == 1920
keys = ['protocol', 'Pid', 'Class_id', 'target', 'mode']
m = pred.groupby(keys, as_index=False).agg(prediction=('prediction', 'median'), observed=('observed', 'first'), baseline=('baseline', 'median'))
rows, counts = [], []
for (protocol, target), g in m.groupby(['protocol', 'target']):
    er = g[g['mode'].eq('ERROR_REGRESSION')]
    for mode, h in g.groupby('mode'):
        rows.append(dict(protocol=protocol, target=target, mode=mode, n=len(h), RMSE=float(np.sqrt(np.mean((h.prediction-h.observed)**2)))))
    er_errors = er.assign(error=(er.prediction-er.observed).abs()).groupby('Pid').error.mean()
    for mode, h in g.groupby('mode'):
        errors = h.assign(error=(h.prediction-h.observed).abs()).groupby('Pid').error.mean()
        counts.append(dict(protocol=protocol, target=target, comparator=mode, ER_lower_MAE=int((errors-er_errors>0).sum()), n_people=len(errors)))
pd.DataFrame(rows).to_csv(a.out/'main_RMSE.csv', index=False)
pd.DataFrame(counts).to_csv(a.out/'main_participant_MAE_counts.csv', index=False)
# Keep original string-ID ordering and the original two-comparator RNG stream.
pooled=pred.groupby(['protocol','Pid','Class_id','EnvironmentDateKey','target','mode'],sort=False).agg(observed=('observed','first'),prediction=('prediction','median')).reset_index()
def rmse(y,x): return np.sqrt(np.mean((y-x)**2))
bootstrap_rows=[]
for comparators,stream in [(['NO_ER','SIMPLE_RNN'],'original_model_comparisons'),(['TRAINING_MEAN'],'training_mean_extension')]:
    rng=np.random.default_rng(721)
    for (protocol,target),g in pooled.groupby(['protocol','target'],sort=False):
        index=['Pid','Class_id','EnvironmentDateKey']
        w=g.pivot(index=index,columns='mode',values='prediction')
        y=g.groupby(index)['observed'].first().reindex(w.index).to_numpy()
        cluster='Pid' if protocol=='PARTICIPANT_LOO' else 'EnvironmentDateKey'
        ids=w.index.get_level_values(cluster).to_numpy();groups=np.unique(ids)
        er=w.ERROR_REGRESSION.to_numpy()
        for comparator in comparators:
            ref=w[comparator].to_numpy();draws=[]
            for _ in range(2000):
                sample=rng.choice(groups,size=len(groups),replace=True)
                ii=np.concatenate([np.flatnonzero(ids==k) for k in sample])
                draws.append(100*(rmse(y[ii],ref[ii])-rmse(y[ii],er[ii]))/rmse(y[ii],ref[ii]))
            low,high=np.quantile(draws,[.025,.975])
            bootstrap_rows.append(dict(protocol=protocol,target=target,comparator=comparator,comparator_RMSE=float(rmse(y,ref)),ER_RMSE=float(rmse(y,er)),gain_pct=float(100*(rmse(y,ref)-rmse(y,er))/rmse(y,ref)),ci_low=float(low),ci_high=float(high),cluster=cluster,n_clusters=len(groups),bootstrap_reps=2000,rng_seed=721,rng_stream=stream))
stats=pd.DataFrame(bootstrap_rows)
historical=pd.read_csv(run/'behavior_11/cluster_bootstrap.csv')
check=stats[stats.rng_stream.eq('original_model_comparisons')].copy()
check['comparison']='ER_vs_'+check.comparator
check=check.merge(historical,on=['protocol','target','comparison'],validate='one_to_one')
assert len(check)==12 and np.allclose(check.ci_low,check.ci95_low,atol=1e-10) and np.allclose(check.ci_high,check.ci95_high,atol=1e-10)
stats.to_csv(a.out/'main_paired_RMSE_improvements.csv',index=False)
d = pd.read_csv(run/'behavior_11/reconstruction_diagnostics.csv')
reconstruction = []
for protocol, g in d.groupby('protocol'):
    pair = g.pivot(index=['seed','Pid','Class_id'], columns='mode', values='MSE_all')
    assert len(pair)==80 and (pair.ERROR_REGRESSION<pair.NO_ER).all()
    for field in ['MSE_all','MSE_environment','MSE_physiology']:
        means=g.groupby(['seed','mode'])[field].mean().unstack()
        gains=100*(means.NO_ER-means.ERROR_REGRESSION)/means.NO_ER
        reconstruction.append(dict(protocol=protocol, diagnostic=field, median_seed_reduction_pct=float(gains.median()), minimum_seed_reduction_pct=float(gains.min()), maximum_seed_reduction_pct=float(gains.max())))
pd.DataFrame(reconstruction).to_csv(a.out/'main_reconstruction.csv', index=False)
assert len(d[d['mode'].eq('ERROR_REGRESSION')])==160
assert d.loc[d['mode'].eq('ERROR_REGRESSION'),'best_step'].eq(150).all()
part=d[d.protocol.eq('PARTICIPANT_LOO')].pivot(index=['seed','Pid','Class_id'],columns='mode',values='MSE_all')
reduction=(part.NO_ER-part.ERROR_REGRESSION)/part.NO_ER
selection=reduction.groupby(['Pid','Class_id']).median().rename('median_seed_fraction_reduction').reset_index()
selection['distance_to_median']=(selection.median_seed_fraction_reduction-selection.median_seed_fraction_reduction.median()).abs()
selection.sort_values('distance_to_median').to_csv(a.out/'figure6_selection.csv',index=False)
selected=selection.loc[selection.distance_to_median.idxmin()]
assert (int(selected.Pid),int(selected.Class_id))==(1,217)
manifest=json.loads((run/'run_manifest.json').read_text())
hashes=[]
for key, expected in manifest['implementation_sources'].items():
    path=root/key.replace('\\','/')
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    hashes.append(dict(file=key,expected_sha256=expected,actual_sha256=actual,match=actual==expected))
assert all(x['match'] for x in hashes)
(a.out/'main_implementation_hashes.json').write_text(json.dumps(hashes,indent=2))
train=pd.read_csv(a.formal_run/'protocol/train_records.csv')
val=pd.read_csv(a.formal_run/'protocol/validation_records.csv')
cal=pd.read_csv(a.formal_run/'protocol/calibration_records.csv')
assert set(zip(train.Pid,train.Class_id)).isdisjoint(zip(val.Pid,val.Class_id))
assert set(zip(cal.Pid,cal.Class_id)) <= set(zip(train.Pid,train.Class_id))
scope=[]
for target in val.itertuples():
    same=train.Pid.eq(target.Pid)
    assert pd.to_datetime(train.loc[same,'ClassEnd']).le(pd.to_datetime(target.ClassStart)).all()
    later=pd.to_datetime(train.ClassStart)>pd.to_datetime(target.ClassStart)
    scope.append(dict(Pid=target.Pid,Class_id=target.Class_id,target_start=target.ClassStart,later_training_records_other_people=int((later&~same).sum()),later_training_reports_other_people=int((later&~same&train.has_report).sum())))
pd.DataFrame(scope).to_csv(a.out/'temporal_training_scope.csv',index=False)
(a.out/'audit_scope_summary.json').write_text(json.dumps(dict(main_prediction_rows=len(pred),main_ER_diagnostics=160,main_all_reconstruction_pairs_improve=True,main_implementation_hashes_all_match=True,formal_train_records=len(train),formal_train_reports=int(train.has_report.sum()),formal_targets=len(val),formal_target_reports=int(val.has_report.sum()),formal_calibration_records=len(cal),own_history_precedes_target=True,global_calendar_prospective_split=False,main_manifest_status=manifest.get('status')),indent=2))
print('PASS: saved main summaries, reconstruction pairs, source hashes, Figure 6 selection, and personal-history split. See temporal_training_scope.csv for calendar scope.')
