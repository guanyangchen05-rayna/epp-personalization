"""Recompute four-phase simulation and held-out metrics from saved predictions."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--simulation-run', type=Path, required=True)
    parser.add_argument('--validation-run', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sim, val, source, out = args.simulation_run, args.validation_run, args.source, args.output
    out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((sim/'run_manifest.json').read_text())
    source_checks = {name: sha(source/name) == expected
                     for name, expected in manifest['code'].items()}
    assert all(source_checks.values()), source_checks
    for name, expected in manifest['inputs'].items():
        assert sha(source/'data'/name) == expected, name
    model_checks = {}
    for seed in [11, 23, 37]:
        for rel in [f'models/seed{seed}.pt', f'profiles/personal_A_seed{seed}.csv']:
            model_checks[rel] = sha(sim/rel) == sha(val/rel)
    assert all(model_checks.values())
    stage_files = 0
    for path in (sim/'stages').glob('*.json'):
        stage = json.loads(path.read_text())
        for name, expected in stage['files'].items():
            assert sha(sim/name.replace('\\', '/')) == expected, name
            stage_files += 1

    scenarios = pd.read_csv(sim/'protocol/scenarios.csv')
    stable = scenarios[scenarios.scenario.eq('stable')].sort_values('minute')
    changing = scenarios[scenarios.scenario.eq('stable_then_fluctuating')].sort_values('minute')
    channels = ['IndoorTemperature', 'IndoorCO2']
    onset = int(np.flatnonzero(np.any(changing[channels].to_numpy() !=
                                     stable[channels].to_numpy(), axis=1))[0])
    assert onset == 11
    assert changing.phase.tolist() == sum(([p]*10 for p in
        ['stable_prefix', 'rising', 'falling', 'fluctuating']), [])
    info = json.loads((sim/'protocol/scenario_definition.json').read_text())
    reference = json.loads((source/'original_reference/original_scenario_definition.json').read_text())
    np.testing.assert_array_equal(info['baseline'], reference['baseline'])
    np.testing.assert_array_equal(info['amplitudes'], reference['amplitudes'])
    raw = pd.read_csv(sim/'simulation/all_trajectories_by_seed.csv')
    assert len(raw) == 24960 and set(raw.seed) == {11, 23, 37}
    keys = ['Pid', 'condition', 'minute', 'variable', 'scenario']
    assert not raw.duplicated(keys+['seed']).any()
    assert raw.groupby(keys).seed.nunique().eq(3).all()
    mean = raw.groupby(keys, as_index=False).prediction.mean()
    saved = pd.read_csv(sim/'simulation/trajectories_seed_mean.csv')
    np.testing.assert_allclose(mean.set_index(keys).prediction.sort_index(),
                              saved.set_index(keys).prediction.sort_index(), atol=1e-12, rtol=0)
    wide = mean.pivot(index=keys[:-1], columns='scenario', values='prediction').reset_index()
    wide['response'] = wide.stable_then_fluctuating-wide.stable
    assert wide.loc[wide.minute.lt(onset), 'response'].abs().max() < 1e-12
    zero = wide[wide.condition.eq('zero')][['minute', 'variable', 'response']].rename(
        columns={'response': 'zero_response'})
    paired = wide.merge(zero, on=['minute', 'variable'], validate='many_to_one')
    paired['response_minus_zero'] = paired.response-paired.zero_response
    post = paired[paired.minute.ge(onset) & ~paired.variable.isin(channels)].copy()
    post['abs_contrast'] = post.response_minus_zero.abs()
    post['abs_response'] = post.response.abs()
    summary = post.groupby(['Pid', 'condition', 'variable'], as_index=False).agg(
        mean_response=('response', 'mean'), mean_absolute_response=('abs_response', 'mean'),
        mean_absolute_response_difference_vs_zero=('abs_contrast', 'mean'), n_minutes=('minute', 'size'))
    provided = pd.read_csv(sim/'simulation/response_summary.csv')
    provided = provided[provided.analysis_window.eq('actual_input_onset')]
    skeys = ['Pid', 'condition', 'variable']
    cols = ['mean_response', 'mean_absolute_response', 'mean_absolute_response_difference_vs_zero']
    np.testing.assert_allclose(summary.set_index(skeys)[cols].sort_index(),
        provided.set_index(skeys)[cols].sort_index(), atol=1e-12, rtol=0)
    summary.to_csv(out/'simulation_primary_response_summary.csv', index=False)
    personal = post[post.condition.eq('personal')]
    personal.groupby('variable', as_index=False).agg(
        mean_absolute_DID=('abs_contrast', 'mean'),
        mean_absolute_response=('abs_response', 'mean'),
        mean_signed_DID=('response_minus_zero', 'mean'),
        maximum_absolute_DID=('abs_contrast', 'max')).to_csv(
            out/'simulation_interaction_seed_mean.csv', index=False)

    validation = pd.read_csv(val/'validation/all_trajectories_by_seed.csv')
    assert len(validation) == 90000 and set(validation.seed) == {11, 23, 37}
    vkeys = ['Pid', 'Class_id', 'mode', 'condition', 'minute', 'variable']
    assert not validation.duplicated(vkeys+['seed']).any()
    vm = validation.groupby(vkeys, as_index=False).agg(
        prediction=('prediction', 'mean'), observed=('observed', 'first'))
    physiology = vm[vm.variable.isin(['EDA', 'HR', 'TEMP'])].copy()
    physiology['sqerr'] = np.square(physiology.prediction-physiology.observed)
    physiology['abserr'] = np.abs(physiology.prediction-physiology.observed)
    physiology['bias'] = physiology.prediction-physiology.observed
    groups = ['mode', 'condition', 'variable']
    metrics = physiology.groupby(groups, as_index=False).agg(
        MSE=('sqerr', 'mean'), MAE=('abserr', 'mean'), bias=('bias', 'mean'), n=('sqerr', 'size'))
    metrics['RMSE'] = np.sqrt(metrics.MSE)
    metrics.to_csv(out/'physiology_metrics.csv', index=False)
    reports = pd.read_csv(val/'validation/report_endpoint_estimates.csv')
    reports = reports[reports.scored.astype(bool)].copy()
    assert reports.groupby(groups).size().eq(7).all()
    reports['bias'] = reports.prediction-reports.observed
    report_metrics = reports.groupby(groups, as_index=False).agg(
        MSE=('squared_error', 'mean'), MAE=('absolute_error', 'mean'), bias=('bias', 'mean'),
        n=('squared_error', 'size'))
    report_metrics['RMSE'] = np.sqrt(report_metrics.MSE)
    report_metrics.to_csv(out/'report_metrics.csv', index=False)
    expected = pd.read_csv(val/'validation/summary_metrics.csv')
    for table in [metrics, report_metrics]:
        joined = table.merge(expected, on=groups, suffixes=('_new', '_saved'), validate='one_to_one')
        assert len(joined) == len(table)
        for metric in ['RMSE', 'MAE']:
            np.testing.assert_allclose(joined[metric+'_new'], joined[metric+'_saved'], atol=1e-12, rtol=0)
    audit = dict(simulation_onset_minute=onset, primary_window=[onset, 40],
                 source_hashes_match=source_checks, matched_checkpoints_and_profiles=model_checks,
                 stage_output_hashes_checked=stage_files, simulation_rows=len(raw),
                 validation_rows=len(validation), simulation_recalculated=True,
                 validation_metrics_recalculated=True, model_refitting=False,
                 validation_source='unchanged held-out run formal_20261028_180424_097163')
    (out/'audit_summary.json').write_text(json.dumps(audit, indent=2)+'\n')
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    main()
