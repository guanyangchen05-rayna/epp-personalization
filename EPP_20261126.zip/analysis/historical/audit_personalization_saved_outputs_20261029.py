from pathlib import Path
import argparse,json,hashlib,zipfile,collections
import numpy as np
import pandas as pd

WORK=Path(__file__).resolve().parents[2]
ap=argparse.ArgumentParser(description='Independent read-only audit of the two40 result archive; no torch or model rerun.')
ap.add_argument('--run',type=Path,default=WORK/'numeric_verification/user_two40_20261028/formal_20261028_180424_097163')
ap.add_argument('--source',type=Path,default=WORK/'output/EPP_personalization_mechanism_two40')
ap.add_argument('--archive',type=Path,default=WORK/'upload/formal_20261028_180424_097163.zip')
ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parent)
args=ap.parse_args()
RUN,SRC,ARCHIVE,OUT=[p.expanduser().resolve() for p in [args.run,args.source,args.archive,args.output]]
OUT.mkdir(parents=True,exist_ok=True)
CHANNELS=['IndoorTemperature','IndoorCO2','EDA','HR','TEMP']
REPORTS=['EngageScore','Arousal','Valence'];VARS=CHANNELS+REPORTS
SEEDS=[11,23,37]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def save(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def close(a,b,name,tol=1e-9):
 e=np.nanmax(np.abs(np.asarray(a,float)-np.asarray(b,float)))
 assert np.isfinite(e) and e<=tol,(name,e)
 return float(e)
manifest=json.loads((RUN/'run_manifest.json').read_text());cfg=manifest['config']
complete=json.loads((RUN/'run_complete.json').read_text())
assert complete['full_validation'] and cfg['mode']=='formal' and cfg['validation_max_minutes']==0
payload={k:manifest[k] for k in ['config','inputs','split','code']};assert digest(payload)==manifest['signature']
source_match={n:sha(SRC/n)==h for n,h in manifest['code'].items()};assert all(source_match.values())
assert sha(SRC/'plots.py')==manifest['presentation_code_sha256']
for n,h in manifest['inputs'].items():assert sha(SRC/'data'/n)==h
stagefiles=sorted((RUN/'stages').glob('*.json'));assert len(stagefiles)==78
checked=0
for p in stagefiles:
 s=json.loads(p.read_text());assert s['complete']
 for n,h in s['files'].items():assert sha(RUN/n.replace('\\','/'))==h,(p,n);checked+=1
 name=p.stem
 if name.startswith('train_seed'):
  seed=int(name.removeprefix('train_seed'))
  sig=digest(dict(mode=cfg['mode'],seed=seed,epochs=cfg['train_epochs'],algorithm=cfg['algorithm'],split=manifest['split'],inputs=manifest['inputs'],source={n:sha(SRC/n) for n in ['training.py','data_io.py','protocol.py','backbone.py','personal_a.py','v6_dynamics.py','v6_reference/model.py']}))
 elif name.startswith('calibration_seed'):
  seed=int(name.removeprefix('calibration_seed'))
  sig=digest(dict(checkpoint=sha(RUN/'models'/f'seed{seed}.pt'),split=manifest['split'],steps=cfg['calibration_steps'],algorithm=cfg['algorithm'],inputs=manifest['inputs'],source=sha(SRC/'personal_a.py')))
 else:
  seed=int(name.split('_seed')[1].split('_')[0])
  sig=digest([manifest['signature'],sha(RUN/'models'/f'seed{seed}.pt'),sha(RUN/'profiles'/f'personal_A_seed{seed}.csv'),name])
 assert sig==s['signature'],name
for seed in SEEDS:
 for rel in [f'models/seed{seed}.pt',f'profiles/personal_A_seed{seed}.csv',f'profiles/personal_A_seed{seed}.json']:
  assert sha(RUN/rel)==sha(SRC/'bundled'/Path(rel).name),rel
train=pd.read_csv(RUN/'protocol/train_records.csv');cal=pd.read_csv(RUN/'protocol/calibration_records.csv');val=pd.read_csv(RUN/'protocol/validation_records.csv');exc=pd.read_csv(RUN/'protocol/excluded_records.csv')
keys=lambda d:set(map(tuple,d[['Pid','Class_id']].to_numpy(int)))
assert not keys(train)&keys(val) and not keys(cal)&keys(val) and keys(cal)<=keys(train)
assert not keys(train)&keys(exc)
for r in val.itertuples():assert cal[cal.Pid==r.Pid].ClassEnd.le(r.ClassStart).all()
assert (len(train),len(cal),len(val),len(exc),int(train.has_report.sum()),int(val.has_report.sum()),int(val.n_minutes.sum()))==(87,34,11,15,9,7,625)
# Raw completeness, exact data identities and independent seed aggregation.
audit_errors={}
raws={};means={}
for ds,expected in [('simulation',24960),('validation',90000)]:
 raw=pd.concat([pd.read_csv(p) for p in sorted((RUN/ds/'cases').glob('*.csv'))],ignore_index=True)
 aggregate=pd.read_csv(RUN/ds/'all_trajectories_by_seed.csv')
 assert len(raw)==len(aggregate)==expected
 assert np.isfinite(raw[['prediction','prediction_pre_ER']]).all().all()
 assert set(raw.seed)==set(SEEDS)
 if ds=='validation':
  k=['Pid','Class_id','mode','condition','step','minute','variable','complete_session']
  assert raw.complete_session.all()
  assert keys(raw)==keys(val)
  assert raw[raw.variable.isin(REPORTS)].observed.isna().all()
  assert raw.groupby(['seed','mode','condition']).size().eq(625*8).all()
  assert set(raw.condition)=={'personal','zero','local10'}
  assert raw.used_as_ER_target.eq(raw.variable.isin(CHANNELS)&(raw['mode'].eq('EP_online')|raw.variable.isin(CHANNELS[:2]))).all()
 else:
  k=['scenario','Pid','condition','step','minute','variable']
  assert raw[~raw.variable.isin(CHANNELS[:2])].observed.isna().all()
  expected_members={(0,'zero'),(0,'local10')}|{(int(p),'personal') for p in cfg['validation_pids']}
  assert set(zip(raw.Pid,raw.condition))==expected_members
  assert set(raw.minute)==set(range(40))
 assert not raw.duplicated(k+['seed']).any()
 pd.testing.assert_frame_equal(raw.sort_values(k+['seed']).reset_index(drop=True),aggregate[raw.columns].sort_values(k+['seed']).reset_index(drop=True),check_exact=False,atol=1e-12,rtol=1e-12)
 assert raw.groupby(k).seed.nunique().eq(3).all()
 m=raw.groupby(k,as_index=False,dropna=False).agg(prediction=('prediction','mean'),observed=('observed','first'))
 provided=pd.read_csv(RUN/ds/'trajectories_seed_mean.csv')
 merged=m.merge(provided,on=k,suffixes=('_recalc','_provided'),validate='one_to_one')
 assert len(merged)==len(m)==len(provided)
 audit_errors[ds+'_mean']=close(merged.prediction_recalc,merged.prediction_provided,ds+'_mean')
 raws[ds]=raw;means[ds]=m
# Validate each actual observed value against the frozen source, original minute IDs intact.
frozen=pd.read_csv(SRC/'data/minutes.csv')
v=means['validation']
for variable in CHANNELS:
 original=raws['validation'][raws['validation'].variable==variable]
 q=original.merge(frozen[['Pid','Class_id','minute',variable]],on=['Pid','Class_id','minute'],validate='many_to_one')
 assert len(q)==len(original);close(q.observed,q[variable],variable+' observed',1e-10)
# Recompute physiology pooled/per-person and report endpoints, without provided summarizer.
phys=v[v.variable.isin(CHANNELS[2:])].copy()
end=v[v.variable.isin(REPORTS)].sort_values('minute').groupby(['Pid','Class_id','mode','condition','variable'],as_index=False).tail(1).copy()
labels=val.melt(id_vars=['Pid','Class_id','has_report'],value_vars=REPORTS,var_name='variable',value_name='label')
end=end.merge(labels,on=['Pid','Class_id','variable'],validate='many_to_one')
assert len(end)==198;assert int((end.has_report & end.label.notna()).sum())==126
end['observed']=end.label
provided_end=pd.read_csv(RUN/'validation/report_endpoint_estimates.csv')
for r in provided_end.itertuples():
 q=end[(end.Pid==r.Pid)&(end.Class_id==r.Class_id)&(end['mode']==r.mode)&(end.condition==r.condition)&(end.variable==r.variable)].iloc[0]
 assert r.scored==q.has_report
 close([r.prediction],[q.prediction],'endpoint prediction')
 if r.scored:close([r.observed],[q.label],'endpoint label')

def metrics(d,group):
 d=d.copy();d['sq']=(d.prediction-d.observed)**2;d['ab']=(d.prediction-d.observed).abs();d['err']=d.prediction-d.observed
 q=d.groupby(group,as_index=False).agg(MSE=('sq','mean'),MAE=('ab','mean'),bias=('err','mean'),n=('sq','size'));q['RMSE']=np.sqrt(q.MSE);return q
scored=end[end.has_report].copy()
recalc=pd.concat([metrics(phys,['mode','condition','variable']),metrics(scored,['mode','condition','variable'])],ignore_index=True)
provided=pd.read_csv(RUN/'validation/summary_metrics.csv')
m=recalc.merge(provided,on=['mode','condition','variable'],suffixes=('_calc','_csv'),validate='one_to_one')
for column in ['MSE','RMSE','MAE','bias']:audit_errors[column]=close(m[column+'_calc'],m[column+'_csv'],column)
# Recompute paired stats and show participant-level wins, macro sensitivity and seed consistency.
per=pd.concat([metrics(phys,['Pid','Class_id','mode','condition','variable']),metrics(scored,['Pid','Class_id','mode','condition','variable'])],ignore_index=True)
per.to_csv(OUT/'independent_per_participant_metrics.csv',index=False)
summary=[]
for metric in ['RMSE','MAE']:
 p=recalc.pivot(index=['mode','variable'],columns='condition',values=metric)
 indiv=per.pivot(index=['Pid','mode','variable'],columns='condition',values=metric).reset_index()
 for (mode,variable),r in p.iterrows():
  q=indiv[(indiv['mode']==mode)&(indiv.variable==variable)]
  for comparator in ['zero','local10']:
   delta=q[comparator]-q.personal
   summary.append(dict(mode=mode,variable=variable,metric=metric,comparator=comparator,
                       personal=r.personal,reference=r[comparator],gain_percent=100*(r[comparator]-r.personal)/r[comparator],
                       wins=int((delta>1e-10).sum()),n_people=len(q),median_paired_gain=float(delta.median()),
                       macro_personal=float(q.personal.mean()),macro_reference=float(q[comparator].mean()),
                       macro_gain_percent=float(100*(q[comparator].mean()-q.personal.mean())/q[comparator].mean())))
summary=pd.DataFrame(summary);summary.to_csv(OUT/'comparison_metrics.csv',index=False)
# Every seed report/physiology score independently from raw, then compare provided table.
srows=[]
for seed,g in raws['validation'].groupby('seed'):
 pp=metrics(g[g.variable.isin(CHANNELS[2:])],['mode','condition','variable']);pp['seed']=seed;srows.append(pp)
 ee=g[g.variable.isin(REPORTS)].sort_values('minute').groupby(['Pid','Class_id','mode','condition','variable'],as_index=False).tail(1).merge(labels,on=['Pid','Class_id','variable'],validate='many_to_one')
 ee['observed']=ee.label
 bb=metrics(ee[ee.has_report],['mode','condition','variable']);bb['seed']=seed;srows.append(bb)
ss=pd.concat(srows,ignore_index=True)
sp=pd.read_csv(RUN/'validation/metrics_by_seed.csv');mm=ss.merge(sp,on=['mode','condition','variable','seed'],suffixes=('_calc','_provided'),validate='one_to_one')
for metric in ['RMSE','MAE']:audit_errors['per_seed_'+metric]=close(mm[metric+'_calc'],mm[metric+'_provided'],'per_seed_'+metric)
ss.to_csv(OUT/'independent_metrics_by_seed.csv',index=False)
# LOPO sensitivity of endpoint RMSE advantage; diagnostics, not new model training/CV.
lopo=[]
for mode,g in scored.groupby('mode'):
 for variable,h in g.groupby('variable'):
  for excluded in sorted(h.Pid.unique()):
   p=metrics(h[h.Pid!=excluded],['condition']).set_index('condition')
   for c in ['zero','local10']:
    lopo.append(dict(mode=mode,variable=variable,excluded_Pid=int(excluded),comparator=c,
                     gain_percent=100*(p.loc[c,'RMSE']-p.loc['personal','RMSE'])/p.loc[c,'RMSE']))
pd.DataFrame(lopo).to_csv(OUT/'report_leave_one_person_out_sensitivity.csv',index=False)
# Post-hoc diagnostic constant references, fitted exclusively to predeclared training/history data.
train_keys=train[['Pid','Class_id']];training_minutes=frozen.merge(train_keys,on=['Pid','Class_id'],validate='many_to_one')
training_reports=train[train.has_report]
baserows=[]
for r in val.itertuples():
 obs=frozen[(frozen.Pid==r.Pid)&(frozen.Class_id==r.Class_id)]
 hkeys=cal[cal.Pid==r.Pid][['Pid','Class_id']];history=frozen.merge(hkeys,on=['Pid','Class_id'],validate='many_to_one')
 for variable in CHANNELS[2:]:
  for name,pred in [('training_mean',training_minutes[variable].mean()),('personal_history_mean',history[variable].mean())]:
   err=pred-obs[variable].to_numpy()
   baserows.append(dict(Pid=r.Pid,Class_id=r.Class_id,variable=variable,reference=name,n=len(obs),MSE=float(np.mean(err**2)),MAE=float(np.mean(abs(err))),RMSE=float(np.sqrt(np.mean(err**2)))))
 if r.has_report:
  for variable in REPORTS:
   pred=training_reports[variable].mean();err=pred-getattr(r,variable)
   baserows.append(dict(Pid=r.Pid,Class_id=r.Class_id,variable=variable,reference='training_mean',n=1,MSE=err**2,MAE=abs(err),RMSE=abs(err)))
baselines=pd.DataFrame(baserows);baselines.to_csv(OUT/'posthoc_constant_references_by_person.csv',index=False)
b=[]
for (variable,reference),g in baselines.groupby(['variable','reference']):
 w=g.n.to_numpy();b.append(dict(variable=variable,reference=reference,RMSE=float(np.sqrt(np.average(g.MSE,weights=w))),MAE=float(np.average(g.MAE,weights=w))))
pd.DataFrame(b).to_csv(OUT/'posthoc_constant_reference_summary.csv',index=False)
# Matched scenario prefix and DID, separately in each seed and then seed mean.
sim=raws['simulation'];si=['seed','Pid','condition','minute','variable']
p=sim.pivot(index=si,columns='scenario',values='prediction')
p['response']=p.stable_then_fluctuating-p.stable
assert p.reset_index().loc[lambda d:d.minute<25,'response'].eq(0).all()
rsp=p.reset_index();zr=rsp[(rsp.Pid==0)&(rsp.condition=='zero')][['seed','minute','variable','response']].rename(columns={'response':'zero_response'})
rsp=rsp.merge(zr,on=['seed','minute','variable'],validate='many_to_one');rsp['DID']=rsp.response-rsp.zero_response
mean_rsp=rsp.groupby(['Pid','condition','minute','variable'],as_index=False)[['response','DID']].mean()
provided_rsp=pd.read_csv(RUN/'simulation/matched_environment_responses.csv')
mm=mean_rsp[mean_rsp.variable.isin(VARS[2:])].merge(provided_rsp,on=['Pid','condition','minute','variable'],suffixes=('_calc','_provided'),validate='one_to_one')
audit_errors['response']=close(mm.response_calc,mm.response_provided,'response');audit_errors['DID']=close(mm.DID,mm.response_minus_zero,'DID')
provided_windows=pd.read_csv(RUN/'simulation/response_summary.csv')
for label,start in [('actual_input_onset',25),('scheduled_second_phase',20)]:
 q=provided_rsp[(provided_rsp.minute>=start)&(provided_rsp.minute<40)].copy()
 q['abs_resp']=q.response.abs();q['abs_did']=q.response_minus_zero.abs()
 a=q.groupby(['Pid','condition','variable'],as_index=False).agg(mean_response=('response','mean'),mean_absolute_response=('abs_resp','mean'),mean_absolute_response_difference_vs_zero=('abs_did','mean'),n_minutes=('minute','size'))
 z=a.merge(provided_windows[provided_windows.analysis_window==label],on=['Pid','condition','variable'],suffixes=('_calc','_csv'),validate='one_to_one')
 for column in ['mean_response','mean_absolute_response','mean_absolute_response_difference_vs_zero','n_minutes']:
  audit_errors[label+'_'+column]=close(z[column+'_calc'],z[column+'_csv'],label+column)
rsp.to_csv(OUT/'simulation_responses_independently_by_seed.csv',index=False)
q=rsp[(rsp.condition=='personal')&(rsp.minute>=25)&rsp.variable.isin(VARS[2:])].copy();q['abs_DID']=q.DID.abs();q['abs_response']=q.response.abs()
q.groupby(['variable','seed'],as_index=False).agg(mean_absolute_DID=('abs_DID','mean'),mean_absolute_response=('abs_response','mean'),mean_signed_DID=('DID','mean')).to_csv(OUT/'simulation_interaction_by_seed.csv',index=False)
q=mean_rsp[(mean_rsp.condition=='personal')&(mean_rsp.minute>=25)&mean_rsp.variable.isin(VARS[2:])].copy();q['abs_DID']=q.DID.abs();q['abs_response']=q.response.abs()
q.groupby('variable',as_index=False).agg(mean_absolute_DID=('abs_DID','mean'),mean_absolute_response=('abs_response','mean'),mean_signed_DID=('DID','mean'),maximum_absolute_DID=('abs_DID','max')).to_csv(OUT/'simulation_interaction_seed_mean.csv',index=False)
# Profile and ER budget diagnostics, finite objectives and monotone accepted fits.
profile_stats=[]
for seed in SEEDS:
 d=pd.read_csv(RUN/'profiles'/f'personal_A_seed{seed}.csv')
 assert len(d)==11 and d.calibration_records.sum()==34 and d.calibration_minutes.sum()==1841
 profile_stats.append(dict(seed=seed,n_profiles=len(d),best_at_600=int((d.best_step==600).sum()),norm_min=float(np.hypot(d.A_slow_0,d.A_slow_1).min()),norm_max=float(np.hypot(d.A_slow_0,d.A_slow_1).max())))
 (OUT/f'profiles_seed{seed}.csv').write_text(d.to_csv(index=False))
diags=[]
for ds in ['simulation','validation']:
 d=pd.concat([pd.read_csv(f) for f in (RUN/ds/'diagnostics').glob('*.csv')],ignore_index=True)
 if 'mode' not in d.columns:d['mode']='E_only'
 assert np.isfinite(d[['objective_before','objective_after']]).all().all()
 assert (d.objective_after<=d.objective_before+1e-10).all()
 assert d.fixed_coordinates_verified.all()
 d['dataset']=ds;d['at100']=d.best_step.eq(100)
 diags.append(d)
d=pd.concat(diags,ignore_index=True)
d.groupby(['dataset','mode','condition'],dropna=False,as_index=False).agg(n_fits=('best_step','size'),at100=('at100','sum'),fraction_at100=('at100','mean'),median_best_step=('best_step','median'),objective_before=('objective_before','mean'),objective_after=('objective_after','mean')).to_csv(OUT/'optimization_diagnostics.csv',index=False)
# Descriptive distribution shift and report-eligible subset, without changing main estimates.
h=frozen.merge(cal[['Pid','Class_id']],on=['Pid','Class_id']).groupby('Pid')[CHANNELS].mean().add_prefix('history_')
t=frozen.merge(val[['Pid','Class_id']],on=['Pid','Class_id']).groupby('Pid')[CHANNELS].mean().add_prefix('target_')
h.join(t).to_csv(OUT/'historical_target_channel_means.csv')
rows=[]
for (mode,variable,condition),g in per[per.Pid.isin(val[val.has_report].Pid)&per.variable.isin(CHANNELS[2:])].groupby(['mode','variable','condition']):
 rows.append(dict(mode=mode,variable=variable,condition=condition,RMSE=float(np.sqrt(np.average(g.MSE,weights=g.n))),n_people=7))
pd.DataFrame(rows).to_csv(OUT/'physiology_report_eligible_subset_diagnostic.csv',index=False)
# ZIP entry times provide stage completion timing in the user's local timestamps.
with zipfile.ZipFile(ARCHIVE) as z:
 from datetime import datetime
 times={Path(i.filename).name:datetime(*i.date_time) for i in z.infolist() if '/stages/' in i.filename and i.filename.endswith('.json')}
 seq=sorted((t,n) for n,t in times.items());rows=[]
 for j,(t,n) in enumerate(seq):rows.append(dict(local_time=t.isoformat(),stage=n,seconds_since_previous=(t-seq[j-1][0]).total_seconds() if j else None))
 pd.DataFrame(rows).to_csv(OUT/'stage_timing.csv',index=False)
save('audit_summary.json',dict(archive_sha256=sha(ARCHIVE),formal_complete=True,elapsed_seconds=complete['elapsed_this_invocation_seconds'],stage_count=len(stagefiles),hashed_output_references_checked=checked,exact_released_models_profiles=True,source_hashes_match=source_match,split_counts=dict(train=87,calibration=34,validation=11,report_validation=7),raw_rows=dict(simulation=24960,validation=90000),max_independent_recalculation_errors=audit_errors,profile_diagnostics=profile_stats,simulation_prefix_difference=0.0))
print(json.dumps(json.loads((OUT/'audit_summary.json').read_text()),indent=2))
print('\nRMSE COMPARISONS\n',summary[(summary.metric=='RMSE')].round(5).to_string(index=False))
print('\nCONSTANT REFERENCES\n',pd.DataFrame(b).round(5).to_string(index=False))
