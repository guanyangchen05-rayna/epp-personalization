from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd

def corr(x,y):return float(np.corrcoef(x,y)[0,1])
def ranks(x):return pd.Series(x).rank(method='average').to_numpy()
def analyse(stage_pairs,training22,out):
 out.mkdir(parents=True,exist_ok=True)
 p=pd.read_csv(stage_pairs);t=pd.read_csv(training22)
 summary=[];neighbors=[]
 for seed,g in p.groupby('seed',sort=True):
  g=g.sort_values('Pid');a=g[['train_A0','train_A1']].to_numpy(float);b=g[['cal_A0','cal_A1']].to_numpy(float);ids=g.Pid.to_numpy(int)
  full=t[t.seed.eq(seed)].sort_values('Pid');pool=full[['training_A0','training_A1']].to_numpy(float);pool_ids=full.Pid.to_numpy(int)
  assert len(g)==11 and len(pool)==22
  assert np.allclose(a,pool[np.array([int(np.flatnonzero(pool_ids==pid)[0]) for pid in ids])])
  # Raw same-coordinate nearest neighbor, with the own identity among candidates.
  d=np.linalg.norm(b[:,None]-pool[None,:],axis=2);nn=d.argmin(1);nn11=np.linalg.norm(b[:,None]-a[None,:],axis=2).argmin(1)
  # Same-participant spread correlation, after removing a common mean shift only.
  ac=a-a.mean(0);bc=b-b.mean(0)
  centered_cos=float((ac*bc).sum()/np.sqrt((ac*ac).sum()*(bc*bc).sum()))
  da=np.linalg.norm(a[:,None]-a[None,:],axis=2)[np.triu_indices(11,1)]
  db=np.linalg.norm(b[:,None]-b[None,:],axis=2)[np.triu_indices(11,1)]
  # Positive scalar fit b = mean(b) + beta*(a-mean(a)); descriptive only.
  beta=float((ac*bc).sum()/(ac*ac).sum())
  separation=float(np.linalg.norm(pool[:,None]-pool[None,:],axis=2)[np.triu_indices(22,1)].mean())
  shift=float(np.linalg.norm(b-a,axis=1).mean())
  row=dict(seed=int(seed),n_people=len(g),mean_pairwise_training_22=separation,mean_recalibration_distance=shift,shift_to_training_separation_ratio=shift/separation,pearson_A0=corr(a[:,0],b[:,0]),pearson_A1=corr(a[:,1],b[:,1]),spearman_A0=corr(ranks(a[:,0]),ranks(b[:,0])),spearman_A1=corr(ranks(a[:,1]),ranks(b[:,1])),centered_vector_correlation=centered_cos,mean_pairwise_training_11=float(da.mean()),mean_pairwise_recalibrated_11=float(db.mean()),pairwise_distance_pearson=corr(da,db),pairwise_distance_spearman=corr(ranks(da),ranks(db)),raw_same_person_nearest_among22=int((pool_ids[nn]==ids).sum()),raw_same_person_nearest_among11=int((ids[nn11]==ids).sum()),positive_scalar_fit=beta)
  summary.append(row)
  for j,pid in enumerate(ids):
   rank=int(np.flatnonzero(pool_ids[np.argsort(d[j],kind='stable')]==pid)[0]+1)
   neighbors.append(dict(seed=int(seed),Pid=int(pid),nearest_training_Pid=int(pool_ids[nn[j]]),same_person=bool(pool_ids[nn[j]]==pid),own_identity_distance_rank_among22=rank,own_distance=float(np.linalg.norm(b[j]-a[j])),nearest_distance=float(d[j,nn[j]])))
 result=pd.DataFrame(summary);result.to_csv(out/'offset_correspondence_summary.csv',index=False)
 pd.DataFrame(neighbors).to_csv(out/'nearest_neighbor_details.csv',index=False)
 (out/'offset_correspondence_summary.json').write_text(json.dumps(summary,indent=2))
 print(result.to_string(index=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage-pairs',type=Path,required=True);p.add_argument('--training22',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();analyse(a.stage_pairs,a.training22,a.output)
