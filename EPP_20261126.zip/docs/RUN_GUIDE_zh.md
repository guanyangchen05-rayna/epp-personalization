# 运行

代码包与配套复现包内部采用相同相对路径。将配套包的内容合并到包含 `reproduce.py`
的目录后，输入、权重与正式输出位于各模块下。

```bash
python -m pip install -r requirements.txt
python reproduce.py verify
python reproduce.py statistics
python reproduce.py figure-data
python reproduce.py figures
```

仅运行补充 ANOVA 时，不需要配套包或 PyTorch：

```bash
python -m pip install -r requirements-summaries.txt
python reproduce.py anova
```

统计复算写入 `reproduced/statistics/`。默认读取的两份 personalization 输出是：

- `personalization/results/formal_fourphase_20261125/`：已完成的新版四阶段模拟。
- `personalization/results/formal_20261028_180424_097163/`：原完整 held-out 评估及训练、校准记录。

新版改变假想环境情景，不改变真实目标输入，因此持有会话评价沿用原已完成预测。
旧 run 的旧环境模拟保留作历史记录，当前汇总和 Figure 6 不读取它作为新版轨迹。

```bash
python reproduce.py check-inputs
python reproduce.py personalization-check
python reproduce.py tests
python reproduce.py train-main
python reproduce.py personalization-simulate
python reproduce.py personalization-all
python reproduce.py personalization-retrain
```

模拟和全部评估默认复用经过身份校验的 bundled 网络与 A；`personalization-retrain`
才执行重新训练和校准。推断或训练可持续数小时。中断续跑使用新版运行目录：

```bash
python personalization/run_project.py --mode formal --phase all --resume /path/to/new_run
```

`--resume` 不与 `--force-train` 合用。当前代码、输入、设置与运行签名需要一致。
主分析入口固定 `--stage behavior --cohorts 11`；旧 rho、chain 与 recovery 分支
保留在原源码中，不是当前论文分析。

GitHub 使用代码包内容。配套复现包包含输入、拟合参数与逐人输出，按原项目方式
与代码分开保存；`.gitignore` 已列出这些路径。
