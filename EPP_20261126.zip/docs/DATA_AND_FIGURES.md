# Data and figure paths

The reproduction companion supplies aligned input tables, model checkpoints, and
individual outputs. The supplementary ANOVA includes its own selected prediction
rows in the code archive.

| Data | Path |
| --- | --- |
| Main aligned inputs | `main_pvrnn/data/processed_epp_v6_20261020_131548_599411/` |
| Main frozen run | `main_pvrnn/results/epp_v6/20261020T142629_112453Z/` |
| Personalization minute inputs | `personalization/data/` |
| Bundled models and A | `personalization/bundled/` |
| Held-out personalization results | `personalization/results/formal_20261028_180424_097163/validation/` |
| Four-phase simulation | `personalization/results/formal_fourphase_20261125/` |
| ANOVA predictions | `supplementary/anova/data/participant_loo_predictions.csv` |

The source cohort has 102 sessions / 22 participants before the personalization
partition. Its 16 complete report-linked sessions provide the main model comparison.

| Figure | Source |
| --- | --- |
| Figure 5 model comparison | `figures/main/prepare_data.py` and `plot_main.py` |
| Figure 6 personalized simulation | `figures/common_environment/plot_figure6.py` |
| Archived reconstruction example | `plot_main.py --figure legacy6` |
| Conceptual assets from October snapshot | `figures/assets/` |

Figure 6 replaces only the plotted paths and phase markers in the archived vector
layout. Fonts, units, labels, and page geometry remain those of the supplied
reference. It reads the saved four-phase outputs without shifting their times.
Figures 1–4 assets retain their October snapshot identities; subsequent manuscript
redraws are outside this code update.

Machine fields: `IndoorTemperature` = Indoor T, `IndoorCO2` = CO2, `TEMP` = Skin T,
`EngageScore` = engagement. `SIMPLE_RNN` = RNN, `NO_ER` = PV-RNN without ER,
`ERROR_REGRESSION` = PV-RNN. `TRAINING_MEAN` is a reference, not an ANOVA condition.
`personal`, `zero`, and `local10` identify the three personalization A conditions.
