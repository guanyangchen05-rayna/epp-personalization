# 计算逻辑

主分析、personalization 和补充 ANOVA 分别使用不同的评价单位。

## 主分析

`main_pvrnn/epp_v6/` 保留正式 v6 实现。五通道顺序为 Indoor T、CO2、EDA、HR、
Skin T；机器字段 `TEMP` 指 Skin T。共享 PV-RNN 有 668 个参数；快慢确定性维度
8/4、随机维度 3/2，时间常数 2/5。报告头读取最终有效状态。

重建与 KL 更新训练 A；报告损失更新共享网络和报告头，不直接更新 A。
Participant-LOO 为 11 折，Date-LOO 为四折，五个 seed 为 11、23、37、51、71。
主要误差先取每个 session 的五 seed 预测中位数，再计算 16 个 session 等权的
pooled RMSE。固定预测的 cluster bootstrap 使用 2,000 次重采样。

PV-RNN 与 PV-RNN without ER 共用训练网络，后者将 A 固定为零。RNN 直接读取
观测序列。原始机器键保留 `ERROR_REGRESSION`、`NO_ER`、`SIMPLE_RNN`。

## Personalization

共享训练为 87 sessions / 22 人 / 九条报告；历史校准为 34 sessions / 1,841 分钟。
11 个目标 session 共 625 分钟，其中七个有完整报告。目标及同人重叠或更晚记录
从共享训练中排除，历史校准记录也参与共享训练。

每个 seed 的二维慢层 posterior-mean offsets 在冻结网络下重新校准 600 步。
目标推断使用最多十个保留分钟的窗口，每步 ER 100 次，学习率 0.05。
`personal` 固定二维历史值并更新其余八维；`zero` 固定二维为零并更新八维；
`local10` 更新全部十维。三者均冻结网络，不使用目标报告优化。

共同环境模拟有独立的恒定对照和四阶段变化情景，各自重置循环状态及局部 A。
四阶段样本为 0–9 恒定、10–19 上升、20–29 下降、30–39 波动；首次非基准输入
位于 minute 11。原基准、幅度和五分钟变化约束保持不变。

个人环境响应调制为：

`[personal(changing) - personal(stable)] - [zero(changing) - zero(stable)]`

主要汇总窗口为 `11 <= minute < 40`。三个 seed 的预测先取 mean，再计算生理
分钟等权及报告 session 等权的误差。二维 A 不跨 seed 混合使用。

## 补充 ANOVA

仅比较 Participant-LOO 的三个模型。每个 session 先取五 seed 预测中位数，
计算平方误差，再按参与者平均，构成每项报告的 11 人 × 3 模型 MSE 表。
三个单因素重复测量检验均采用 GG 校正，再对三个 p 值做 Holm 校正。
该分析让参与者等权，区别于主体 session 等权的 RMSE；不涉及 personalization。
