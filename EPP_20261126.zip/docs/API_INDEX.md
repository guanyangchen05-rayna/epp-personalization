# Source index

| Module | Top-level functions and classes |
| --- | --- |
| `main_pvrnn/epp_v6/__init__.py` |  |
| `main_pvrnn/epp_v6/behavior.py` | `metrics`, `bootstrap`, `run_behavior` |
| `main_pvrnn/epp_v6/chain.py` | `align_reports`, `training_reports`, `report_record`, `_summary`, `summarize_chain` |
| `main_pvrnn/epp_v6/data.py` | `sha256`, `read_csv`, `session_keys`, `Cohort`, `load_cohort`, `scaled_training`, `transform`, `outer_folds` |
| `main_pvrnn/epp_v6/individual.py` | `profile_parameter`, `_checkpoint`, `describe`, `score_hidden_physiology`, `validate`, `recovery` |
| `main_pvrnn/epp_v6/model.py` | `Settings`, `seed_all`, `pad`, `valid_mask`, `window_ids_tensor`, `minute_gaps`, `gaussian_kl`, `FiveArrowPVRNN`, `objective`, `diagnostics`, `frozen`, `infer`, `train`, `SimpleRNN`, `train_simple` |
| `main_pvrnn/epp_v6/plots.py` | `save`, `architecture`, `make_figures` |
| `main_pvrnn/epp_v6/startup.py` | `complete`, `fingerprint`, `choose_tables`, `remember_tables`, `run_visible`, `preflight_and_run` |
| `personalization/backbone.py` | `PositiveEDAHead`, `make_backbone` |
| `personalization/data_io.py` | `Data`, `key`, `load_data`, `partition`, `training_payload`, `write_partition` |
| `personalization/experiment.py` | `trajectory_frame`, `run_simulations`, `run_validation`, `completed_inputs`, `main` |
| `personalization/online_inference.py` | `weight_hash`, `condition_parameters`, `fit_window`, `OnlineER`, `physical_and_reports`, `infer_sequence` |
| `personalization/personal_a.py` | `sha`, `load_shared`, `compose_A`, `losses`, `_clip_independent`, `fit_profiles`, `fit_local`, `OnlinePersonalA`, `save_profile`, `load_profile` |
| `personalization/plots.py` | `figure3_axes`, `save_figure`, `personal_legend`, `simulation_plot`, `response_plot`, `environment_error_plot`, `validation_plot`, `make_simulation_plots`, `make_validation_plots`, `make_all_plots` |
| `personalization/protocol.py` | `Config`, `config_for`, `sha_file`, `digest`, `write_json`, `write_csv`, `code_hashes`, `mark_stage`, `stage_complete`, `config_dict`, `verify_bundled` |
| `personalization/run_project.py` | `child_run`, `diagnose`, `run`, `main` |
| `personalization/scenarios.py` | `simulation_config`, `four_phase_wave`, `make_scenarios` |
| `personalization/summaries.py` | `scenario_timing`, `summarize_response_windows`, `seed_mean`, `error_table`, `summarize_simulation`, `report_endpoints`, `summarize_validation`, `summarize_all` |
| `personalization/test_mechanism.py` | `MechanismTests` |
| `personalization/training.py` | `training_signature`, `ensure_model`, `calibration_signature`, `ensure_profiles`, `verified_profiles` |
| `personalization/v6_dynamics.py` | `State`, `zero_state`, `forward` |
| `analysis/audit_main_and_scope.py` | `rmse` |
| `analysis/audit_personalization_fourphase.py` | `sha`, `main` |
| `analysis/audit_personalization_offsets_and_contrasts.py` | `read_tensor_checkpoint` |
| `analysis/check_offset_correspondence.py` | `corr`, `ranks`, `analyse` |
| `supplementary/anova/run_anova.py` | `holm`, `rm_anova_gg`, `read_predictions`, `aggregate_predictions`, `analyze`, `sha256`, `main` |
