"""Render four-phase Figure 6 using the manuscript vector layout."""
from pathlib import Path
import re,json,hashlib
import fitz
import numpy as np
import pandas as pd

import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run',type=Path)
parser.add_argument('--output',type=Path)
args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[2]
OUT=(args.output or Path(__file__).resolve().parent).resolve()
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'tmp').mkdir(exist_ok=True)
REFERENCE=ROOT/'figures/assets/Figure6_layout_reference.pdf'
OLD=ROOT/'personalization/results/formal_20261028_180424_097163'
NEW=(args.run or ROOT/'personalization/results/formal_fourphase_20261125').resolve()
people=[1,2,4,15,16,17,18,19,20,21,22]
variables=['IndoorTemperature','IndoorCO2','EDA','HR','TEMP','EngageScore','Arousal','Valence']
old=pd.read_csv(OLD/'simulation/trajectories_seed_mean.csv')
new=pd.read_csv(NEW/'simulation/trajectories_seed_mean.csv')
old=old[old.scenario=='stable_then_fluctuating'];new=new[new.scenario=='stable_then_fluctuating']
old_e=pd.read_csv(OLD/'protocol/scenarios.csv');old_e=old_e[old_e.scenario=='stable_then_fluctuating']
new_e=pd.read_csv(NEW/'protocol/scenarios.csv');new_e=new_e[new_e.scenario=='stable_then_fluctuating']
doc=fitz.open(REFERENCE);page=doc[0];height=page.rect.height
original_text=page.get_text('dict')
# Page coordinates from the reference's eight white panel backgrounds.
panels=[d['rect'] for d in page.get_drawings() if d['type']=='f' and d['fill']==(1.,1.,1.) and abs(d['rect'].width-628.35588)<.01 and abs(d['rect'].height-71.21002)<.01]
assert len(panels)==8
xleft=panels[0].x0;xright=panels[0].x1
counts=[0]*8;changed={'traces':0,'shading':0,'phase_markers':0,'onset_markers':0};residual=[]
num=r'-?(?:\d+(?:\.\d*)?|\.\d+)'
block=re.compile(r'q\s+(?P<box>'+num+r'\s+'+num+r'\s+'+num+r'\s+'+num+r')\s+re W n(?P<body>.*?)\bQ\b',re.S)
path_pattern=re.compile(r'(?P<path>(?:'+num+r'\s+'+num+r'\s+[ml]\s*)+)\s*S',re.S)
point_pattern=re.compile('('+num+r')\s+('+num+r')\s+([ml])')
stream=b'\n'.join(doc.xref_stream(x) for x in page.get_contents()).decode('latin1')
source_box=list(map(float,block.search(stream).group('box').split()))
xleft=source_box[0];xright=xleft+source_box[2]
# Recover each original numerical axis transform from its tick labels/grid lines.
spans=[s for b in original_text['blocks'] for line in b.get('lines',[]) for s in line['spans']]
scales=[]
for panel in panels:
    labels=[s for s in spans if s['size']==10.5 and 100<s['bbox'][0] and s['bbox'][2]<122
            and panel.y0-3 < (s['bbox'][1]+s['bbox'][3])/2 < panel.y1+3]
    grids=[d['rect'].y0 for d in page.get_drawings() if d['type']=='s' and d.get('color')
           and abs(d['color'][0]-.9294117647)<1e-6 and abs(d['rect'].width-panel.width)<.01
           and d['rect'].height<.001 and panel.y0<=d['rect'].y0<=panel.y1]
    values=[];positions=[]
    for label in labels:
        value=float(label['text'])
        cy=(label['bbox'][1]+label['bbox'][3])/2
        y=min(grids,key=lambda y:abs(y-cy))
        assert abs(y-cy)<3
        values.append(value);positions.append(height-y)
    assert len(values)>=2
    scales.append(np.polyfit(values,positions,1))


def coordinates(values,minutes,slope,intercept,step=False):
    xx=xleft+np.asarray(minutes)/40*(xright-xleft)
    yy=np.asarray(values)*slope+intercept
    if step:
        pts=[(xx[0],yy[0])]
        for k in range(1,len(xx)):
            pts += [(xx[k],yy[k-1]),(xx[k],yy[k])]
        pts.append((xright,yy[-1]))
    else:pts=list(zip(xx,yy))
    return '\n'.join(f'{x:.6f} {y:.6f} '+('m' if i==0 else 'l') for i,(x,y) in enumerate(pts))+'\n\n'

def replace_block(match):
    box=list(map(float,match.group('box').split()))
    if abs(box[0]-xleft)>.01 or abs(box[2]-(xright-xleft))>.01:return match.group(0)
    row=int(np.argmin([abs((height-r.y1)-box[1]) for r in panels]))
    assert abs(height-panels[row].y1-box[1])<.001
    body=match.group('body')
    # Exactly preserve original shading color and its initial-stable meaning.
    if '0.9607843137 0.968627451' in body and re.search(r'\bB\b',body):
        old_boundary=f'{xleft+(xright-xleft)*.5:.6f}'
        new_boundary=f'{xleft+(xright-xleft)*.25:.6f}'
        assert old_boundary in body
        body=body.replace(old_boundary,new_boundary)
        changed['shading']+=1
    elif re.search(r'\[\s*0\.78\s+1\.365\s*\]\s+0 d',body):
        pm=path_pattern.search(body);assert pm
        y0,y1=box[1],box[1]+box[3]
        paths=[]
        for t in [10,20,30]:
            x=xleft+t/40*(xright-xleft)
            paths.append(f'{x:.6f} {y0:.6f} m\n{x:.6f} {y1:.6f} l\n\nS\n')
        # The tail contains the original S, so the replacement includes all S's.
        body=body[:pm.start()]+''.join(paths)+body[pm.end():]
        changed['phase_markers']+=1
    elif re.search(r'\[\s*2\.6\s+1\.95\s*\]\s+0 d',body):
        pm=path_pattern.search(body);assert pm
        x=xleft+11/40*(xright-xleft)
        body=body[:pm.start('path')]+f'{x:.6f} {box[1]:.6f} m\n{x:.6f} {box[1]+box[3]:.6f} l\n\n'+body[pm.end('path'):]
        changed['onset_markers']+=1
    elif re.search(r'\b(?:0\.8|1\.15|1\.25) w\b',body):
        pm=path_pattern.search(body);assert pm
        pts=point_pattern.findall(pm.group('path'))
        yy=np.array([float(y) for x,y,op in pts])
        variable=variables[row]
        index=counts[row]
        if row<2:
            a,b=scales[row]
            values=new_e[variable].to_numpy();minutes=new_e.minute.to_numpy()
            new_path=coordinates(values,minutes,a,b,step=True)
        else:
            condition='personal' if index<11 else ('zero' if index==11 else 'local10')
            pid=people[index] if index<11 else 0
            query=lambda d:d[(d.variable==variable)&(d.condition==condition)&(d.Pid==pid)].sort_values('minute')
            g0=query(old);g1=query(new)
            assert len(g0)==len(g1)==len(yy)==40
            a,b=scales[row]
            error=float(np.max(np.abs(a*g0.prediction.to_numpy()+b-yy)))
            # Reference numeric axes are retained exactly; old-run differences are diagnostic only.
            residual.append(error)
            values=g1.prediction.to_numpy();minutes=g1.minute.to_numpy()
            mapped=a*values+b
            assert mapped.min()>=box[1]-.01 and mapped.max()<=box[1]+box[3]+.01,(variable,pid,'would clip')
            new_path=coordinates(values,minutes,a,b)
        body=body[:pm.start('path')]+new_path+body[pm.end('path'):]
        counts[row]+=1;changed['traces']+=1
    return match.group(0)[:match.start('body')-match.start()]+body+'Q'

updated=block.sub(replace_block,stream)
assert counts==[1,1,13,13,13,13,13,13],counts
assert changed=={'traces':80,'shading':8,'phase_markers':8,'onset_markers':8},changed
contents=page.get_contents();doc.update_stream(contents[0],updated.encode('latin1'));page.set_contents(contents[0])
pdf=OUT/'Figure6_fourphase_matched119.pdf'
doc.save(pdf,garbage=4,deflate=True)
doc.close()
result=fitz.open(pdf);pg=result[0]
# Verify the template's text, fonts, sizes, and positions after replacing paths.
def text_spans(p):
    return [{k:s[k] for k in ['text','font','size','bbox','color','origin']} for b in p.get_text('dict')['blocks'] for line in b.get('lines',[]) for s in line['spans']]
with fitz.open(REFERENCE) as ref:
    assert pg.rect==ref[0].rect
    assert text_spans(pg)==text_spans(ref[0])
pg.get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False).save(OUT/'Figure6_fourphase_matched119.png')
(OUT/'Figure6_fourphase_matched119.svg').write_text(pg.get_svg_image(text_as_path=True))
pg.get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False).save(OUT/'tmp/result_preview.png')
(OUT/'tmp/verification.json').write_text(json.dumps(dict(changed=changed,all_text_fonts_sizes_units_positions_exactly_preserved=True,page_size=list(pg.rect),max_original_trace_transform_fit_residual=max(residual),simulation_values_changed=False,source_pdf_sha256=hashlib.sha256(REFERENCE.read_bytes()).hexdigest()),indent=2)+'\n')
print(json.dumps({'files':[str(pdf),str(OUT/'Figure6_fourphase_matched119.png'),str(OUT/'Figure6_fourphase_matched119.svg')],'changed':changed,'text_style_exact':True,'max_residual':max(residual)}))
