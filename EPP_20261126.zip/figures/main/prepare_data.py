"""Rebuild current Figure 5-7 input tables from main/v2 saved outputs."""
from pathlib import Path
import argparse
import shutil
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT/'main_pvrnn'
RUN = MAIN/'results/epp_v6/20261020T142629_112453Z/behavior_11'
sys.path.insert(0, str(MAIN))
from epp_v6.data import load_cohort, scaled_training, CHANNELS, TARGETS


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'reproduced/figure_data')
    a=parser.parse_args();d=a.output;d.mkdir(parents=True,exist_ok=True)
    cohort=load_cohort(MAIN/'data/processed_epp_v6_20261020_131548_599411','11')
    pred=pd.read_csv(RUN/'out_of_fold_predictions.csv')
    assert len(pred)==1920 and not pred.duplicated(['protocol','seed','Pid','Class_id','target','mode']).any()
    pred.to_csv(d/'out_of_fold_predictions.csv',index=False)
    shutil.copyfile(RUN/'performance_summary.csv',d/'original_performance_summary.csv')
    rows=[]
    for (protocol,seed,mode,target),g in pred.groupby(['protocol','seed','mode','target']):
        rmse=np.sqrt(np.mean((g.observed-g.prediction)**2))
        base=np.sqrt(np.mean((g.observed-g.baseline)**2))
        rows.append(dict(protocol=protocol,seed=seed,mode=mode,target=target,RMSE=rmse,RelativeRMSE=rmse/base))
    metrics=pd.DataFrame(rows);metrics.to_csv(d/'LOO_seed_metrics.csv',index=False)
    med=pred.groupby(['protocol','Pid','Class_id','target','mode'],as_index=False).agg(prediction=('prediction','median'),observed=('observed','first'))
    med['absolute_error']=abs(med.prediction-med.observed)
    pp=med.groupby(['protocol','Pid','target','mode']).absolute_error.mean().unstack('mode')
    pp['MAE_decrease_ER_vs_NO_ER']=pp.NO_ER-pp.ERROR_REGRESSION
    pp.reset_index().to_csv(d/'LOO_participant_MAE_change.csv',index=False)
    diag=pd.read_csv(RUN/'reconstruction_diagnostics.csv')
    w=diag[diag.protocol.eq('PARTICIPANT_LOO')].pivot(index=['Pid','Class_id','seed'],columns='mode',values='MSE_all')
    w['reduction']=1-w.ERROR_REGRESSION/w.NO_ER
    session=w.groupby(['Pid','Class_id']).reduction.median()
    pid,cid=map(int,(session-session.median()).abs().idxmin())
    idx=int(cohort.meta.index[cohort.meta.Pid.eq(str(pid))&cohort.meta.Class_id.eq(str(cid))][0])
    train_idx=np.flatnonzero(~cohort.meta.Pid.eq(str(pid)))
    scaler,_=scaled_training(cohort,train_idx)
    records=[]
    for seed in sorted(pred.seed.unique()):
        q=pd.read_csv(RUN/f'PARTICIPANT_LOO_{pid}_seed_{seed}_session_{idx}_reconstruction.csv');q['seed']=seed
        assert np.array_equal(q.window_id.to_numpy(),cohort.times[idx])
        observed=q[['observed_'+x for x in CHANNELS]].to_numpy()
        assert np.allclose(observed,cohort.arrays[idx],atol=2e-5)
        for mode in ['NO_ER','ERROR_REGRESSION']:
            rec=q[[mode+'_'+x for x in CHANNELS]].to_numpy()
            q[mode+'_MSE_standardized']=np.mean(((observed-rec)/scaler.scale_)**2,axis=1)
            q[mode+'_MSE_physiology_standardized']=np.mean(((observed[:,2:]-rec[:,2:])/scaler.scale_[2:])**2,axis=1)
            assert np.isclose(q[mode+'_MSE_standardized'].mean(),float(w.loc[(pid,cid,seed),mode]),rtol=2e-5,atol=2e-7)
        records.append(q)
    pd.concat(records,ignore_index=True).to_csv(d/'ER_representative_reconstruction_by_seed.csv',index=False)
    pred[pred.protocol.eq('PARTICIPANT_LOO')&pred.Pid.eq(pid)&pred.Class_id.eq(cid)].to_csv(d/'ER_representative_report_predictions.csv',index=False)
    w.reset_index().to_csv(d/'ER_case_selection_all_sessions_by_seed.csv',index=False)
    print(f"Figure 6: P{pid}, session {cid}; wrote main plotting tables to {d}")

if __name__ == "__main__":
    main()
