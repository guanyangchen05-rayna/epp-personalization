"""Compact Results figures from real output tables; no training or inference."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

ROOT=Path(__file__).resolve().parent;D=ROOT/'data';F=ROOT/'figures';F.mkdir(exist_ok=True)
INK='#3B4751';MUTED='#7A8790';GRID='#E9EDF0';EDGE='#CCD4DA';GRAY='#9DA7AE'
BLUE='#7E9FBC';PURPLE='#A293BC';GREEN='#82A897';YELLOW='#BDB579';RED='#BA8B93'
MC={'SIMPLE_RNN':BLUE,'NO_ER':PURPLE,'ERROR_REGRESSION':GREEN}
TARGETS=['EngageScore','Arousal','Valence'];NAMES={'EngageScore':'Engagement','Arousal':'Arousal','Valence':'Valence'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8.8,'axes.labelsize':8,
    'xtick.labelsize':7.3,'ytick.labelsize':7.3,'text.color':INK,'axes.labelcolor':INK,'axes.edgecolor':EDGE,
    'xtick.color':MUTED,'ytick.color':MUTED,'axes.spines.top':False,'axes.spines.right':False,
    'svg.fonttype':'none','pdf.fonttype':42,'lines.solid_capstyle':'round','axes.titleweight':'bold',
    'legend.frameon':False,'savefig.facecolor':'white'})
LAYOUT=[]
def clean(ax,axis='y'):
    ax.set_axisbelow(True);ax.grid(axis=axis,color=GRID,lw=.6);ax.tick_params(length=2.5,width=.55)
def save(fig,name):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();outside=[]
    ticks=[t for ax in fig.axes for t in ax.get_xticklabels()+ax.get_yticklabels()]
    for obj in fig.findobj(matplotlib.text.Text):
        if not obj.get_visible() or not obj.get_text() or obj in ticks:continue
        b=obj.get_window_extent(renderer)
        if b.width<=0 or b.height<=0:continue
        if b.x0<-2 or b.y0<-2 or b.x1>fig.bbox.width+2 or b.y1>fig.bbox.height+2:outside.append(obj.get_text())
    if outside:raise AssertionError((name,outside))
    LAYOUT.append({'figure':name,'text_outside_canvas':outside,'axes_count':len(fig.axes),
        'width_inches':fig.get_figwidth(),'height_inches':fig.get_figheight()})
    for ext in ['pdf','svg','png']:
        tmp=F/f'.{name}.{ext}.tmp'
        fig.savefig(tmp,format=ext,dpi=300 if ext=='png' else 150,
            bbox_inches='tight' if name=='Figure_6_ER_state_adaptation' else None,pad_inches=.04)
        tmp.replace(F/f'{name}.{ext}')
    plt.close(fig)

def figure5():
    metrics=pd.read_csv(D/'LOO_seed_metrics.csv').query("protocol=='PARTICIPANT_LOO'")
    person=pd.read_csv(D/'LOO_participant_MAE_change.csv').query("protocol=='PARTICIPANT_LOO'")
    modes=['SIMPLE_RNN','NO_ER','ERROR_REGRESSION'];seeds=sorted(metrics.seed.unique());pids=sorted(person.Pid.unique())
    fig=plt.figure(figsize=(7.3,5.55))
    gs=fig.add_gridspec(2,3,left=.095,right=.985,bottom=.19,top=.875,hspace=.33,wspace=.31,height_ratios=[1,1.38])
    vals=metrics.RelativeRMSE.to_numpy();ylim=(min(.90,vals.min()-.04),vals.max()+.055)
    person['MAE_decrease_ER_vs_RNN']=person.SIMPLE_RNN-person.ERROR_REGRESSION
    person.to_csv(D/'LOO_participant_two_comparisons.csv',index=False)
    bound=np.abs(person[['MAE_decrease_ER_vs_NO_ER','MAE_decrease_ER_vs_RNN']].to_numpy()).max()*1.12
    for col,target in enumerate(TARGETS):
        ax=fig.add_subplot(gs[0,col]);q=metrics[metrics.target.eq(target)]
        for k,seed in enumerate(seeds):
            yy=q[q.seed.eq(seed)].set_index('mode').loc[modes,'RelativeRMSE'].to_numpy();xx=np.arange(3)+(k-2)*.035
            ax.plot(xx,yy,color=EDGE,lw=.65,zorder=1)
            for j,m in enumerate(modes):ax.scatter(xx[j],yy[j],s=14,color=MC[m],zorder=3)
        for j,m in enumerate(modes):ax.scatter(j,q[q['mode'].eq(m)].RelativeRMSE.median(),s=39,marker='_',linewidths=2,color=INK,zorder=5)
        ax.axhline(1,color=GRAY,ls=(0,(3,3)),lw=.8);ax.set_xticks([0,1,2],['RNN','PV-RNN\nwithout ER','PV-RNN'])
        ax.set_xlim(-.33,2.33);ax.set_ylim(*ylim);ax.set_title(NAMES[target],pad=10);ax.yaxis.set_major_locator(MaxNLocator(5));clean(ax)
        if col==0:ax.set_ylabel('Relative RMSE')
        ax=fig.add_subplot(gs[1,col]);q=person[person.target.eq(target)].set_index('Pid').loc[pids]
        yy=np.arange(len(pids));ax.axvline(0,color=GRAY,lw=.8,ls=(0,(3,3)))
        for field,color,marker,offset in [('MAE_decrease_ER_vs_RNN',BLUE,'o',-.15),('MAE_decrease_ER_vs_NO_ER',PURPLE,'^',.15)]:
            for y,val in zip(yy,q[field].to_numpy()):
                ax.plot([0,val],[y+offset,y+offset],color=color,lw=.85,alpha=.72)
                ax.scatter(val,y+offset,color=color,marker=marker,s=16,zorder=3)
        ax.set_yticks(yy,[f'P{p}' for p in pids]);ax.set_ylim(len(pids)-.5,-.5);ax.set_xlim(-bound,bound)
        ax.text(.01,1.035,'PV-RNN error higher',transform=ax.transAxes,color=MUTED,ha='left',fontsize=6.8)
        ax.text(.99,1.035,'PV-RNN error lower',transform=ax.transAxes,color=MUTED,ha='right',fontsize=6.8)
        ax.xaxis.set_major_locator(MaxNLocator(3));clean(ax,'x')
    fig.supxlabel('MAE difference (scale points)',x=.54,y=.095,fontsize=8.5)
    handles=[Line2D([],[],ls='',marker='o',color=GRAY,markersize=3,label='Training seed'),
             Line2D([],[],ls='',marker='_',color=INK,markersize=7,markeredgewidth=2,label='Median'),
             Line2D([],[],ls=(0,(3,3)),color=GRAY,label='Training-mean reference')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.53,.993),ncol=3,fontsize=7.3,columnspacing=1.8,handlelength=1.8)
    fig.legend(handles=[Line2D([],[],color=BLUE,marker='o',lw=.8,markersize=4,label='RNN vs PV-RNN'),
        Line2D([],[],color=PURPLE,marker='^',lw=.8,markersize=4,label='PV-RNN without ER vs PV-RNN')],
        loc='lower center',bbox_to_anchor=(.54,.008),ncol=2,fontsize=7.5,columnspacing=2)
    save(fig,'Figure_5_LOO_performance')

def figure6():
    q=pd.read_csv(D/'ER_representative_reconstruction_by_seed.csv');p=pd.read_csv(D/'ER_representative_report_predictions.csv')
    fig=plt.figure(figsize=(7.3,5.45))
    gs=fig.add_gridspec(3,6,left=.09,right=.98,bottom=.09,top=.825,hspace=1.02,wspace=.82,height_ratios=[1,.84,1])
    time=q.groupby('window_id').first().index.to_numpy()+.5;time_axes=[]
    for col,(var,title,unit) in enumerate([('IndoorTemperature','Temperature','°C'),('IndoorCO2','CO₂','ppm')]):
        ax=fig.add_subplot(gs[0,col*3:(col+1)*3],sharex=time_axes[0] if time_axes else None);time_axes.append(ax)
        ax.plot(time,q.groupby('window_id')['observed_'+var].first(),color=INK,lw=1,label='Recorded')
        for mode in ['NO_ER','ERROR_REGRESSION']:ax.plot(time,q.groupby('window_id')[mode+'_'+var].median(),color=MC[mode],lw=1.55)
        ax.set_title(title,loc='left',pad=5);ax.set_ylabel(unit);ax.set_xlim(time.min(),time.max());ax.tick_params(labelbottom=False);clean(ax)
    ax=fig.add_subplot(gs[1,:],sharex=time_axes[0]);phys_ax=ax
    for mode in ['NO_ER','ERROR_REGRESSION']:
        h=q.groupby('window_id')[mode+'_MSE_physiology_standardized'];m=h.median();lo=h.quantile(.25);hi=h.quantile(.75)
        ax.fill_between(time,lo.to_numpy(),hi.to_numpy(),color=MC[mode],alpha=.16,lw=0);ax.plot(time,m,color=MC[mode],lw=1.55)
    ax.set_ylabel('Standardized MSE');ax.set_xlabel('Classroom minute',labelpad=3);ax.set_ylim(bottom=0);ax.yaxis.set_major_locator(MaxNLocator(4));clean(ax)
    report_axes=[]
    for col,target in enumerate(TARGETS):
        ax=fig.add_subplot(gs[2,col*2:col*2+2]);report_axes.append(ax);g=p[p.target.eq(target)];vals=[]
        for x,mode in enumerate(['NO_ER','ERROR_REGRESSION']):
            a=g[g['mode'].eq(mode)].sort_values('seed').prediction.to_numpy();vals.append(float(np.median(a)))
            ax.scatter(x+np.linspace(-.065,.065,len(a)),a,color=MC[mode],s=11,alpha=.6,zorder=3)
            ax.scatter(x,np.median(a),s=33,color=MC[mode],edgecolor='white',linewidth=.65,zorder=5)
        ax.plot([0,1],vals,color=GRAY,lw=.8,zorder=1);ax.scatter(2,float(g.observed.iloc[0]),marker='D',color=INK,s=29,zorder=5)
        ax.axvspan(1.55,2.45,color=GRID,alpha=.55,zorder=0);ax.set_xticks([0,1,2],['No-ER','ER','Report']);ax.set_xlim(-.35,2.45)
        ax.set_ylim(.75,5.3 if target=='EngageScore' else 4.3);ax.set_yticks(range(1,6 if target=='EngageScore' else 5))
        ax.set_title(NAMES[target],loc='left',pad=5);clean(ax)
        if col==0:ax.set_ylabel('Scale points')
    c_header_y=report_axes[0].get_position().y1+.043
    for ax in report_axes:
        pos=ax.get_position();ax.set_position([pos.x0,pos.y0-.03,pos.width,pos.height])
    for y,label in [(.945,'A  Environment signal reconstruction'),
                    (phys_ax.get_position().y1+.052,'B  Physiological sensory reconstruction error'),
                    (c_header_y,'C  Engagement and affect estimates')]:
        fig.text(.05,y,label,fontsize=9.5,weight='bold',va='center')
    fig.legend(handles=[Line2D([],[],color=INK,lw=1,label='Recorded'),Line2D([],[],color=PURPLE,lw=1.55,label='No-ER'),Line2D([],[],color=GREEN,lw=1.55,label='ER')],loc='center right',bbox_to_anchor=(.985,.945),ncol=3,fontsize=7.5)
    save(fig,'Figure_6_ER_state_adaptation')


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Plot main model comparison or archived reconstruction example.')
    parser.add_argument('--figure', choices=['5', 'legacy6', 'all'], default='5')
    args = parser.parse_args()
    if args.figure in ['5', 'all']: figure5()
    if args.figure in ['legacy6', 'all']: figure6()
    (ROOT/"LAYOUT_CHECK.json").write_text(json.dumps(LAYOUT, indent=2))
    print("Selected figures exported.")
