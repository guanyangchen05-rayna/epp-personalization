"""Protocol and filesystem utilities. Standard library only: safe in Jupyter."""
from pathlib import Path
from dataclasses import dataclass, asdict, replace
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parent
PEOPLE = (1, 2, 4, 15, 16, 17, 18, 19, 20, 21, 22)
CHANNELS = ('IndoorTemperature', 'IndoorCO2', 'EDA', 'HR', 'TEMP')
REPORTS = ('EngageScore', 'Arousal', 'Valence')
VARIABLES = CHANNELS + REPORTS
CONDITIONS = ('personal', 'zero', 'local10')


@dataclass(frozen=True)
class Config:
    mode: str = 'formal'
    seeds: tuple = (11, 23, 37)
    train_epochs: int = 150
    calibration_steps: int = 600
    online_steps: int = 100
    window: int = 10
    scenario_minutes: int = 40
    scenario_switch: int = 20
    scenario_interval: int = 5
    scenario_amplitude_IQR_fraction: float = .25
    scenario_nearest_training_limit: float = .50
    validation_min_calibration_minutes: int = 20
    validation_modes: tuple = ('E_only', 'EP_online')
    validation_max_minutes: int = 0
    validation_pids: tuple = PEOPLE
    algorithm: str = 'v3_1_same_backbone_fixed2_local8_vs_local10'
    split_rule: str = 'latest_report_with_history_else_latest_EP; exclude_person_future'

    def validate(self):
        for name in ('train_epochs', 'calibration_steps', 'online_steps', 'window',
                     'scenario_minutes', 'scenario_switch', 'scenario_interval',
                     'validation_min_calibration_minutes'):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f'Positive integer required: {name}')
        if not 0 < self.scenario_switch < self.scenario_minutes:
            raise ValueError('Scenario switch must be internal')
        if (self.scenario_minutes-self.scenario_switch) % (2*self.scenario_interval):
            raise ValueError('Second half must have an even number of environment blocks')
        if (self.scenario_minutes-self.scenario_switch)//self.scenario_interval < 4:
            raise ValueError('At least four environment blocks required to avoid a degenerate sampled waveform')
        if self.scenario_switch % self.scenario_interval:
            raise ValueError('Switch must align with the five-minute input grid')
        if self.validation_max_minutes < 0 or len(set(self.seeds)) != len(self.seeds):
            raise ValueError('Invalid prefix budget or duplicate seeds')
        if self.mode == 'formal' and self.validation_max_minutes:
            raise ValueError('Formal validation must use complete records')
        return self


def config_for(mode):
    c = Config()
    if mode == 'quickcheck':
        c = replace(c, mode=mode, seeds=(11,), train_epochs=3,
                    calibration_steps=5, online_steps=4, window=3,
                    scenario_minutes=40, scenario_switch=20,
                    validation_max_minutes=4, validation_pids=(18, 19))
    elif mode != 'formal':
        raise ValueError('Mode must be formal or quickcheck')
    return c.validate()


def sha_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n',
                   encoding='utf-8')
    os.replace(tmp, path)


def write_csv(path, frame):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    frame.to_csv(tmp, index=False)
    os.replace(tmp, path)


def code_hashes():
    names = ['protocol.py', 'data_io.py', 'training.py', 'online_inference.py',
             'scenarios.py', 'experiment.py', 'summaries.py',
             'personal_a.py', 'backbone.py', 'v6_dynamics.py',
             'v6_reference/model.py', 'v6_reference/data.py']
    return {n: sha_file(ROOT/n) for n in names}


def mark_stage(run, name, signature, paths):
    files = {str(Path(p).relative_to(run)): sha_file(p) for p in paths}
    write_json(Path(run)/'stages'/(name+'.json'),
               dict(signature=signature, files=files, complete=True))


def stage_complete(run, name, signature):
    f = Path(run)/'stages'/(name+'.json')
    if not f.is_file():
        return False
    m = json.loads(f.read_text(encoding='utf-8'))
    if m.get('signature') != signature:
        raise ValueError(f'Cached stage {name} belongs to a different protocol')
    for n, expected in m['files'].items():
        p = Path(run)/n
        if not p.is_file() or sha_file(p) != expected:
            raise ValueError(f'Cached output changed/missing: {p}; use a fresh run')
    return bool(m.get('complete'))


def config_dict(c):
    # JSON canonical representation: tuples become lists consistently.
    return json.loads(json.dumps(asdict(c)))


def verify_bundled():
    folder = ROOT/'bundled'
    manifest = folder/'manifest.json'
    if not manifest.is_file():
        if folder.exists() and any(folder.glob('*.pt')):
            raise ValueError('Bundled checkpoints have no integrity manifest; use a complete package or force a fresh training run')
        return {}
    m = json.loads(manifest.read_text(encoding='utf-8'))
    for name, expected in m['files_sha256'].items():
        path = folder/name
        if not path.is_file() or sha_file(path) != expected:
            raise ValueError(f'Bundled file missing/modified: {name}; restore package or explicitly force retraining')
    return m
