@echo off
cd /d "%~dp0"
python run_project.py --mode formal --phase all
pause
