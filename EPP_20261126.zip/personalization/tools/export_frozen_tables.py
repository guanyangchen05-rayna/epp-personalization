"""Optional reproducible export from the original frozen archive.

Run: python tools/export_frozen_tables.py --source-archive PATH --output NEW_DIR
The packaged minute tables are already exported; normal runs do not need this.
"""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
import numpy as np
import pandas as pd

CHANNELS = ['IndoorTemperature', 'IndoorCO2', 'EDA', 'HR', 'TEMP']


def export(source, output):
    output = Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError('Export destination must be new or empty; never overwrite active data')
    output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(source) as z:
        candidates = [n for n in z.namelist() if n.endswith('/processed_epp_v6_20261020_131548_599411/envphys_session_analysis.csv')]
        if len(candidates) != 1:
            raise ValueError('Expected one exact frozen metadata file')
        mn = candidates[0]; tn = mn.rsplit('/', 1)[0]+'/envphys_temporal_1s.csv'
        m = pd.read_csv(z.open(mn)); temporal = pd.read_csv(z.open(tn), parse_dates=['DateTime'])
        if (len(m), m.Pid.nunique(), int(m.StrictBehaviorReady.sum())) != (102, 22, 16):
            raise ValueError('Wrong source cohort')
        groups = dict(tuple(temporal.groupby(['Pid', 'Class_id'], sort=False)))
        rows, counts = [], []
        for r in m.itertuples(index=False):
            g = groups[(r.Pid, r.Class_id)].sort_values('DateTime').copy()
            if g.DateTime.duplicated().any() or not g.DateTime.between(pd.Timestamp(r.ClassStart), pd.Timestamp(r.ClassEnd)).all():
                raise ValueError('Invalid source timestamps')
            g = g[np.isfinite(g[CHANNELS].to_numpy(float)).all(1)].copy()
            if len(g) != r.n_complete_env_phys_seconds:
                raise ValueError('Source complete-second count mismatch')
            g['minute'] = np.floor((g.DateTime-pd.Timestamp(r.ClassStart)).dt.total_seconds()/60).astype(int)
            count = 0
            for minute, w in g.groupby('minute', sort=True):
                if len(w) < 30: continue
                values = w[CHANNELS].mean().to_numpy(np.float32)
                rows.append(dict(Pid=int(r.Pid), Class_id=int(r.Class_id), minute=int(minute),
                                 **dict(zip(CHANNELS, map(float, values)))))
                count += 1
            if not count: raise ValueError('No retained minute')
            counts.append(count)
        keep = ['Pid', 'Class_id', 'ClassDate', 'ClassStart', 'ClassEnd', 'EnvironmentDateKey',
                'EnvironmentScope', 'ContextWindowKey', 'BehaviorLabelTime', 'BehaviorLabelLagMin',
                'EngageScore', 'Arousal', 'Valence', 'StrictBehaviorReady']
        m = m[keep].copy(); m['n_minutes'] = counts; m['has_report'] = m.StrictBehaviorReady.astype(bool)
        m = m.drop(columns='StrictBehaviorReady')
        m.loc[~m.has_report, ['EngageScore', 'Arousal', 'Valence']] = np.nan
        m.sort_values(['ClassStart', 'Pid', 'Class_id']).to_csv(output/'records.csv', index=False)
        d = pd.DataFrame(rows).sort_values(['Pid', 'Class_id', 'minute'])
        d.to_csv(output/'minutes.csv', index=False)
        info = dict(source_archive=Path(source).name,
                    source_metadata_sha256=hashlib.sha256(z.read(mn)).hexdigest(),
                    source_temporal_sha256=hashlib.sha256(z.read(tn)).hexdigest(),
                    aggregation='Original class-start 60-second bins; at least 30 jointly complete seconds; native means cast to float32. No EDA log transform or interpolation. Original minute IDs retained.',
                    n_records=len(m), n_people=int(m.Pid.nunique()), n_minutes=len(d),
                    n_complete_reports=int(m.has_report.sum()),
                    data_sha256={n: hashlib.sha256((output/n).read_bytes()).hexdigest() for n in ['records.csv', 'minutes.csv']},
                    environment_scope='shared school-level indoor context, not verified room/personal exposure')
        (output/'provenance.json').write_text(json.dumps(info, indent=2)+'\n')
        print(json.dumps(info, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-archive', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args(); export(a.source_archive, a.output)
