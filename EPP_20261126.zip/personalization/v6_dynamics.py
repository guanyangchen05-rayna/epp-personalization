"""Causal environment-conditioned PV-RNN ER, with record-specific A.

No network training, personal precision fitting, guessed missing history,
subject embedding, latent prior multiplier, or Gaussian observation noise.
Only the original A is optimized. Conditional outputs use posterior means.
"""
from dataclasses import dataclass
import numpy as np
import torch
from v6_reference.model import gaussian_kl

A_GROUPS=[('fast_mean_offset',0,3),('fast_logvariance_offset',3,6),
          ('slow_mean_offset',6,8),('slow_logvariance_offset',8,10)]

@dataclass
class State:
    fast: torch.Tensor
    slow: torch.Tensor
    minute: int | None

    def clone(self):
        return State(self.fast.detach().clone(),self.slow.detach().clone(),self.minute)

def zero_state(model,batch=1):
    return State(torch.zeros(batch,model.cfg.fast_d),torch.zeros(batch,model.cfg.slow_d),None)

def forward(model,A,times,initial=None):
    """Original v6 equations with an explicit fixed left-boundary state.

    This is posterior-mean inference, not unconditional prior sampling.
    Gap minutes follow original prior-mean transitions, without extra A/loss.
    """
    times=np.asarray(times,dtype=int)
    if A.ndim!=3 or A.shape[1]!=len(times) or A.shape[2]!=model.adaptive_width:
        raise ValueError('Expected A[batch, time, 10] and matching minute ids')
    if len(times)==0 or np.any(np.diff(times)<=0):raise ValueError('Increasing nonempty times required')
    state=zero_state(model,A.shape[0]) if initial is None else initial.clone()
    if state.minute is not None and times[0]<=state.minute:raise ValueError('Boundary must precede window')
    hf,hs=state.fast,state.slow;last=state.minute;c=model.cfg
    rec=[];states=[];raw=[];kf=[];ks=[];posterior=[]
    def step(adaptive):
        nonlocal hf,hs
        df,ds=hf.tanh(),hs.tanh()
        mpf,lpf=model.split(model.prior_fast(torch.cat([df,ds],-1)))
        mps,lps=model.split(model.prior_slow(ds))
        if adaptive is None:
            mqf,lqf,mqs,lqs=mpf,lpf,mps,lps
        else:
            bmf,blf=model.split(model.post_base_fast(torch.cat([df,ds],-1)))
            bms,bls=model.split(model.post_base_slow(ds))
            amf,alf,ams,als=torch.split(adaptive,(c.fast_z,c.fast_z,c.slow_z,c.slow_z),-1)
            mqf,lqf=bmf+amf,(blf+alf).clamp(-7,3)
            mqs,lqs=bms+ams,(bls+als).clamp(-7,3)
        nf=(1-1/c.tau_fast)*hf+model.fast_dyn(torch.cat([df,ds,mqf],-1))/c.tau_fast
        ns=(1-1/c.tau_slow)*hs+model.slow_dyn(torch.cat([ds,df,mqs],-1))/c.tau_slow
        hf,hs=nf,ns
        return gaussian_kl(mqf,lqf,mpf,lpf),gaussian_kl(mqs,lqs,mps,lps),torch.cat([mqf,lqf,mqs,lqs],-1)
    for j,minute in enumerate(times):
        if last is not None:
            for _ in range(int(last)+1,int(minute)):step(None)
        f,s,q=step(A[:,j]);representation=torch.cat([hf.tanh(),hs.tanh()],-1)
        rec.append(model.sensory_head(representation));states.append(representation)
        raw.append(torch.cat([hf,hs],-1));kf.append(f);ks.append(s);posterior.append(q)
        last=int(minute)
    representation=states[-1]
    return dict(reconstruction=torch.stack(rec,1),states=torch.stack(states,1),
        raw_states=torch.stack(raw,1),posterior=torch.stack(posterior,1),
        kl_fast=torch.stack(kf,1),kl_slow=torch.stack(ks,1),
        prediction=model.behavior_head(representation),final=State(hf.detach(),hs.detach(),last))

