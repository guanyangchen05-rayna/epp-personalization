"""Unmodified reference v6 model/data adapter; no new training."""
