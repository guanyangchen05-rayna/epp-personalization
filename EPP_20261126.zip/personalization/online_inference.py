"""Matched frozen-network ER: fixed personal-2/local-8 versus local-10.

No report labels are accepted. Masked channels are excluded before arithmetic.
All arms use identical optimizers, window boundaries, objective and clocks.
"""
import hashlib
import numpy as np
import torch
from personal_a import losses
from v6_dynamics import forward, zero_state, State


def weight_hash(model):
    h = hashlib.sha256()
    for n, a in sorted(model.state_dict().items()):
        h.update(n.encode()); h.update(a.detach().cpu().numpy().tobytes())
    return h.hexdigest()


def condition_parameters(conditions, profiles):
    if len(conditions) != len(profiles):
        raise ValueError('One profile per condition')
    mask = torch.ones(len(conditions), 10)
    fixed = torch.zeros(len(conditions), 10)
    for i, (c, p) in enumerate(zip(conditions, profiles)):
        if c not in ('personal', 'zero', 'local10'):
            raise ValueError(c)
        if c != 'local10':
            mask[i, 6:8] = 0
        if c == 'personal':
            a = torch.as_tensor(p, dtype=torch.float32)
            if a.shape != (2,) or not torch.isfinite(a).all():
                raise ValueError('Two finite historical offsets required')
            fixed[i, 6:8] = a
    return mask, fixed


def fit_window(model, x, observed, times, learn_mask, fixed, initial,
               warm_start, steps):
    if model.training or any(p.requires_grad for p in model.parameters()):
        raise ValueError('Network must be in eval mode and frozen')
    if steps < 1:
        raise ValueError('Positive update budget required')
    u = torch.nn.Parameter(warm_start.detach().clone())
    lengths = torch.full((len(x),), x.shape[1], dtype=torch.long)
    opt = torch.optim.Adam([u], lr=model.cfg.er_lr)
    best = torch.full((len(x),), float('inf'))
    best_u = u.detach().clone()
    best_step = torch.zeros(len(x), dtype=torch.long)
    first = None; pre_state = None; trace = []
    for k in range(steps+1):
        A = u*learn_mask[:, None, :] + fixed[:, None, :]
        out = forward(model, A, times, initial)
        per = losses(out, x, observed, lengths, model.cfg)
        if not torch.isfinite(per).all():
            raise FloatingPointError('Nonfinite ER objective')
        if k == 0:
            first = per.detach().clone()
            pre_state = out['states'][:, -1].detach().clone()
        value = per.detach(); changed = value < best
        best = torch.where(changed, value, best)
        best_u[changed] = u.detach()[changed]; best_step[changed] = k
        if k in (0, steps//2, steps):
            trace.append(dict(step=k, objective=best.tolist()))
        if k == steps:
            break
        opt.zero_grad(set_to_none=True)
        per.sum().backward()
        # Independent clipping prevents the 11-person simulation batch from
        # changing any person's step through another person's gradient norm.
        norms = u.grad.flatten(1).norm(dim=1).clamp_min(1e-12)
        u.grad.mul_((5./norms).clamp_max(1)[:, None, None])
        opt.step()
    A = best_u*learn_mask[:, None, :] + fixed[:, None, :]
    frozen = learn_mask.eq(0)[:, None, :].expand_as(A)
    expected = fixed[:, None, :].expand_as(A)
    if not torch.equal(A[frozen], expected[frozen]):
        raise AssertionError('Fixed historical offsets changed')
    with torch.no_grad():
        out = forward(model, A, times, initial)
    return out, best_u, dict(objective_before=first.tolist(),
                             objective_after=best.tolist(), best_step=best_step.tolist(),
                             pre_state=pre_state, trace=trace)


class OnlineER:
    def __init__(self, model, conditions, profiles, window=10, steps=100):
        self.model, self.conditions = model, list(conditions)
        self.learn_mask, self.fixed = condition_parameters(conditions, profiles)
        if window < 1 or steps < 1:
            raise ValueError('Positive window and update budget required')
        self.window, self.steps = window, steps
        self.rows, self.masks, self.times, self.local, self.cache = [], [], [], [], []
        self.initial = zero_state(model, len(conditions))

    def observe(self, environment, minute, physiology=None):
        e = np.asarray(environment, np.float32)
        p = np.full(3, np.nan, np.float32) if physiology is None else np.asarray(physiology, np.float32)
        if e.shape != (2,) or p.shape != (3,) or not np.isfinite(e).all():
            raise ValueError('Expected finite E[2], and P[3] or None')
        if not float(minute).is_integer() or minute < 0:
            raise ValueError('Nonnegative original integer minute required')
        if self.times and minute <= self.times[-1]:
            raise ValueError('Minute IDs must strictly increase')
        row = np.r_[e, p]
        self.rows.append(row); self.masks.append(np.isfinite(row)); self.times.append(int(minute))
        self.local.append(torch.zeros(len(self.conditions), 10))
        start = max(0, len(self.times)-self.window)
        boundary = self.initial if start == 0 else self.cache[start-1]
        x = torch.tensor(np.asarray(self.rows[start:]))[None].expand(len(self.conditions), -1, -1).clone()
        observed = torch.tensor(np.asarray(self.masks[start:]))[None].expand_as(x).clone()
        warm = torch.stack(self.local[start:], dim=1)
        out, local, info = fit_window(self.model, x, observed, self.times[start:],
                                      self.learn_mask, self.fixed, boundary, warm, self.steps)
        self.cache = self.cache[:start]
        for j, t in enumerate(self.times[start:]):
            self.local[start+j] = local[:, j].clone()
            self.cache.append(State(out['raw_states'][:, j, :8].clone(),
                                    out['raw_states'][:, j, 8:].clone(), t))
        return dict(out=out, info=info, window_times=self.times[start:].copy())


def physical_and_reports(model, saved, state, report=None):
    """Use the positive raw EDA link directly; never clip report outputs."""
    with torch.no_grad():
        p = model.sensory_head.raw_mean(state).cpu().numpy()
        b = model.behavior_head(state) if report is None else report
        b = b.cpu().numpy()*np.asarray(saved['target_scaler_scale'])+np.asarray(saved['target_scaler_mean'])
    return np.concatenate([p, b], axis=1)


def infer_sequence(model, saved, observations, times, conditions, profiles,
                   mode='E_only', window=10, steps=100, progress=None):
    """Observations only, no metadata or report labels. Return issued values."""
    a = np.asarray(observations, np.float32); times = np.asarray(times, int)
    if mode not in ('E_only', 'EP_online') or a.shape != (len(times), 5):
        raise ValueError('Five-channel observations and matching times required')
    if not len(times):
        raise ValueError('Empty record')
    if not np.isfinite(a[:, :2]).all() or (mode == 'EP_online' and not np.isfinite(a).all()):
        raise ValueError('Required observation absent')
    before_hash = weight_hash(model)
    xm, xs = np.asarray(saved['scaler_mean']), np.asarray(saved['scaler_scale'])
    online = OnlineER(model, conditions, profiles, window, steps)
    output, pre, diagnostics = [], [], []
    for j, t in enumerate(times):
        p = (a[j, 2:]-xm[2:])/xs[2:] if mode == 'EP_online' else None
        result = online.observe((a[j, :2]-xm[:2])/xs[:2], int(t), p)
        output.append(physical_and_reports(model, saved, result['out']['states'][:, -1],
                                           result['out']['prediction']))
        pre.append(physical_and_reports(model, saved, result['info']['pre_state']))
        for k, condition in enumerate(conditions):
            diagnostics.append(dict(step=j+1, minute=int(t), batch_index=k, condition=condition,
                                    objective_before=result['info']['objective_before'][k],
                                    objective_after=result['info']['objective_after'][k],
                                    best_step=result['info']['best_step'][k],
                                    retained_coordinates_fixed=(condition != 'local10'),
                                    fixed_coordinates_verified=True,
                                    current_P_used=(mode == 'EP_online')))
        if progress and ((j+1) % 10 == 0 or j+1 == len(times)):
            progress(j+1, len(times))
    if weight_hash(model) != before_hash:
        raise AssertionError('Shared network weights changed')
    return np.stack(output, axis=1), np.stack(pre, axis=1), diagnostics
