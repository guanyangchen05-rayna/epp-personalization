"""Safe entry point: standard library only, scientific work in a subprocess."""
from pathlib import Path
from datetime import datetime
import argparse
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def child_run(arguments, root=ROOT, python_executable=None, name='worker'):
    python = Path(python_executable or sys.executable)
    if python.name.lower() == 'pythonw.exe' and python.with_name('python.exe').is_file():
        python = python.with_name('python.exe')
    root = Path(root).resolve()
    logs = root/'startup_logs'; logs.mkdir(exist_ok=True)
    log = logs/(name+'_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.log')
    env = os.environ.copy()
    env.update(PYTHONIOENCODING='utf-8', MKL_THREADING_LAYER='SEQUENTIAL')
    # Do not silently inherit the unsupported duplicate-runtime bypass.
    env.pop('KMP_DUPLICATE_LIB_OK', None)
    command = [str(python), '-X', 'faulthandler', '-u']+list(arguments)
    print('Python:', python, flush=True)
    print('Log:', log, flush=True)
    print('Child-only MKL_THREADING_LAYER=SEQUENTIAL; KMP_DUPLICATE_LIB_OK is not used.', flush=True)
    output = None
    with log.open('w', encoding='utf-8') as stream:
        stream.write('Python: '+str(python)+'\n')
        process = subprocess.Popen(command, cwd=str(root), stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace',
            env=env, bufsize=1)
        try:
            for line in process.stdout:
                stream.write(line); stream.flush(); print(line, end='', flush=True)
                if line.startswith('OUTPUT: '): output = line[len('OUTPUT: '):].strip()
            code = process.wait()
        except BaseException:
            process.terminate()
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired: process.kill(); process.wait()
            raise
        finally:
            process.stdout.close()
        status = f'Exit code: {code} (0x{code & 0xffffffff:08X})'
        stream.write('\n'+status+'\n')
    print(status, flush=True)
    if code:
        print('Child failed. Keep this log; completed stages may be resumed. No environment was reinstalled.', flush=True)
    return dict(success=(code == 0), exit_code=code, log=str(log), output=output)


def diagnose(root=ROOT, python_executable=None):
    torch_only = "import torch; print('OK torch',torch.__version__,flush=True); print('CPU check',torch.ones(2).sum().item(),flush=True)"
    if not child_run(['-c', torch_only], root, python_executable, '01_torch_only')['success']:
        return False
    stack = """
import importlib
for n in ['numpy','pandas','torch','sklearn','matplotlib','personal_a','experiment']:
    print('START import', n, flush=True)
    m=importlib.import_module(n)
    print('OK', n, getattr(m,'__version__',''), flush=True)
import torch
x=torch.zeros(1,requires_grad=True)
o=torch.optim.Adam([x]);o.zero_grad();x.square().sum().backward();o.step()
from data_io import load_data,partition
d=load_data();s=partition(d)
print('DATA OK:',len(d.meta),'source records;',len(s['train']),'train;',len(s['validation']),'validation;',int(s['validation'].has_report.sum()),'reports',flush=True)
print('DEPENDENCY AND DATA CHECKS PASSED',flush=True)
"""
    return child_run(['-c', stack], root, python_executable, '02_dependencies_data')['success']


def run(root=ROOT, python_executable=None, mode='formal', phase='all', resume=None,
        force_train=False, output=None):
    args = [str(Path(root)/'experiment.py'), '--mode', mode, '--phase', phase]
    if resume: args += ['--resume', str(resume)]
    if output: args += ['--output', str(output)]
    if force_train: args += ['--force-train']
    return child_run(args, root, python_executable, '03_'+mode+'_'+phase)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode', choices=['formal', 'quickcheck'], default='formal')
    ap.add_argument('--phase', choices=['all', 'train', 'calibrate', 'simulate', 'validate', 'report'], default='all')
    ap.add_argument('--resume')
    ap.add_argument('--output')
    ap.add_argument('--python', dest='python_executable')
    ap.add_argument('--force-train', action='store_true')
    ap.add_argument('--check-only', action='store_true')
    a = ap.parse_args()
    if not diagnose(ROOT, a.python_executable): return 1
    if a.check_only: return 0
    result = run(ROOT, a.python_executable, a.mode, a.phase, a.resume, a.force_train, a.output)
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
