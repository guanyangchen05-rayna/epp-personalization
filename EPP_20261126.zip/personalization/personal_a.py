"""A tied slow-posterior mean is a reusable model-conditional personal code.

New modeling assumption: existing A coordinates 6:8 are tied across calibration
minutes/records for a person and retained at EVERY subsequent observed minute.
The other eight original A coordinates remain local ER variables. No new
network weights, observation precision or arbitrary gain is introduced.
This is a restricted inference family, not an established neural trait assay.
"""
from pathlib import Path
import json,hashlib
import numpy as np,torch
from v6_reference.model import FiveArrowPVRNN,Settings,valid_mask,window_ids_tensor
from v6_dynamics import forward,State,zero_state

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_shared(path):
    saved=torch.load(path,map_location='cpu',weights_only=False)
    if saved.get('target_scaler_mean') is None or len(saved.get('report_training_keys',[]))<2:
        raise ValueError('Shared backbone must include a trained E/P/B report head')
    cfg=Settings(**saved['config']).validate()
    if saved.get('backbone_kind')=='tied_A_positive_EDA_v2':
        from backbone import make_backbone
        model=make_backbone(cfg,saved['scaler_mean'],saved['scaler_scale'])
    else:model=FiveArrowPVRNN(cfg)
    model.load_state_dict(saved['state_dict']);model.eval()
    for p in model.parameters():p.requires_grad_(False)
    if (model.cfg.fast_z,model.cfg.slow_z)!=(3,2):raise ValueError('Expected original 3/2 latent dimensions')
    return model,saved

def compose_A(local,personal):
    """[fast mu 3, fast logvar 3, PERSONAL slow mu 2, local slow logvar 2]."""
    if local.ndim!=3 or local.shape[-1]!=8 or personal.shape!=(local.shape[0],2):raise ValueError('A needs local[B,T,8] and personal[B,2]')
    tied=personal[:,None,:].expand(-1,local.shape[1],-1)
    return torch.cat([local[:,:,:6],tied,local[:,:,6:]],dim=-1)

def losses(out,x,mask,lengths,cfg):
    valid=valid_mask(lengths,x.shape[1]);observed=mask&valid[:,:,None]
    if observed.dtype!=torch.bool or not observed.any() or not torch.isfinite(x[observed]).all():raise ValueError('Invalid observed values')
    err=(out['reconstruction'][observed]-x[observed]).square()
    which=torch.arange(len(x))[:,None,None].expand_as(x)[observed]
    residual=torch.zeros(len(x),dtype=x.dtype);residual.scatter_add_(0,which,err)
    n=lengths.to(x.dtype)
    return residual/(5*n)+cfg.kl_fast*(out['kl_fast']*valid).sum(1)/n+cfg.kl_slow*(out['kl_slow']*valid).sum(1)/n

def _clip_independent(personal,local,person_index,n_people):
    pgrad=torch.zeros(n_people,2) if personal is None else personal.grad
    norm2=pgrad.square().sum(1)
    q=local.grad.flatten(1).square().sum(1)
    norm2.scatter_add_(0,person_index,q)
    scale=(5./norm2.sqrt().clamp_min(1e-12)).clamp_max(1)
    if personal is not None:personal.grad.mul_(scale[:,None])
    local.grad.mul_(scale[person_index,None,None])

def fit_profiles(model,sequences,times,steps=600,person_index=None,observed_masks=None,initial_profile=None,progress=None):
    """Jointly fit tied personal slow A and local A; reports are not arguments.

    Several calibration records may share the same person_index. Each record
    starts from zero state, preserving actual gaps between its retained minutes.
    Hidden placeholders are indexed out before arithmetic. Whole-row missing
    observations must be omitted, not filled with generated observations.
    """
    if model.training or any(p.requires_grad for p in model.parameters()):raise ValueError('Freeze the shared backbone')
    if not sequences or len(sequences)!=len(times) or steps<1:raise ValueError('Calibration records and positive budget required')
    nrec=len(sequences);ids=np.arange(nrec) if person_index is None else np.asarray(person_index,dtype=int)
    if ids.shape!=(nrec,) or ids.min()<0 or set(ids)!=set(range(ids.max()+1)):raise ValueError('Contiguous person indices required')
    lengths=torch.tensor([len(s) for s in sequences],dtype=torch.long)
    if (lengths<1).any():raise ValueError('Empty calibration record')
    x=torch.full((nrec,int(lengths.max()),5),float('nan'));mask=torch.zeros_like(x,dtype=torch.bool)
    for i,s in enumerate(sequences):
        q=np.asarray(s,dtype=np.float32)
        if q.shape!=(int(lengths[i]),5):raise ValueError('Expected five channels')
        m=np.isfinite(q) if observed_masks is None else np.asarray(observed_masks[i],bool)
        if m.shape!=q.shape or not np.isfinite(q[m]).all() or not m.any(1).all():raise ValueError('Remove wholly absent rows; retain timestamps as gaps')
        x[i,:len(q)]=torch.tensor(q);mask[i,:len(q)]=torch.tensor(m)
    index=torch.tensor(ids);nperson=int(ids.max()+1)
    for pid in range(nperson):
        if not mask[index.eq(pid),:,2:].any():raise ValueError(f'Person {pid} has no measured P: cannot claim personal calibration')
    window_ids=window_ids_tensor(times,lengths,x.shape[1])
    personal=torch.nn.Parameter(torch.zeros(nperson,2) if initial_profile is None else torch.as_tensor(initial_profile,dtype=torch.float32).clone())
    if personal.shape!=(nperson,2):raise ValueError('Expected one 2-D profile per person')
    local=torch.nn.Parameter(torch.zeros(nrec,x.shape[1],8))
    opt=torch.optim.Adam([personal,local],lr=model.cfg.er_lr)
    totals=torch.zeros(nperson);totals.scatter_add_(0,index,lengths.float());weight=lengths.float()/totals[index]
    best=torch.full((nperson,),float('inf'));best_p=personal.detach().clone();best_u=local.detach().clone();best_step=torch.zeros(nperson,dtype=torch.long);trace=[]
    for k in range(steps+1):
        A=compose_A(local,personal[index]);out=model(lengths,A,sample=False,window_ids=window_ids)
        per=losses(out,x,mask,lengths,model.cfg)*weight
        loss=torch.zeros(nperson).scatter_add_(0,index,per)
        if not torch.isfinite(loss).all():raise FloatingPointError('Nonfinite calibration objective')
        value=loss.detach();changed=value<best
        best=torch.where(changed,value,best);best_p[changed]=personal.detach()[changed];best_u[changed[index]]=local.detach()[changed[index]];best_step[changed]=k
        if k%150==0 or k==steps:
            trace.extend(dict(person_index=i,step=k,objective=float(value[i]),best_objective=float(best[i]),A_slow_0=float(best_p[i,0]),A_slow_1=float(best_p[i,1])) for i in range(nperson))
            if progress:progress(k,steps)
        if k==steps:break
        opt.zero_grad(set_to_none=True);loss.sum().backward();_clip_independent(personal,local,index,nperson);opt.step()
    return dict(personal=best_p,local=best_u,lengths=lengths,person_index=index,best_objective=best.tolist(),best_step=best_step.tolist(),trace=trace,
                measured_counts=mask.sum((0,1)).tolist(),per_record_counts=mask.sum(1).tolist())

def fit_local(model,x,mask,times,personal,steps,initial=None,local_initial=None,adapt_personal=False):
    """Only 8 local coordinates are optimized; the personal 2-D A is immutable."""
    x=torch.as_tensor(x,dtype=torch.float32);mask=torch.as_tensor(mask,dtype=torch.bool)
    p=torch.as_tensor(personal,dtype=torch.float32).detach().clone()
    if adapt_personal:
        if not mask[:,:,2:].any():raise ValueError('Persistent personal A updates require actual P observations')
        p=torch.nn.Parameter(p)
    if model.training or any(q.requires_grad for q in model.parameters()):raise ValueError('Frozen network required')
    u=torch.nn.Parameter(torch.zeros(len(x),x.shape[1],8) if local_initial is None else local_initial.detach().clone())
    opt=torch.optim.Adam([u,p] if adapt_personal else [u],lr=model.cfg.er_lr);lengths=torch.full((len(x),),x.shape[1],dtype=torch.long)
    best=torch.full((len(x),),float('inf'));best_u=u.detach().clone();best_p=p.detach().clone();best_step=torch.zeros(len(x),dtype=torch.long);trace=[]
    for k in range(steps+1):
        A=compose_A(u,p);out=forward(model,A,times,initial)
        loss=losses(out,x,mask,lengths,model.cfg)
        if not torch.isfinite(loss).all():raise FloatingPointError('Nonfinite online objective')
        v=loss.detach();change=v<best;best=torch.where(change,v,best);best_u[change]=u.detach()[change];best_p[change]=p.detach()[change];best_step[change]=k
        if k in {0,steps//2,steps}:trace.append(dict(step=k,objective=best.tolist()))
        if k==steps:break
        opt.zero_grad(set_to_none=True);loss.sum().backward()
        if adapt_personal:_clip_independent(p,u,torch.arange(len(x)),len(x))
        else:
            norms=u.grad.flatten(1).norm(dim=1).clamp_min(1e-12);u.grad.mul_((5./norms).clamp_max(1)[:,None,None])
        opt.step()
    with torch.no_grad():out=forward(model,compose_A(best_u,best_p),times,initial)
    return out,best_u,dict(objective=best.tolist(),best_step=best_step.tolist(),trace=trace,personal=best_p)

class OnlinePersonalA:
    """Reusable personal code + causal sliding-window local state adaptation.

    New contexts start from the same zero state by default, so person effects
    cannot be attributed just to different calibration-end states. Missing
    minutes are propagated by the original prior transitions. Providing actual
    current P permits local state updating; a change to the persistent profile
    is explicit through recalibrate(), using real calibration data only.
    """
    def __init__(self,model,personal,window=10,steps=100):
        self.model=model;self.personal=torch.as_tensor(personal,dtype=torch.float32).reshape(-1,2).detach().clone()
        if window<1 or steps<1 or not torch.isfinite(self.personal).all():raise ValueError('Invalid online configuration')
        self.window=window;self.steps=steps;self.reset()
    def reset(self):
        self.initial=zero_state(self.model,len(self.personal));self.rows=[];self.masks=[];self.times=[];self.local=[];self.cache=[]
    def observe(self,environment,minute,physiology=None,update_personal=False):
        e=np.asarray(environment,np.float32);p=np.full(3,np.nan,np.float32) if physiology is None else np.asarray(physiology,np.float32)
        if e.shape!=(2,) or p.shape!=(3,) or not float(minute).is_integer():raise ValueError('Expected E[2], P[3], integer minute')
        row=np.r_[e,p];mask=np.isfinite(row)
        if not mask.any():raise ValueError('No actual observations: skip this row, preserve its elapsed gap')
        if update_personal and not np.isfinite(p).any():raise ValueError('Only newly measured real P can update the personal code')
        if self.times and minute<=self.times[-1]:raise ValueError('Minutes must increase')
        self.rows.append(row);self.masks.append(mask);self.times.append(int(minute));self.local.append(torch.zeros(len(self.personal),8))
        start=max(0,len(self.times)-self.window);boundary=self.initial if start==0 else self.cache[start-1]
        x=torch.tensor(np.asarray(self.rows[start:]))[None].expand(len(self.personal),-1,-1).clone()
        m=torch.tensor(np.asarray(self.masks[start:]))[None].expand_as(x).clone()
        u0=torch.stack(self.local[start:],1)
        out,u,info=fit_local(self.model,x,m,self.times[start:],self.personal,self.steps,boundary,u0,adapt_personal=update_personal)
        if update_personal:self.personal=info['personal'].detach().clone()
        raw=out['raw_states'];self.cache=self.cache[:start]
        for j,t in enumerate(self.times[start:]):
            self.local[start+j]=u[:,j].clone();self.cache.append(State(raw[:,j,:8].clone(),raw[:,j,8:].clone(),t))
        A=compose_A(u,self.personal)
        if not torch.equal(A[:,:,6:8],self.personal[:,None,:].expand(-1,u.shape[1],-1)):raise AssertionError('Persistent personal A was lost')
        return dict(out=out,A=A,info=info,personal=self.personal.clone(),window_times=self.times[start:].copy(),boundary=boundary.clone())
    def recalibrate(self,sequences,times,steps=600):
        if len(self.personal)!=1:raise ValueError('Recalibration API handles a single incoming person')
        fit=fit_profiles(self.model,sequences,times,steps,person_index=[0]*len(sequences),initial_profile=self.personal)
        self.personal=fit['personal'].clone();self.reset()
        return fit

def save_profile(path,personal,checkpoint_path,provenance):
    a=np.asarray(personal,float)
    if a.shape!=(2,) or not np.isfinite(a).all():raise ValueError('Two finite existing slow-mean offsets required')
    record=dict(format='tied_slow_A_v2',personal_A_slow_mean=a.tolist(),checkpoint_sha256=sha(checkpoint_path),
                existing_A_coordinates=[6,7],persistent_usage='inserted at every observed simulation minute',
                interpretation='model-conditional personal calibration code, not neural precision or ASD trait',provenance=provenance)
    Path(path).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
def load_profile(path,checkpoint_path):
    q=json.loads(Path(path).read_text())
    if q.get('format')!='tied_slow_A_v2' or q['checkpoint_sha256']!=sha(checkpoint_path):raise ValueError('Personal code must be used with its exact shared network and scaling')
    return torch.tensor(q['personal_A_slow_mean'],dtype=torch.float32).reshape(1,2)
