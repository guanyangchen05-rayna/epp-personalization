"""Scientific worker. Always launched as a child process by run_project.py."""
from pathlib import Path
from datetime import datetime
import argparse
import json
import time
import platform
import numpy as np
import pandas as pd
import torch
from protocol import (ROOT, PEOPLE, VARIABLES, CHANNELS, config_for, config_dict,
                      code_hashes, digest, sha_file, write_csv, write_json,
                      stage_complete, mark_stage, verify_bundled)
from data_io import load_data, partition, key, write_partition
from training import (ensure_model, ensure_profiles, verified_profiles,
                      training_signature, calibration_signature)
from personal_a import load_shared
from online_inference import infer_sequence
from scenarios import make_scenarios, simulation_config


def trajectory_frame(out, pre, observations, times, batch_conditions, batch_pids):
    rows = []
    for b, (condition, pid) in enumerate(zip(batch_conditions, batch_pids)):
        for j, minute in enumerate(times):
            for k, variable in enumerate(VARIABLES):
                rows.append(dict(Pid=pid, condition=condition, step=j+1, minute=int(minute),
                                 variable=variable, prediction=float(out[b, j, k]),
                                 prediction_pre_ER=float(pre[b, j, k]),
                                 observed=float(observations[j, k]) if k < 5 else np.nan))
    return pd.DataFrame(rows)


def run_simulations(run, data, split, cfg, seed, cp, profile_csv, signature):
    model, saved = load_shared(cp)
    profiles = verified_profiles(profile_csv, model, cp, split)
    scenarios = pd.read_csv(run/'protocol'/'scenarios.csv')
    # Shared references are computed once, not relabeled as 11 independent people.
    conditions = ['zero', 'local10']+['personal']*len(PEOPLE)
    pids = [0, 0]+list(PEOPLE)
    values = [[0., 0.], [0., 0.]]+[profiles[p] for p in PEOPLE]
    for scenario, g in scenarios.groupby('scenario', sort=False):
        name = f'simulation_seed{seed}_{scenario}'
        sig = digest([signature, sha_file(cp), sha_file(profile_csv), name])
        if stage_complete(run, name, sig):
            print(f'  {name}: verified cached output', flush=True); continue
        times = g.minute.to_numpy(int)
        x = np.c_[g[list(CHANNELS[:2])].to_numpy(np.float32), np.full((len(g), 3), np.nan)]
        print(f'SIMULATION seed {seed} / {scenario}: {len(g)} full steps / 11 profiles + 2 references', flush=True)
        out, pre, diagnostic = infer_sequence(model, saved, x, times, conditions, values,
            mode='E_only', window=cfg.window, steps=cfg.online_steps,
            progress=lambda n, total: print(f'  {scenario}: {n}/{total}', flush=True))
        d = trajectory_frame(out, pre, x, times, conditions, pids)
        d['seed'], d['scenario'] = seed, scenario
        d['observation_role'] = np.where(d.variable.isin(CHANNELS[:2]), 'ER input', 'simulated; no ground truth')
        dg = pd.DataFrame(diagnostic)
        dg['Pid'] = dg.batch_index.map(dict(enumerate(pids)))
        dg['seed'], dg['scenario'] = seed, scenario
        paths = [run/'simulation'/'cases'/(name+'.csv'),
                 run/'simulation'/'diagnostics'/(name+'.csv')]
        write_csv(paths[0], d); write_csv(paths[1], dg)
        mark_stage(run, name, sig, paths)


def run_validation(run, data, split, cfg, seed, cp, profile_csv, signature):
    model, saved = load_shared(cp)
    profiles = verified_profiles(profile_csv, model, cp, split)
    for r in split['validation'].itertuples(index=False):
        if r.Pid not in cfg.validation_pids:
            continue
        x = data.arrays[key(r)]; times = data.times[key(r)]
        complete = cfg.validation_max_minutes == 0 or cfg.validation_max_minutes >= len(x)
        if cfg.validation_max_minutes:
            x, times = x[:cfg.validation_max_minutes], times[:cfg.validation_max_minutes]
        for mode in cfg.validation_modes:
            name = f'validation_P{r.Pid}_C{r.Class_id}_seed{seed}_{mode}'
            sig = digest([signature, sha_file(cp), sha_file(profile_csv), name])
            if stage_complete(run, name, sig):
                print(f'  {name}: verified cached output', flush=True); continue
            print(f'VALIDATION P{r.Pid} / Class{r.Class_id} / seed {seed} / {mode}: {len(times)} minutes; complete={complete}', flush=True)
            conditions = ['personal', 'zero', 'local10']
            # A real record is shared ONLY by its own three matched arms.
            out, pre, diagnostic = infer_sequence(model, saved, x, times, conditions,
                [profiles[r.Pid], [0., 0.], [0., 0.]], mode, cfg.window, cfg.online_steps,
                progress=lambda n, total: print(f'  P{r.Pid} {mode}: {n}/{total}', flush=True))
            d = trajectory_frame(out, pre, x, times, conditions, [r.Pid]*3)
            d['Class_id'], d['seed'], d['mode'] = r.Class_id, seed, mode
            d['complete_session'] = complete
            d['used_as_ER_target'] = d.variable.isin(CHANNELS if mode == 'EP_online' else CHANNELS[:2])
            dg = pd.DataFrame(diagnostic)
            dg['Pid'], dg['Class_id'], dg['seed'], dg['mode'] = r.Pid, r.Class_id, seed, mode
            paths = [run/'validation'/'cases'/(name+'.csv'),
                     run/'validation'/'diagnostics'/(name+'.csv')]
            write_csv(paths[0], d); write_csv(paths[1], dg)
            mark_stage(run, name, sig, paths)


def completed_inputs(run, data, cfg, split, signature):
    for seed in cfg.seeds:
        cp = run/'models'/f'seed{seed}.pt'
        pc = run/'profiles'/f'personal_A_seed{seed}.csv'
        if not cp.is_file() or not pc.is_file(): return False
        if not stage_complete(run, f'train_seed{seed}', training_signature(data, split, cfg, seed)):
            return False
        if not stage_complete(run, f'calibration_seed{seed}', calibration_signature(data, split, cfg, cp)):
            return False
        for scenario in ('stable', 'stable_then_fluctuating'):
            name = f'simulation_seed{seed}_{scenario}'
            sig = digest([signature, sha_file(cp), sha_file(pc), name])
            if not stage_complete(run, name, sig):
                return False
        for r in split['validation'].itertuples(index=False):
            if r.Pid not in cfg.validation_pids: continue
            for mode in cfg.validation_modes:
                name = f'validation_P{r.Pid}_C{r.Class_id}_seed{seed}_{mode}'
                sig = digest([signature, sha_file(cp), sha_file(pc), name])
                if not stage_complete(run, name, sig): return False
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode', choices=['formal', 'quickcheck'], default='formal')
    ap.add_argument('--output', type=Path)
    ap.add_argument('--resume', type=Path)
    ap.add_argument('--phase', choices=['all', 'train', 'calibrate', 'simulate', 'validate', 'report'], default='all')
    ap.add_argument('--force-train', action='store_true')
    args = ap.parse_args()
    if args.resume and (args.output or args.force_train):
        ap.error('--resume cannot be combined with --output or --force-train')
    torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
    cfg = simulation_config(config_for(args.mode)); data = load_data(); split = partition(data, cfg.validation_min_calibration_minutes)
    if cfg.mode == 'formal' and not args.force_train:
        verify_bundled()
    payload = dict(config=config_dict(cfg), inputs=data.hashes, split=split['signature'], code=code_hashes())
    signature = digest(payload)
    run = (args.resume or args.output or ROOT/'results'/
           (args.mode+'_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))).resolve()
    manifest_file = run/'run_manifest.json'
    if args.resume:
        if not manifest_file.is_file(): ap.error('Resume directory has no run manifest')
        previous = json.loads(manifest_file.read_text(encoding='utf-8'))
        if previous.get('signature') != signature:
            ap.error('Resume protocol/data/code differs; use a new output directory')
    else:
        if run.exists() and any(run.iterdir()): ap.error('Output is nonempty; choose a new folder or explicit --resume')
        run.mkdir(parents=True, exist_ok=True)
        write_json(manifest_file, dict(signature=signature, **payload,
                     presentation_code_sha256=sha_file(ROOT/'plots.py'),
                     software=dict(python=platform.python_version(), torch=torch.__version__,
                                   numpy=np.__version__, pandas=pd.__version__),
                     purpose='mechanism simulation + matched unseen-record evaluation',
                     experimental_status='FORMAL FULL RUN' if cfg.mode == 'formal' else 'DIAGNOSTIC ONLY; NOT PAPER RESULTS'))
    write_partition(run, data, split)
    scenarios, scenario_info = make_scenarios(data, split, cfg)
    write_csv(run/'protocol'/'scenarios.csv', scenarios)
    write_json(run/'protocol'/'scenario_definition.json', scenario_info)
    if cfg.mode == 'quickcheck':
        (run/'DIAGNOSTIC_NOT_FOR_PAPER.txt').write_text('Reduced budgets and prefixes; not scientific results.\n')
    print(f'OUTPUT: {run}', flush=True)
    print(f'MODE: {cfg.mode}; seeds={list(cfg.seeds)}; train records={len(split["train"])}; validation={len(split["validation"])} ({int(split["validation"].has_report.sum())} reports)', flush=True)
    print(f'Simulation: TWO independent paired sessions x {cfg.scenario_minutes} minutes; design boundary={cfg.scenario_switch}, first changed E={scenario_info["first_nonbaseline_minute"]}; 11 profiles, 3 A conditions; real validation modes={list(cfg.validation_modes)}', flush=True)
    tic = time.perf_counter()
    if args.phase != 'report':
        for seed in cfg.seeds:
            cp = ensure_model(run, data, split, cfg, seed, args.force_train)
            if args.phase == 'train': continue
            pc = ensure_profiles(run, data, split, cfg, seed, cp, args.force_train)
            if args.phase == 'calibrate': continue
            if args.phase in ('all', 'simulate'):
                run_simulations(run, data, split, cfg, seed, cp, pc, signature)
            if args.phase in ('all', 'validate'):
                run_validation(run, data, split, cfg, seed, cp, pc, signature)
    if args.phase == 'simulate':
        from summaries import summarize_simulation
        from plots import make_simulation_plots
        summarize_simulation(run, cfg); make_simulation_plots(run, cfg)
        write_json(run/'simulation_complete.json', dict(mode=cfg.mode, seeds=list(cfg.seeds),
                   n_sessions=2, minutes_per_session=cfg.scenario_minutes,
                   design_boundary_minute=cfg.scenario_switch,
                   first_nonbaseline_minute=scenario_info['first_nonbaseline_minute'],
                   coverage='simulation phase only; check run_complete.json for all-stage completion',
                   plotting_source_sha256=sha_file(ROOT/'plots.py')))
    elif args.phase == 'validate':
        from summaries import summarize_validation
        from plots import make_validation_plots
        summarize_validation(run, data, split, cfg); make_validation_plots(run, split, cfg)
        write_json(run/'validation_complete.json', dict(mode=cfg.mode, seeds=list(cfg.seeds),
                   n_records=len(cfg.validation_pids),
                   full_records=(cfg.validation_max_minutes == 0)))
    if args.phase in ('all', 'report'):
        if not completed_inputs(run, data, cfg, split, signature):
            raise ValueError('Full requested simulation/validation outputs are not yet present; no completion marker written')
        from summaries import summarize_all
        from plots import make_all_plots
        summarize_all(run, data, split, cfg)
        make_all_plots(run, data, split, cfg)
        write_json(run/'figures'/'figure_manifest.json',
                   dict(plotting_source_sha256=sha_file(ROOT/'plots.py'),
                        aggregation_source_sha256=sha_file(ROOT/'summaries.py'),
                        simulation_data_sha256=sha_file(run/'simulation'/'trajectories_seed_mean.csv'),
                        validation_data_sha256=sha_file(run/'validation'/'trajectories_seed_mean.csv')))
        write_json(run/'run_complete.json', dict(mode=cfg.mode, phase='all requested stages complete',
                   elapsed_this_invocation_seconds=time.perf_counter()-tic,
                   full_validation=(cfg.mode == 'formal'), seeds=list(cfg.seeds),
                   validation_records=len(cfg.validation_pids),
                   real_targets_excluded_from_training=True,
                   simulated_P_B_are_model_outputs_not_observations=True))
        print('ALL REQUESTED STAGES COMPLETE', flush=True)
    else:
        print(f'PHASE {args.phase} COMPLETE; this is not the all-stage completion marker', flush=True)
    print(f'SAVED: {run}', flush=True)


if __name__ == '__main__':
    main()
