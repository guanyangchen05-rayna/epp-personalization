"""Publication-editable SVG + PNG; the Figure-3 three-domain layout."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from protocol import PEOPLE, VARIABLES, REPORTS
from summaries import scenario_timing

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                     'svg.fonttype': 'none', 'axes.spines.top': False,
                     'axes.spines.right': False})
LABELS = ['Temperature\n(°C)', 'CO₂\n(ppm)', 'EDA\n(µS)', 'Heart rate\n(bpm)',
          'Skin temperature\n(°C)', 'Engagement\n(model readout)',
          'Arousal\n(model readout)', 'Valence\n(model readout)']
COLORS = {p: plt.get_cmap('tab20')(j) for p, j in zip(PEOPLE, [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 1])}


def figure3_axes(n=8, title=''):
    fig, axes = plt.subplots(n, 1, sharex=True, figsize=(11.2, 12.8 if n == 8 else 10.4))
    fig.subplots_adjust(left=.16, right=.98, bottom=.13, top=.94, hspace=.17)
    if n == 8:
        bounds = [(0, 2, 'ENVIRONMENT'), (2, 5, 'PHYSIOLOGY'), (5, 8, 'REPORT READOUTS')]
        for start, stop, text in bounds:
            top, bottom = axes[start].get_position().y1, axes[stop-1].get_position().y0
            fig.text(.018, (top+bottom)/2, text, rotation=90, ha='center', va='center',
                     fontsize=9, fontweight='bold', color='#455466')
    for ax in axes:
        ax.grid(axis='y', alpha=.16)
        ax.tick_params(labelsize=8)
        ax.yaxis.set_label_coords(-.06, .5)
    fig.suptitle(title, fontsize=12, y=.985)
    return fig, axes


def save_figure(fig, folder, name):
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    fig.savefig(folder/(name+'.svg'))
    fig.savefig(folder/(name+'.png'), dpi=180)
    if name == 'Figure_simulation_three_layers':
        fig.savefig(folder/'Figure6_fourphase.svg')
        fig.savefig(folder/'Figure6_fourphase.png', dpi=180)
        fig.savefig(folder/'Figure6_fourphase.pdf')
    plt.close(fig)


def personal_legend():
    return [Line2D([0], [0], color=COLORS[p], lw=1.4, label=f'P{p}') for p in PEOPLE]


def simulation_plot(mean, scenarios, cfg, scenario, folder):
    d = mean[mean.scenario == scenario]
    e = scenarios[scenarios.scenario == scenario]
    first_changed = scenario_timing(scenarios, cfg)
    name = 'Stable → rising → falling → fluctuating' if scenario != 'stable' else 'Matched stable control'
    if cfg.mode != 'formal': name += ' [DIAGNOSTIC ONLY]'
    fig, axes = figure3_axes(title=f'{name}: {cfg.scenario_minutes}-min paired session / common E / 11 profiles')
    for j, variable in enumerate(VARIABLES):
        ax = axes[j]; ax.set_ylabel(LABELS[j], fontsize=8, rotation=0, ha='right', va='center')
        if j < 2:
            ax.step(np.r_[e.minute, cfg.scenario_minutes], np.r_[e[variable], e[variable].iloc[-1]],
                    where='post', color=['#527ca3', '#4d9a95'][j], lw=1.7)
        else:
            q = d[d.variable == variable]
            for pid in PEOPLE:
                g = q[(q.condition == 'personal') & (q.Pid == pid)].sort_values('minute')
                ax.step(np.r_[g.minute, cfg.scenario_minutes], np.r_[g.prediction, g.prediction.iloc[-1]], where='post', color=COLORS[pid], lw=.95, alpha=.82)
            for condition, color, style in [('zero', '#535e6b', '--'), ('local10', '#111111', '-.')]:
                g = q[q.condition == condition].sort_values('minute')
                ax.step(np.r_[g.minute, cfg.scenario_minutes], np.r_[g.prediction, g.prediction.iloc[-1]], where='post', color=color, ls=style, lw=1.5, zorder=5)
        if scenario != 'stable':
            for left, right, color in [(0,10,'#f1f3f6'), (10,20,'#f8e9dc'),
                                       (20,30,'#e7f1f7'), (30,40,'#e7efe5')]:
                ax.axvspan(left, right, color=color, alpha=.55, zorder=-5)
            for boundary in (10,20,30):
                ax.axvline(boundary, color='#8c97a1', ls=':', lw=.8)
            if j == 0:
                for middle, label in [(5,'Constant'),(15,'Rising'),(25,'Falling'),(35,'Fluctuating')]:
                    ax.text(middle, 1.04, label, transform=ax.get_xaxis_transform(),
                            ha='center', va='bottom', fontsize=8)
        else:
            ax.axvspan(0,40,color='#f1f3f6',alpha=.55,zorder=-5)
        ax.set_xlim(0, cfg.scenario_minutes)
    axes[-1].set_xlabel('Simulated minute (common across all variables)')
    legend = personal_legend()+[
        Line2D([0], [0], color='#535e6b', ls='--', lw=1.5, label='aᵢ = 0 reference'),
        Line2D([0], [0], color='#111111', ls='-.', lw=1.5, label='Fully adaptive A')]
    fig.legend(handles=legend, loc='lower center', ncol=7, frameon=False, fontsize=8,
               bbox_to_anchor=(.55, .035))
    timing = (f'Phase boundaries: 10, 20, 30 min; first nonbaseline sample: {first_changed} min. '
              if scenario != 'stable' else 'Independent zero-state reset; same retained personal A. ')
    fig.text(.55, .008, timing+'Seed-mean P/B outputs; no observed ground truth.',
             ha='center', fontsize=8, color='#5a6570')
    save_figure(fig, folder, 'Figure_simulation_three_layers' if scenario != 'stable' else 'Figure_stable_control')


def response_plot(response, cfg, folder, first_changed):
    fig, axes = figure3_axes(n=6, title='Personal A modulation of the matched environment response')
    for j, variable in enumerate(VARIABLES[2:]):
        ax = axes[j]; ax.set_ylabel('Δ '+LABELS[j+2], fontsize=8, rotation=0, ha='right', va='center')
        q = response[(response.variable == variable) & (response.condition == 'personal')]
        for pid in PEOPLE:
            g = q[q.Pid == pid].sort_values('minute')
            ax.step(np.r_[g.minute, cfg.scenario_minutes], np.r_[g.response_minus_zero, g.response_minus_zero.iloc[-1]], where='post', color=COLORS[pid], lw=1.)
        ax.axhline(0, color='#666666', lw=.8)
        ax.axvline(cfg.scenario_switch, color='#888888', ls=':', lw=1.)
        if first_changed != cfg.scenario_switch:
            ax.axvline(first_changed, color='#b77731', ls='--', lw=.8)
        ax.set_xlim(0, cfg.scenario_minutes)
    axes[-1].set_xlabel('Simulated minute')
    fig.legend(handles=personal_legend(), loc='lower center', ncol=6, frameon=False, fontsize=8,
               bbox_to_anchor=(.55, .035))
    fig.text(.55, .01, '(Changing − stable) for personal A, minus zero-A contrast. '
             f'First changed E: {first_changed} min (orange dashed).',
             ha='center', fontsize=8)
    save_figure(fig, folder, 'Figure_personal_environment_interaction')


def environment_error_plot(mean, cfg, folder, first_changed):
    q = mean[mean.scenario == 'stable_then_fluctuating'].copy()
    q['before'] = (q.prediction_pre_ER-q.observed).abs()
    q['after'] = (q.prediction-q.observed).abs()
    fig, axes = plt.subplots(2, 1, sharex=True, figsize=(10.4, 5.4))
    for j, variable in enumerate(VARIABLES[:2]):
        g = q[(q.variable == variable) & (q.condition == 'personal')]
        g = g.groupby('minute', as_index=False)[['before', 'after']].mean()
        axes[j].step(g.minute, g.before, where='post', color='#a5aab0', ls='--', label='Before local ER')
        axes[j].step(g.minute, g.after, where='post', color='#7451a4', label='After local ER')
        axes[j].set_ylabel('Absolute error\n'+LABELS[j]); axes[j].grid(axis='y', alpha=.15)
        axes[j].axvline(cfg.scenario_switch, color='#888888', ls=':')
        if first_changed != cfg.scenario_switch:
            axes[j].axvline(first_changed, color='#b77731', ls='--', lw=.8)
        axes[j].set_xlim(0, cfg.scenario_minutes)
    axes[0].legend(frameon=False); axes[-1].set_xlabel('Simulated minute')
    fig.suptitle('Current E reconstruction error; mean across 11 profiles after seed averaging', fontsize=10)
    fig.tight_layout()
    save_figure(fig, folder, 'Figure_environment_error_regression')


def validation_plot(data, r, mode, folder):
    title = f'Unseen record P{r.Pid} / Class {r.Class_id} / {mode}'
    if not data.complete_session.all(): title += ' [PREFIX: diagnostic only]'
    fig, axes = figure3_axes(title=title)
    for j, variable in enumerate(VARIABLES):
        ax = axes[j]; q = data[data.variable == variable]
        obs = q[['minute', 'observed']].drop_duplicates().sort_values('minute')
        ax.set_ylabel(LABELS[j], fontsize=8, rotation=0, ha='right', va='center')
        if j < 2:
            ax.plot(obs.minute, obs.observed, color=['#527ca3', '#4d9a95'][j])
        else:
            if j < 5:
                ax.plot(obs.minute, obs.observed, color='#777777', alpha=.5, lw=1.1)
            for condition, color, style in [('personal', '#7954a3', '-'), ('zero', '#667580', '--'), ('local10', '#181818', '-.')]:
                g = q[q.condition == condition].sort_values('minute')
                ax.plot(g.minute, g.prediction, color=color, ls=style, lw=1.25)
            if j >= 5 and r.has_report:
                # One marker outside the trajectory, never a minute-by-minute truth.
                x = float(q.minute.max())+3
                ax.plot(x, getattr(r, variable), marker='D', color='#252525', ms=4, ls='none')
                ax.annotate('Report', (x, getattr(r, variable)), xytext=(0, 6), textcoords='offset points',
                            fontsize=7, ha='center')
    axes[-1].set_xlabel('Original class-minute index; separate session-report marker')
    fig.legend(handles=[Line2D([0], [0], color='#7954a3', label='Personal A'),
                         Line2D([0], [0], color='#667580', ls='--', label='aᵢ = 0 reference'),
                         Line2D([0], [0], color='#181818', ls='-.', label='Fully adaptive A'),
                         Line2D([0], [0], color='#777777', alpha=.5, label='Recorded P'),
                         Line2D([0], [0], marker='D', color='#252525', ls='none', label='Session report')],
               loc='lower center', ncol=3, frameon=False, fontsize=8, bbox_to_anchor=(.55, .035))
    fig.text(.55, .008, 'Reconstruction when P is observed; conditional generation when P is masked.',
             ha='center', fontsize=8)
    save_figure(fig, folder, f'P{r.Pid}_Class{r.Class_id}_{mode}')


def make_simulation_plots(run, cfg):
    mean = pd.read_csv(run/'simulation'/'trajectories_seed_mean.csv')
    scenarios = pd.read_csv(run/'protocol'/'scenarios.csv')
    first_changed = scenario_timing(scenarios, cfg)
    for scenario in ['stable', 'stable_then_fluctuating']:
        simulation_plot(mean, scenarios, cfg, scenario, run/'figures')
    response_plot(pd.read_csv(run/'simulation'/'matched_environment_responses.csv'), cfg, run/'figures', first_changed)
    environment_error_plot(mean, cfg, run/'figures', first_changed)


def make_validation_plots(run, split, cfg):
    val = pd.read_csv(run/'validation'/'trajectories_seed_mean.csv')
    for r in split['validation'].itertuples(index=False):
        if r.Pid not in cfg.validation_pids: continue
        for mode in cfg.validation_modes:
            g = val[(val.Pid == r.Pid) & (val.Class_id == r.Class_id) & (val['mode'] == mode)]
            validation_plot(g, r, mode, run/'figures'/'real_records')


def make_all_plots(run, data, split, cfg):
    make_simulation_plots(run, cfg)
    make_validation_plots(run, split, cfg)
