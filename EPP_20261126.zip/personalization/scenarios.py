"""Four 10-minute E phases; original training-derived baseline/amplitudes.

Only the environmental waveform changes. Model and ER are imported unchanged.
"""
from dataclasses import replace
import numpy as np
import pandas as pd
from protocol import CHANNELS
from data_io import key


def simulation_config(config):
    """Scenario-only settings; protocol.py and training identity stay intact."""
    if config.scenario_minutes != 40:
        raise ValueError('This release requires four 10-minute phases (40 minutes)')
    return replace(config, scenario_switch=10, scenario_interval=1).validate()


def four_phase_wave():
    """40 one-minute samples; continuous joins and exact unit peak magnitude."""
    oscillation = np.sin(np.linspace(0., 2.*np.pi, 10))
    oscillation /= np.max(np.abs(oscillation))
    oscillation[[0, -1]] = 0.
    return np.r_[np.zeros(10), np.linspace(0., 1., 10),
                 np.linspace(1., 0., 10), oscillation]


def make_scenarios(data, split, config):
    config = simulation_config(config)
    e = np.unique(np.concatenate([data.arrays[key(r)][:, :2]
                                for r in split['train'].itertuples(index=False)]), axis=0).astype(float)
    center = np.median(e, axis=0); scale = e.std(axis=0)
    if (scale <= 0).any():
        raise ValueError('Training environmental variability required')
    baseline = e[np.argmin(np.sum(((e-center)/scale)**2, axis=1))]
    amp = (np.quantile(e, .75, axis=0)-np.quantile(e, .25, axis=0))*config.scenario_amplitude_IQR_fraction
    iqr_amp = amp.copy()
    wave = four_phase_wave()
    # Preserve the ORIGINAL amplitude calculation: five-minute observed changes
    # and the old stepped waveform's unit jump. One-minute ramps must not refit
    # amplitudes and thereby change the original physical range.
    amplitude_reference_interval = 5
    changes = []
    for r in split['train'].itertuples(index=False):
        k = key(r); t = data.times[k]; x = data.arrays[k][:, :2]
        lookup = {int(v): j for j, v in enumerate(t)}
        for j, v in enumerate(t):
            if int(v)+amplitude_reference_interval in lookup:
                changes.append(np.abs(x[lookup[int(v)+amplitude_reference_interval]]-x[j]))
    changes = np.asarray(changes, float)
    rate_limits = np.array([np.quantile(changes[changes[:, j] > 1e-6, j], .95)
                            for j in range(2)])
    original_wave = np.zeros(40)
    for b in range(4):
        original_wave[20+5*b:20+5*(b+1)] = np.sin(2*np.pi*b/4)
    original_max_jump = np.abs(np.diff(original_wave[::5])).max()
    amp = np.minimum(amp, rate_limits/original_max_jump)
    shrink = 1.
    for _ in range(30):
        changing = baseline+wave[:, None]*amp[None, :]*shrink
        nearest = np.sqrt(np.min(np.sum(((changing[:, None, :]-e[None, :, :])/scale)**2, axis=2), axis=1))
        inside = ((changing >= e.min(0)) & (changing <= e.max(0))).all()
        if inside and nearest.max() <= config.scenario_nearest_training_limit:
            break
        shrink *= .8
    else:
        raise ValueError('Cannot make a scenario near the training input envelope')
    if shrink != 1.:
        raise ValueError('Four-phase inputs would require changing the original amplitude')
    if np.any(amp < 1e-8):
        raise ValueError('A scenario channel has no variation')
    stable = np.tile(baseline, (40, 1))
    phases = np.repeat(['stable_prefix', 'rising', 'falling', 'fluctuating'], 10)
    frames = []
    # Preserve the existing scenario key for unchanged inference/summary APIs.
    for name, values in [('stable', stable), ('stable_then_fluctuating', changing)]:
        frames.append(pd.DataFrame(dict(scenario=name, minute=np.arange(40),
                        phase=np.repeat('stable_control', 40) if name == 'stable' else phases,
                        IndoorTemperature=values[:, 0], IndoorCO2=values[:, 1])))
    info = dict(source='training-only unique observed E pairs; no validation inputs',
                baseline=baseline.tolist(), initial_amplitudes=iqr_amp.tolist(),
                rate_limited_amplitudes=amp.tolist(), amplitudes=amp.tolist(),
                deterministic_shrink=shrink,
                first_nonbaseline_minute=int(np.flatnonzero(np.abs(wave) > 1e-8)[0]),
                distance_scale_unique_E_SD=scale.tolist(),
                training_nonzero_change_95th=rate_limits.tolist(),
                amplitude_reference_interval_minutes=amplitude_reference_interval,
                amplitude_rule='unchanged original IQR and five-minute-change rule',
                simulated_max_change_per_input_step=(np.abs(np.diff(wave)).max()*amp).tolist(),
                nearest_standardized_training_distance_max=float(nearest.max()),
                training_channel_min=e.min(0).tolist(), training_channel_max=e.max(0).tolist(),
                n_minutes=40, switch_minute=10, input_update_minutes=1,
                phase_boundaries_minutes=[10, 20, 30],
                phase_samples={'constant': [0, 9], 'rising': [10, 19],
                               'falling': [20, 29], 'fluctuating': [30, 39]},
                waveform='constant; linear rise baseline to +amplitude; linear fall to baseline; normalized sine cycle +/-amplitude; 10 samples each',
                changing_mean_deviation=(changing.mean(0)-baseline).tolist(),
                mean_matched_to_stable=False,
                sessions='two independent paired sessions; each starts at minute zero',
                state_reset='zero recurrent states, zero local A; same retained personal A',
                stochastic_inference=False, design_boundary_minute=10,
                primary_response_window='first actual nonbaseline input through session end',
                claim_scope='joint environmental path variation; not independently identified channel causality or physiological response latency')
    return pd.concat(frames, ignore_index=True), info
