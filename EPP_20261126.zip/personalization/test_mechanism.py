"""Scientific invariants and actual-checkpoint tests; no paper-effect assertions."""
from pathlib import Path
from dataclasses import replace
import copy
import json
import tempfile
import unittest
import numpy as np
import pandas as pd
import torch

from protocol import ROOT, Config, config_for, PEOPLE, CHANNELS, REPORTS, write_json, mark_stage, stage_complete
from data_io import Data, load_data, partition, training_payload, key
from personal_a import load_shared, OnlinePersonalA, fit_profiles, compose_A
from online_inference import (OnlineER, infer_sequence, condition_parameters,
                              fit_window, weight_hash)
from scenarios import make_scenarios, simulation_config, four_phase_wave
from summaries import seed_mean, report_endpoints, scenario_timing, summarize_response_windows
from training import verified_profiles, training_signature
from v6_dynamics import zero_state
from v6_reference.model import infer


class MechanismTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
        cls.data = load_data(); cls.split = partition(cls.data)
        cls.cp = ROOT/'bundled'/'seed11.pt'
        if not cls.cp.is_file():
            raise RuntimeError('Run training first; packaged tests require the actual strict checkpoint')
        cls.model, cls.saved = load_shared(cls.cp)
        cls.profiles = verified_profiles(ROOT/'bundled'/'personal_A_seed11.csv', cls.model, cls.cp, cls.split)
        cls.record = cls.data.arrays[(18, 226)][:4].copy()
        cls.times = cls.data.times[(18, 226)][:4].copy()

    def run_record(self, x=None, mode='E_only'):
        return infer_sequence(self.model, self.saved, self.record if x is None else x,
                              self.times, ['personal', 'zero', 'local10'],
                              [self.profiles[18], [0., 0.], [0., 0.]], mode, 3, 4)

    def test_strict_partition_and_chronology(self):
        s = self.split
        self.assertEqual((len(s['train']), len(s['validation']), len(s['calibration']), len(s['excluded'])),
                         (87, 11, 34, 15))
        self.assertEqual(int(s['validation'].has_report.sum()), 7)
        self.assertEqual(int(s['train'].has_report.sum()), 9)
        self.assertFalse(set(s['keys']['train_keys']) & set(s['keys']['target_keys']))
        for r in s['validation'].itertuples(index=False):
            h = s['calibration'][s['calibration'].Pid == r.Pid]
            self.assertTrue(h.ClassEnd.le(r.ClassStart).all())

    def test_target_values_cannot_change_train_scalers_or_scenarios(self):
        d = copy.deepcopy(self.data)
        for k in self.split['keys']['excluded_keys']: d.arrays[k] += 100000.
        for r in self.split['excluded'].itertuples(index=False):
            select = (d.meta.Pid == r.Pid) & (d.meta.Class_id == r.Class_id)
            d.meta.loc[select, list(REPORTS)] = 100000.
        a = training_payload(self.data, self.split)
        # Use changed metadata but exactly the predeclared split membership.
        changed_split = dict(self.split)
        changed_split['train'] = d.meta[[key(r) in set(self.split['keys']['train_keys'])
                                       for r in d.meta.itertuples(index=False)]].reset_index(drop=True)
        b = training_payload(d, changed_split)
        np.testing.assert_array_equal(a['xs'].mean_, b['xs'].mean_)
        np.testing.assert_array_equal(a['ys'].mean_, b['ys'].mean_)
        ea, ia = make_scenarios(self.data, self.split, Config())
        eb, ib = make_scenarios(d, changed_split, Config())
        pd.testing.assert_frame_equal(ea, eb); self.assertEqual(ia, ib)

    def test_hidden_physiology_changes_only_EP_outputs(self):
        x = self.record.copy()
        x[:, 2:] += 2*np.asarray(self.saved['scaler_scale'])[2:]
        a = self.run_record()[0]; b = self.run_record(x)[0]
        np.testing.assert_array_equal(a, b)
        c = self.run_record(mode='EP_online')[0]; d = self.run_record(x, 'EP_online')[0]
        self.assertGreater(float(np.abs(c-d).max()), 1e-5)

    def test_future_input_cannot_revise_issued_outputs(self):
        x = self.record.copy(); x[-1] += np.asarray(self.saved['scaler_scale'])*3
        for mode in ['E_only', 'EP_online']:
            a = self.run_record(mode=mode)[0]; b = self.run_record(x, mode)[0]
            np.testing.assert_array_equal(a[:, :-1], b[:, :-1])

    def test_all_arms_keep_network_frozen_and_positive_EDA(self):
        before = weight_hash(self.model)
        out, pre, d = self.run_record(mode='EP_online')
        self.assertEqual(before, weight_hash(self.model))
        self.assertTrue(np.isfinite(out).all()); self.assertTrue((out[..., 2] >= 0).all())
        self.assertTrue(all(q['fixed_coordinates_verified'] for q in d))
        self.assertTrue(all(q['objective_after'] <= q['objective_before']+1e-7 for q in d))

    def test_fixed_coordinates_and_fully_local_mask(self):
        mask, fixed = condition_parameters(['personal', 'zero', 'local10'], [[.3, -.4], [0., 0.], [0., 0.]])
        self.assertEqual(mask.sum(1).tolist(), [8., 8., 10.])
        np.testing.assert_array_equal(fixed[0, 6:8].numpy(), np.array([.3, -.4], np.float32))
        torch.testing.assert_close(fixed[1:], torch.zeros(2, 10))

    def test_fixed2_local8_matches_original_v2_through_windows_and_gaps(self):
        a = OnlineER(self.model, ['personal', 'zero'], [[.2, -.3], [0., 0.]], 3, 4)
        b = OnlinePersonalA(self.model, [[.2, -.3], [0., 0.]], 3, 4)
        for t in [0, 1, 3, 4, 5]:
            x = a.observe([.1, .2], t, [.4, .5, .6])['out']
            y = b.observe([.1, .2], t, [.4, .5, .6])['out']
            torch.testing.assert_close(x['reconstruction'], y['reconstruction'], atol=2e-6, rtol=2e-5)
            torch.testing.assert_close(x['prediction'], y['prediction'], atol=2e-6, rtol=2e-5)

    def test_local10_single_window_matches_original_main_ER(self):
        a = (self.record[:3]-np.asarray(self.saved['scaler_mean']))/np.asarray(self.saved['scaler_scale'])
        x = torch.tensor(a.astype(np.float32))[None]
        times = np.arange(3); mask, fixed = condition_parameters(['local10'], [[0., 0.]])
        out, _, _ = fit_window(self.model, x, torch.ones_like(x, dtype=torch.bool), times,
                               mask, fixed, zero_state(self.model, 1), torch.zeros(1, 3, 10), 4)
        reference, _, _ = infer(self.model, x, torch.tensor([3]), self.model.cfg,
                                steps=4, window_ids=torch.tensor(times)[None])
        torch.testing.assert_close(out['reconstruction'], reference['reconstruction'], atol=2e-6, rtol=2e-5)
        torch.testing.assert_close(out['prediction'], reference['prediction'], atol=2e-6, rtol=2e-5)

    def test_batch_row_order_does_not_change_predictions_within_float32_tolerance(self):
        a = OnlineER(self.model, ['personal', 'zero', 'local10'], [[.5, -.3], [0., 0.], [0., 0.]], 3, 4)
        b = OnlineER(self.model, ['local10', 'zero', 'personal'], [[0., 0.], [0., 0.], [.5, -.3]], 3, 4)
        for t in range(5):
            x = a.observe([.1*t, .2], t)['out']['reconstruction']
            y = b.observe([.1*t, .2], t)['out']['reconstruction'].flip(0)
            torch.testing.assert_close(x, y, atol=2e-6, rtol=2e-5)

    def test_multirecord_calibration_shares_personal_only_not_session_state(self):
        x = (self.record-np.asarray(self.saved['scaler_mean']))/np.asarray(self.saved['scaler_scale'])
        fit = fit_profiles(self.model, [x[:2], x[2:]], [np.arange(2), np.arange(2)],
                           steps=4, person_index=[0, 0])
        self.assertEqual(tuple(fit['personal'].shape), (1, 2))
        A = compose_A(fit['local'], fit['personal'].expand(2, -1))
        torch.testing.assert_close(A[0, :, 6:8], A[1, :, 6:8])

    def test_four_phases_and_original_amplitudes(self):
        original = json.loads((ROOT/'original_reference/original_scenario_definition.json').read_text())
        for c in [Config(), config_for('quickcheck')]:
            c = simulation_config(c)
            d, info = make_scenarios(self.data, self.split, c)
            stable = d[d.scenario == 'stable'][list(CHANNELS[:2])].to_numpy()
            changing = d[d.scenario == 'stable_then_fluctuating'][list(CHANNELS[:2])].to_numpy()
            np.testing.assert_array_equal(stable[:11], changing[:11])
            np.testing.assert_allclose(info['baseline'], original['baseline'], rtol=0, atol=0)
            np.testing.assert_allclose(info['amplitudes'], original['amplitudes'], rtol=0, atol=0)
            wave = (changing-stable)/np.asarray(info['amplitudes'])
            np.testing.assert_allclose(wave[:,0], wave[:,1], atol=1e-12)
            self.assertTrue((np.diff(wave[10:20,0]) > 0).all())
            self.assertTrue((np.diff(wave[20:30,0]) < 0).all())
            self.assertAlmostEqual(float(wave[19,0]), 1.)
            self.assertAlmostEqual(float(wave[29,0]), 0.)
            self.assertAlmostEqual(float(wave[30:40,0].max()), 1.)
            self.assertAlmostEqual(float(wave[30:40,0].min()), -1.)
            self.assertEqual(info['phase_boundaries_minutes'], [10,20,30])
            self.assertEqual(info['first_nonbaseline_minute'], 11)
            self.assertTrue((np.abs(np.diff(changing,axis=0)).max(0) <=
                             np.asarray(info['training_nonzero_change_95th'])+1e-7).all())

    def test_seed_mean_is_not_median_or_average_of_errors(self):
        f = pd.DataFrame(dict(seed=[11, 23, 37], key=[1, 1, 1], prediction=[0., 2., 10.],
                              prediction_pre_ER=[0., 0., 0.], observed=[0., 0., 0.]))
        m = seed_mean(f, ['key'], [11, 23, 37])
        self.assertEqual(float(m.prediction.iloc[0]), 4.)
        self.assertEqual(float(((m.prediction-m.observed)**2).iloc[0]), 16.)

    def test_two40_default_and_actual_input_onset(self):
        c = simulation_config(config_for('formal'))
        self.assertEqual((c.scenario_minutes,c.scenario_switch,c.scenario_interval),(40,10,1))
        d,info = make_scenarios(self.data,self.split,c)
        self.assertEqual(len(d),80)
        self.assertEqual(scenario_timing(d,c),11)
        self.assertFalse(info['stochastic_inference'])
        for _,g in d.groupby('scenario'):
            np.testing.assert_array_equal(g.minute,np.arange(40))

    def test_independent_session_reset_keeps_same_profile_and_outputs(self):
        x = self.record.copy()
        conditions = ['personal', 'zero', 'local10']
        profiles = [self.profiles[18], [0., 0.], [0., 0.]]
        before = copy.deepcopy(profiles)
        a = infer_sequence(self.model, self.saved, x, self.times, conditions, profiles, steps=4, window=3)[0]
        # An intervening unrelated session cannot contaminate a fresh session.
        other = x.copy(); other[:, :2] += np.asarray(self.saved['scaler_scale'])[:2]
        infer_sequence(self.model, self.saved, other, self.times, conditions, profiles, steps=4, window=3)
        b = infer_sequence(self.model, self.saved, x, self.times, conditions, profiles, steps=4, window=3)[0]
        np.testing.assert_array_equal(a, b)
        self.assertEqual(profiles, before)

    def test_response_window_does_not_silently_dilute_actual_response(self):
        c = Config()
        f = pd.DataFrame(dict(Pid=18, condition='personal', variable='HR', minute=np.arange(40),
                              response=np.r_[np.zeros(25), np.ones(15)*2],
                              response_minus_zero=np.r_[np.zeros(25), np.ones(15)]))
        s = summarize_response_windows(f, c, 25).set_index('analysis_window')
        self.assertEqual(int(s.loc['actual_input_onset', 'n_minutes']), 15)
        self.assertEqual(int(s.loc['scheduled_second_phase', 'n_minutes']), 20)
        self.assertEqual(float(s.loc['actual_input_onset', 'mean_absolute_response_difference_vs_zero']), 1.)
        self.assertEqual(float(s.loc['scheduled_second_phase', 'mean_absolute_response_difference_vs_zero']), .75)

    def test_simulation_duration_does_not_change_model_training_identity(self):
        c = Config()
        old_duration = replace(c, scenario_minutes=80, scenario_switch=40)
        self.assertEqual(training_signature(self.data, self.split, c, 11),
                         training_signature(self.data, self.split, old_duration, 11))

    def test_reports_score_once_per_complete_record_and_not_for_unlabeled(self):
        r = self.split['validation'][self.split['validation'].Pid == 18].copy()
        rows = []
        for step in [1, 2, 3]:
            for v in REPORTS:
                rows.append(dict(Pid=18, Class_id=226, mode='E_only', condition='personal',
                                  variable=v, minute=step, prediction=2., complete_session=True))
        complete = report_endpoints(pd.DataFrame(rows), r)
        self.assertEqual(len(complete), 3); self.assertTrue(complete.scored.all())
        partial = pd.DataFrame(rows); partial['complete_session'] = False
        self.assertFalse(report_endpoints(partial, r).scored.any())
        r['has_report'] = False
        self.assertFalse(report_endpoints(pd.DataFrame(rows), r).scored.any())

    def test_wrong_checkpoint_profile_and_tampered_cache_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); fake = root/'wrong.pt'; fake.write_bytes(b'not this model')
            with self.assertRaises(ValueError):
                verified_profiles(ROOT/'bundled/personal_A_seed11.csv', self.model, fake, self.split)
            f = root/'result.txt'; f.write_text('ok')
            mark_stage(root, 'test', 'signature', [f])
            self.assertTrue(stage_complete(root, 'test', 'signature'))
            f.write_text('changed')
            with self.assertRaises(ValueError): stage_complete(root, 'test', 'signature')

    def test_quickcheck_cannot_be_mistaken_for_formal_training(self):
        self.assertNotEqual(training_signature(self.data, self.split, Config(), 11),
                            training_signature(self.data, self.split, config_for('quickcheck'), 11))
        with self.assertRaises(ValueError): replace(Config(), validation_max_minutes=20).validate()


if __name__ == '__main__':
    unittest.main(verbosity=2)
