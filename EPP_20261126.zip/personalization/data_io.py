"""Frozen minute data, deterministic record split, train-only scaling."""
from dataclasses import dataclass
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from protocol import ROOT, PEOPLE, CHANNELS, REPORTS, sha_file, digest, write_csv, write_json


@dataclass
class Data:
    meta: pd.DataFrame
    arrays: dict
    times: dict
    hashes: dict


def key(row):
    return (int(row.Pid), int(row.Class_id))


def load_data(folder=None):
    folder = ROOT/'data' if folder is None else Path(folder)
    provenance = json.loads((folder/'provenance.json').read_text(encoding='utf-8'))
    actual = {n: sha_file(folder/n) for n in ('records.csv', 'minutes.csv')}
    if actual != provenance['data_sha256']:
        raise ValueError('Frozen input data changed. Do not silently reuse model/scalers.')
    m = pd.read_csv(folder/'records.csv')
    d = pd.read_csv(folder/'minutes.csv')
    if (len(m), m.Pid.nunique(), int(m.has_report.sum())) != (102, 22, 16):
        raise ValueError('Expected frozen 102/22/16 source counts')
    if m.duplicated(['Pid', 'Class_id']).any() or d.duplicated(['Pid', 'Class_id', 'minute']).any():
        raise ValueError('Duplicate record/minute keys')
    if not m.EnvironmentScope.eq('school_indoor_context').all():
        raise ValueError('Wrong exposure representation')
    arrays, times = {}, {}
    for k, g in d.groupby(['Pid', 'Class_id'], sort=True):
        g = g.sort_values('minute')
        x = g[list(CHANNELS)].to_numpy(np.float32)
        t = g.minute.to_numpy(int)
        if not np.isfinite(x).all() or (np.diff(t) <= 0).any():
            raise ValueError('Nonfinite values or invalid time sequence')
        arrays[tuple(map(int, k))], times[tuple(map(int, k))] = x, t
    if set(arrays) != set(map(tuple, m[['Pid', 'Class_id']].to_numpy(int))):
        raise ValueError('Record metadata and minute keys disagree')
    for r in m.itertuples(index=False):
        if len(arrays[key(r)]) != r.n_minutes:
            raise ValueError('Minute counts do not match metadata')
    return Data(m.sort_values(['ClassStart', 'Pid', 'Class_id']).reset_index(drop=True),
                arrays, times, actual)


def partition(data, min_minutes=20):
    """One target per specified person, selected without looking at model errors.

    Prefer the last report-linked record with sufficient earlier E/P history;
    otherwise use the last E/P record with that history. Exclude targets and
    every record of the same person that is not entirely before their target.
    Other people's shared dates remain allowed: this is record-level separation.
    """
    m = data.meta
    targets, calibration, excluded = [], [], []
    for pid in PEOPLE:
        p = m[m.Pid == pid].sort_values(['ClassStart', 'Class_id'])
        eligible = []
        for _, r in p.iterrows():
            history = p[p.ClassEnd <= r.ClassStart]
            if history.n_minutes.sum() >= min_minutes:
                eligible.append(r)
        if not eligible:
            raise ValueError(f'Person {pid} lacks a valid historical calibration/target split')
        candidates = pd.DataFrame(eligible)
        labeled = candidates[candidates.has_report]
        target = (labeled if len(labeled) else candidates).iloc[-1].copy()
        target['selection_reason'] = 'latest eligible report record' if len(labeled) else 'latest eligible EP record'
        targets.append(target)
        history = p[p.ClassEnd <= target.ClassStart].copy()
        if history.empty or (history.Class_id == target.Class_id).any():
            raise AssertionError('Invalid calibration membership')
        calibration.append(history)
        bad = p[p.ClassEnd > target.ClassStart].copy()
        bad['exclusion_reason'] = np.where(bad.Class_id.eq(target.Class_id),
                                            'validation target',
                                            'same-person overlapping/later record')
        excluded.append(bad)
    val = pd.DataFrame(targets).sort_values('Pid').reset_index(drop=True)
    cal = pd.concat(calibration, ignore_index=True).sort_values(['Pid', 'ClassStart'])
    exc = pd.concat(excluded, ignore_index=True).sort_values(['Pid', 'ClassStart'])
    excluded_keys = {key(r) for r in exc.itertuples(index=False)}
    train = m[[key(r) not in excluded_keys for r in m.itertuples(index=False)]].copy()
    train_keys = {key(r) for r in train.itertuples(index=False)}
    target_keys = {key(r) for r in val.itertuples(index=False)}
    cal_keys = {key(r) for r in cal.itertuples(index=False)}
    if train_keys & target_keys or cal_keys & target_keys or not cal_keys <= train_keys:
        raise AssertionError('Partition leakage')
    if len(val) != 11 or val.Pid.nunique() != 11:
        raise AssertionError('Need one genuine target for each of 11 people')
    for r in val.itertuples(index=False):
        if not cal[cal.Pid.eq(r.Pid)].ClassEnd.le(r.ClassStart).all():
            raise AssertionError('Future record in personal calibration')
    payload = dict(train_keys=sorted(train_keys), target_keys=sorted(target_keys),
                   calibration_keys=sorted(cal_keys), excluded_keys=sorted(excluded_keys))
    return dict(train=train.reset_index(drop=True), validation=val,
                calibration=cal.reset_index(drop=True), excluded=exc.reset_index(drop=True),
                signature=digest(payload), keys=payload)


def training_payload(data, split):
    train = split['train']
    arrays = [data.arrays[key(r)] for r in train.itertuples(index=False)]
    times = [data.times[key(r)] for r in train.itertuples(index=False)]
    xs = StandardScaler().fit(np.concatenate(arrays))
    y = train[list(REPORTS)].to_numpy(float)
    selected = train.has_report.to_numpy(bool)
    if selected.sum() < 2 or not np.isfinite(y[selected]).all():
        raise ValueError('Need complete training-only report supervision')
    ys = StandardScaler().fit(y[selected])
    yz = np.full(y.shape, np.nan, np.float32)
    yz[selected] = ys.transform(y[selected]).astype(np.float32)
    return dict(arrays=[xs.transform(a).astype(np.float32) for a in arrays],
                times=times, y=yz, selected=selected, xs=xs, ys=ys)


def write_partition(run, data, split):
    paths = []
    for n in ('train', 'validation', 'calibration', 'excluded'):
        p = run/'protocol'/(n+'_records.csv')
        write_csv(p, split[n]); paths.append(p)
    note = dict(split_signature=split['signature'], input_sha256=data.hashes,
                training_records=len(split['train']), training_people=int(split['train'].Pid.nunique()),
                training_reports=int(split['train'].has_report.sum()),
                validation_records=len(split['validation']),
                validation_reports=int(split['validation'].has_report.sum()),
                calibration_records=len(split['calibration']),
                excluded_records=len(split['excluded']), keys=split['keys'],
                scope='unseen participant-records; shared people/dates/contexts allowed; not a new-participant or new-date test',
                calibration='only earlier records; all five real channels; no report labels',
                selection='report availability and chronology only; never output quality')
    p = run/'protocol'/'data_partition.json'; write_json(p, note); paths.append(p)
    return paths
