"""Same v6 network, tied personal slow-A inference family and positive EDA mean.

The observation link is fixed and used in training AND inference. No observation
noise is sampled; outputs are conditional mean trajectories, not a validated
physiological stochastic process. Original v6/LOSO checkpoints are untouched.
"""
import torch
from v6_reference.model import FiveArrowPVRNN

class PositiveEDAHead(torch.nn.Module):
    def __init__(self,base,mean,scale):
        super().__init__();self.base=base
        self.register_buffer('mean',torch.as_tensor(mean,dtype=torch.float32))
        self.register_buffer('scale',torch.as_tensor(scale,dtype=torch.float32))
    def forward(self,state):
        z=self.base(state)
        # A positive conditional mean in raw EDA units. The existing training
        # SD supplies the unit scale; there is no fitted or hand-tuned gain.
        raw_eda=z[...,2]*self.scale[2]+self.mean[2]
        eda=torch.nn.functional.softplus(raw_eda/self.scale[2])*self.scale[2]
        return torch.cat([z[...,:2],((eda-self.mean[2])/self.scale[2])[...,None],z[...,3:]],-1)
    def raw_mean(self,state):
        """Export physical units directly, avoiding a near-zero inverse-scaling roundoff."""
        z=self.base(state);raw=z*self.scale+self.mean
        eda=torch.nn.functional.softplus(raw[...,2]/self.scale[2])*self.scale[2]
        return torch.cat([raw[...,:2],eda[...,None],raw[...,3:]],-1)

def make_backbone(cfg,mean,scale):
    model=FiveArrowPVRNN(cfg)
    model.sensory_head=PositiveEDAHead(model.sensory_head,mean,scale)
    return model
