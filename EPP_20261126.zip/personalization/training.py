"""Train-only shared model, followed by separate history-only A calibration."""
from pathlib import Path
import json
import os
import shutil
import time
import numpy as np
import pandas as pd
import torch
from protocol import (ROOT, PEOPLE, REPORTS, digest, sha_file, write_csv, write_json,
                      mark_stage, stage_complete)
from data_io import key, training_payload
from v6_reference.model import Settings, pad, seed_all, window_ids_tensor
from backbone import make_backbone
from personal_a import compose_A, losses, fit_profiles, load_shared
from online_inference import weight_hash


def training_signature(data, split, cfg, seed):
    return digest(dict(mode=cfg.mode, seed=seed, epochs=cfg.train_epochs,
                       algorithm=cfg.algorithm, split=split['signature'], inputs=data.hashes,
                       source={n: sha_file(ROOT/n) for n in ['training.py', 'data_io.py', 'protocol.py', 'backbone.py',
                                'personal_a.py', 'v6_dynamics.py', 'v6_reference/model.py']}))


def ensure_model(run, data, split, cfg, seed, force=False):
    signature = training_signature(data, split, cfg, seed)
    stage = f'train_seed{seed}'
    cp = run/'models'/f'seed{seed}.pt'
    trace_path = run/'models'/f'training_seed{seed}.csv'
    if stage_complete(run, stage, signature):
        print(f'  seed {seed}: training cache verified', flush=True)
        return cp
    bundled = ROOT/'bundled'/f'seed{seed}.pt'
    if not force and cfg.mode == 'formal' and bundled.is_file():
        saved = torch.load(bundled, map_location='cpu', weights_only=False)
        if saved.get('training_signature') == signature:
            cp.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(bundled, cp)
            shutil.copyfile(ROOT/'bundled'/f'training_seed{seed}.csv', trace_path)
            mark_stage(run, stage, signature, [cp, trace_path])
            print(f'  seed {seed}: bundled train-only checkpoint verified and reused', flush=True)
            return cp
    payload = training_payload(data, split)
    seed_all(seed)
    settings = Settings(epochs=cfg.train_epochs, seeds=tuple(cfg.seeds))
    xs, ys = payload['xs'], payload['ys']
    model = make_backbone(settings, xs.mean_, xs.scale_)
    model.train()
    x, lengths = pad(payload['arrays'])
    ids = window_ids_tensor(payload['times'], lengths, x.shape[1])
    observed = torch.arange(x.shape[1])[None, :, None] < lengths[:, None, None]
    observed = observed.expand_as(x)
    pids = sorted(split['train'].Pid.unique())
    person_index = torch.tensor([pids.index(pid) for pid in split['train'].Pid])
    personal = torch.nn.Parameter(torch.zeros(len(pids), 2))
    local = torch.nn.Parameter(torch.zeros(len(x), x.shape[1], 8))
    opt = torch.optim.AdamW([
        dict(params=model.parameters(), lr=settings.lr, weight_decay=settings.weight_decay),
        dict(params=[personal, local], lr=settings.adaptive_lr, weight_decay=0.)])
    y = torch.tensor(payload['y']); selected = torch.tensor(payload['selected'])
    trace = []; tic = time.perf_counter()
    for epoch in range(cfg.train_epochs):
        opt.zero_grad(set_to_none=True)
        centered = personal-personal.mean(0, keepdim=True)
        A = compose_A(local, centered[person_index])
        out = model(lengths, A, sample=True, window_ids=ids)
        gen = (losses(out, x, observed, lengths, settings)*lengths).sum()/lengths.sum()
        yp = model(lengths, A.detach(), sample=False, window_ids=ids)['prediction']
        sup = (yp[selected]-y[selected]).square().mean()
        objective = gen+sup
        if not torch.isfinite(objective):
            raise FloatingPointError('Nonfinite training loss')
        objective.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        torch.nn.utils.clip_grad_norm_([personal, local], 5., error_if_nonfinite=True)
        opt.step()
        trace.append(dict(epoch=epoch+1, generative_objective=float(gen.detach()),
                          report_loss=float(sup.detach())))
        if (epoch+1) % 25 == 0 or epoch+1 == cfg.train_epochs:
            print(f'  training seed {seed}: {epoch+1}/{cfg.train_epochs}', flush=True)
    model.eval()
    reports = split['train'][split['train'].has_report]
    record = dict(backbone_kind='tied_A_positive_EDA_v2', state_dict=model.state_dict(),
                  config=vars(settings), scaler_mean=xs.mean_.tolist(),
                  scaler_scale=xs.scale_.tolist(), target_scaler_mean=ys.mean_.tolist(),
                  target_scaler_scale=ys.scale_.tolist(),
                  training_keys=split['train'][['Pid', 'Class_id']].to_dict('records'),
                  report_training_keys=reports[['Pid', 'Class_id']].to_dict('records'),
                  training_person_ids=list(map(int, pids)),
                  centered_training_personal_A=(personal-personal.mean(0, keepdim=True)).detach(),
                  training_signature=signature, split_signature=split['signature'],
                  target_keys=split['keys']['target_keys'], input_sha256=data.hashes,
                  report_supervision_gradients_to_A=False,
                  observation_link='positive raw EDA; same link in train and inference',
                  scope='strict record exclusion; other people/dates may be shared',
                  software=dict(torch=torch.__version__, numpy=np.__version__, pandas=pd.__version__),
                  seconds=time.perf_counter()-tic)
    cp.parent.mkdir(parents=True, exist_ok=True)
    temp = cp.with_suffix('.pt.tmp'); torch.save(record, temp); os.replace(temp, cp)
    write_csv(trace_path, pd.DataFrame(trace))
    mark_stage(run, stage, signature, [cp, trace_path])
    return cp


def calibration_signature(data, split, cfg, checkpoint):
    return digest(dict(checkpoint=sha_file(checkpoint), split=split['signature'],
                       steps=cfg.calibration_steps, algorithm=cfg.algorithm,
                       inputs=data.hashes, source=sha_file(ROOT/'personal_a.py')))


def ensure_profiles(run, data, split, cfg, seed, checkpoint, force=False):
    signature = calibration_signature(data, split, cfg, checkpoint)
    stage = f'calibration_seed{seed}'
    csv = run/'profiles'/f'personal_A_seed{seed}.csv'
    info = run/'profiles'/f'personal_A_seed{seed}.json'
    trace = run/'profiles'/f'calibration_trace_seed{seed}.csv'
    if stage_complete(run, stage, signature):
        return csv
    source_info = ROOT/'bundled'/info.name
    if not force and cfg.mode == 'formal' and source_info.is_file():
        m = json.loads(source_info.read_text(encoding='utf-8'))
        if m.get('signature') == signature:
            for dest in [csv, info, trace]:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ROOT/'bundled'/dest.name, dest)
            mark_stage(run, stage, signature, [csv, info, trace])
            print(f'  seed {seed}: bundled history-only profiles verified and reused', flush=True)
            return csv
    model, saved = load_shared(checkpoint); before = weight_hash(model)
    cal = split['calibration']; xs_m = np.asarray(saved['scaler_mean']); xs_s = np.asarray(saved['scaler_scale'])
    arrays = [(data.arrays[key(r)]-xs_m)/xs_s for r in cal.itertuples(index=False)]
    times = [data.times[key(r)] for r in cal.itertuples(index=False)]
    index = [PEOPLE.index(pid) for pid in cal.Pid]
    tic = time.perf_counter()
    fit = fit_profiles(model, arrays, times, steps=cfg.calibration_steps, person_index=index,
                       progress=lambda n, total: print(f'  calibration seed {seed}: {n}/{total}', flush=True))
    if weight_hash(model) != before:
        raise AssertionError('Calibration changed shared weights')
    rows = []
    for j, pid in enumerate(PEOPLE):
        q = cal[cal.Pid == pid]
        rows.append(dict(Pid=pid, seed=seed, A_slow_0=float(fit['personal'][j, 0]),
                         A_slow_1=float(fit['personal'][j, 1]), best_step=fit['best_step'][j],
                         objective=fit['best_objective'][j], calibration_records=len(q),
                         calibration_minutes=int(q.n_minutes.sum()), network_sha=before,
                         checkpoint_sha=sha_file(checkpoint), split_signature=split['signature']))
    write_csv(csv, pd.DataFrame(rows)); write_csv(trace, pd.DataFrame(fit['trace']))
    write_json(info, dict(signature=signature, seed=seed, checkpoint_sha=sha_file(checkpoint),
                         network_sha=before, split_signature=split['signature'],
                         measured_counts=fit['measured_counts'], seconds=time.perf_counter()-tic,
                         profile_uses_report_labels=False, network_frozen=True,
                         scope='all earlier calibration records; validation and later records excluded'))
    mark_stage(run, stage, signature, [csv, info, trace])
    return csv


def verified_profiles(csv, model, checkpoint, split):
    p = pd.read_csv(csv)
    if set(p.Pid) != set(PEOPLE) or p.Pid.duplicated().any():
        raise ValueError('Wrong personal-profile membership')
    if not p.checkpoint_sha.eq(sha_file(checkpoint)).all() or not p.network_sha.eq(weight_hash(model)).all():
        raise ValueError('Profiles belong to another checkpoint; old v2 A cannot be substituted')
    if not p.split_signature.eq(split['signature']).all():
        raise ValueError('Profiles belong to a different data partition')
    return {int(r.Pid): [float(r.A_slow_0), float(r.A_slow_1)] for r in p.itertuples(index=False)}
