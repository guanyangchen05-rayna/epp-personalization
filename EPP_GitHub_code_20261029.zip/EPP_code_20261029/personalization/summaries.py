"""Seed-mean summaries; no invented truths for the hypothetical session."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from protocol import CHANNELS, REPORTS, PEOPLE, write_csv, write_json


def scenario_timing(scenarios, cfg):
    """Find the actual onset from saved E inputs, rather than a plot boundary."""
    if set(scenarios.scenario) != {'stable', 'stable_then_fluctuating'}:
        raise ValueError('Exactly two paired environmental sessions required')
    values = []
    for name in ['stable', 'stable_then_fluctuating']:
        g = scenarios[scenarios.scenario == name].sort_values('minute')
        if not np.array_equal(g.minute.to_numpy(), np.arange(cfg.scenario_minutes)):
            raise ValueError('Each session must have its own complete minute-zero clock')
        values.append(g[list(CHANNELS[:2])].to_numpy(float))
    stable, changing = values
    if not np.isfinite(values).all() or not np.array_equal(stable, np.tile(stable[0], (len(stable), 1))):
        raise ValueError('Invalid stable control')
    changed = np.flatnonzero(np.any(changing != stable, axis=1))
    if not len(changed) or int(changed[0]) < cfg.scenario_switch:
        raise ValueError('Invalid environmental onset')
    return int(changed[0])


def summarize_response_windows(response, cfg, first_changed):
    """Keep the primary actual-onset window separate from the planned phase."""
    tables = []
    for name, start in [('actual_input_onset', first_changed),
                        ('scheduled_second_phase', cfg.scenario_switch)]:
        post = response[(response.minute >= start) & (response.minute < cfg.scenario_minutes)].copy()
        post['abs_response'] = post.response.abs()
        post['abs_interaction'] = post.response_minus_zero.abs()
        q = post.groupby(['Pid', 'condition', 'variable'], as_index=False).agg(
            mean_response=('response', 'mean'), mean_absolute_response=('abs_response', 'mean'),
            mean_absolute_response_difference_vs_zero=('abs_interaction', 'mean'),
            n_minutes=('minute', 'size'))
        if not q.n_minutes.eq(cfg.scenario_minutes-start).all():
            raise ValueError('Incomplete paired-response time window')
        q['analysis_window'] = name
        q['primary_window'] = name == 'actual_input_onset'
        q['start_minute_inclusive'] = start
        q['end_minute_exclusive'] = cfg.scenario_minutes
        tables.append(q)
    return pd.concat(tables, ignore_index=True)


def seed_mean(frame, keys, expected_seeds):
    if set(frame.seed.unique()) != set(expected_seeds):
        raise ValueError('Incomplete/unexpected seed membership')
    counts = frame.groupby(keys, dropna=False).seed.nunique()
    if not counts.eq(len(expected_seeds)).all():
        raise ValueError('Some outputs are missing requested seeds')
    if frame.duplicated(keys+['seed']).any():
        raise ValueError('Duplicate seed/time/condition output')
    return frame.groupby(keys, as_index=False, dropna=False).agg(
        prediction=('prediction', 'mean'), prediction_pre_ER=('prediction_pre_ER', 'mean'),
        seed_min=('prediction', 'min'), seed_max=('prediction', 'max'),
        observed=('observed', 'first'), n_seeds=('seed', 'nunique'))


def error_table(d, keys):
    a = d.copy()
    a['squared_error'] = (a.prediction-a.observed)**2
    a['absolute_error'] = (a.prediction-a.observed).abs()
    a['signed_error'] = a.prediction-a.observed
    table = a.groupby(keys, as_index=False, dropna=False).agg(
        MSE=('squared_error', 'mean'), MAE=('absolute_error', 'mean'),
        bias=('signed_error', 'mean'), n_values=('prediction', 'size'),
        n_records=('Class_id', 'size'), n_people=('Pid', 'nunique'))
    table['RMSE'] = np.sqrt(table.MSE)
    return table


def summarize_simulation(run, cfg):
    files = sorted((run/'simulation'/'cases').glob('simulation_seed*.csv'))
    d = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    expected_rows = len(cfg.seeds)*2*cfg.scenario_minutes*(len(PEOPLE)+2)*8
    if len(d) != expected_rows:
        raise ValueError(f'Wrong simulation size {len(d)} != {expected_rows}')
    scenarios = pd.read_csv(run/'protocol'/'scenarios.csv')
    first_changed = scenario_timing(scenarios, cfg)
    saved_timing = json.loads((run/'protocol'/'scenario_definition.json').read_text(encoding='utf-8'))
    if saved_timing['first_nonbaseline_minute'] != first_changed:
        raise ValueError('Scenario metadata and actual input onset disagree')
    expected_membership = {(0, 'zero'), (0, 'local10')} | {(p, 'personal') for p in PEOPLE}
    if set(zip(d.Pid, d.condition)) != expected_membership:
        raise ValueError('Wrong simulation profiles or duplicated shared-reference identities')
    if set(d.minute) != set(range(cfg.scenario_minutes)) or set(d.variable) != set(CHANNELS+REPORTS):
        raise ValueError('Wrong simulation clock or channels')
    if set(d.scenario) != {'stable', 'stable_then_fluctuating'}:
        raise ValueError('Wrong simulation scenarios')
    if d.loc[~d.variable.isin(CHANNELS[:2]), 'observed'].notna().any():
        raise ValueError('Hypothetical P/B must not contain fabricated ground truth')
    keys = ['scenario', 'Pid', 'condition', 'step', 'minute', 'variable']
    mean = seed_mean(d, keys, cfg.seeds)
    # Check each model fit: averaging seeds must not conceal prefix differences.
    before = d[d.minute < first_changed]
    prefixes = before.pivot(index=['seed', 'Pid', 'condition', 'minute', 'variable'],
                            columns='scenario', values='prediction')
    max_error = float((prefixes.stable-prefixes.stable_then_fluctuating).abs().max())
    if max_error > 2e-6:
        raise AssertionError('Identical input prefixes produced different issued outputs')
    write_csv(run/'simulation'/'all_trajectories_by_seed.csv', d)
    write_csv(run/'simulation'/'trajectories_seed_mean.csv', mean)
    response_rows = []
    for variable, g in mean[~mean.variable.isin(CHANNELS[:2])].groupby('variable'):
        response = g.pivot(index=['Pid', 'condition', 'minute'], columns='scenario', values='prediction')
        response['response'] = response.stable_then_fluctuating-response.stable
        zero = response.loc[(0, 'zero'), 'response']
        for (pid, condition), q in response.reset_index().groupby(['Pid', 'condition']):
            for r in q.itertuples(index=False):
                response_rows.append(dict(Pid=pid, condition=condition, minute=r.minute,
                                         variable=variable, response=r.response,
                                         response_minus_zero=r.response-zero.loc[r.minute]))
    response = pd.DataFrame(response_rows)
    write_csv(run/'simulation'/'matched_environment_responses.csv', response)
    summary = summarize_response_windows(response, cfg, first_changed)
    write_csv(run/'simulation'/'response_summary.csv', summary)
    write_json(run/'simulation'/'interpretation.json', dict(
        prefix_max_abs_difference=max_error, n_simulated_people=len(PEOPLE),
        prefix_checked='every seed separately, through the minute before actual E first differs',
        n_sessions=2, minutes_per_session=cfg.scenario_minutes,
        design_boundary_minute=cfg.scenario_switch, first_nonbaseline_minute=first_changed,
        primary_response_window='actual_input_onset; start inclusive, end exclusive',
        secondary_response_window='scheduled_second_phase; includes initial baseline block',
        reference_curves='zero and local10 each generated once per scenario/seed',
        simulated_truth='No real P/B ground truth exists for these scenarios; no RMSE/MAE computed',
        B='report-head readout; session-level supervision does not establish minute-level accuracy',
        response='fluctuating minus stable at the same time; then subtract zero-reference response',
        uncertainty='seed min/max are model-fit ranges, not confidence intervals'))


def report_endpoints(mean, metadata):
    rows = []
    reports = mean[mean.variable.isin(REPORTS)]
    for (pid, cid, mode, condition, variable), g in reports.groupby(
            ['Pid', 'Class_id', 'mode', 'condition', 'variable']):
        g = g.sort_values('minute'); last = g.iloc[-1]
        meta = metadata[(metadata.Pid == pid) & (metadata.Class_id == cid)].iloc[0]
        full = bool(last.complete_session)
        label = float(meta[variable]) if meta.has_report else np.nan
        scored = full and np.isfinite(label)
        error = float(last.prediction)-label if scored else np.nan
        rows.append(dict(Pid=pid, Class_id=cid, mode=mode, condition=condition,
                         variable=variable, minute=int(last.minute),
                         prediction=float(last.prediction), observed=label,
                         complete_session=full, scored=scored,
                         absolute_error=abs(error), squared_error=error**2,
                         label_use='evaluation only after inference'))
    return pd.DataFrame(rows)


def summarize_validation(run, data, split, cfg):
    files = sorted((run/'validation'/'cases').glob('validation_P*.csv'))
    d = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    meta = split['validation'][split['validation'].Pid.isin(cfg.validation_pids)]
    n = sum(min(int(r.n_minutes), cfg.validation_max_minutes) if cfg.validation_max_minutes else int(r.n_minutes)
            for r in meta.itertuples(index=False))
    expected = n*len(cfg.seeds)*len(cfg.validation_modes)*3*8
    if len(d) != expected:
        raise ValueError(f'Wrong validation output size: {len(d)} != {expected}')
    keys = ['Pid', 'Class_id', 'mode', 'condition', 'step', 'minute', 'variable', 'complete_session']
    mean = seed_mean(d, keys, cfg.seeds)
    write_csv(run/'validation'/'all_trajectories_by_seed.csv', d)
    write_csv(run/'validation'/'trajectories_seed_mean.csv', mean)
    physiology = mean[mean.variable.isin(CHANNELS[2:])]
    per_session = error_table(physiology, ['Pid', 'Class_id', 'mode', 'condition', 'variable'])
    per_session['n_records'] = 1
    per_session['role'] = np.where(per_session['mode'].eq('EP_online'), 'observed-P reconstruction', 'unobserved-P generation')
    write_csv(run/'validation'/'physiology_by_session.csv', per_session)
    pooled = error_table(physiology, ['mode', 'condition', 'variable'])
    pooled['n_records'] = len(meta)
    pooled['weighting'] = 'equal observed minutes; seed-mean output first'
    pooled['role'] = np.where(pooled['mode'].eq('EP_online'), 'observed-P reconstruction', 'unobserved-P generation')
    endpoints = report_endpoints(mean, meta)
    write_csv(run/'validation'/'report_endpoint_estimates.csv', endpoints)
    valid = endpoints[endpoints.scored]
    if not valid.empty:
        reports = error_table(valid, ['mode', 'condition', 'variable'])
        reports['weighting'] = 'one complete-session endpoint per record; seed-mean output first'
        reports['role'] = 'unseen-record report estimate'
    else:
        reports = pd.DataFrame(columns=pooled.columns)
    table = pooled.copy() if reports.empty else pd.concat([pooled, reports], ignore_index=True)
    write_csv(run/'validation'/'summary_metrics.csv', table)
    # All pairings are within the same observation mode, record and outcome.
    paired = per_session.pivot(index=['Pid', 'Class_id', 'mode', 'variable'], columns='condition', values='RMSE').reset_index()
    paired['personal_gain_vs_zero_percent'] = 100*(paired.zero-paired.personal)/paired.zero.replace(0, np.nan)
    paired['personal_gain_vs_local10_percent'] = 100*(paired.local10-paired.personal)/paired.local10.replace(0, np.nan)
    write_csv(run/'validation'/'physiology_paired_RMSE.csv', paired)
    if not valid.empty:
        paired_b = valid.pivot(index=['Pid', 'Class_id', 'mode', 'variable'], columns='condition', values='absolute_error').reset_index()
        paired_b['zero_minus_personal_absolute_error'] = paired_b.zero-paired_b.personal
        paired_b['local10_minus_personal_absolute_error'] = paired_b.local10-paired_b.personal
    else:
        paired_b = pd.DataFrame(columns=['Pid', 'Class_id', 'mode', 'variable', 'zero_minus_personal_absolute_error'])
    write_csv(run/'validation'/'reports_paired_absolute_error.csv', paired_b)
    # Per-seed summaries remain distinct from metrics of the seed-mean trajectory.
    seed_rows = []
    for seed, g in d.groupby('seed'):
        p = error_table(g[g.variable.isin(CHANNELS[2:])], ['mode', 'condition', 'variable'])
        p['n_records'] = len(meta); p['seed'] = seed; seed_rows.append(p)
        b = report_endpoints(g, meta); b = b[b.scored]
        if len(b):
            q = error_table(b, ['mode', 'condition', 'variable']); q['seed'] = seed; seed_rows.append(q)
    write_csv(run/'validation'/'metrics_by_seed.csv', pd.concat(seed_rows, ignore_index=True))
    write_json(run/'validation'/'interpretation.json', dict(
        n_records=len(meta), n_people=int(meta.Pid.nunique()), n_report_records=int(meta.has_report.sum()),
        n_scored_report_endpoints=len(valid), real_minutes=n, seeds=list(cfg.seeds),
        targets_in_network_training=False, targets_in_scaler_fitting=False,
        targets_in_personal_calibration=False,
        scope='unseen participant-records, known people; other people may share dates/context; no unseen-person/date claim',
        EP_physiology='current real P is used for ER: reconstruction, not future prediction',
        E_only_physiology='current real P is withheld from ER and used only for scoring',
        B='one complete-session endpoint; no minute-level labels or significance test'))


def summarize_all(run, data, split, cfg):
    summarize_simulation(run, cfg)
    summarize_validation(run, data, split, cfg)
    rows = []
    for dataset in ['simulation', 'validation']:
        dg = pd.concat([pd.read_csv(f) for f in (run/dataset/'diagnostics').glob('*.csv')], ignore_index=True)
        dg['at_budget'] = dg.best_step.eq(cfg.online_steps)
        if 'mode' not in dg: dg['mode'] = 'E_only'
        g = dg.groupby(['seed', 'mode', 'condition'], as_index=False).agg(
            n_fits=('best_step', 'size'), fits_at_budget=('at_budget', 'sum'),
            objective_before=('objective_before', 'mean'), objective_after=('objective_after', 'mean'))
        g['fraction_at_budget'] = g.fits_at_budget/g.n_fits
        g['dataset'] = dataset; rows.append(g)
    write_csv(run/'optimization_boundary_summary.csv', pd.concat(rows, ignore_index=True))
