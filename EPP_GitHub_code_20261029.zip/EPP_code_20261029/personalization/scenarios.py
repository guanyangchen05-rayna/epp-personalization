"""Predefined stable / stable-then-fluctuating E; TRAINING INPUTS ONLY."""
import numpy as np
import pandas as pd
from protocol import CHANNELS
from data_io import key


def make_scenarios(data, split, config):
    # Unweighted unique observed pairs avoid counting the same school-level
    # environment repeatedly through different people's physiology records.
    e = np.unique(np.concatenate([data.arrays[key(r)][:, :2]
                                for r in split['train'].itertuples(index=False)]), axis=0).astype(float)
    center = np.median(e, axis=0); scale = e.std(axis=0)
    if (scale <= 0).any():
        raise ValueError('Training environmental variability required')
    baseline = e[np.argmin(np.sum(((e-center)/scale)**2, axis=1))]
    amp = (np.quantile(e, .75, axis=0)-np.quantile(e, .25, axis=0))*config.scenario_amplitude_IQR_fraction
    iqr_amp = amp.copy()
    n = config.scenario_minutes; switch = config.scenario_switch
    after_blocks = (n-switch)//config.scenario_interval
    wave = np.zeros(n)
    for b in range(after_blocks):
        left = switch+b*config.scenario_interval
        wave[left:left+config.scenario_interval] = np.sin(2*np.pi*b/after_blocks)
    # Also constrain five-minute change magnitudes, not only marginal levels.
    changes = []
    for r in split['train'].itertuples(index=False):
        k = key(r); t = data.times[k]; x = data.arrays[k][:, :2]
        lookup = {int(v): j for j, v in enumerate(t)}
        for j, v in enumerate(t):
            if int(v)+config.scenario_interval in lookup:
                changes.append(np.abs(x[lookup[int(v)+config.scenario_interval]]-x[j]))
    changes = np.asarray(changes, float)
    rate_limits = np.array([np.quantile(changes[changes[:, j] > 1e-6, j], .95)
                            for j in range(2)])
    max_wave_change = np.abs(np.diff(wave[::config.scenario_interval])).max()
    if max_wave_change < 1e-6:
        raise ValueError('Degenerate sampled scenario waveform')
    amp = np.minimum(amp, rate_limits/max_wave_change)
    # One deterministic full cycle: mean level stays constant. This is a
    # temporal-variation scenario, not an estimated psychological volatility.
    shrink = 1.
    for _ in range(30):
        fluctuating = baseline+wave[:, None]*amp[None, :]*shrink
        nearest = np.sqrt(np.min(np.sum(((fluctuating[:, None, :]-e[None, :, :])/scale)**2, axis=2), axis=1))
        inside = ((fluctuating >= e.min(0)) & (fluctuating <= e.max(0))).all()
        if inside and nearest.max() <= config.scenario_nearest_training_limit:
            break
        shrink *= .8
    else:
        raise ValueError('Cannot make a scenario near the training input envelope')
    if np.any(amp*shrink < 1e-8):
        raise ValueError('A scenario channel has no variation')
    stable = np.tile(baseline, (n, 1))
    if not np.array_equal(stable[:switch], fluctuating[:switch]):
        raise AssertionError('Scenario prefixes differ')
    if not np.allclose(fluctuating[switch:].mean(0), baseline, atol=1e-8):
        raise AssertionError('Scenario mean shifts confound variation')
    frames = []
    for name, values in [('stable', stable), ('stable_then_fluctuating', fluctuating)]:
        frames.append(pd.DataFrame(dict(scenario=name, minute=np.arange(n),
                        phase=np.where(np.arange(n) < switch, 'stable_prefix',
                                       'stable_control' if name == 'stable' else 'fluctuating'),
                        IndoorTemperature=values[:, 0], IndoorCO2=values[:, 1])))
    info = dict(source='training-only unique observed E pairs; no validation inputs',
                baseline=baseline.tolist(), initial_amplitudes=iqr_amp.tolist(),
                rate_limited_amplitudes=amp.tolist(),
                amplitudes=(amp*shrink).tolist(), deterministic_shrink=shrink,
                first_nonbaseline_minute=int(np.flatnonzero(np.abs(wave) > 1e-8)[0]),
                distance_scale_unique_E_SD=scale.tolist(),
                training_nonzero_change_95th=rate_limits.tolist(),
                simulated_max_change_per_input_step=(max_wave_change*amp*shrink).tolist(),
                nearest_standardized_training_distance_max=float(nearest.max()),
                training_channel_min=e.min(0).tolist(), training_channel_max=e.max(0).tolist(),
                n_minutes=n, switch_minute=switch, input_update_minutes=config.scenario_interval,
                waveform='one five-minute-stepped sinusoidal cycle in second half; zero phase at scheduled boundary; both E channels change in phase',
                sessions='two independent paired sessions, each starting at minute zero; not a concatenated session',
                state_reset='new local ER engine, zero recurrent state and zero local A for each session; same retained personal A',
                stochastic_inference=False,
                design_boundary_minute=switch,
                primary_response_window='first actual nonbaseline input through session end',
                claim_scope='joint temporal variation; not separate channel causality, randomized volatility or human intervention effects')
    return pd.concat(frames, ignore_index=True), info
