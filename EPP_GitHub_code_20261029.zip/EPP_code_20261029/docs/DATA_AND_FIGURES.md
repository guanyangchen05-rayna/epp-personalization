# Data dependencies and manuscript mapping

Paths below are relative to the repository root after merging the companion. Model input files and individual outputs are supplied in that companion, not in the code-only archive.

## Input stages

| Stage | Files | Purpose / status |
|---|---|---|
| Original exports | Complete original dated environment, wearable, class and survey tree | **Not recovered** in the selected archives; original source-processing scripts preserved |
| Prepared environmental context | `main_pvrnn/data/epp_input_20261020_131548_599411/` | Classroom_Data, POOLED_INDOOR, panel inventory and QC; supplied |
| Aligned one-second inputs | `main_pvrnn/data/processed_epp_v6_20261020_131548_599411/` | Supplied; source for minute aggregation/refitting |
| Main report metadata | `behavior_session_analysis.csv` within that folder | 16 complete-report sessions / 11 participants |
| Main report sequences | `behavior_temporal_1s.csv` within that folder | Corresponding aligned seconds; 749 retained minute bins after aggregation |
| Full E/P metadata/sequences | `envphys_session_analysis.csv`, `envphys_temporal_1s.csv` | 102 sessions / 22 participants; 5,641 retained minutes |
| QC/provenance | `processing_summary.json`, `session_master.csv`, `00_qc/`, `v6_temporal_export.json` | Retention, fixed panel, EDA QC and export identity |
| Frozen personalization inputs | `personalization/data/records.csv`, `minutes.csv`, `provenance.json` | Same frozen cohort; float32 minute arrays and original minute IDs; exact SHA256 checked |
| Calibration/checkpoints | `personalization/bundled/` | Three matched models/scalers, personal A, fitting histories and integrity manifest |

The processed tables use pseudonymous participant IDs. Input data, participant-level trajectories, checkpoints containing fitted personal values, and real-record plots remain in the separate reproduction companion.

## Current methods/results

| Manuscript | Code | Actual outputs |
|---|---|---|
| 2.1 PV-RNN | `main_pvrnn/epp_v6/model.py` | Main model architecture/objective; 668 shared parameters |
| 2.2 processing | `main_pvrnn/scripts/`, `epp_v6/data.py` | Frozen processing tables and minute loader |
| 2.3 evaluation | `main_pvrnn/epp_v6/behavior.py` | `main_pvrnn/results/epp_v6/20261020T142629_112453Z/behavior_11/` |
| 3.1–3.2 main estimates/ER | Main behavior run plus `analysis/audit_main_and_scope.py` | Predictions, bootstrap, reconstruction, MAE direction counts |
| 2.4.1 personalization | `personalization/data_io.py`, `training.py`, `personal_a.py` | `personalization/results/formal_20261028_180424_097163/{models,profiles,protocol}/` |
| 2.4.2 matched inference | `scenarios.py`, `online_inference.py`, `experiment.py`, `summaries.py` | Same run's `simulation/`, `validation/`, `stages/` |
| 3.3 personalized results | Above plus saved-output audit scripts | RMSE/MAE/bias, paired contrasts, A distances/correlations |
| Discussion quantitative statements | `analysis/` audits | Independent saved-output recomputations; no extra model fits |

## Figure source map

| Figure | Inputs | Rendering source / recovery status |
|---|---|---|
| 1 EPP framework | Conceptual structure | Current vector PDF in code assets; original editable drawing source not recovered |
| 2 pipeline | Preprocessing/cohort specification | Current vector PDF in code assets; original layout generator not recovered |
| 3 observed E/P/reports | Aligned data and complete-report metadata | Current vector PDF in companion; exact original layout script not recovered |
| 4 model/personalization workflow | Scientific model and current D panel | Current `Figure_4_new.pdf` preserved; old label patch is not the complete current generator |
| 5 LOO performance | Main predictions and derived per-seed/per-person errors | `figures/main/prepare_data.py`, `plot_main.py` |
| 6 ER example | Saved main reconstructions for P1/session217; report predictions and train-fold scale | Same main preparation/plot scripts; representative-case rule recomputed |
| 7 common environment | two40 `simulation/trajectories_seed_mean.csv` and `protocol/scenarios.csv` | `figures/common_environment/plot_figure7.py`; 29 October style revision |

Exact final seven manuscript PDFs are in `figures/frozen_manuscript/`; the complete TeX/bibliography/vector-asset snapshot is in `manuscript_snapshot/`. No supplementary figures/tables are introduced by this release.

## Output names versus manuscript names

| Machine identifier | Manuscript name / interpretation |
|---|---|
| `IndoorTemperature` | Environmental temperature |
| `TEMP` | SkinTEMP |
| `EngageScore` | Engagement |
| `SIMPLE_RNN` | Simple RNN |
| `NO_ER` | PV-RNN without ER / No-ER |
| `ERROR_REGRESSION` | PV-RNN with ER |
| `TRAINING_MEAN` / `baseline` column | Training-mean reference |
| `personal` | PV-RNN with personalized A |
| `zero` | a_i=0 reference, with eight local adaptive coordinates |
| `local10` | Fully adaptive A |
| `E_only` | E-only observation setting |
| `EP_online` | E+P observation setting |

Source names remain unchanged so original scientific hashes and cache signatures remain valid. This also explains why historical comments or filenames can contain older terminology.
