# 运行和上传说明

## 1. 两个压缩包的用途

- `EPP_GitHub_code_20261029.zip`：上传 GitHub 的代码快照，含源码、配置、测试、聚合统计和说明。
- `EPP_reproduction_companion_20261029.zip`：本地配套复现资料，含实际观测输入、个人结果、权重、正式运行和当前论文工程。它不是需要整包上传公开仓库的代码文件。

先解压代码包。需要实际复现时，把 companion 文件夹**内部内容**合并进 `EPP_code_20261029/`，让根目录同时包含 `reproduce.py`、`main_pvrnn/`、`personalization/` 和 `COMPANION_README_zh.md`。不要再多套一层 companion 文件夹。它不替换科学源码。

## 2. 最短核对路径

在含 `reproduce.py` 的目录打开终端：

```bash
python reproduce.py verify
python -m pip install -r requirements-summaries.txt
python reproduce.py statistics
```

第一步只用标准库检查代码及可用 companion 的文件哈希。统计复算只需 numpy/pandas，不加载 torch、不训练；结果写入 `reproduced/statistics/`。

该复算检查保存的数值、划分、权重身份和优化记录，不等于重新执行训练和推断。正式模型与原始输出来自保留的历史运行。

## 3. 图片

```bash
python -m pip install -r requirements.txt
python reproduce.py figure-data
python reproduce.py figures
```

输出：

- `figures/main/figures/Figure_5_LOO_performance.*`
- `figures/main/figures/Figure_6_ER_state_adaptation.*`
- `figures/common_environment/Figure_7_common_environment_simulation.*`

Figure 7 原脚本使用 Nimbus Roman。系统缺该字体时 Matplotlib 可能回退；数字不变，字体和排版不保证逐像素一致。当前论文原图位于 companion 的 `figures/frozen_manuscript/`。

Figure 1–4 使用保留的矢量资产。没有找回 Figure 1–3 完整原始绘制源，不能称七张图都可由 Python 从零生成。Figure 4 已放入最新 D 版，不再用旧标签脚本覆盖。

## 4. 主分析重训

```bash
python reproduce.py check-inputs
python reproduce.py train-main
```

`train-main` 固定调用原入口 `--stage behavior --cohorts 11 --config config/epp_v6.json`，五 seeds、150 epochs、ER 150 步。输出另存在 `reproduced/main_training/<新时间戳>/`；正式历史运行不被覆盖。

旧 v6 的 `--stage all` 会额外运行 rho/chain/recovery 历史实验，不是当前论文所需。`--quick` 降预算仅用于诊断，不可替代论文运行。

新训练运行有新的预测、scaler 和 checkpoint。当前 `statistics`/`figure-data` 默认读取冻结正式 run；若要评估新训练的结果，应明确更改目标 run 或复制脚本并记录路径，不能静默用新文件覆盖旧 run。

## 5. Personalization 运行

```bash
python reproduce.py personalization-check
python reproduce.py personalization-simulate
python reproduce.py personalization-all
```

simulate 完成两个正式 40 分钟模拟；all 另含 11 条完整目标的 E-only/E+P 两设置。默认经签名核查后复用 bundled 中的三个共享模型和个人 A，**这会重做推断，但不会重新训练/校准**。

明确从头重训和校准：

```bash
python reproduce.py personalization-retrain
```

中断后在 `personalization/` 目录运行，路径用实际结果目录：

```bash
python run_project.py --mode formal --phase all --resume "results/实际formal目录"
```

不能把 `--force-train` 和 `--resume` 合用。代码/协议/输入或缓存文件变化会拒绝续用。默认使用独立子进程，处理过的 Windows MKL 设置只作用于子进程，不使用 `KMP_DUPLICATE_LIB_OK`。

原 `START_HERE.ipynb` 与 Windows launcher 保留。它们调用同一 `run_project.py`。打开前确认定位到本包的 `personalization/`；不要指向旧 v2。

## 6. 原始设备文件的重新处理

若另外拥有完整原始 dated dataset，可从下列步骤开始。输出必须用新目录：

```bash
python main_pvrnn/scripts/prepare_indoor_context.py --base-dir /path/to/raw_dataset --output-dir /path/to/new_indoor_input --aggregation median --minimum-sensors 4 --rooms R1,R2,R3,R4,R5
python main_pvrnn/scripts/export_envphys_temporal_v6.py --base-dir /path/to/raw_dataset --input-dir /path/to/new_indoor_input --output-dir /path/to/new_processed_tables
python personalization/tools/export_frozen_tables.py --help
```

最后一个工具的实际输入参数以 `--help` 为准；用新表导出后会产生新哈希，不能与旧 checkpoint 随意混用。所有原始文件路径、解析和计分逻辑在原脚本中保留；当前 companion 从已经对齐的一秒表开始完整。

## 7. 测试与本次核查范围

完整依赖安装后运行：

```bash
python reproduce.py tests
```

该入口选择 v6 核心/时间缺口测试与 two40 mechanism 测试。mechanism 测试需要 companion 的实际输入与 bundled 模型。其他历史 tests 原样保留，可能涉及旧流程或旧文档，不作为本次 release 的统一测试入口。

本次实测结果见 `provenance/verification_20261029.json`。当前打包环境没有 torch/statsmodels，因此未重跑模型级测试，也未重新训练或执行数小时的完整推断。保存结果独立复算、源码哈希、语法与绘图检查的结果分别记录，不把历史测试记录当作本次执行。

## 8. 上传 GitHub

解压代码包后，将其中 `EPP_code_20261029/` 的内容放到仓库根目录，README 即会显示。已提供 `.gitignore`，防止本地 companion 的输入、权重、逐人输出和论文快照被普通 `git add .` 加入。

GitHub 网页上传目录不受 `.gitignore` 自动过滤；网页方式请只上传代码包内容。不要把 companion 压缩包或合并后的整个研究数据目录一并拖入公开仓库。

本次没有替你选择软件 license，也没有创建或发布 GitHub 仓库。代码和数据的授权方式可在确定后加入；包内不伪造 DOI、仓库 URL 或正式发表信息。
