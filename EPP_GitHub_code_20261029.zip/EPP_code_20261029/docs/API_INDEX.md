# Source API index

Generated from the delivered source. Names are machine identifiers; see CODE_LOGIC_zh.md for scientific roles.

## main_pvrnn/epp_v6/__init__.py

(module constants/imports)

## main_pvrnn/epp_v6/behavior.py

`metrics`, `bootstrap`, `run_behavior`

## main_pvrnn/epp_v6/chain.py

`align_reports`, `training_reports`, `report_record`, `_summary`, `summarize_chain`

## main_pvrnn/epp_v6/data.py

`sha256`, `read_csv`, `session_keys`, `Cohort`, `load_cohort`, `scaled_training`, `transform`, `outer_folds`

## main_pvrnn/epp_v6/individual.py

`profile_parameter`, `_checkpoint`, `describe`, `score_hidden_physiology`, `validate`, `recovery`

## main_pvrnn/epp_v6/model.py

`Settings`, `seed_all`, `pad`, `valid_mask`, `window_ids_tensor`, `minute_gaps`, `gaussian_kl`, `FiveArrowPVRNN`, `objective`, `diagnostics`, `frozen`, `infer`, `train`, `SimpleRNN`, `train_simple`

## main_pvrnn/epp_v6/plots.py

`save`, `architecture`, `make_figures`

## main_pvrnn/epp_v6/startup.py

`complete`, `fingerprint`, `choose_tables`, `remember_tables`, `run_visible`, `preflight_and_run`

## main_pvrnn/scripts/audit_mapping.py

`audit`, `main`

## main_pvrnn/scripts/eda_session_qc.py

`apply_eda_session_qc`

## main_pvrnn/scripts/export_envphys_temporal_v6.py

`export`

## main_pvrnn/scripts/heterogeneity_audit.py

`checkpoint`, `core`, `sensitivity`, `main`

## main_pvrnn/scripts/heterogeneity_figures.py

`select_pv_directory`, `component_comparison`, `variance_and_participants`, `boundary_figures`, `sensitivity_figures`, `main`

## main_pvrnn/scripts/heterogeneity_models.py

`near_zero`, `fit`, `fixed_rows`, `adjust_environment_families`, `variance_rows`, `participant_rows`, `compare`

## main_pvrnn/scripts/indoor_context_checks.py

`validate_context_table`, `validate_fold_coverage`

## main_pvrnn/scripts/make_epp_demo.py

`make`

## main_pvrnn/scripts/mixedlm_analysis.py

`parse_args`, `resolve_input_path`, `zscore`, `benjamini_hochberg`, `load_and_prepare`, `participant_coverage`, `random_effect_formulas`, `fit_with_optimizers`, `variance_component_map`, `extract_temperature_slopes`, `_extract_factor_level`, `extract_random_intercepts`, `_natural_sort_key`, `prepare_random_intercept_outputs`, `_random_intercept_matrix`, `make_random_intercept_figure`, `fixed_effect_rows`, `variance_component_rows`, `add_fdr_columns`, `fit_all_models`, `write_outputs`, `main`

## main_pvrnn/scripts/mixedlm_indoor_context.py

`parse_args`, `resolve_input_path`, `zscore`, `benjamini_hochberg`, `load_and_prepare`, `participant_coverage`, `random_effect_formulas`, `fit_with_optimizers`, `variance_component_map`, `extract_temperature_slopes`, `_extract_factor_level`, `extract_random_intercepts`, `_natural_sort_key`, `prepare_random_intercept_outputs`, `_random_intercept_matrix`, `make_random_intercept_figure`, `fixed_effect_rows`, `variance_component_rows`, `add_fdr_columns`, `fit_all_models`, `write_outputs`, `main`

## main_pvrnn/scripts/prepare_classroom_mapping.py

`digest`, `clean`, `locate`, `load_classes`, `load_environment`, `load_crosswalk`, `build`, `prepare`, `main`

## main_pvrnn/scripts/prepare_indoor_context.py

`parse_usability`, `pool_environment`, `prepare`, `main`

## main_pvrnn/scripts/preprocess_indoor_context.py

`preprocess`

## main_pvrnn/scripts/preprocess_sessions.py

`clean_id`, `find_existing`, `parse_date_value`, `combine_date_time`, `max_gap_minutes`, `safe_std`, `safe_range`, `slope_per_minute`, `load_classroom_mapping`, `find_wearable_root`, `build_attendance_sessions`, `parse_environment_datetime`, `EnvironmentCache`, `audit_environment_classes`, `build_class_environment_summary`, `parse_wearable_datetime`, `load_phys_signal_1s`, `build_physiology_1s`, `merge_environment_to_physiology`, `load_survey_source`, `prepare_survey`, `map_surveys_strict`, `build_session_master`, `build_behavior_temporal_1s`, `main`

## main_pvrnn/scripts/pvrnn_frozen_v3.py

`Config`, `parse_args`, `resolve_table_dir`, `seed_everything`, `resolve_file`, `ensure_dir`, `safe_r2`, `metric_rows`, `load_tables`, `zscore_series`, `bh_fdr`, `run_mixedlm_bridge`, `build_session_sequences`, `_history_rows_for_target`, `_summarize_history`, `personal_profile_for_indices`, `build_history_profiles`, `training_global_profile`, `_diag_gaussian_kl`, `FullPVRNN`, `pad_sequences`, `make_adaptive_parameter`, `pv_free_energy`, `get_session_arrays`, `fit_sequence_scaler`, `apply_sequence_scaler`, `prepare_fold`, `train_one_model`, `_error_regress_test_adaptive_variables`, `predict_before_and_after_er`, `count_trainable_parameters`, `build_episode_folds`, `build_pid_folds`, `_paired_seed_gain_table`, `_seed_gain_summary`, `run_protocol`, `_median_oof_by_session`, `_rmse`, `_mae`, `_bootstrap_one_comparison`, `cluster_bootstrap_model_comparisons`, `make_summary_plot`, `main`

## main_pvrnn/scripts/pvrnn_indoor_context.py

`Config`, `parse_args`, `resolve_table_dir`, `seed_everything`, `resolve_file`, `ensure_dir`, `safe_r2`, `metric_rows`, `load_tables`, `zscore_series`, `bh_fdr`, `run_mixedlm_bridge`, `build_session_sequences`, `_history_rows_for_target`, `_summarize_history`, `personal_profile_for_indices`, `build_history_profiles`, `training_global_profile`, `_diag_gaussian_kl`, `FullPVRNN`, `pad_sequences`, `make_adaptive_parameter`, `pv_free_energy`, `get_session_arrays`, `fit_sequence_scaler`, `apply_sequence_scaler`, `prepare_fold`, `train_one_model`, `_error_regress_test_adaptive_variables`, `predict_before_and_after_er`, `count_trainable_parameters`, `build_date_folds`, `build_pid_folds`, `_paired_seed_gain_table`, `_seed_gain_summary`, `run_protocol`, `_median_oof_by_session`, `_rmse`, `_mae`, `_bootstrap_one_comparison`, `cluster_bootstrap_model_comparisons`, `make_summary_plot`, `main`

## main_pvrnn/scripts/revision_audit.py

`save_json`, `digest`, `model_pair`, `core`, `influence`, `environment`, `main`

## main_pvrnn/scripts/revision_figures.py

`style`, `clean`, `save`, `forest`, `mixed_figures`, `pv_figures`, `supplementary_figures`, `main`

## main_pvrnn/scripts/revision_models.py

`boolean`, `read_sessions`, `prepare`, `specification`, `fit`, `fixed_rows`, `adjust_families`, `slope_rows`

## personalization/backbone.py

`PositiveEDAHead`, `make_backbone`

## personalization/data_io.py

`Data`, `key`, `load_data`, `partition`, `training_payload`, `write_partition`

## personalization/experiment.py

`trajectory_frame`, `run_simulations`, `run_validation`, `completed_inputs`, `main`

## personalization/online_inference.py

`weight_hash`, `condition_parameters`, `fit_window`, `OnlineER`, `physical_and_reports`, `infer_sequence`

## personalization/personal_a.py

`sha`, `load_shared`, `compose_A`, `losses`, `_clip_independent`, `fit_profiles`, `fit_local`, `OnlinePersonalA`, `save_profile`, `load_profile`

## personalization/plots.py

`figure3_axes`, `save_figure`, `personal_legend`, `simulation_plot`, `response_plot`, `environment_error_plot`, `validation_plot`, `make_simulation_plots`, `make_validation_plots`, `make_all_plots`

## personalization/protocol.py

`Config`, `config_for`, `sha_file`, `digest`, `write_json`, `write_csv`, `code_hashes`, `mark_stage`, `stage_complete`, `config_dict`, `verify_bundled`

## personalization/run_project.py

`child_run`, `diagnose`, `run`, `main`

## personalization/scenarios.py

`make_scenarios`

## personalization/summaries.py

`scenario_timing`, `summarize_response_windows`, `seed_mean`, `error_table`, `summarize_simulation`, `report_endpoints`, `summarize_validation`, `summarize_all`

## personalization/test_mechanism.py

`MechanismTests`

## personalization/training.py

`training_signature`, `ensure_model`, `calibration_signature`, `ensure_profiles`, `verified_profiles`

## personalization/v6_dynamics.py

`State`, `zero_state`, `forward`
