# 最新论文代码逻辑说明

对应 2026-10-29 的 `main-1029-ep_micro_revised`。本文件按实际执行逻辑组织，源码函数索引见 `API_INDEX.md`。

## 1. 两条正式分析路径

| 路径 | 提出的问题 | 输入和输出 | 正式来源 |
|---|---|---|---|
| 主分析 | 在新参与者或新日期上估计 engagement、arousal、valence；ER 带来多少增量 | 本次 session 的环境和生理 → 末端三项报告估计 | v6 `20261020T142629_112453Z/behavior_11` |
| Personalization | 历史观测校准得到的二维 A 是否改变共同环境下的输出，是否帮助同一人的新 session 估计 | 历史 E/P → 个人 A；目标 E-only 或 E+P → 生理和报告读出 | two40 `formal_20261028_180424_097163` |

两条路径分别训练，不能互换 checkpoint、scaler 或 A。主分析结果不由新版 personalization 重算替代。当前论文没有把旧 rho 个体参数分析作为结果。

## 2. 原始观测到模型输入

### 2.1 环境和生理对齐

1. `prepare_indoor_context.py` 从有日期的环境记录和课程时间确定共享 indoor context，固定八传感器面板；保留面板选择和传感器 QC。
2. `preprocess_indoor_context.py` 复用 `preprocess_sessions.py` 的时间解析、生理聚合、环境对齐与问卷匹配，加入 EDA session QC。
3. `export_envphys_temporal_v6.py` 在相同预处理流程中额外导出所有合格 E/P session 的一秒表，核对报告子集与原表一致。

这里的环境是共享学校情境 proxy，不是重新推断了每个参与者的所在房间。主模型的五个通道依次为 `IndoorTemperature, IndoorCO2, EDA, HR, TEMP`；机器字段 `TEMP` 是 SkinTEMP，不能和 `IndoorTemperature` 混淆。

冻结的 EDA QC 阈值为零值比例 0.95。session 基础保留规则含至少 300 秒五通道完整对齐数据。完整规则仍由原脚本执行，不另写一套近似版。

### 2.2 报告匹配和一分钟聚合

报告匹配到提交前最近结束、且落在 90 分钟范围内的合格课程。Engagement 为五题合成分数，反向题在预处理计分，三个 outcome 完整才进入主报告子集。

`main_pvrnn/epp_v6/data.py::load_cohort`：

- 从 class start 划分不重叠 60 秒 bin。
- 每 bin 至少 30 秒五通道完整观测；对五通道取均值。
- **模型 EDA 不先取 log**；图中 log display 不改变模型输入。
- 保留真实 minute IDs 及缺口，不插值补齐。
- 得到 102 sessions / 22 人 / 5,641 个保留分钟；报告子集 16 sessions / 11 人 / 749 分钟。

`cohort='22'/'11'` 是历史 cohort 名称，不代表两个新的划分算法。主 LOO 实际只训练报告子集；102-session 样本为 personalization 提供来源记录。

## 3. 主分析：v6 PV-RNN 与 Simple RNN

### 3.1 状态、A 与读出

`model.py` 实现 fast/slow recurrent layers。确定性维度 8/4，随机维度 3/2，时间常数 2/5，dropout 0.25；共享 PV-RNN 参数 668。每个有效分钟的 A 有 10 维，对应快慢随机状态的 posterior mean 和 scale offsets。训练用每个 session 的独立 A。

这些网络层与概念上的 environment、physiology、behavior/affect 三个 measurement layers 不一一对应。共同 recurrent states 经 sensory head 重建五通道，经 report head 在最终状态估计三项报告。

### 3.2 训练目标与梯度

`model.py::train` 以五通道标准化重建项、快慢 KL，以及标准化报告 MSE 训练。重建 pass 使用随机 latent samples；报告 pass 使用 latent means，并对 A 做 detach。

所以：**report loss 更新共享网络和 report head，不直接更新 A。** A 从观测重建与 KL 得到梯度。

每个 fold 的输入 scaler 只 fit 训练 sessions 的有效分钟；outcome scaler 只 fit 训练 sessions 的报告。训练 150 次 full-batch AdamW，网络学习率 0.001、weight decay 0.01、梯度裁剪 1；A 学习率 0.005、无 weight decay、裁剪 5。

Simple RNN 使用相同划分、训练数据、scaler 和 seeds，共享网络参数 643。缺口时以零标准化输入推进其状态；PV-RNN 缺口则以 prior transitions 推进、不加观测 loss。

### 3.3 测试条件

| 条件 | 测试时执行 | 权重和报告标签 |
|---|---|---|
| `NO_ER` | A 固定为零，通过已训练 posterior-base mappings 生成状态 | 网络冻结；不用测试报告 |
| `ERROR_REGRESSION` | 每个目标 session 从零 A 开始，使用整段五通道观测优化 A，150 步，lr=0.05 | 与 No-ER 同 checkpoint；不使用测试报告 |
| `SIMPLE_RNN` | 读入五通道序列，末端报告读出 | 不进行 ER |
| `TRAINING_MEAN` | 对每个 outcome 使用该 fold 训练报告均值 | 参照，不是额外神经模型 |

主分析 ER 使用完整 session，是离线推断。它不等同于 personalization 的逐分钟因果滑窗推断。连续无缺口 session 中 No-ER 的生成输出由 checkpoint 和序列长度决定。

### 3.4 划分和汇总

`behavior.py::run_behavior` 对 11 个参与者和 4 个日期执行 LOO。每个 fold、每个 seed 单独训练；ER/No-ER 共享 PV-RNN 权重。五个 seeds 为 11/23/37/51/71。

- 保存 1,920 行 out-of-fold 报告预测：2 个协议 × 16 sessions × 5 seeds × 3 outcomes × 4 条件。
- 主要 pooled RMSE/配对 gain：先对每个 session 的五 seed 预测取 **median**，再算误差。
- 图中 seed RMSE 点：各 seed 单独算 RMSE，不能与 seed-median prediction 的 RMSE混为一谈。
- bootstrap：固定预测、按参与者或日期重采样，2,000 次，不重新训练模型。
- 原模型两个比较使用 RNG seed 721 的原遍历顺序；training-mean 扩展用独立同种子 stream。`audit_main_and_scope.py` 保留该口径，避免仅因 ID 排序或随机流变化造成区间不同。
- 重建改善按 session/seed 汇总；Figure 6 按跨 seed 的 session 重建改善接近中位数选 P1/session217，与报告误差无关。

## 4. Personalization：two40 正式流程

### 4.1 数据划分

`data_io.py::partition` 从冻结 102-session 数据中，对 11 名指定参与者各选一个目标。优先选具有至少 20 个更早校准分钟的最后一条完整报告记录；没有符合条件的报告则用最后一条合格 E/P 记录。此规则不查看输出质量。

目标及该人重叠/更晚记录从共享训练中排除。最终共享训练 87 sessions / 22 人 / 9 条报告；校准 34 条历史 sessions / 1,841 分钟；11 条真实目标 / 625 分钟，其中 7 条有报告；总排除 15 条含 11 目标和 4 条额外记录。

34 条校准记录本身也参与共享网络训练。校准只用该人更早记录；其他人的跨日期记录可能晚于某目标。这个协议检验已知参与者的新 session，不是 Participant-LOO、Date-LOO 或全局日历前瞻部署。

### 4.2 共享训练与重新校准

`backbone.py`、`v6_dynamics.py` 和 `v6_reference/` 保留 v6 动力学，`personal_a.py` 处理 A 的共享/固定约束和 EDA 正值链接。

`training.py` 在训练阶段将两维 slow posterior-mean offsets 按参与者跨 sessions 共享、中心化；其余维度保持局部。训练 150 epochs。报告 pass 仍对 A detach。

冻结共享网络和 scaler 后，`ensure_profiles` / `personal_a.py` 从零重新拟合每个人的二维 A：同人历史 sessions 共享二维量，每条 session 有各自其余八维局部量和零初始状态；600 次 Adam 更新、lr=0.05，使用观测及 KL，不用报告标签。各人按有效分钟加权，按参与者独立裁剪。

训练阶段的 A 与重新校准的 A 是两次拟合的结果。每个 seed 的 A 必须与自己的网络和 scaler 配对；不可先跨 seed 平均二维 A 再塞入一个网络。

### 4.3 三种 A 条件与两种观测设置

| 机器键 | 论文名称 | 两维慢层 mean offsets | 其余八维 |
|---|---|---|---|
| `personal` | PV-RNN with personalized A | 固定为该人的历史重新校准值 | 局部 ER |
| `zero` | a_i=0 reference | 固定为零 | 局部 ER |
| `local10` | Fully adaptive A | 作为局部量一起更新 | 局部 ER |

三者使用同一网络、scaler、观测、初始状态、窗口和预算。zero 仍有八维 ER，**不是主分析的 No-ER**。

`online_inference.py` 每步只使用当前和过去最多 10 个保留分钟，100 次 Adam 更新、lr=0.05、按条件独立裁剪 5；包含零更新初始候选，选择最低目标迭代。缺口使用 prior transitions；未来观测不回写已发出的过去输出。

| 设置 | ER 目标 | 生理误差的含义 |
|---|---|---|
| `E_only` → E-only | 当前环境两通道 | 当前生理未作为输入，评价其生成输出 |
| `EP_online` → E+P | 当前环境和生理五通道 | 生理参与推断，评价重建；不是未来生理预测 |

报告只在完整目标 session 最终保留分钟评价一次。Figure 7 的逐分钟 B 曲线是同一个末端监督 report head 的状态读出，没有逐分钟报告真值。

### 4.4 两个共同环境情景

`scenarios.py` 创建两个独立 40 分钟序列：稳定情景与前 20 分钟稳定、后 20 分钟五分钟阶梯正弦变化情景。温度和 CO₂ 同相变化；基准、幅度和变化速率由训练环境范围及预设规则确定。

两个情景各自从零状态、零局部 A、空窗口开始，保留同一个个人 A；不是前后连续运行的 80 分钟。分钟索引为 0–39；设计分界 20，首次实际输入变化在 25。

11 条 personal 曲线各使用相同环境，只改变历史 A。zero/local10 公共参照各计算一次，不伪装为 11 个人。模拟无实测 P/B，不计算其模拟准确度。

稳定情景 personal–zero 的差回答输出水平如何改变。环境响应的个人调制用配对差中差：

`[personal(changing) − personal(stable)] − [zero(changing) − zero(stable)]`。

主要响应汇总窗口为 25≤minute<40。不要把 20–40 的辅助窗口当成独立重复，也不要把稳定水平差 2.28 bpm 与约 0.33 bpm 的响应调制混为一谈。

### 4.5 结果汇总

`summaries.py` 先对同一记录/条件/分钟的三 seed **预测取 mean**，再计算误差。生理 pooled RMSE 对实际分钟等权；报告 RMSE 对有报告的七条记录等权。单人、单 seed 和优化诊断另存。不同单位通道不合成一个总误差。

正式保存输出含模拟 24,960 行、真实目标 90,000 行 seed-specific 长表。模型生成和真实 session 收益分别解释，不把 A 的移动幅度当作稳定特质检验。

## 5. 统计与图片的生成链

`reproduce.py statistics` 依次运行：

1. `audit_main_and_scope.py`：主 RMSE、bootstrap、MAE 人数、重建、Figure 6 选择及训练时间范围。
2. `audit_personalization_saved_outputs.py`：全部阶段签名/文件哈希、输入身份、seed 聚合、session 指标、优化轨迹。
3. `audit_personalization_offsets_and_contrasts.py`：训练/校准 A、模拟水平与响应、各 outcome 对照。
4. `check_offset_correspondence.py`：距离参照、逐维相关和最近邻；不运行模型。

Figure 5–6 的数据从当前主运行提取；Figure 7 从 two40 正式 simulation/scenarios 表提取。最新 Figure 7 样式脚本来自 `Figure7_style_matched_20261029.zip`，没有采用旧 v2 的 Class226/246 图。

## 6. 为什么包里还有旧文件

v6 入口顶层 import `individual.py` 和 `chain.py`，并核对五个 parent source 文件。为保留正式源码哈希，未删除这些依赖。`config/epp_v6.json` 的 rho grid 等字段也保留。

当前论文主分析只执行 `--stage behavior --cohorts 11`。`parameters/validation/chain/recovery`、MixedLM、旧 frozen-v3、historical room mapping 属于保留的历史分支，不进入当前结果；不能将其 rho 参数解释为本文 personalized A。

本次没有纳入早期 102-session personalization v2、独立 online-EP extension 或 80 分钟连续模拟。需要追溯时按原历史包读取，不与这份正式工程混跑。
