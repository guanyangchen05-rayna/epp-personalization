"""Redraw Figure 7 from the unchanged, archived three-seed mean outputs."""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FormatStrFormatter

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
plt.rcParams.update({
    'font.family': 'Nimbus Roman', 'font.size': 7.8,
    'axes.labelsize': 7.8, 'xtick.labelsize': 7, 'ytick.labelsize': 7,
    'text.color': '#333A42', 'axes.labelcolor': '#333A42',
    'xtick.color': '#59636E', 'ytick.color': '#59636E',
    'axes.edgecolor': '#AEB7BF', 'axes.linewidth': 0.55,
    'grid.color': '#EDF0F3', 'grid.linewidth': 0.4,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
    'mathtext.fontset': 'stix', 'savefig.facecolor': 'white',
})
traces = pd.read_csv(DATA / 'simulation_trajectories_seed_mean.csv')
scenarios = pd.read_csv(DATA / 'simulation_scenarios.csv')
scenario = 'stable_then_fluctuating'
traces = traces[traces.scenario.eq(scenario)]
env = scenarios[scenarios.scenario.eq(scenario)].sort_values('minute')
pids = sorted(traces.loc[traces.condition.eq('personal'), 'Pid'].unique())
# Figure 3 hues, extended with muted companion colors for eleven profiles.
palette = ['#397DAD', '#277F80', '#4B8D69', '#C36362', '#B1833A',
           '#7760A6', '#C47C3D', '#956298', '#78858F', '#80A7BD', '#A89B5B']
colors = dict(zip(pids, palette))
rows = [
    ('IndoorTemperature', 'Temperature\n(°C)', [20.4, 20.6, 20.8, 21.0], '%.1f'),
    ('IndoorCO2', r'CO$_2$'+'\n(ppm)', [850, 900, 950, 1000], '%d'),
    ('EDA', 'EDA\n(µS)', [0.4, 0.5, 0.6, 0.7, 0.8], '%.1f'),
    ('HR', 'Heart rate\n(bpm)', [80, 85, 90], '%d'),
    ('TEMP', 'Skin temp.\n(°C)', [31, 32], '%d'),
    ('EngageScore', 'Engagement\n(model readout)', [3.0, 3.5, 4.0], '%.1f'),
    ('Arousal', 'Arousal\n(model readout)', [2.0, 2.2, 2.4, 2.6], '%.1f'),
    ('Valence', 'Valence\n(model readout)', [2.75, 3.0, 3.25, 3.5], '%.2f'),
]
fig, axes = plt.subplots(8, 1, figsize=(708.6614 / 72, 10.6), sharex=True)
fig.subplots_adjust(left=0.166, right=0.987, bottom=0.105, top=0.988, hspace=0.18)
line_count = 0
for i, (ax, (var, label, ticks, fmt)) in enumerate(zip(axes, rows)):
    ax.set_facecolor('white')
    ax.axvspan(0, 20, color='#F5F7F8', zorder=0)
    ax.grid(True, axis='both', zorder=0)
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(axis='both', which='both', direction='out', length=2.2,
                   width=0.5, pad=3, color='#9DA7B1')
    ax.tick_params(axis='x', bottom=(i == 7), labelbottom=(i == 7))
    ax.set_ylabel(label, rotation=0, ha='center', va='center', labelpad=0)
    ax.yaxis.set_label_coords(-0.115, 0.5)
    ax.yaxis.set_major_locator(FixedLocator(ticks))
    ax.yaxis.set_major_formatter(FormatStrFormatter(fmt))
    ax.set_xlim(0, 40)
    ax.set_xticks(np.arange(0, 41, 5))
    ax.axvline(20, color='#9DA7B1', linestyle=(0, (1.2, 2.1)), linewidth=0.65, zorder=2)
    ax.axvline(25, color='#C47C3D', linestyle=(0, (4, 3)), linewidth=0.65, zorder=2)
    if i < 2:
        # Inputs are piecewise constant. Extend only their final plateau to x=40.
        x = np.r_[env.minute.to_numpy(), 40]
        y = np.r_[env[var].to_numpy(), env[var].iloc[-1]]
        ax.step(x, y, where='post', color=['#397DAD', '#277F80'][i], linewidth=1.25)
        ax.margins(y=0.08)
    else:
        d = traces[traces.variable.eq(var)]
        for pid in pids:
            v = d[d.condition.eq('personal') & d.Pid.eq(pid)].sort_values('minute')
            assert len(v) == 40
            ax.plot(v.minute, v.prediction, color=colors[pid], linewidth=0.8, alpha=0.94)
            line_count += 1
        for condition, color, style, width in [
            ('zero', '#59636E', (0, (4.3, 2.6)), 1.15),
            ('local10', '#28323B', (0, (6, 2.2, 1.3, 2.2)), 1.15),
        ]:
            v = d[d.condition.eq(condition)].sort_values('minute')
            assert len(v) == 40
            ax.plot(v.minute, v.prediction, color=color, linestyle=style, linewidth=width, zorder=4)
            line_count += 1
        ax.margins(y=0.09)

axes[-1].set_xlabel('Simulated minute', labelpad=5)
for first, last, text in [(0, 1, 'ENVIRONMENT'), (2, 4, 'PHYSIOLOGY'), (5, 7, 'REPORT READOUTS')]:
    y = (axes[first].get_position().y1 + axes[last].get_position().y0) / 2
    fig.text(0.023, y, text, rotation=90, va='center', ha='center',
             fontsize=7.8, fontweight='bold', color='#28323B')

handles = [Line2D([], [], color=colors[pid], lw=1.1, label=f'P{pid}') for pid in pids]
handles += [Line2D([], [], color='#59636E', lw=1.15, linestyle=(0, (4.3, 2.6)),
                   label=r'$\mathbf{a}_i = 0$ reference'),
            Line2D([], [], color='#28323B', lw=1.15, linestyle=(0, (6, 2.2, 1.3, 2.2)),
                   label='Fully adaptive A')]
fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.567, 0.016),
           ncol=7, frameon=False, fontsize=7.5, handlelength=2.5,
           columnspacing=1.75, handletextpad=0.6, labelspacing=0.65)

for ext in ['pdf', 'svg', 'png']:
    fig.savefig(ROOT / f'Figure_7_common_environment_simulation.{ext}', dpi=300)
assert line_count == 78
verification = {
    'scenario': scenario, 'participant_profiles': [int(p) for p in pids],
    'seed_mean': True, 'source_rows_in_scenario': len(traces),
    'unchanged_output_series': line_count, 'output_points': line_count * 40,
    'input_files_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in sorted(DATA.glob('*.csv'))},
    'legend_rename': {'local10': 'Fully adaptive A'},
    'definition': 'All 10 A dimensions are updated locally by ER; shared network weights stay frozen.',
    'removed': ['figure title', 'bottom explanatory note', 'parenthesis after Simulated minute'],
}
(ROOT / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps(verification, indent=2))
