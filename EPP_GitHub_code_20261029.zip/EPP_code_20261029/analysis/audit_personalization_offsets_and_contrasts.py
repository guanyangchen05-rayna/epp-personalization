from pathlib import Path
import io,pickle,zipfile,collections,json,hashlib
import numpy as np
import pandas as pd
import argparse
parser=argparse.ArgumentParser(description='Audit saved personalization results; no model execution.')
parser.add_argument('--run',required=True,type=Path,help='Extracted formal run folder.')
parser.add_argument('--output',required=True,type=Path,help='Folder for audit outputs.')
args=parser.parse_args()
RUN=args.run.resolve()
OUT=args.output.resolve()
OUT.mkdir(parents=True,exist_ok=True)
# Read only the known numeric tensor serialization, with no torch import or executable globals.
def read_tensor_checkpoint(path):
 with zipfile.ZipFile(path) as z:
  prefix=next(n[:-8] for n in z.namelist() if n.endswith('data.pkl'))
  byteorder=z.read(prefix+'byteorder').decode(); dtype=np.dtype('<f4' if byteorder=='little' else '>f4')
  def rebuild(storage,offset,size,stride,requires_grad,hooks,*args):
   if not size:return np.asarray(storage[offset]).reshape(())
   assert all(x>=0 for x in stride)
   last=offset+sum((int(n)-1)*int(s) for n,s in zip(size,stride))
   assert 0<=offset<=last<len(storage)
   return np.lib.stride_tricks.as_strided(storage[offset:],shape=tuple(size),strides=tuple(int(s)*4 for s in stride),writeable=False).copy()
  class Restricted(pickle.Unpickler):
   def find_class(self,module,name):
    known={('collections','OrderedDict'):collections.OrderedDict,('torch._utils','_rebuild_tensor_v2'):rebuild,('torch','FloatStorage'):'FLOAT32',('torch.torch_version','TorchVersion'):str}
    if (module,name) not in known:raise ValueError((module,name))
    return known[(module,name)]
   def persistent_load(self,pid):
    kind,storage_type,key,location,n=pid
    assert kind=='storage' and storage_type=='FLOAT32'
    a=np.frombuffer(z.read(prefix+'data/'+str(key)),dtype=dtype)
    assert len(a)==n
    return a
  return Restricted(io.BytesIO(z.read(prefix+'data.pkl'))).load()
train=pd.read_csv(RUN/'protocol/train_records.csv');cal=pd.read_csv(RUN/'protocol/calibration_records.csv');targets=pd.read_csv(RUN/'protocol/validation_records.csv')
assert set(map(tuple,cal[['Pid','Class_id']].to_numpy()))==set(map(tuple,train.loc[train.Pid.isin(targets.Pid),['Pid','Class_id']].to_numpy()))
pid_counts=cal.groupby('Pid').agg(n_records=('Class_id','size'),n_minutes=('n_minutes','sum')).reset_index()
pid_counts.to_csv(OUT/'calibration_record_counts.csv',index=False)
keys=['Pid','condition','minute','variable']
sim=pd.read_csv(RUN/'simulation/all_trajectories_by_seed.csv')
mean=sim.groupby(keys+['scenario'],as_index=False).prediction.mean()
piv=mean.pivot(index=keys,columns='scenario',values='prediction').reset_index()
piv['response']=piv['stable_then_fluctuating']-piv['stable']
zero=piv[piv.condition.eq('zero')][['minute','variable','response']].rename(columns={'response':'zero_response'})
p=piv[piv.condition.eq('personal')].merge(zero,on=['minute','variable'],validate='many_to_one')
p['D']=p.response-p.zero_response
assert (p[p.minute.lt(25)].D.abs()<1e-12).all()
stablezero=piv[piv.condition.eq('zero')][['minute','variable','stable']].rename(columns={'stable':'stable_zero'})
p=p.merge(stablezero,on=['minute','variable'],validate='many_to_one');p['stable_departure']=p.stable-p.stable_zero
rows=[]
for var,g in p.groupby('variable'):
 if var in ['IndoorTemperature','IndoorCO2']:continue
 q=g[g.minute.ge(25)&g.minute.lt(40)]
 d=q.D.abs().mean();shared=q.zero_response.abs().mean()
 rows.append(dict(variable=var,mean_abs_personal_contrast=d,mean_abs_zero_environment_response=shared,ratio_of_means=d/shared,mean_abs_stable_departure_0_39=g.stable_departure.abs().mean()))
summ=pd.DataFrame(rows);summ.to_csv(OUT/'simulation_effect_sizes.csv',index=False)
# Signed time means, not pointwise sign agreement and not mean absolute effects.
byseed=sim.pivot(index=['seed']+keys,columns='scenario',values='prediction').reset_index()
byseed['response']=byseed.stable_then_fluctuating-byseed.stable
z=byseed[byseed.condition.eq('zero')][['seed','minute','variable','response']].rename(columns={'response':'zero_response'})
b=byseed[byseed.condition.eq('personal')].merge(z,on=['seed','minute','variable'],validate='many_to_one')
b['D']=b.response-b.zero_response
signed=b[b.minute.ge(25)&b.minute.lt(40)].groupby(['variable','Pid','seed']).D.mean().unstack('seed')
assert signed.shape==(88,3)
signed['same_sign_all_three']=(signed[[11,23,37]].gt(1e-10).all(axis=1)|signed[[11,23,37]].lt(-1e-10).all(axis=1))
signed.reset_index().to_csv(OUT/'time_mean_D_sign_by_seed.csv',index=False)
agreement=signed.groupby('variable').same_sign_all_three.sum().to_dict()
# Stable absolute departure and shared response by seed for source data transparency.
b=b.merge(byseed[byseed.condition.eq('zero')][['seed','minute','variable','stable']].rename(columns={'stable':'stable_zero'}),on=['seed','minute','variable'])
b['stable_departure']=b.stable-b.stable_zero
b.to_csv(OUT/'simulation_contrasts_by_seed.csv',index=False)
# Recompute P participant RMSE from seed-mean trajectories; do not average seed metrics.
v=pd.read_csv(RUN/'validation/all_trajectories_by_seed.csv')
print('validation columns',v.columns.tolist())
gcols=['Pid','Class_id','mode','condition','minute','variable']
vm=v.groupby(gcols,as_index=False).agg(prediction=('prediction','mean'),observed=('observed','first'))
ph=vm[vm.variable.isin(['EDA','HR','TEMP'])].copy();ph['sqerr']=(ph.prediction-ph.observed)**2
pp=ph.groupby(['Pid','mode','condition','variable']).sqerr.mean().pow(.5).rename('RMSE').reset_index()
pp.to_csv(OUT/'physiology_RMSE_by_participant.csv',index=False)
wide=pp.pivot(index=['Pid','mode','variable'],columns='condition',values='RMSE').reset_index()
assert len(wide)==66
count=[]
for (mode,var),g in wide.groupby(['mode','variable']):
 count.append(dict(mode=mode,variable=var,personal_worse_zero=int((g.personal>g.zero).sum()),personal_better_zero=int((g.personal<g.zero).sum()),personal_worse_local10=int((g.personal>g.local10).sum()),n_people=len(g)))
counts=pd.DataFrame(count);counts.to_csv(OUT/'physiology_participant_direction_counts.csv',index=False)
# Compare training offsets with the frozen-network recalibrations only within the same seed.
comparisons=[]
training22=[]
for seed in [11,23,37]:
 ck=read_tensor_checkpoint(RUN/f'models/seed{seed}.pt')
 h=hashlib.sha256()
 for name,tensor in sorted(ck['state_dict'].items()):
  h.update(name.encode());h.update(tensor.tobytes())
 expected_network_hash=pd.read_csv(RUN/f'profiles/personal_A_seed{seed}.csv').network_sha.unique().tolist()
 assert expected_network_hash==[h.hexdigest()]
 assert set(map(lambda x:(x['Pid'],x['Class_id']),ck['training_keys']))==set(map(tuple,train[['Pid','Class_id']].to_numpy()))
 ids=ck['training_person_ids'];a=ck['centered_training_personal_A'];assert a.shape==(22,2)
 assert np.abs(a.mean(0)).max()<1e-7
 for pid,value in zip(ids,a):
  training22.append(dict(seed=seed,Pid=int(pid),training_A0=float(value[0]),training_A1=float(value[1])))
 cp=pd.read_csv(RUN/f'profiles/personal_A_seed{seed}.csv')
 for r in cp.itertuples(index=False):
  t=a[ids.index(int(r.Pid))].astype(float);c=np.array([r.A_slow_0,r.A_slow_1])
  comparisons.append(dict(seed=seed,Pid=int(r.Pid),train_A0=t[0],train_A1=t[1],cal_A0=c[0],cal_A1=c[1],euclidean_distance=float(np.linalg.norm(c-t)),training_norm=float(np.linalg.norm(t)),calibrated_norm=float(np.linalg.norm(c))))
pd.DataFrame(training22).to_csv(OUT/'training_offsets_22_participants.csv',index=False)
comp=pd.DataFrame(comparisons);comp.to_csv(OUT/'training_vs_recalibrated_A.csv',index=False)
comp_summary=comp.groupby('seed').agg(mean_distance=('euclidean_distance','mean'),median_distance=('euclidean_distance','median'),max_distance=('euclidean_distance','max'),mean_training_norm=('training_norm','mean'),mean_calibrated_norm=('calibrated_norm','mean'))
comp_summary.to_csv(OUT/'training_vs_recalibrated_A_summary.csv')
# All report-level directions in the two observation settings, not only a favorable case.
rp=pd.read_csv(RUN/'validation/report_endpoint_estimates.csv')
print('report endpoint columns',rp.columns.tolist())
info=dict(all_34_calibration_records_equal_target_participants_training_records=True,target_selection_counts=targets.selection_reason.value_counts().to_dict(),fallback_people=targets.loc[~targets.has_report,'Pid'].tolist(),fallback_labeled_training_records=train.loc[train.Pid.isin(targets.loc[~targets.has_report,'Pid'])&train.has_report,['Pid','Class_id']].to_dict('records'),mean_calibration_records=float(pid_counts.n_records.mean()),range_calibration_records=[int(pid_counts.n_records.min()),int(pid_counts.n_records.max())],time_mean_D_sign_agreement_primary_window=agreement,calibration_vs_training=comp_summary.to_dict('index'))
(OUT/'audit_summary.json').write_text(json.dumps(info,indent=2))
print('\nSIMULATION EFFECTS\n',summ.to_string(index=False))
print('\nP COUNTS\n',counts.to_string(index=False))
print('\nINFO\n',json.dumps(info,indent=2))

# Report direction counts and differences between the two simulation references.
rp=rp[rp.scored.astype(bool)]
w=rp.pivot(index=['Pid','mode','variable'],columns='condition',values='absolute_error').reset_index()
rows=[]
for (mode,var),g in w.groupby(['mode','variable']):
 rows.append(dict(mode=mode,variable=var,personal_better_zero=int((g.personal<g.zero).sum()),personal_worse_zero=int((g.personal>g.zero).sum()),personal_better_local10=int((g.personal<g.local10).sum()),n_people=len(g)))
pd.DataFrame(rows).to_csv(OUT/'report_participant_direction_counts.csv',index=False)
s=pd.read_csv(RUN/'simulation/trajectories_seed_mean.csv')
w=s[s.condition.isin(['local10','zero'])].pivot(index=['scenario','minute','variable'],columns='condition',values='prediction').reset_index()
w['abs_difference']=(w.local10-w.zero).abs()
w.groupby(['scenario','variable']).abs_difference.agg(['mean','max']).to_csv(OUT/'fully_adaptive_vs_zero_simulation.csv')
