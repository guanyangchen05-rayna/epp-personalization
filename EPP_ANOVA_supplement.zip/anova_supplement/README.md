# Supplementary ANOVA for the RQ1 model comparison

[中文说明](README_zh.md)

This folder reproduces the exploratory repeated-measures ANOVAs added to the
Methods and Results for RQ1. It is a standalone supplement to the main EPP/PV-RNN
analysis. It uses frozen out-of-fold predictions and does not train models,
change predictions, or replace the primary RMSE analysis.

Place this folder anywhere in the existing repository, for example at
`supplementary/anova/`. No changes to the main package or its imports are needed.

## Run

Python 3.10 or later is required. From this folder:

```bash
python -m pip install -r requirements.txt
python run_anova.py
```

The calculation takes about a second after dependencies are installed. CPU only;
PyTorch, model checkpoints, and raw sensor data are not required. Paths are
resolved relative to the script, so the script can also be invoked from another
working directory.

Outputs are written to `results_rerun/`, leaving the checked-in `results/`
unchanged. To choose another destination:

```bash
python run_anova.py --output ./my_results
```

## Analysis represented in the manuscript

1. Use Participant-LOO predictions for the RNN, PV-RNN without ER, and PV-RNN.
2. For each session, outcome, and model, take the median prediction across seeds
   11, 23, 37, 51, and 71. Calculate squared error after taking this median.
3. Average session squared errors within each participant. Each outcome then has
   an 11-participant by 3-model MSE matrix.
4. Run a separate one-way repeated-measures ANOVA for engagement, arousal, and
   valence, with model as the within-participant factor.
5. Apply Greenhouse–Geisser correction to all three tests, and then Holm
   correction across the three corrected p values. The threshold is 0.05.

| Outcome | F | GG epsilon | GG-corrected p | GG + Holm p |
| --- | ---: | ---: | ---: | ---: |
| Engagement | 1.929 | 0.598 | 0.191 | 0.383 |
| Arousal | 0.218 | 0.868 | 0.776 | 0.776 |
| Valence | 2.507 | 0.840 | 0.118 | 0.354 |

`results/rm_anova_GG.csv` also contains corrected degrees of freedom, sums of
squares, uncorrected p values, and partial eta squared. Partial eta squared uses
the uncorrected ANOVA sums of squares; GG changes degrees of freedom, not F or
the sums of squares.

None of the three omnibus tests reaches 0.05. Nonsignificance does not establish
equivalence. Participants are equally weighted here, whereas the primary pooled
RMSE weights sessions equally. This exploratory test does not fully account for
dependence due to overlapping cross-validation training sets or shared classroom
contexts. GG correction addresses sphericity; it does not remove those
dependencies or address all distributional concerns in this small sample.

No Date-LOO ANOVA, training-mean condition, pairwise tests, bootstrap rerun, or
personalization analysis is included. Those are separate from the supplementary
omnibus tests reported in the manuscript.

## Files

| Path | Purpose |
| --- | --- |
| `run_anova.py` | Input validation, seed aggregation, participant MSE, GG ANOVA, and Holm correction |
| `requirements.txt` | NumPy, pandas, and SciPy dependencies |
| `data/participant_loo_predictions.csv` | 720 existing prediction rows used by these tests |
| `results/` | Checked-in reproducible analysis outputs |
| `validation/independent_software_check.json` | Earlier independent checks against Statsmodels 0.14.6 and Pingouin 0.5.5 |
| `PROVENANCE.json` | Source run, extraction rule, hashes, and verification scope |
| `MANIFEST.sha256` | SHA-256 checksums for packaged files |

The input retains the original CSV column names. `Pid` identifies a participant,
`Class_id` a class window, and `EnvironmentDateKey` a recording date. A session is
a participant's recording within a class window. `target` uses `EngageScore`,
`Arousal`, and `Valence`. Stored method IDs map as follows:

| Stored `mode` | Manuscript name |
| --- | --- |
| `SIMPLE_RNN` | RNN |
| `NO_ER` | PV-RNN without ER |
| `ERROR_REGRESSION` | PV-RNN |

`observed` and `prediction` use the native report scales. Five seeds are repeated
fits to the same data, not five independent participant samples. The bundled
input contains derived report labels and predictions from the existing analysis;
it does not contain raw environmental or physiological time series. Source data:
In-Gauge and En-Gage, calendar-dated version 2,
<https://doi.org/10.25439/rmt.14578908.v2>.

The numerical ANOVA and Holm functions are unchanged from the previously
verified script `run_anova_review.py`. The input selection, CLI, and outputs are
narrowed to the manuscript's supplementary ANOVA. Reproduction was checked with
Python 3.12, NumPy 2.3.5, pandas 2.2.3, and SciPy 1.17.0. The independent software
record is a historical validation of the same computations; Statsmodels and
Pingouin are not runtime dependencies. No new software or data license is assigned
by this folder; it can accompany the parent repository's applicable licensing.
