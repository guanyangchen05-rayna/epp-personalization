# RQ1 补充 ANOVA

这是加入论文 Methods 和 Results 的探索性重复测量 ANOVA 的独立复现文件夹。
它读取已经保存的预测结果，不重新训练模型，也不替换主体 RMSE 分析。

## 上传 GitHub

将整个文件夹放入现有仓库，例如 `supplementary/anova/`。
保留内部相对目录即可，无需更改主体项目配置。

## 运行

需要 Python 3.10 或更新版本。在本文件夹中运行：

```bash
python -m pip install -r requirements.txt
python run_anova.py
```

安装依赖后，统计计算约 1 秒。无需 GPU、PyTorch、模型权重或原始传感器数据。
结果保存在 `results_rerun/`；已核验结果保存在 `results/`，默认不会被覆盖。
也可以使用 `--output 路径` 指定输出位置。

## 与论文对应的计算

1. 仅使用 Participant-LOO 下 RNN、PV-RNN without ER 和 PV-RNN 的预测。
2. 每个 session、指标和模型，先取五个 seed 的预测中位数，再计算平方误差。
3. 对同一参与者的 session 平方误差取平均，得到每个指标的 11 人 × 3 模型 MSE 表。
4. 对 engagement、arousal、valence 分别进行单因素重复测量 ANOVA，模型为被试内因素。
5. 三个检验都使用 Greenhouse–Geisser（GG）校正，再对三个 GG 校正后的 p 值做 Holm 校正。

| 指标 | F | GG 校正后的 p | 再经 Holm 校正后的 p |
| --- | ---: | ---: | ---: |
| Engagement | 1.929 | 0.191 | 0.383 |
| Arousal | 0.218 | 0.776 | 0.776 |
| Valence | 2.507 | 0.118 | 0.354 |

三项总体检验均未达到 0.05，但这不证明三个模型等效。本分析让参与者等权，
主体 pooled RMSE 让 session 等权。它处理了同一人的模型配对和 session 汇总，
没有完整处理 LOO 训练集重叠及共享课堂情境产生的依赖。
GG 校正不解决这些依赖，也不消除小样本下所有分布假设方面的问题。

## 包含范围

- 可独立运行的脚本和依赖清单。
- 720 行必要输入：16 sessions × 3 指标 × 3 模型 × 5 seeds。
- session 中位数预测、参与者 MSE、ANOVA 结果和运行审计记录。
- 原分析独立核验记录、来源说明及校验和。

只提取论文已经采用的补充总体 ANOVA。Date-LOO、配对 t 检验、bootstrap 重算、
personalization、meeting 转写和主体训练代码均未并入本文件夹。

输入保留旧代码字段：`SIMPLE_RNN` 对应 RNN，`NO_ER` 对应 PV-RNN without ER，
`ERROR_REGRESSION` 对应 PV-RNN。`EngageScore` 对应 engagement。
五个 seed 是同一数据上的重复模型拟合，不作为五批独立参与者。

统计函数沿用已经核验的 `run_anova_review.py`，仅缩小输入和输出范围。
`validation/independent_software_check.json` 是此前与 Statsmodels / Pingouin
交叉核验的记录，不代表本文件夹会重新安装或调用它们。
完整字段、输出与来源说明见 [README.md](README.md)。
